"""Direct realistic-vs-realistic ring comparison at the SAME true track:
PhotonSim photons vs SIREN-emitted photons, both sampled through make_hits (realistic).
Compares sensor multiplicity, participation ratio (Sq)^2/Sq^2, and the ring radial-width profile.
A broader real ring (more sensors, larger rho-width) at equal total charge => SIREN emission too sharp.
Usage: CUDA_VISIBLE_DEVICES=g python ring_compare.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=4, suppress=True)

Sp = PS.setup(event=0, nphot=80_000, truth_source='photonsim')
Ss = PS.setup(event=0, nphot=80_000, truth_source='siren')
ocp = np.array(Sp['oc']); ocs = np.array(Ss['oc'])
theta = np.array(Sp['theta_star'])
dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
sp = np.array(dg.sensor_points); vtx = theta[1:4]
pol, az = float(theta[4]), float(theta[5])
d = np.array([np.sin(pol)*np.cos(az), np.sin(pol)*np.sin(az), np.cos(pol)])
rel = sp - vtx; s = rel @ d; rho = np.linalg.norm(rel - np.outer(s, d), axis=1)

def stats(oc, tag):
    hit = oc > 0
    pr = oc.sum()**2 / (np.sum(oc**2) + 1e-12)
    print(f"[{tag}] sensors_hit={int(hit.sum())}  total_q={oc.sum():.0f}  "
          f"mean_q/hit={oc[hit].mean():.2f}  max_q={oc.max():.1f}  participation_ratio={pr:.0f}")
    return hit

print("=== realistic truth at the SAME track ===")
hp = stats(ocp, 'PhotonSim'); hs = stats(ocs, 'SIREN    ')

# ring band = sensors in the dominant longitudinal peak; compare rho distribution there
band = (s > 10) & (s < 22)
def rho_profile(oc, tag):
    m = band & (oc > 0)
    w = oc[m]; r = rho[m]
    rc = float((w*r).sum()/w.sum()); rw = float(np.sqrt((w*(r-rc)**2).sum()/w.sum()))
    print(f"  [{tag}] ring band: nsens={int(m.sum())} <rho>={rc:.3f} m  rho_width(std)={rw:.3f} m")
    edges = np.linspace(8, 18, 11); mid = 0.5*(edges[:-1]+edges[1:])
    prof = np.array([w[(r>=edges[i])&(r<edges[i+1])].sum() for i in range(10)])
    return mid, prof
print("=== ring radial width (longitudinal band 10<s<22 m) ===")
mp, pp = rho_profile(ocp, 'PhotonSim')
ms, ps = rho_profile(ocs, 'SIREN    ')
print("  rho_mid:  " + " ".join(f"{m:6.2f}" for m in mp))
print("  PhotonSim:" + " ".join(f"{v:6.0f}" for v in pp))
print("  SIREN:    " + " ".join(f"{v:6.0f}" for v in ps))
np.savez('/tmp/ring_compare.npz', ocp=ocp, ocs=ocs, s=s, rho=rho, mp=mp, pp=pp, ps=ps)
