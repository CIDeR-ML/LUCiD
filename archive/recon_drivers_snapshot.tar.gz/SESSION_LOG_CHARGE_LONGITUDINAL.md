# Session log — charge term / longitudinal vertex investigation

**Status: STOP & RESTART.** This log records everything done in this session so we can start over with a
clean, assumption-free picture. The central unresolved tension (see §6) is: I measured a ~15–20cm per-event
longitudinal vertex resolution and attributed it to "model mismatch", but the user states the SIREN is a
**good match per event** (limited only by stochasticity) and that **prior work obtained much better fits**.
That contradiction is unresolved. Several of my conclusions rest on assumptions that turned out wrong
(§5) — treat all numbers below as provisional.

Units: meters, ns, MeV. Detector: SK geometry, 1050 MeV muon, TTS=2.5 ns. Target track: vertex (0,0,0),
polar 0.6, azim 0.8, t0 0. Truth = PhotonSim photons (one GEANT4 event each) rotated/shifted onto the target
track via `recon_ps_setup.setup` (or the inlined copy in the multi-event scripts). Targets: vtx<15cm,
dir<2°, t0<1ns, E<20%.

---

## 1. Starting point (from prior sessions, pre-this-session)
- Best end-to-end was `endtoend6.py`: vtx ~56cm, dir 1.52°, t0 0.87ns, E 14% (3/4 targets; vertex the holdout).
- Longitudinal vertex was the bottleneck; believed to be a charge-centroid (`lCEN`) floor + t0 degeneracy.
- The loss used `lE` (total charge) + `lCEN` (charge centroid·d) + `lT_gd` (count-decoupled first-arrival timing).

## 2. Scripts created this session (all in /sdf/group/neutrino/omara/LUCiD_recon/)
| script | purpose | headline result |
|---|---|---|
| `charge_crb.py` | analytic Poisson Fisher (CRB) by charge OBSERVABLE (total / centroid / full per-PMT). FD-CRN Jacobian of predictor mean charge + wavefront time Fisher | centroid carries ~970× LESS longitudinal info than full per-PMT; full-Poisson charge-only longitudinal **CRB 1.2cm** (flat vs MUFLOOR); combination (charge+time) CRB lon 1.2/trans 1.1/dir 0.03/t0 0.05/E 0.2 |
| `charge_forms.py` | profile likelihood of charge loss FORMS (Poisson/√-MSE/Anscombe/logMSE/shape) along longitudinal, both truths | single-event: √-MSE looked great (+1.5cm bias) — **later shown to be event-0 luck** |
| `charge_bias_events.py` | multi-event (20) charge longitudinal+transverse bias/scatter per form + charge thresholds | Poisson lon **bias +9.9 scatter 11.7 RMS 15.3**; √-MSE WORSE (RMS 35); Shape==Poisson; transverse from charge POOR (scatter ~72cm); Q>2 threshold worse |
| `term_crb.py` | systematic per-TERM CRB vs hyperparameters (THR, temperature, σ) | charge THR=0 best (every threshold hurts); temperature 0.05→0.2 minor (lon 1.1→1.4); timing alone DEGENERATE(5/7); combination ceiling lon 1.2/trans 1.1/t0 0.05 |
| `timing_bias_events.py` | timing term multi-event (20) numerical: transverse/dir/t0 vs (σ,THR) | transverse **THR≈4 σ1.5 → 5.4cm** (THR=0→21cm, THR=10→21cm); dir best THR=0→2.0° (charge does dir better ~0.5°); t0 THR=0 σ1.5 → scatter 0.12ns + **bias +0.64ns** (order-statistic, grows with σ/THR) |
| `combo_profile.py` | combination check: loss on the degenerate (lon,t0) plane, charge vs timing vs combined, WC scan | raw timing NLL span 13471 vs charge 502 (27×); timing valley mismatch-tilted to lon −71; **degeneracy breaks when charge up-weighted WC≈5–30**; plateau WC15–30 → lon −14±16, t0 +0.15±0.59 (t0 bias collapses −1.75→+0.15) |
| `endtoend_glike.py` | generalized time-charge likelihood REFINER (Poisson charge + decoupled timing), several variants | truth=siren staged/joint/projected: best vtx 11.2 (NKG5,NPHOT150k) to 15.6cm; **PhotonSim (5 events×3 keys): scattered vtx 2–59cm, mean ~21** |
| `lon_improve.py` | try to BEAT the longitudinal floor: robust losses (trim/Cauchy), bias calibration, observable correlation | Poisson lon bias +10 scatter 20.1 RMS 22.5; TRIM10/20 WORSE (35/51); Cauchy ≈ Poisson; bias split-half +4.8 vs +14.8 (unstable); corr(err,totalQ)=0.00 — **all fail** |
| `geom_lon.py` | model-independent geometric Cherenkov-ring-edge longitudinal estimator | **FAILS** — angular edge never matches θ_c (scattered/late light pollutes the edge); returned grid edge |
| `test_overlap.py` | HARD (temp=None, matches truth) vs SOFT (temp=0.1/0.05) overlap predictor for longitudinal | HARD bias +8.2 scatter 12.2 **RMS 14.7**; SOFT0.10 RMS 17.2 — **marginal, NOT the big regression I hypothesized** |

## 3. Memory files written/updated this session
- NEW `recon-charge-observable-crb.md` — centroid vs full-Poisson; CRB; multi-event; failed improvement attempts.
- NEW `recon-term-hyperparameter-crb.md` — per-term hyperparameter scan + combination.
- Updated `MEMORY.md` index with both.
- (These memories ALSO contain my possibly-wrong "model mismatch" framing — revisit on restart.)

## 4. What I believe is SOLID (low-assumption findings)
- **Observable matters**: full per-PMT Poisson charge carries ~970× more longitudinal Fisher info than the
  charge centroid (`lCEN`). The old `lE+lCEN` discarded almost all longitudinal info. (CRB, analytic.)
- **Charge longitudinal is a SHAPE measurement**: Poisson and scale-invariant Shape give byte-identical
  longitudinal argmins → energy normalization carries zero longitudinal info.
- **Timing first-arrival is longitudinally degenerate** (lon↔t0 exact null in the wavefront) and its valley
  is mismatch-tilted; it does NOT independently localize longitudinal.
- **Per-term roles**: charge→longitudinal+E+direction; timing→transverse(THR≈4)+t0(THR=0). Timing transverse
  has a THR robustness optimum (≈4) that the CRB cannot see.
- **Combination**: charge must be up-weighted (~15–30×) over the count-inflated raw timing term to break the
  degeneracy; doing so also removes the timing t0 bias.

## 5. ASSUMPTIONS I MADE THAT WERE WRONG (the user flagged this pattern repeatedly)
- **A1 (corrected by user):** interpreted "assume the SIREN is good" as "use SIREN as truth (self-consistent)".
  WRONG — it meant "assume the SIREN forward model is adequate; still evaluate on PhotonSim truth."
- **A2 (disproven):** "variance-stabilized (√-MSE) reduces the bias" — true for event 0 only; over 20 events
  it is WORSE than plain Poisson. Single-event conclusions are unreliable.
- **A3 (disproven):** "the soft-overlap predictor (temp=0.1) vs hard truth is the regression" — `test_overlap.py`
  shows HARD 14.7 vs SOFT 17.2cm: marginal, NOT the explanation for a "much better prior fit".
- **A4 (DISPUTED by user — the big one):** I attributed the ~15–20cm longitudinal floor to "SIREN↔PhotonSim
  ring-shape MODEL MISMATCH (coherent, irreducible)". The user states the **SIREN is a good per-event match**
  and the limit is **stochasticity**, and that **prior fits were much better**. So my "model-mismatch" framing
  is likely WRONG or at least not the whole story.
- **A5 (unvalidated):** assumed the per-event argmin scatter from a 1D PROFILE (other params fixed at truth)
  equals the achievable resolution. Never validated against an actual joint fit or the prior method.
- **A6 (unstable measurement):** the "scatter" itself varied a lot run-to-run (11.7 / 12.2 / 17.0 / 20.1cm)
  depending on event count, NPHOT, predictor settings, grid. The measurement is not stable — I quoted point
  values as if they were.

## 6. THE CENTRAL UNRESOLVED QUESTION (start here on restart)
**Why is my ~15–20cm per-event longitudinal worse than the prior "much better fit"?** The user asserts the
SIREN matches each event well; if so the per-event charge ≈ SIREN mean and the longitudinal argmin should
barely scatter (≈ the 1.2cm CRB), NOT 15–20cm. Either (a) my measurement/method inflates it, or (b) the
SIREN does not match as well as believed. Hypotheses NOT yet tested:
- **H1:** prior used a JOINT charge+time fit (TWOFIT, factored loss), not 1D per-axis profiles — cross-info.
- **H2:** prior used grid-search + **cubic overlap + IMPORTANCE sampling** (memory `recon-resolution-recipe-solved`:
  PhotonSim vtx 7.8cm with K8+mc16+cubic+IMPORTANCE). I used NONE of these.
- **H3:** prior may have quoted fit PRECISION (per-event loss curvature) rather than event-to-event SCATTER —
  different quantities; need to be explicit which one the target refers to.
- **H4:** the prior 7.8cm is flagged in memory as a NOISE-FREE-clock + near-truth-start ARTIFACT — maybe it
  was never truly that good; need to confirm what the honest prior number actually was.
- **H5:** my truth construction (rotate/shift PhotonSim onto target track), NKT averaging, parabola argmin,
  or event selection inflates the scatter. NOT audited.
- **H6:** how well does the SIREN mean μ_i actually match a single PhotonSim event's charge Q_i? Never
  measured directly (the residual map). This would settle (a) vs (b) immediately.

## 7. Current best numbers (provisional, PhotonSim truth)
- longitudinal vtx ~15–20cm (UNSTABLE estimate); transverse ~5.4cm (timing THR≈4); dir ~0.5° (charge);
  t0 ~0.6ns (timing, bias removed by combination); E ~10%. Joint refiner on PhotonSim was much worse/scattered
  (vtx 2–59cm) than the per-axis profiles — the joint optimizer does not reach the per-axis optima.

## 8. What the RESTART should do (no assumptions)
1. **First, audit the measurement** (H6): directly compare SIREN mean μ_i to single-event PhotonSim Q_i —
   quantify the actual per-event match. This decides whether 15–20cm is real or a method artifact.
2. **Pin down the prior result** (H2/H3/H4): find the prior scripts/numbers, what method + settings (cubic
   overlap? importance? grid vs gradient? joint vs profile?), and whether it was scatter or precision.
3. **Reproduce the prior method exactly** before changing anything, to establish the real baseline.
4. Only then iterate — and validate every claim on ≥20 events, never a single event.
