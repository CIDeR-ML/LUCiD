"""Coverage check: is the SIREN realistic sensor count (836) limited by the number of RAYS (so paying for
more unit-weight rays in the TRUTH realization climbs toward PhotonSim's 2271), or saturated by something
deeper (grid)? Scan nphot for SIREN realistic and PhotonSim realistic; report sensors hit, total PE,
participation. With the weight fix the rays are already ~uniform-weight, so this isolates ray-COUNT vs the
weighting. Usage: CUDA_VISIBLE_DEVICES=g python coverage_scan.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True)

def stats(oc):
    oc=np.array(oc); hit=oc>0
    pr=oc.sum()**2/(np.sum(oc**2)+1e-12)
    return int(hit.sum()), float(oc.sum()), float(pr)

print(f"{'nphot':>8} | {'SIREN sens':>10} {'SIR PE':>8} {'SIR part':>9} | {'PS sens':>8} {'PS PE':>7} {'PS part':>8}")
for N in [80_000, 200_000, 500_000, 1_000_000]:
    Ss=PS.setup(event=0,nphot=N,truth_source='siren')
    Sp=PS.setup(event=0,nphot=N,truth_source='photonsim')
    sh_s,pe_s,pr_s=stats(Ss['oc']); sh_p,pe_p,pr_p=stats(Sp['oc'])
    print(f"{N:>8} | {sh_s:>10} {pe_s:>8.0f} {pr_s:>9.0f} | {sh_p:>8} {pe_p:>7.0f} {pr_p:>8.0f}", flush=True)
print("(PhotonSim has 355921 real photons -> saturates; SIREN can emit any count.)")
print("If SIREN sensors-hit climbs toward ~2271 with N, coverage is ray-limited (more rays for TRUTH = fix).")
