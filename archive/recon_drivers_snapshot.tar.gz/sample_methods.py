"""Compare SIREN emission-sampling methods on CORRECTNESS (energy gradient vs exact)
and EFFICIENCY (compile + run wall-clock, gradient variance).

Ground truth = grid-exact expectation  O(E) = sum_grid p(x|E) g(x) / sum_grid p(x|E),
fully differentiable in E (no sampling). Each sampler estimates O(E) with Nphot draws;
its key-averaged AD gradient must match the exact dO/dE.

Methods:
  A  current-style: sample bins ~ p(E) with the SELECTION detached (argsort/categorical,
     geometry sg) -> energy enters only via the per-photon weight. (BIASED energy grad)
  C  DiCE score (REINFORCE): sample ~ p(E) detached, multiply by exp(logp - sg logp).
     Unbiased, higher variance, ~free overhead.
  B  reparameterized inverse-CDF: g sampled via interp(u, cdf(E), g_grid). Pathwise,
     unbiased, low variance; overhead = cumsum + interp.
  E  fixed-proposal importance sampling: sample geometry ~ p(E_ref) (FIXED), reweight by
     p(E)/p(E_ref). Pathwise through the weight, low variance, low overhead; proposal must
     be refreshed if E drifts.
"""
import os, time, jax, jax.numpy as jnp, numpy as np
from functools import partial
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
from lucid.sources.siren_rays import normalize_inputs_jit, denormalize_log_predictions
from lucid.siren.core import SIREN
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=4, suppress=True)

pp = unpack_photonsim_params('muon', 'water')
predictor = SIRENPredictor(pp['siren_model_path'])
td = create_photonsim_siren_grid(predictor)
mparams = predictor.params
(n_bins, e_min, e_max, a_min, a_max, d_min, d_max, a_bins, d_bins,
 angle_dist_grid, angle_mesh, distance_mesh, log_min, log_max) = td
ADG = jnp.asarray(angle_dist_grid)          # (n_grid, 2): (angle, dist[mm])
n_grid = ADG.shape[0]
ang_grid = ADG[:, 0]; dist_grid = ADG[:, 1]
_model = SIREN(hidden_features=256, hidden_layers=3, out_features=1)

@jax.jit
def density_grid(E):
    grid = jnp.stack([jnp.full((n_grid,), E), ang_grid, dist_grid], axis=1)
    ng = normalize_inputs_jit(grid, e_min, e_max, a_min, a_max, d_min, d_max)
    w, _ = _model.apply(mparams, ng)
    dens = denormalize_log_predictions(jnp.squeeze(w), log_max, log_min)
    return jnp.clip(dens, 1e-12, None)

# observable proxy: absorption-weighted profile (sensitive to the longitudinal geometry)
L_ABS_MM = 4000.0
g_grid = jnp.exp(-dist_grid / L_ABS_MM)

E0 = jnp.array(1050.0); NPHOT = 20000

def O_exact(E):
    d = density_grid(E)
    return jnp.sum(d * g_grid) / jnp.sum(d)
truthO = float(O_exact(E0)); truthG = float(jax.grad(O_exact)(E0))
print(f"n_grid={n_grid}  Nphot={NPHOT}  E0={float(E0)}", flush=True)
print(f"GROUND TRUTH:  O={truthO:.6f}   dO/dE={truthG:.6e}\n", flush=True)

sg = jax.lax.stop_gradient
E_REF = jnp.array(1050.0)

@jax.jit
def method_A(E, key):
    d = density_grid(E); p = sg(d) / jnp.sum(sg(d))
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=p)        # detached selection
    w = d[idx]                                                  # weight carries grad; geometry detached
    return jnp.sum(w * g_grid[idx]) / jnp.sum(w)

@jax.jit
def method_C(E, key):
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))   # DiCE box
    return jnp.mean(g_grid[idx] * score)

@jax.jit
def method_B(E, key):
    d = density_grid(E); cdf = jnp.cumsum(d) / jnp.sum(d)
    u = jax.random.uniform(key, (NPHOT,))
    g_s = jnp.interp(u, cdf, g_grid)                            # reparam inverse-CDF (pathwise)
    return jnp.mean(g_s)

@jax.jit
def method_E(E, key):
    dref = sg(density_grid(E_REF)); pref = dref / jnp.sum(dref)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=pref)      # fixed proposal
    dE = density_grid(E)
    w = dE[idx] / dref[idx]                                     # importance weight carries grad
    return jnp.sum(w * g_grid[idx]) / jnp.sum(w)

NK = 64
keys = jax.random.split(jax.random.PRNGKey(0), NK)
print(f"{'method':>8} {'O (mean)':>12} {'dO/dE (mean)':>14} {'grad/truth':>11} {'grad std':>11} {'compile s':>10} {'run ms':>8}", flush=True)
for name, fn in [('A current', method_A), ('C DiCE', method_C), ('B reparamCDF', method_B), ('E fixedprop', method_E)]:
    gfn = jax.jit(jax.grad(fn))
    # compile timing
    t0 = time.time(); _ = float(fn(E0, keys[0])); _ = float(gfn(E0, keys[0])); tc = time.time() - t0
    # run timing (avg over keys)
    t0 = time.time()
    Os = np.array([float(fn(E0, k)) for k in keys])
    Gs = np.array([float(gfn(E0, k)) for k in keys])
    tr = (time.time() - t0) / (2 * NK) * 1000
    rel = Gs.mean() / (truthG + 1e-30)
    print(f"{name:>8} {Os.mean():>12.6f} {Gs.mean():>14.4e} {rel:>10.2f}x {Gs.std():>11.4e} {tc:>10.2f} {tr:>8.2f}", flush=True)
