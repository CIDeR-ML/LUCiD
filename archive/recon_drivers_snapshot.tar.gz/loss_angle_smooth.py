"""ANGLE kink source — is polar/azim forward non-smoothness from overlap discreteness?
The angle profile is KINKY in the forward loss (sg-independent). Test whether more overlap smoothing
(temperature) or more cells (MAXCELL) smooths the forward polar/azim profile. Reports multi-scale profile
slopes (consistent = smooth). Env: TEMP MAXCELL NPHOT NKEYS RECON_K.
Usage: CUDA_VISIBLE_DEVICES=g TEMP=0.3 MAXCELL=16 python loss_angle_smooth.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '48'))
K = int(os.environ.get('RECON_K', '8')); TEMP = float(os.environ.get('TEMP', '0.1')); MC = int(os.environ.get('MAXCELL', '8'))
PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0, 0, 0.0175, 0, 0.5])
theta0 = theta_true + delta; keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
os.environ['MAXCELL'] = str(MC)
print(f"# ANGLE smoothness  TEMP={TEMP} MAXCELL={MC} K={K} NKEYS={NKEYS}", flush=True)
pred = H.build_predictor(temperature=TEMP, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred); oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(777))
loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=1.0); lossj = jax.jit(loss)
for nm, i in [('polar', 4), ('azim', 5)]:
    sv = np.linspace(-6 * PS[i], 6 * PS[i], 33); j0 = 16; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(lossj(jnp.asarray(theta0 + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    sl = {w: (prof[j0 + w] - prof[j0 - w]) / (2 * w * dg) for w in [1, 2, 4, 8]}
    kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
    print(f"#  {nm:6s} slopes w1/2/4/8 {sl[1]:+10.1f} {sl[2]:+10.1f} {sl[4]:+10.1f} {sl[8]:+10.1f}  {'KINKY' if kinky else 'SMOOTH'}", flush=True)
