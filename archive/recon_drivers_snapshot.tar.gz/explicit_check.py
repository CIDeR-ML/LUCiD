"""EXPLICIT checks (no assumptions) of whether the PhotonSim recon residual is a genuine loss-minimum
offset (model) or an iteration artifact. For TRUTH_SOURCE in {siren, photonsim}, temp=0.1:

  (1) GRADIENT HONESTY at truth: AD (DiCE, avg over keys) vs central FD, per channel (charge / time /
      full), with the sharp recon HP (TAU, THR). cosine + magnitude. If AD~=FD, the gradient is honest.
  (2) IS TRUTH A STATIONARY POINT? |grad(full)| at truth, normalized. Self-consistent => ~0 expected.
      If PhotonSim |grad| at truth >> self-consistent, the loss MINIMUM is genuinely offset (not iteration).
  (3) INIT-AT-TRUTH DRIFT: start exactly at truth, run the annealed staged optimizer, report the vertex
      after each stage. If it WALKS AWAY, the min is offset; if it STAYS, earlier bias was iteration/init.
  (4) TIME-ONLY-FROM-TRUTH: start at truth, energy frozen at truth, run only the annealed TIME stages.
      Does the (honest, sharp) first-arrival time alone hold the vertex at truth or push it off?

Usage: CUDA_VISIBLE_DEVICES=g TRUTH_SOURCE=photonsim [TAU=0.3 THR=4] python explicit_check.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=130)

SRC = os.environ.get('TRUTH_SOURCE', 'photonsim')
TAU = float(os.environ.get('TAU', '0.3')); THR = float(os.environ.get('THR', '4'))
WT  = float(os.environ.get('WT', '0.05')); NK = int(os.environ.get('NKEYS', '24'))
SC = np.array(H.PARAM_SCALE)

S = PS.setup(event=0, nphot=80_000, truth_source=SRC, pred_temperature=0.1)
ts = np.array(S['theta_star'])
mk_full = PS.make_loss(S, WT=WT, TAU=TAU, THR=THR)
mk_chrg = PS.make_loss(S, WT=0.0, TAU=TAU, THR=THR)
mk_time = PS.make_loss(S, WT=1.0, TAU=TAU, THR=THR)   # use [1]=time channel
gfull = jax.jit(jax.grad(lambda th,k: mk_full(th,k)[2]))
gchrg = jax.jit(jax.grad(lambda th,k: mk_chrg(th,k)[2]))
gtime = jax.jit(jax.grad(lambda th,k: mk_time(th,k)[1]))
lfull = jax.jit(lambda th,k: mk_full(th,k)[2])
lchrg = jax.jit(lambda th,k: mk_chrg(th,k)[0])
ltime = jax.jit(lambda th,k: mk_time(th,k)[1])
keys = [jax.random.PRNGKey(4000+k) for k in range(NK)]
print(f"=== EXPLICIT CHECK  TRUTH={SRC}  temp=0.1  TAU={TAU} THR={THR}  ntime={PS.n_time_sensors(S,THR)} ===", flush=True)

def ad(gfn, th):
    G = np.stack([np.array(gfn(jnp.array(th),k))*SC for k in keys]); return G.mean(0), G.std(0)/np.sqrt(NK)
def fd(lfn, th, step=0.5):
    o=np.zeros(7)
    for i in range(7):
        v=[]
        for k in keys:
            hp=jnp.array(th).at[i].add(step*SC[i]); hm=jnp.array(th).at[i].add(-step*SC[i])
            v.append((float(lfn(hp,k))-float(lfn(hm,k)))/(2*step))
        o[i]=np.mean(v)
    return o
def cmp(name, gfn, lfn):
    a,se=ad(gfn,ts); f=fd(lfn,ts)
    cos=float(a@f/(np.linalg.norm(a)*np.linalg.norm(f)+1e-12))
    print(f"\n[{name}] grad at truth (normalized):")
    print(f"  AD: "+" ".join(f"{H.PARAM_NAMES[i][:3]}={a[i]:+.2f}" for i in range(7)))
    print(f"  FD: "+" ".join(f"{H.PARAM_NAMES[i][:3]}={f[i]:+.2f}" for i in range(7)))
    print(f"  cosine(AD,FD)={cos:.3f}  |AD|={np.linalg.norm(a):.2f} |FD|={np.linalg.norm(f):.2f}  "
          f"|AD_pos|={np.linalg.norm(a[1:4]):.2f} (SE~{np.mean(se[1:4]):.2f})")
    return a

# (1)+(2) gradient honesty + stationarity at truth
cmp("charge", gchrg, lchrg)
cmp("time  ", gtime, ltime)
gf = cmp("full  ", gfull, lfull)
print(f"\n  => |grad_full(truth)|_pos = {np.linalg.norm(gf[1:4]):.2f} normalized units "
      f"(=> truth is{'' if np.linalg.norm(gf[1:4])<1.0 else ' NOT'} a stationary point of position)")

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr=np.zeros(7)
    if freeze:
        for i in freeze: fr[i]=1.0
    T=[]
    for s in range(steps):
        ks=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in ks]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); step=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(step*(1-fr))
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(th): return np.linalg.norm((np.array(th)-ts)[1:4])*100
SCHED=[2,1,0.5,0.3,0.2]
gtmp={tau: jax.jit(jax.grad(lambda th,k,f=PS.make_loss(S,WT=WT,TAU=tau,THR=THR): f(th,k)[2])) for tau in SCHED}

# (3) INIT-AT-TRUTH drift (full staged optimizer)
th=jnp.array(ts.copy())
th=gnlm(th, gchrg, 90, tag=1); print(f"\n(3) init-at-truth: after charge stage  vertex={vtx(th):.1f}cm  E={float(th[0]-ts[0]):.0f}MeV")
for j,tau in enumerate(SCHED):
    th=gnlm(th, gtmp[tau], 50, freeze=[0], tag=2+j)
print(f"    after full annealed time stages       vertex={vtx(th):.1f}cm   (drift from 0 => loss min offset)")

# (4) TIME-ONLY from truth, energy+all-charge influence removed (energy frozen at truth)
th=jnp.array(ts.copy())
gtime_tau={tau: jax.jit(jax.grad(lambda th,k,f=PS.make_loss(S,WT=1.0,TAU=tau,THR=THR): f(th,k)[1])) for tau in SCHED}
for j,tau in enumerate(SCHED):
    th=gnlm(th, gtime_tau[tau], 50, freeze=[0], tag=20+j)
print(f"(4) time-only from truth (E frozen@truth): vertex={vtx(th):.1f}cm  t0={float(th[6]-ts[6]):+.2f}ns "
      f"(does honest sharp time hold the vertex at truth?)", flush=True)
