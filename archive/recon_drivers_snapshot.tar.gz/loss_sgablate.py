"""LOSS sg-ABLATION — what happens to the AD gradient when stop_gradients in photon_step are removed.

The forward loss is INDEPENDENT of the stop_gradients (sg is identity in the forward), so the clean
noise-averaged profile slope is the SAME ground truth for every flag setting; only the AD gradient changes.
We restore each detached track-gradient path and measure AD/profile per param. ratio -> 1 when restoring a
given sg => that sg WAS the source of the underestimate.

PSTEP_DBG flags (set via env, read in photon_step at trace):
  ''                      baseline (all sg ON)
  norm_live               restore reflection-NORMAL gradient (Igehy curvature term)
  dpos_live               restore FREE-PATH gradient in the scatter position
  norm_live,dpos_live     both
  cont_sg                 (removes MORE: fully detach the survival/continuing factor)
Run each in its OWN process. Env: PSTEP_DBG NPHOT NKEYS RECON_K.  Usage: CUDA_VISIBLE_DEVICES=g PSTEP_DBG=norm_live python loss_sgablate.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '48'))
K = int(os.environ.get('RECON_K', '8')); FLAGS = os.environ.get('PSTEP_DBG', '')
PN = H.PARAM_NAMES; PS = np.asarray(H.PARAM_SCALE)
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0.0, 0.0, 0.0175, 0.0, 0.5])
theta0 = theta_true + delta
PARAMS = [('y', 2), ('z', 3), ('energy', 0), ('x', 1), ('polar', 4), ('azim', 5)]
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
print(f"# sg-ABLATION  PSTEP_DBG='{FLAGS}'  K={K} NPH={NPH} NKEYS={NKEYS}  (charge+time loss, eval@theta0)", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred); oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(777))
loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=1.0)
lossj = jax.jit(loss); gradj = jax.jit(jax.grad(loss))
gAD = np.stack([np.asarray(gradj(jnp.asarray(theta0), k)) for k in keys]).mean(0)

def prof_slopes(i):
    sv = np.linspace(-6 * PS[i], 6 * PS[i], 25); j0 = 12; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(lossj(jnp.asarray(theta0 + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    return {w: (prof[j0 + w] - prof[j0 - w]) / (2 * w * dg) for w in [1, 2, 4]}

print(f"#  param   AD          prof(w2)     AD/prof    [angles: multi-scale slopes]", flush=True)
for nm, i in PARAMS:
    sl = prof_slopes(i); ad = gAD[i]
    kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
    if kinky:
        print(f"#  {nm:6s} {ad:+11.2f}  KINKY        slopes w1/2/4 {sl[1]:+10.1f} {sl[2]:+10.1f} {sl[4]:+10.1f}", flush=True)
    else:
        print(f"#  {nm:6s} {ad:+11.2f}  {sl[2]:+11.2f}  {ad/(sl[2]+1e-30):+7.3f}", flush=True)
