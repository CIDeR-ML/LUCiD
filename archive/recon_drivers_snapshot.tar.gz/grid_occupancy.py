"""Measure SK grid cell occupancy: how many GEOMETRIC sensor-assignments per cell vs max_sensors_per_cell.
If many cells exceed the cap, the inverse map DROPS sensors -> charge loss. Reports for each MC the grid
resolution, mean/max sensors-per-cell, and fraction of geometric assignments DROPPED (>cap).
Usage: CUDA_VISIBLE_DEVICES=g python grid_occupancy.py
"""
import os
os.environ.setdefault('TTS_NS','2.5')
import numpy as np, jax, jax.numpy as jnp
from lucid.geometry import generate_detector
det = generate_detector('config/SK_geom_config.json')
P = np.asarray(det.raw_positions); r = det.S_radius
print(f"# SK n_sensors={det.n_sensors} S_radius={r:.3f}", flush=True)
from scipy.spatial import cKDTree
nn = cKDTree(P).query(P, k=2)[0][:,1]; print(f"# nn_min={nn.min():.3f} nn_med={np.median(nn):.3f}", flush=True)
print(f"#  MC | n_ang x n_h (+caps) | cells | geom-assign/cell mean/max | %cells>cap | %assignments DROPPED", flush=True)
for MC in [4,8,16,24,32,48,64,96]:
    det.configure_grid(max_sensors_per_cell=MC)
    na,nh,nc = det._n_angular, det._n_height, det._n_cap
    # geometric assignment (n_sensors,4,3); count per linear cell
    asg = np.asarray(det.assign_sensor_to_cells(jnp.asarray(P), r))   # (n,4,3)
    nwall = na*nh
    lin=[]
    for s in range(asg.shape[0]):
        for a in range(4):
            ci,cj,ck = asg[s,a]
            if ci<0: continue
            if ck==0: lin.append(int(ci)*nh+int(cj))
            elif ck==1: lin.append(nwall+int(ci)*nc+int(cj))
            else: lin.append(nwall+nc*nc+int(ci)*nc+int(cj))
    lin=np.array(lin); total_cells=na*nh+2*nc*nc
    occ=np.bincount(lin, minlength=total_cells)
    occ_nz=occ[occ>0]
    over = occ>MC
    dropped = np.sum(np.maximum(occ-MC,0))   # geometric assignments dropped
    print(f"#  {MC:3d} | {na:3d}x{nh:<3d} nc={nc:3d} | {total_cells:6d} | {occ_nz.mean():5.1f}/{occ.max():3d} | {100*over.mean():5.1f}% | {100*dropped/max(len(lin),1):4.1f}%", flush=True)
print(f"# READ: if max>>MC and %dropped grows as MC shrinks => overflow-drop is the charge-loss bug.", flush=True)
