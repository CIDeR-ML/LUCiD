"""The fix implied by the explicit checks: the per-sensor charge NLL energy is corrupted by the SIREN
ring-shape mismatch (+15.7% at true vertex); the TOTAL charge needs only ~+4.5% (calibration). Use a
shape-robust TOTAL-charge energy + honest annealed TIME for the vertex. PhotonSim. Compare recipes.
Usage: CUDA_VISIBLE_DEVICES=g python iterate2.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
THR = 4.0; SC = np.array(H.PARAM_SCALE); SCHED = [2, 1, 0.5, 0.3, 0.2]

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; SUMOBS = S['sumobs']
def gchan(WT_, TAU_, chan):
    f = PS.make_loss(S, WT=WT_, TAU=TAU_, THR=THR); return jax.jit(jax.grad(lambda th,k: f(th,k)[chan]))
gchrg = gchan(0.0, 0.3, 0)
gtime = {tau: gchan(1.0, tau, 1) for tau in SCHED}
# total-charge energy loss (shape-robust): ((Sq - Sobs)/Sobs)^2
def etot_loss(theta, key):
    _,_,_,q = pred(H.theta_to_track(theta), key)
    return ((jnp.sum(q) - SUMOBS)/SUMOBS)**2 * 1e4
getot = jax.jit(jax.grad(etot_loss))

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T=[]
    for s in range(steps):
        ks=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in ks]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st*(1-fr))
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t): return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t): return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
def anneal(th, gd, freeze, t0):
    for j,tau in enumerate(SCHED): th=gnlm(th, gd[tau], 50, freeze=freeze, tag=t0+j)
    return th

rng=np.random.default_rng(SEED)
th0=jnp.array(ts + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)

# rough charge fit (per-sensor) for pos/dir; energy will be REPLACED by total-charge
r = gnlm(th0, gchrg, 90, tag=1)
print(f"ITER2 seed={SEED}: rough-charge vtx={vtx(r):.0f}cm E={Ep(r):+.0f}%", flush=True)

# RECIPE T: total-charge energy -> annealed time -> (re-total-E -> time) x2
th = r
for it in range(3):
    th = gnlm(th, getot, 60, freeze=[1,2,3,4,5,6], tag=500+it)     # energy from TOTAL charge (pos fixed)
    if it == 0: print(f"  after total-charge E (round 0): E={Ep(th):+.1f}%", flush=True)
    th = anneal(th, gtime, [0], 600+it*10)                          # pos/dir/t0 from TIME (E fixed)
    print(f"  recipeT round {it}: vtx={vtx(th):5.1f}cm  E={Ep(th):+.1f}%  dir={deg(th):.2f}  t0={float(th[6]-ts[6]):+.2f}", flush=True)
