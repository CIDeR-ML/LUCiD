"""Characterize the SIREN-vs-PhotonSim emission mismatch at the TRUE track.
Compares per-sensor predicted charge (SIREN expected, avg over keys) to observed charge (real PhotonSim
photons), projected onto the track's longitudinal axis s=(sensor-vtx).dir and perpendicular radius rho.
A monopole (total-yield) mismatch -> energy bias; a longitudinal dipole (centroid shift) -> vertex bias.
Usage: CUDA_VISIBLE_DEVICES=g python emission_diag.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=4, suppress=True)
NK = int(os.environ.get('NKEYS', '12'))

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim')
theta = jnp.array(S['theta_star']); pred = S['pred']
oc = np.array(S['oc'])
# predicted per-sensor charge at truth, averaged over keys
qs = []
for k in range(NK):
    _, _, _, q = jax.jit(pred)(H.theta_to_track(theta), jax.random.PRNGKey(500 + k))
    qs.append(np.array(q))
qpred = np.mean(qs, 0)

# sensor positions (same ordering as charge)
dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
sp = np.array(dg.sensor_points)                      # (ND,3) meters
vtx = np.array(S['theta_star'][1:4])
pol, az = float(S['theta_star'][4]), float(S['theta_star'][5])
d = np.array([np.sin(pol)*np.cos(az), np.sin(pol)*np.sin(az), np.cos(pol)])
rel = sp - vtx
s = rel @ d                                          # longitudinal coord along track (m)
rho = np.linalg.norm(rel - np.outer(s, d), axis=1)   # perpendicular radius (m)

print(f"Sigma q_pred={qpred.sum():.1f}  Sigma oc={oc.sum():.1f}  ratio={qpred.sum()/oc.sum():.4f}")
print(f"hit sensors: pred>0 {int((qpred>1e-4).sum())}  obs>0 {int((oc>0).sum())}")
# charge-weighted longitudinal centroid
def cen(w): return float((w*s).sum()/ (w.sum()+1e-12))
print(f"<s>_pred={cen(qpred):+.3f} m  <s>_obs={cen(oc):+.3f} m  dipole shift={cen(qpred)-cen(oc):+.3f} m")
print(f"<rho>_pred={float((qpred*rho).sum()/(qpred.sum()+1e-12)):.3f} m  "
      f"<rho>_obs={float((oc*rho).sum()/(oc.sum()+1e-12)):.3f} m")

# longitudinal profile (bin charge by s)
edges = np.linspace(s.min(), s.max(), 13)
mid = 0.5*(edges[:-1]+edges[1:])
op = np.array([oc[(s>=edges[i])&(s<edges[i+1])].sum() for i in range(12)])
pp = np.array([qpred[(s>=edges[i])&(s<edges[i+1])].sum() for i in range(12)])
print("longitudinal charge profile (s_mid : obs / pred):")
for i in range(12):
    print(f"  s={mid[i]:+6.2f} m  obs={op[i]:7.1f}  pred={pp[i]:7.1f}  ratio={pp[i]/(op[i]+1e-9):.3f}")
np.savez('/tmp/emiss_diag.npz', s=s, rho=rho, oc=oc, qpred=qpred, mid=mid, op=op, pp=pp, d=d, vtx=vtx)
