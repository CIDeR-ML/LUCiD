"""PHASE 3 — BASIN of attraction (corrected count-conditioned loss + fixes). For param PIDX, start Adam at
truth + offset*SC (both signs, increasing), run the fit, report the FINAL residual + total errors. Capture radius
= largest offset that still returns to ~truth. Single-realization truth. Compare to prior memory radii.
Env: PIDX(0-8) NPHOT NKEYS STEPS.  Usage: CUDA_VISIBLE_DEVICES=g PIDX=3 python basin_check.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ['MAXCELL']='16'; os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np, optax
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=170)
NPH=int(os.environ.get('NPHOT','500000')); NKEYS=int(os.environ.get('NKEYS','4')); STEPS=int(os.environ.get('STEPS','250'))
PIDX=int(os.environ.get('PIDX','3')); K=8; MC=16; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0)); POL,AZ=0.6,0.8
th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
SC=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
AMP=bool(int(os.environ.get('AMP','1')))
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def th9dir(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=np.hypot(st,ct); npp=np.hypot(sp,cp); st,ct,sp,cp=st/nt,ct/nt,sp/npp,cp/npp
    return np.array([st*cp,st*sp,ct])
print(f"# BASIN PIDX={PIDX}({NM[PIDX]}) NPH={NPH} NKEYS={NKEYS} STEPS={STEPS} AMP={AMP}",flush=True)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); ND=H.num_detectors(pred)
truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=K,is_data=False,use_expected_value=False,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
trk=sc2(jnp.asarray(th9)); dtrue=th9dir(th9)
c,t=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(5000))); oc=jnp.asarray(np.asarray(c)); ot=jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def loss(t9,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jnp.exp(jnp.clip(lw,-60,20)); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8)
    wR=jax.lax.stop_gradient(ww) if AMP else ww; muS=jax.lax.stop_gradient(mu) if AMP else mu
    Rlo=jax.ops.segment_sum(wR*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(wR*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(mu-oc*jnp.log(mu))+jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
gradf=jax.jit(jax.grad(loss)); SCj=jnp.asarray(SC); T0=jnp.asarray(th9)
def fit(start):
    opt=optax.adam(3e-2); z=(jnp.asarray(start)-T0)/SCj; st=opt.init(z)
    for i in range(STEPS):
        th=T0+z*SCj; G=jnp.zeros(9)
        for s in range(NKEYS): G=G+gradf(th,jax.random.PRNGKey(s))
        u,st=opt.update((G/NKEYS)*SCj,st); z=optax.apply_updates(z,u)
    return np.asarray(T0+z*SCj)
print(f"#  off(xSC) | start-offset | FINAL {NM[PIDX]} resid | vtx dir E t0 errors | converged?",flush=True)
for off in [0.5,1,2,4,8,16,-1,-2,-4,-8,-16]:
    start=th9+off*SC*np.eye(9)[PIDX]
    fin=fit(start); d=fin-th9
    vtx=np.sqrt(d[1]**2+d[2]**2+d[3]**2); dang=np.degrees(np.arccos(np.clip(np.dot(th9dir(fin),dtrue),-1,1)))
    conv=(vtx<0.3)and(abs(d[0])<80)and(dang<3)and(abs(d[8])<1.0)
    print(f"#  {off:+5.1f} | {off*SC[PIDX]:+8.3f} | {d[PIDX]:+9.4f} | vtx{vtx*100:5.1f}cm dir{dang:4.1f}deg E{d[0]:+6.0f} t0{d[8]:+.2f} | {'YES' if conv else 'no'}",flush=True)
print(f"# DONE basin PIDX={PIDX}",flush=True)
