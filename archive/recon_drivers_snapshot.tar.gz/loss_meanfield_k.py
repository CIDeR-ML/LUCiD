"""MEAN-FIELD covariance check — is the ~1% EXPECTED-vs-SAMPLE charge gap the dropped Cov(survival, detect)?
Prediction: the gap = E[survival.detect] - E[survival]E[detect] accumulates with bounces, so it should be ~0
at K=1 (survival==1, no covariance) and GROW with K. Compare total + dim-bucket charge EXP(expected) vs
SAMP(sample), both via per_photon (readout identical; only the propagator differs), averaged, for K=1,2,4,8.
(K<6 here is a FORWARD mechanism diagnostic only, not a recon truth.)
Env: NPHOT NREAL NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_meanfield_k.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '32')); NKEYS = int(os.environ.get('NKEYS', '12'))
MC = 16; POL, AZ = 0.6, 0.8
th9 = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def trk():
    return ParticleParams(energy=th9[0], position=jnp.asarray(th9[1:4]), theta=jnp.asarray(POL), phi=jnp.asarray(AZ), t0=0.0)
print(f"# MEAN-FIELD gap vs K  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS}", flush=True)
def build(use_ev, K):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=use_ev,
        hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True,
        particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
print(f"#   K | EXP Q | SAMP Q | ratio | dim-bucket ratio(0.05-0.2)", flush=True)
for K in [1, 2, 4, 8]:
    EXP = build(True, K); SAMP = build(False, K); ND = H.num_detectors(EXP); t = trk()
    qe = np.mean([np.asarray(jax.lax.stop_gradient(EXP(t, jax.random.PRNGKey(s)))[3]) for s in range(NKEYS)], 0)
    qs = np.mean([np.asarray(jax.lax.stop_gradient(SAMP(t, jax.random.PRNGKey(1000 + r)))[3]) for r in range(NREAL)], 0)
    dim = np.where((qe > 0.05) & (qe <= 0.2))[0]
    dr = qe[dim].sum() / max(qs[dim].sum(), 1e-9) if dim.size else float('nan')
    print(f"#  {K:2d} | {qe.sum():6.0f} | {qs.sum():6.0f} | {qe.sum()/max(qs.sum(),1):.4f} | {dr:.4f} ({dim.size} pmt)", flush=True)
print(f"# READ: ratio ~1.000 at K=1 and DROPPING with K => the gap is the dropped survival.detect covariance", flush=True)
print(f"#       (mean-field implicit-capture under-counts; grows with accumulated survival / bounces).", flush=True)
