"""FORWARD early-edge residual — the decisive test for the survival-term bias.

At theta_true, for a CORRECT model the Poisson compensator at the first arrival R(t_obs)=sum_j w_j Phi((t_obs-tau_j)/sigma)
should have MEAN 1 per PMT (time-change: R at the first jump ~ Exp(1)). If the predictor's R(t_obs) >> 1, it
OVER-POPULATES the early edge vs truth (SIM-vs-TRUTH forward timing residual) -> the survival term -1.88m bias.

Compares per-PMT at theta_true (truth first-arrival t_obs from sample engine; predictor per-photon rate from
expected engine), bucketed by occupancy. Also reports the predictor's early-time quantile vs t_obs (is the
expected engine's early edge ahead of the hard-sampled truth?). K=8, MAXCELL=16, TTS=2.5.
Env: NPHOT NKT NTRUTH SIGMA.  Usage: CUDA_VISIBLE_DEVICES=g python loss_fwd_earlyedge.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKT = int(os.environ.get('NKT', '8')); NTRUTH = int(os.environ.get('NTRUTH', '24')); SIGMA = float(os.environ.get('SIGMA', '2.5')); K = 8
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.asarray(theta_true))
print(f"# FWD early-edge  NPH={NPH} NKT={NKT} NTRUTH={NTRUTH} SIGMA={SIGMA} K={K} MC={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
# truth mean first-arrival + charge
ct, tt = [], []
for s in range(NTRUTH):
    c, t = [np.asarray(x) for x in jax.lax.stop_gradient(tsim(track, jax.random.PRNGKey(s)))]
    ct.append(c); tt.append(np.where(c > 0, t, np.nan))
q_tru = np.mean(ct, 0); t_obs = np.nanmean(tt, 0)
# predictor per-photon arrays (one rep key); compute per-PMT R(t_obs) and early quantile
def pred_arrays(key):
    lw, ft, fi, tot = [np.asarray(x) for x in jax.lax.stop_gradient(pred(track, key))]
    return lw, ft, fi, tot
SQ = float(np.sqrt(2.0))
Rvals = np.zeros(ND); qearly = np.full(ND, np.nan)
acc_R = np.zeros(ND); nacc = 0
for s in range(NKT):
    lw, ft, fi, tot = pred_arrays(jax.random.PRNGKey(100 + s))
    w = np.exp(np.clip(lw, -60, 10))
    tob = t_obs[fi]
    contrib = w * 0.5 * (1.0 + erf((tob - ft) / (SIGMA * SQ)))
    acc_R += np.bincount(fi, weights=np.where(np.isfinite(tob), contrib, 0.0), minlength=ND); nacc += 1
R_pred = acc_R / nacc
m = (q_tru > 1e-6) & np.isfinite(t_obs)
print(f"# lit PMTs {m.sum()}  R(t_obs)=predictor expected #photons before truth first-arrival (should be ~1 if unbiased):", flush=True)
print(f"#  ALL: mean R {R_pred[m].mean():.3f} median {np.median(R_pred[m]):.3f}", flush=True)
for lo, hi in [(0, 1), (1, 3), (3, 8), (8, 1e9)]:
    mm = m & (q_tru >= lo) & (q_tru < hi)
    if mm.sum() > 20:
        print(f"#  occ[{lo:>2.0f},{hi:>4.0f}) n={mm.sum():5d}: mean R(t_obs) {R_pred[mm].mean():.3f} median {np.median(R_pred[mm]):.3f}", flush=True)
print(f"# READ: R(t_obs) >> 1 => predictor over-populates the early edge vs truth (expected-vs-sample engine forward residual) => survival-term vertex bias.", flush=True)
