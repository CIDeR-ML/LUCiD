"""EMISSION-CHARGE BIAS map. The Fisher charge gradient at truth is large for PhotonSim (polar angle + vertex):
SIREN's predicted charge pattern != GEANT4's. Localize WHERE by comparing per-PMT mu_SIREN vs q_GEANT4 at the
derive_truth, binned by track geometry:
  cos_view = (p_pmt - vtx).d / |p_pmt - vtx|   (Cherenkov-cone / angular structure; ring ~ cos 0.75)
  long_s   = (p_pmt - vtx).d                   (longitudinal position along the track)
Reports mean mu (SIREN), mean q (GEANT4), ratio, residual per bin -> shows if SIREN over/under-lights the
front/back of the track or the cone peak/tails (the emission-profile defect driving the angle+vertex bias).
Env: EVENT NPHP NKEYS.  Usage: CUDA_VISIBLE_DEVICES=0 EVENT=0 python emission_map.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.geometry.cylinder import Cylinder
np.set_printoptions(precision=3, suppress=True, linewidth=170)
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NBUF=400_000
MC=int(os.environ['MAXCELL']); K=8; EV=int(os.environ.get('EVENT','0')); NKEYS=int(os.environ.get('NKEYS','6')); NPHP=int(os.environ.get('NPHP','1500000'))
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times'])
    C=P-P.mean(0); _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d; proj=-proj
    vtx=P.mean(0)+proj.min()*d; pol=float(np.arccos(np.clip(d[2],-1,1))); az=float(np.arctan2(d[1],d[0]))
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]),d,vtx
det=Cylinder.from_pmt_file('config/sk_geometry.npz'); POS=np.asarray(det.all_points); print(f"# EMISSION_MAP ev{EV} NPHP={NPHP} ND={POS.shape[0]}",flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred); assert ND==POS.shape[0], (ND,POS.shape)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
raw=read_photon_data_from_photonsim(ROOT,EV); th9,d,vtx=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
NDET=int(os.environ.get('NDET','1'))
q=np.mean([np.asarray(jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+EV+1000*r),pd))[0]) for r in range(NDET)],0)  # GEANT4 charge (NDET-averaged)
mu=np.mean([np.asarray(jax.lax.stop_gradient(pred(sc2(T0),jax.random.PRNGKey(s)))[3]) for s in range(NKEYS)],0)  # SIREN mu
_lit=(mu>0.05)|(q>0.05); _fr=(mu[_lit]-q[_lit])/np.sqrt(np.maximum(q[_lit],0.05))   # Pearson residual (in sigma units)
print(f"# SYSTEMATIC per-PMT (NDET={NDET}): charge-wtd RMS frac |mu-q|/q = {np.sqrt(np.sum((mu[_lit]-q[_lit])**2)/np.sum(q[_lit]**2))*100:.2f}%  | mean Pearson resid={_fr.mean():+.3f}sigma rms={_fr.std():.3f}sigma over {_lit.sum()} PMT",flush=True)
r=POS-vtx; dist=np.linalg.norm(r,axis=1); cosv=(r@d)/np.maximum(dist,1e-9); longs=r@d
print(f"# truth pol={np.degrees(np.arccos(d[2])):.1f}deg  Qtot: SIREN={mu.sum():.0f} GEANT4={q.sum():.0f} ratio={mu.sum()/q.sum():.3f}",flush=True)
lit=(mu>1e-3)|(q>0.5)
def report(val,name,bins,lab):
    print(f"#\n# charge by {name}:  (SIREN mu / GEANT4 q / ratio / #PMT)",flush=True)
    for lo,hi in bins:
        m=lit&(val>=lo)&(val<hi)
        if m.sum()<3: continue
        sm=mu[m].sum(); sq=q[m].sum()
        print(f"#  {lab} {lo:+6.2f}..{hi:+6.2f} | mu={sm:8.1f} q={sq:8.1f} ratio={sm/max(sq,1e-6):6.3f} | {int(m.sum()):4d} PMT",flush=True)
report(cosv,'cos_view (Cherenkov cone; ring~+0.75)',[(-1,-0.5),(-0.5,0),(0,0.3),(0.3,0.6),(0.6,0.8),(0.8,0.95),(0.95,1.01)],'cos')
report(longs,'long_s (m along track from vertex)',[(-3,-1),(-1,0),(0,1),(1,2),(2,3),(3,5),(5,9)],'s')
print("# DONE",flush=True)
