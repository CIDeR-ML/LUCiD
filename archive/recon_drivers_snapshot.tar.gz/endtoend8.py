"""END-TO-END v8: PURE-GRADIENT (no line-searches). Key insight: lCEN (charge-centroid-on-axis) BREAKS the
longitudinal<->t0 degeneracy, which is exactly what was starving the t0 gradient -> with lCEN in the loss,
BOTH longitudinal vertex AND t0 become gradient-recoverable. So it's ONE differentiable optimization on
  L = lE + WCEN*lCEN + WT*lT_gd
The only reason earlier gradient runs didn't move was Adam's step was tuned for fine refinement (~0.6cm/step,
can't cross 7m in 80 steps). Fix = a COARSE phase (big LR, wide sigma) to traverse the initial meters, then a
FINE sigma-annealed phase to settle. No line-searches. Seed = radial point-fit transverse + charge-axis dir
+ total-charge E + wavefront-rough t0. Env: TRUTH TTS_NS NKG WT WCEN TKS EVENT NW CLR CSTEPS.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 python endtoend8.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.grid_search import hierarchical_position_grid_search_4d, get_detector_bounds
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
WT = float(os.environ.get('WT', '1.0')); WCEN = float(os.environ.get('WCEN', '4.0'))
NKG = int(os.environ.get('NKG', '3')); CLR = float(os.environ.get('CLR', '0.12')); CSTEPS = int(os.environ.get('CSTEPS', '250'))
FLR = float(os.environ.get('FLR', '0.03')); SPS = int(os.environ.get('SPS', '16')); CSIG = float(os.environ.get('CSIG', '20'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0')); NW = float(os.environ.get('NW', '1.34'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi); C = 0.299792; G = float(np.sqrt(NW ** 2 - 1.0))
FINE_SIG = [s for s in [12, 8, 5, 3, SIGEND] if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points)); BOUNDS = get_detector_bounds(det)
def dvec(pol, az): return jnp.array([jnp.sin(pol) * jnp.cos(az), jnp.sin(pol) * jnp.sin(az), jnp.cos(pol)])

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    d = dvec(theta[4], theta[5]); cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / sumobs
    lCEN = ((cen_p - cen_o) @ d) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WCEN * lCEN + WT * lT
gfn = jax.jit(jax.grad(loss))

def adam_phase(th, m, v, t, oc, ot, hi, sig, lr, nsteps, seed):
    b1, b2 = 0.9, 0.999
    for s in range(nsteps):
        ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
        g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
        t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g; mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
        th = th - lr * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return th, m, v, t

def optimize(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); t = 0
    th, m, v, t = adam_phase(th, m, v, t, oc, ot, hi, CSIG, CLR, CSTEPS, seed)   # COARSE: traverse meters
    for sig in FINE_SIG:                                                          # FINE: settle
        th, m, v, t = adam_phase(th, m, v, t, oc, ot, hi, sig, FLR, SPS, seed)
    return np.array(th)

def geom_seed(oc, ot, hi):
    hm = np.array(hi); Pn = np.array(DP)[hm]; tobs = np.array(ot)[hm]; q = np.array(oc)[hm]
    r = hierarchical_position_grid_search_4d(jnp.array(Pn), jnp.array(tobs), jnp.array(q), true_position=ts[1:4],
        true_t0=ts[6], t0_guess=0.0, detector_bounds=BOUNDS, n_div=5, t0_n_div=5, levels=6, fraction=1.0,
        t0_min=-15.0, t0_max=15.0, verbosity=0)
    V = np.array(r['best_position']); dv = Pn - V[None, :]; dv = dv / (np.linalg.norm(dv, axis=1, keepdims=True) + 1e-9)
    ax = (q[:, None] * dv).sum(0); ax = ax / (np.linalg.norm(ax) + 1e-9)
    a = Pn - V[None, :]; apar = a @ ax; aperp = np.sqrt(np.maximum((a * a).sum(1) - apar ** 2, 1e-9))
    res = tobs - (apar + aperp * G) / C; o = np.argsort(res); cw = np.cumsum(q[o]) / (q.sum() + 1e-9)
    t0 = float(np.interp(0.08, cw, res[o]))
    E = float(estimate_muon_energy_from_photon_count(float(q.sum())))
    return np.array([E, V[0], V[1], V[2], float(np.arccos(np.clip(ax[2], -1, 1))), float(np.arctan2(ax[1], ax[0])), t0])

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t): return float(np.degrees(np.arccos(np.clip(np.array(dvec(t[4], t[5])) @ np.array(dvec(ts[4], ts[5])), -1, 1))))
def lon(t): return float(((np.array(t) - ts)[1:4] @ np.array(dvec(ts[4], ts[5]))) * 100)
def report(tag, th): return f"{tag}: vtx={vtx(th):6.1f}cm (lon={lon(th):+5.0f}) dir={degf(th):5.2f}deg t0_err={abs(th[6]-ts[6]):5.2f}ns E_err={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"
print(f"# ENDTOEND8 TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} WCEN={WCEN} COARSE(sig={CSIG},lr={CLR},{CSTEPS}st) FINE{FINE_SIG} (PURE GRADIENT, no line-search)", flush=True)
print(f"#   truth theta = {ts}", flush=True)
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0 = geom_seed(oc, ot, hi); thf = optimize(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    print(f"  key {tk}  {report('SEED ', th0)}", flush=True); print(f"  key {tk}  {report('FINAL', thf)}", flush=True)
SE = np.array([[vtx(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():6.1f}cm dir={SE[:,1].mean():5.2f}deg t0={SE[:,2].mean():5.2f}ns E={SE[:,3].mean():5.1f}%", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():6.1f}cm dir={FE[:,1].mean():5.2f}deg t0={FE[:,2].mean():5.2f}ns E={FE[:,3].mean():5.1f}%  TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
