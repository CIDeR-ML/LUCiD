"""Test a TTS-AWARE first-arrival timing loss vs the current one. The correct model: photons are a Poisson
process at predicted times t_j with weights w_j, each Gaussian-smeared by sigma (TTS). The observed
first-arrival t_obs has NLL = -log lambda(t_obs) + Lambda(t_obs), where
  lambda(t) = sum_j w_j * phi((t-t_j)/sig)/sig    (smeared intensity)
  Lambda(t) = sum_j w_j * Phi((t-t_j)/sig)         (cumulative)
Its MLE should be UNBIASED under TTS (matches the data-generating process). Compare the gradient MEAN at
truth (bias) of lT_tts vs the old lT (fa_shape), over M data realizations, PhotonSim & SIREN, TTS=2.5.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 SIG=2.5 python tts_loss_test.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True, linewidth=160)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '150000'))
M = int(os.environ.get('M', '48')); SIG = float(os.environ.get('SIG', '2.5')); THR = float(os.environ.get('THR', '4.0'))
TAU = float(os.environ.get('TAU', '2.5')); NAMES = H.PARAM_NAMES; SC = np.array(H.PARAM_SCALE)
S = PS.setup(event=0, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = jnp.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)

def lT_tts(theta, key, oc, ot, hi):
    """TTS-aware Poisson first-arrival NLL with Gaussian smearing sigma=SIG."""
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    w = jnp.exp(jnp.clip(lw, -50.0, 10.0))
    valid = lw > -20.0
    tobs = (ot - theta[6])[fi]
    x = (tobs - ft) / SIG
    phi = jnp.exp(-0.5 * x ** 2) / (SQ2PI * SIG)
    Phi = 0.5 * (1.0 + jax.lax.erf(x / SQ2))
    lam_j = jnp.where(valid, w * phi, 0.0)
    Lam_j = jnp.where(valid, w * Phi, 0.0)
    lam = jax.ops.segment_sum(lam_j, fi, ND)
    Lam = jax.ops.segment_sum(Lam_j, fi, ND)
    nll = -jnp.log(lam + 1e-12) + Lam
    tmask = hi & (oc >= THR)
    return jnp.sum(jnp.where(tmask, nll, 0.0))

def fa_shape(lw, ft, fi, tobs, tau):   # the OLD timing loss (logistic, normalized)
    t_obs = tobs[fi]; x = (t_obs - ft) / tau
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.where(empty, 0.0, -lf - (Ns - 1.0) * l1mf)
def lT_old(theta, key, oc, ot, hi):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    tmask = hi & (oc >= THR)
    return jnp.sum(jnp.where(tmask, fa_shape(lw, ft, fi, ot - theta[6], TAU), 0.0))

def lT_gd(theta, key, oc, ot, hi):
    """Count-DECOUPLED TTS-aware: Gaussian kernel (sigma=SIG) order-statistic with per-sensor NORMALIZED
    weights + detached count N_s -> energy-independent AND TTS-aware (the intended fix)."""
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / SIG
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]              # normalized (count-decoupled)
    log_dens = -0.5 * x ** 2 - jnp.log(SIG * SQ2PI)                        # log Gaussian density
    log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))   # log Phi(-x) = log(1-F)
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    nll = -lf - (Ns - 1.0) * l1mf
    tmask = hi & (oc >= THR)
    return jnp.sum(jnp.where(tmask & (~empty), nll, 0.0))

gN = jax.jit(jax.grad(lT_tts)); gO = jax.jit(jax.grad(lT_old)); gD = jax.jit(jax.grad(lT_gd))
GN, GO, GD = [], [], []
for m in range(M):
    oc, ot, hi = regen(3000 + m); pk = jax.random.PRNGKey(m)
    GN.append(np.array(gN(ts, pk, oc, ot, hi)) * SC); GO.append(np.array(gO(ts, pk, oc, ot, hi)) * SC)
    GD.append(np.array(gD(ts, pk, oc, ot, hi)) * SC)
GN, GO, GD = np.array(GN), np.array(GO), np.array(GD)
print(f"# TTS-AWARE timing loss TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} SIG={SIG} M={M}", flush=True)
def bias(G, nm):
    se = G.std(0) / np.sqrt(M)
    print(f"[{nm}] grad_mean/SE @ truth (|.|>3 = biased min): " +
          " ".join(f"{NAMES[i]}={G.mean(0)[i]/(se[i]+1e-12):+.0f}" for i in range(7)), flush=True)
bias(GO, 'lT_old  (logistic,norm)   ')
bias(GN, 'lT_tts  (Poisson abs-count)')
bias(GD, 'lT_gd   (Gaussian,DECOUPLED)')
# implied PHYSICAL bias offset delta = SC * F^-1 <g>  (the shift of the minimum from truth, in ns/cm/MeV)
def bias_size(G, nm):
    F = (G.T @ G) / M; F = F + 1e-6 * np.trace(F) * np.eye(7)
    d = np.linalg.solve(F, G.mean(0)) * SC                      # physical units per param
    vtxb = np.sqrt(d[1]**2 + d[2]**2 + d[3]**2) * 100; dirb = np.sqrt(d[4]**2 + d[5]**2) * 180 / np.pi
    print(f"  -> {nm} implied BIAS: E={d[0]:+.0f}MeV vtx={vtxb:.1f}cm dir={dirb:.2f}deg t0={d[6]:+.2f}ns", flush=True)
bias_size(GO, 'lT_old'); bias_size(GN, 'lT_tts'); bias_size(GD, 'lT_gd')
