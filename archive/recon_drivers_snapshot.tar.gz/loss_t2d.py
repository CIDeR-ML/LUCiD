"""TIER 2d — MODEL-FREE propagator comparison: is the +4ns late bias in the PROPAGATOR rate
(implicit capture) or in the first-arrival model? Run BOTH propagators through the SAME per_photon
hit mode (returns flat w,t,idx), so only the propagator differs:
  EXP  = use_expected_value=True  (implicit-capture, continuous, deposits at every bounce)
  SAMP = use_expected_value=False (sampling, binary, photon STOPS at first detection)
Compare per PMT, per occupancy bucket:
  (1) total weight (charge)         -> should match (E[sample]=expected).
  (2) RATE mean deposit time  Sum(w*t)/Sum(w)  -> if EXP later than SAMP => propagator late bias
      (implicit capture), NOT the first-arrival model. If they MATCH => the +4ns was the first-arrival
      model/threshold, not the propagator.
  (3) per-BOUNCE weight & mean time -> does EXP carry extra LATE-bounce weight that SAMP (stopped) lacks?
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t2d.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '24'))
K = 8; MC = 16
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
trk = sc2track(jnp.asarray(th9_true))
print(f"# T2d MODEL-FREE propagator rate  NPH={NPH} NREAL={NREAL} K={K}", flush=True)

def build(use_ev):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
        use_expected_value=use_ev, hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS,
        default_detector_params=True, particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
EXP = build(True); SAMP = build(False); ND = H.num_detectors(EXP)

@jax.jit
def rate_moments(sim_out):
    log_w, t, idx, tot = sim_out
    w = jnp.where(log_w > -50, jnp.exp(jnp.clip(log_w, -50, 20)), 0.0)
    sw = jax.ops.segment_sum(w, idx, num_segments=ND)
    swt = jax.ops.segment_sum(w * t, idx, num_segments=ND)
    return sw, swt
# bounce index per slot: flat = reshape(-1) of (K, MC, n_rays) -> bounce = slot // (MC*NPH)
_bk = (jnp.arange(K * MC * NPH) // (MC * NPH))
@jax.jit
def bounce_profile(sim_out):
    log_w, t, idx, tot = sim_out
    w = jnp.where(log_w > -50, jnp.exp(jnp.clip(log_w, -50, 20)), 0.0)
    bw = jax.ops.segment_sum(w, _bk, num_segments=K)
    bwt = jax.ops.segment_sum(w * t, _bk, num_segments=K)
    return bw, bwt

# EXP (one call, continuous)
sw_e, swt_e = [np.asarray(a) for a in rate_moments(jax.lax.stop_gradient(EXP(trk, jax.random.PRNGKey(0))))]
bw_e, bwt_e = [np.asarray(a) for a in bounce_profile(jax.lax.stop_gradient(EXP(trk, jax.random.PRNGKey(0))))]
# SAMP (average over realizations)
sw_s = np.zeros(ND); swt_s = np.zeros(ND); bw_s = np.zeros(K); bwt_s = np.zeros(K)
for r in range(NREAL):
    out = jax.lax.stop_gradient(SAMP(trk, jax.random.PRNGKey(1000 + r)))
    a, b = rate_moments(out); sw_s += np.asarray(a); swt_s += np.asarray(b)
    c, d = bounce_profile(out); bw_s += np.asarray(c); bwt_s += np.asarray(d)
sw_s /= NREAL; swt_s /= NREAL; bw_s /= NREAL; bwt_s /= NREAL

mt_e = np.where(sw_e > 1e-9, swt_e / np.maximum(sw_e, 1e-12), np.nan)   # rate mean time per PMT, EXP
mt_s = np.where(sw_s > 1e-9, swt_s / np.maximum(sw_s, 1e-12), np.nan)   # SAMP
print(f"#  total weight EXP={sw_e.sum():.0f}  SAMP={sw_s.sum():.0f}", flush=True)
edges = [0.05, 0.2, 0.5, 1.0, 2.0, 100]
print(f"#  occ-bucket | Npmt | wEXP/wSAMP | <t>rate_EXP | <t>rate_SAMP | dt(EXP-SAMP) ns", flush=True)
for lo, hi in zip(edges[:-1], edges[1:]):
    sel = np.where((sw_e > lo) & (sw_e <= hi))[0]
    if sel.size == 0: continue
    ok = np.isfinite(mt_e[sel]) & np.isfinite(mt_s[sel])
    dt = np.nanmean((mt_e[sel] - mt_s[sel])[ok])
    print(f"#  {lo:4.2f}-{hi:<5.2f}| {sel.size:5d} | {sw_e[sel].mean():.3f}/{sw_s[sel].mean():.3f} | "
          f"{np.nanmean(mt_e[sel]):+8.2f} | {np.nanmean(mt_s[sel]):+8.2f} | {dt:+6.3f}", flush=True)
print(f"#  bounce |  wEXP  |  wSAMP | <t>EXP | <t>SAMP   (per-bounce deposit weight & mean time)", flush=True)
for b in range(K):
    te = bwt_e[b] / max(bw_e[b], 1e-9); ts = bwt_s[b] / max(bw_s[b], 1e-9)
    print(f"#    {b:2d}   | {bw_e[b]:6.1f} | {bw_s[b]:6.1f} | {te:+6.1f} | {ts:+6.1f}", flush=True)
print(f"# READ: dt(EXP-SAMP) rate-mean +ve & occ-dep => implicit-capture PROPAGATOR is late (forward).", flush=True)
print(f"#       per-bounce: does EXP keep depositing weight at LATE bounces where SAMP (stopped@detect) is ~0?", flush=True)
