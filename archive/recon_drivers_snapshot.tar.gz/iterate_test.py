"""Follow the explicit finding: gradients honest + time-only-from-truth=3.9cm on PhotonSim => the vertex
is recoverable; the 48cm bias is the ITERATION (charge biases energy, frozen energy poisons the vertex).
Test iteration strategies + diagnose whether the energy bias is intrinsic or vertex-coupled. PhotonSim.
Usage: CUDA_VISIBLE_DEVICES=g python iterate_test.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
TAU, THR, WT = 0.3, 4.0, 0.05
SC = np.array(H.PARAM_SCALE)
SCHED = [2, 1, 0.5, 0.3, 0.2]

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star'])
def gof(WT_, TAU_, chan=2):
    f = PS.make_loss(S, WT=WT_, TAU=TAU_, THR=THR)
    return jax.jit(jax.grad(lambda th, k: f(th, k)[chan]))
gchrg = gof(0.0, TAU)
gfull = {tau: gof(WT, tau) for tau in SCHED}
gtime = {tau: gof(1.0, tau, chan=1) for tau in SCHED}

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T = []
    for s in range(steps):
        ks = jax.random.split(jax.random.PRNGKey(101 + 7919*tag + s), 6)
        G = np.stack([np.array(gfn(theta, k))*SC for k in ks]); g = G.mean(0); F = (G.T@G)/6
        dd = np.clip(np.diag(F), 1e-12, None); ev, V = np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev = np.clip(ev, 2e-2*ev.max(), None); st = np.clip(V@np.diag(1/ev)@V.T@g, -0.35, 0.35)*SC
        theta = theta - LR*jnp.array(st*(1-fr))
        if s >= steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))
def vtx(t): return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Epct(t): return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p: np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
def anneal_time(th, gd, freeze, tag0):
    for j, tau in enumerate(SCHED):
        th = gnlm(th, gd[tau], 50, freeze=freeze, tag=tag0+j)
    return th

rng = np.random.default_rng(SEED)
th0 = jnp.array(ts + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
print(f"ITER seed={SEED}  init vtx={vtx(th0):.0f}cm E={Epct(th0):+.0f}%", flush=True)

# --- DIAGNOSTIC: is the energy bias intrinsic or vertex-coupled? fit E from charge with pos/dir@TRUTH ---
thd = gnlm(jnp.array(ts.copy()), gchrg, 120, freeze=[1,2,3,4,5,6], tag=900)  # only energy moves
print(f"  [diag] charge-fit ENERGY with pos/dir frozen @TRUTH: E={Epct(thd):+.1f}%  (intrinsic energy bias)", flush=True)

# S0 baseline: charge -> freeze E -> anneal time
a = gnlm(th0, gchrg, 90, tag=1); a = anneal_time(a, gfull, [0], 10)
print(f"  S0 charge->freezeE->time:      vtx={vtx(a):5.1f}cm  E={Epct(a):+.1f}%  dir={deg(a):.2f}", flush=True)

# S1: charge -> anneal time with ENERGY FREE
b = gnlm(th0, gchrg, 90, tag=1); b = anneal_time(b, gfull, None, 20)
print(f"  S1 charge->time(E free):       vtx={vtx(b):5.1f}cm  E={Epct(b):+.1f}%  dir={deg(b):.2f}", flush=True)

# S2: ALTERNATE  (energy from charge with pos fixed)  <->  (pos/dir/t0 from time with E fixed)
c = gnlm(th0, gchrg, 90, tag=1)
for it in range(4):
    c = gnlm(c, gchrg, 40, freeze=[1,2,3,4,5,6], tag=300+it)      # energy only (pos fixed)
    c = anneal_time(c, gtime, [0], 400+it*10)                      # pos/dir/t0 only (E fixed)
print(f"  S2 alternate charge-E<->time-pos: vtx={vtx(c):5.1f}cm  E={Epct(c):+.1f}%  dir={deg(c):.2f}", flush=True)

# S3: time-only for pos from a CHARGE vertex, but energy set to the TRUE-vertex charge fit (diag upper)
d = gnlm(th0, gchrg, 90, tag=1)
d = d.at[0].set(float(thd[0]))                                     # use the intrinsic-energy estimate
d = anneal_time(d, gtime, [0], 600)
print(f"  S3 charge-pos + intrinsicE + time: vtx={vtx(d):5.1f}cm E={Epct(d):+.1f}%  dir={deg(d):.2f}", flush=True)
