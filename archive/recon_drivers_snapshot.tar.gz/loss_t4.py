"""TIER 4 — PhotonSim (real GEANT4) truth vs SIREN predictor + corrected count-conditioned loss.
Truth = is_data simulator fed the event's REAL Cherenkov photons (make_hits_data: hard detect + first-arrival +
TTS). Predictor = SIREN+DiCE expected per-photon (the Tier-5 setup). This folds in the SIREN-vs-PhotonSim
EMISSION mismatch on top of the forward implicit-capture gap. CAREFUL:
  - FIXED 400k photon buffer (>= max event count 361751) + mask (photon_data['N']=real) => NO recompile.
    Pad by TILING real photons (valid geometry; zeroed by intensity=mask).
  - True track from photon ORIGINS: SVD principal axis (direction), oriented by emission-TIME correlation
    (robust, not a z-sign heuristic); vertex = min-projection origin. Energy = PrimaryEnergy. t0=0.
  - SANITY before fitting: PhotonSim truth total charge & hits vs SIREN predictor charge at the derived truth.
Fit all 9 params (sin/cos angles, FREE t0) from the derived truth; residual vs derived truth.
Env: EVENT_START EVENT_COUNT NPHOT_PRED NKEYS STEPS.  Usage: CUDA_VISIBLE_DEVICES=g EVENT_START=0 EVENT_COUNT=1 python loss_t4.py
"""
import os, sys
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
# FIX #1 + FIX #2 default ON (opt_lab.py hardcodes both; gating them off silently inflates the PhotonSim floor
# ~22cm vs ~16cm). Override with AMP_DETACH=0 / OVERLAP_RENORM=1.0 to disable.
os.environ.setdefault('AMP_DETACH', '1'); os.environ.setdefault('OVERLAP_RENORM', '1.009')
import jax, jax.numpy as jnp, numpy as np, optax
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=4, suppress=True, linewidth=160)
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
NBUF = 400_000
NPHP = int(os.environ.get('NPHOT_PRED', '500000')); NKEYS = int(os.environ.get('NKEYS', '4')); STEPS = int(os.environ.get('STEPS', '180'))
E0 = int(os.environ.get('EVENT_START', '0')); EC = int(os.environ.get('EVENT_COUNT', '1'))
SANITY = os.environ.get('SANITY', '1') == '1'
K = 8; MC = int(os.environ.get('MAXCELL', '16')); SIGMA = float(os.environ.get("LOSS_SIGMA","2.5")); DELTA = float(os.environ.get("DELTA","1.0")); SQ = float(np.sqrt(2.0))
OPT = os.environ.get('OPT', 'adam'); START_OFF = float(os.environ.get('START_OFF', '0')); START_PIDX = int(os.environ.get('START_PIDX', '3'))
NITERS = int(os.environ.get('NITERS', '180')); RECOMP = int(os.environ.get('RECOMP', '10'))
RIDGE_EPS = float(os.environ.get('RIDGE_EPS', '0.6')); CLIP_FRAC = float(os.environ.get('CLIP_FRAC', '0.05'))
DAMP = float(os.environ.get('DAMP', '0.7')); TR = float(os.environ.get('TR', '0.3'))
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2]); NAMES = ['E', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
def th9_dir(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = np.hypot(st, ct); npp = np.hypot(sp, cp); st, ct, sp, cp = st/nt, ct/nt, sp/npp, cp/npp
    return np.array([st*cp, st*sp, ct])
def derive_truth(raw):
    # loader returns photon_origins in cm (PhotonPos mm /10). simulator divides by 100 (cm->m).
    P = np.asarray(raw['photon_origins']) / 100.0                 # cm -> m
    tt = np.asarray(raw['photon_times'])
    C = P - P.mean(0); _, _, vt = np.linalg.svd(C, full_matrices=False); d = vt[0]
    proj = C @ d
    if np.corrcoef(proj, tt)[0, 1] < 0: d = -d; proj = -proj      # orient: emission time grows along d (robust)
    vtx = P.mean(0) + proj.min() * d
    pol = float(np.arccos(np.clip(d[2], -1, 1))); az = float(np.arctan2(d[1], d[0]))
    return np.array([float(raw['energy']), vtx[0], vtx[1], vtx[2], np.sin(pol), np.cos(pol), np.sin(az), np.cos(az), 0.0]), d

print(f"# T4 PhotonSim truth  OPT={OPT} START_OFF={START_OFF}({NAMES[START_PIDX]}) MC={MC} NITERS={NITERS} NBUF={NBUF} NPHP={NPHP} NKEYS={NKEYS} STEPS={STEPS} events[{E0}:{E0+EC}] TTS={os.environ['TTS_NS']}", flush=True)
data_sim = setup_event_simulator(H.GEOM, n_photons=NBUF, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True, apply_smearing=False)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHP); ND = H.num_detectors(pred)

def pad_event(raw):
    n = int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a):
        a = np.asarray(a); reps = int(np.ceil(NBUF / n)); return jnp.asarray(np.tile(a, (reps,) + (1,) * (a.ndim - 1))[:NBUF])
    pd = {'photon_origins': tile(raw['photon_origins']), 'photon_directions': tile(raw['photon_directions']),
          'photon_times': tile(raw['photon_times']), 'N': jnp.asarray(n), 'apply_rotation': False,
          'rotation_axis': jnp.array([1., 0., 0.]), 'rotation_angle': jnp.array(0.), 'apply_translation': False,
          'translation_vector': jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths'] = tile(raw['wavelengths'])
    return pd, n

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
_AMP_DETACH = bool(os.environ.get('AMP_DETACH'))    # time term constrains arrival TIMES only, not photon counts
@jax.jit
def loss_one(th9, oc, ot, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key); ww = jnp.exp(jnp.clip(log_w, -60, 20))
    tobs = (ot - th9[8])[fi]; mu = jnp.maximum(tot, 1e-8)
    wR = jax.lax.stop_gradient(ww) if _AMP_DETACH else ww
    Rlo = jax.ops.segment_sum(wR * 0.5 * (1.0 + erf((tobs - DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Rhi = jax.ops.segment_sum(wR * 0.5 * (1.0 + erf((tobs + DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    muS = jax.lax.stop_gradient(mu) if _AMP_DETACH else mu
    S_lo = jnp.clip((muS - Rlo) / muS, 1e-12, 1.0); S_hi = jnp.clip((muS - Rhi) / muS, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(oc > 0, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    chg = jnp.sum(mu - oc * jnp.log(mu))
    return _CHG_W * chg + _TIME_W * time     # LOSS_MODE: full=1,1  charge=1,0  time=0,1
_LMODE = os.environ.get('LOSS_MODE', 'full'); _CHG_W = 1.0 if _LMODE in ('full','charge') else 0.0; _TIME_W = 1.0 if _LMODE in ('full','time') else 0.0
gradone = jax.jit(jax.value_and_grad(loss_one))
SC = jnp.asarray(SCALE9); SCn = np.asarray(SCALE9)
def fit_event(oc, ot, T0):
    """OPT=adam: start AT truth (z=0). OPT=gnrec: start at truth+START_OFF*SC on START_PIDX, GN with FD-Hessian
    recomputed every RECOMP iters, z-scaled + positive-eigen-clip + median ridge (the winning recipe from opt_lab.py)."""
    if OPT == 'adam':
        opt = optax.adam(3e-2); z = jnp.zeros(9); st = opt.init(z)
        for i in range(STEPS):
            th = T0 + z * SC; G = jnp.zeros(9)
            for s in range(NKEYS):
                _, g = gradone(th, oc, ot, jax.random.PRNGKey(s)); G = G + g
            upd, st = opt.update((G / NKEYS) * SC, st); z = optax.apply_updates(z, upd)
        return np.asarray(T0 + z * SC)
    # ---- gnrec ----
    T0n = np.asarray(T0)
    def Gm(th): return np.mean([np.asarray(gradone(jnp.asarray(th), oc, ot, jax.random.PRNGKey(s))[1]) for s in range(NKEYS)], 0)
    def ALm(th): return float(np.mean([float(gradone(jnp.asarray(th), oc, ot, jax.random.PRNGKey(s))[0]) for s in range(NKEYS)]))
    def fd_hess(th):
        Hf = np.zeros((9, 9))
        for j in range(9):
            h = 0.4 * SCn[j]; gp = Gm(th + h * np.eye(9)[j]); gm = Gm(th - h * np.eye(9)[j]); Hf[:, j] = (gp - gm) / (2 * h)
        return 0.5 * (Hf + Hf.T)
    TRACE = bool(os.environ.get('TRACE')); POLYAK = int(os.environ.get('POLYAK', '0'))  # avg th over last POLYAK iters
    th = T0n + START_OFF * SCn * np.eye(9)[START_PIDX]; M = fd_hess(th)
    th_acc = np.zeros(9); n_acc = 0
    if TRACE:
        print(f"#   TRACE loss@truth={ALm(T0n):.1f}  (start_off={START_OFF}, POLYAK={POLYAK})", flush=True)
        print(f"#   it |  loss     | gznorm | dvtx_cm  (vs derive_truth)", flush=True)
    for it in range(NITERS):
        if it % RECOMP == 0 and it > 0: M = fd_hess(th)
        g = Gm(th); gz = g * SCn; Hz = 0.5 * (M * np.outer(SCn, SCn) + (M * np.outer(SCn, SCn)).T)
        ev, V = np.linalg.eigh(Hz); ev = np.clip(ev, CLIP_FRAC * max(np.abs(ev).max(), 1e-9), None); Hz = V @ np.diag(ev) @ V.T
        lam = RIDGE_EPS * np.median(np.diag(Hz)); dz = -np.linalg.solve(Hz + lam * np.eye(9), gz)
        th = th + DAMP * np.clip(dz, -TR, TR) * SCn
        if POLYAK and it >= NITERS - POLYAK: th_acc += th; n_acc += 1   # Polyak tail-average
        if TRACE and (it % 20 == 0 or it == NITERS - 1):
            dv = float(np.sqrt(((th - T0n)[1:4] ** 2).sum())) * 100
            print(f"#   {it:3d} | {ALm(th):9.1f} | {np.linalg.norm(gz):6.1f} | {dv:7.2f}", flush=True)
    th_final = th_acc / n_acc if (POLYAK and n_acc > 0) else th
    if TRACE:
        dvp = float(np.sqrt(((th_final - T0n)[1:4] ** 2).sum())) * 100
        print(f"#   FINAL last-th: loss={ALm(th):.1f} dvtx={float(np.sqrt(((th-T0n)[1:4]**2).sum()))*100:.2f}cm | "
              f"POLYAK-th: loss={ALm(th_final):.1f} dvtx={dvp:.2f}cm  (loss@truth={ALm(T0n):.1f})", flush=True)
    return th_final

# --- optional pre-transform of the raw GEANT4 photons (rotate event / shift vertex / shift t0) ---
ROT_ANGLE = float(os.environ.get('ROT_ANGLE', '0'))      # deg, rotate origins+directions about ROT_AXIS thru the event centroid
ROT_AXIS = os.environ.get('ROT_AXIS', 'y'); SHIFT_M = os.environ.get('SHIFT_M', '0,0,0'); DT0 = float(os.environ.get('DT0', '0'))
def _rotmat(axis, deg):
    a = np.radians(deg); ca, sa = np.cos(a), np.sin(a)
    u = {'x': np.array([1.,0,0]), 'y': np.array([0,1.,0]), 'z': np.array([0,0,1.])}[axis]
    ux = np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])
    return np.eye(3)*ca + sa*ux + (1-ca)*np.outer(u, u)
RANDOMIZE = int(os.environ.get('RANDOMIZE', '0'))   # per-event isotropic direction + fiducial vertex shift (realistic mix)
RSEED = int(os.environ.get('RSEED', '0')); FIDR = float(os.environ.get('FIDR', '12')); FIDZ = float(os.environ.get('FIDZ', '12'))
def _rotmat_axis(u, deg):                            # Rodrigues rotation about arbitrary unit axis u
    a = np.radians(deg); ca, sa = np.cos(a), np.sin(a); u = u/np.linalg.norm(u)
    ux = np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])
    return np.eye(3)*ca + sa*ux + (1-ca)*np.outer(u,u)
def random_transform(raw, ev):                       # isotropic dir (cos b uniform) + uniform fiducial shift, seeded by ev
    rng = np.random.default_rng(RSEED*100003 + ev)
    beta = np.degrees(np.arccos(rng.uniform(-1,1))); al = rng.uniform(0,2*np.pi)
    axis = np.array([-np.sin(al), np.cos(al), 0.0])  # horizontal axis -> tilts the ~vertical gun track to polar beta
    rr = FIDR*np.sqrt(rng.uniform()); ph = rng.uniform(0,2*np.pi)
    shift_cm = np.array([rr*np.cos(ph), rr*np.sin(ph), rng.uniform(-FIDZ,FIDZ)])*100.0
    raw = dict(raw); O = np.asarray(raw['photon_origins']).astype(float); D = np.asarray(raw['photon_directions']).astype(float)
    R = _rotmat_axis(axis, beta); c = O.mean(0)
    raw['photon_origins'] = (O - c) @ R.T + c + shift_cm; raw['photon_directions'] = D @ R.T
    return raw, beta, shift_cm/100.0
def transform_raw(raw):
    if ROT_ANGLE == 0 and SHIFT_M == '0,0,0' and DT0 == 0: return raw
    raw = dict(raw); O = np.asarray(raw['photon_origins']).astype(float)        # cm
    D = np.asarray(raw['photon_directions']).astype(float); R = _rotmat(ROT_AXIS, ROT_ANGLE)
    c = O.mean(0); shift_cm = np.array([float(x) for x in SHIFT_M.split(',')]) * 100.0
    raw['photon_origins'] = (O - c) @ R.T + c + shift_cm                         # rotate about centroid, then translate
    raw['photon_directions'] = D @ R.T
    raw['photon_times'] = np.asarray(raw['photon_times']).astype(float) + DT0
    return raw
if ROT_ANGLE or SHIFT_M != '0,0,0' or DT0:
    print(f"# TRANSFORM rot={ROT_ANGLE}deg/{ROT_AXIS}  shift={SHIFT_M}m  dt0={DT0}ns", flush=True)

import time as _time
rows = []
for ev in range(E0, E0 + EC):
    _t0 = _time.time()
    if RANDOMIZE:
        raw, _beta, _shift = random_transform(read_photon_data_from_photonsim(ROOT, ev), ev)
    else:
        raw = transform_raw(read_photon_data_from_photonsim(ROOT, ev)); _beta = -1; _shift = np.zeros(3)
    th9_star, d = derive_truth(raw)
    if DT0: th9_star[8] = DT0        # photon_times pre-shifted by DT0 -> truth t0 IS DT0 (measure recovery vs it)
    T0 = jnp.asarray(th9_star)
    pd, n = pad_event(raw)
    TRUTH_NDET = int(os.environ.get('TRUTH_NDET', '1'))   # >1: AVERAGE truth charge over NDET detection keys (kill PMT shot noise)
    if TRUTH_NDET > 1:
        cc = np.zeros(ND)
        for r in range(TRUTH_NDET):
            c_, t_ = jax.lax.stop_gradient(data_sim(sc2track(T0), jax.random.PRNGKey(7000 + ev + 1000*r), pd)); cc += np.asarray(c_)
        c = cc / TRUTH_NDET; t = np.asarray(t_)
    else:
        c, t = jax.lax.stop_gradient(data_sim(sc2track(T0), jax.random.PRNGKey(7000 + ev), pd)); c = np.asarray(c); t = np.asarray(t)
    oc = jnp.asarray(np.asarray(c)); ot = jnp.asarray(np.where(np.asarray(c) > 0, np.asarray(t), 0.0))
    nhit = int((np.asarray(c) > 0).sum()); qtot = float(np.asarray(c).sum())
    if SANITY:
        # SIREN predictor charge at the derived truth (should match PhotonSim total to ~1.4% per B7)
        _, _, _, q_pred = jax.lax.stop_gradient(pred(sc2track(T0), jax.random.PRNGKey(0)))
        qp = float(np.asarray(q_pred).sum()); nph = int((np.asarray(q_pred) > 1e-6).sum())
        print(f"#  ev{ev} N_ph={n}  vtx=({th9_star[1]:+.3f},{th9_star[2]:+.3f},{th9_star[3]:+.3f}) pol={np.degrees(np.arccos(d[2])):.1f}deg",
              flush=True)
        print(f"#    SANITY  PhotonSim truth: {nhit} hits, Q={qtot:.0f}  |  SIREN pred: {nph} lit, Q={qp:.0f}  ratio(pred/truth)={qp/max(qtot,1):.3f}", flush=True)
    th = fit_event(oc, ot, T0); dlt = th - th9_star
    dvtx = float(np.sqrt(dlt[1]**2 + dlt[2]**2 + dlt[3]**2))
    dd = th9_dir(th); dang = float(np.degrees(np.arccos(np.clip(np.dot(dd, d), -1, 1))))
    dpos = dlt[1:4]; dlon = float(abs(np.dot(dpos, d))); dtra = float(np.sqrt(max(dvtx**2 - dlon**2, 0.0)))  # along/perp track
    pol = float(np.degrees(np.arccos(np.clip(d[2], -1, 1)))); shmag = float(np.linalg.norm(_shift)); el = _time.time()-_t0
    rows.append([ev, dlt[0], dlt[1], dlt[2], dlt[3], dvtx, dang, dlt[8], pol, shmag, dlon, dtra])
    print(f"#  ev{ev:3d} pol{pol:4.0f} sh{shmag:4.1f}m  E{dlt[0]:+7.1f}  |vtx|{dvtx*100:5.1f}cm (lon{dlon*100:5.1f} tra{dtra*100:5.1f})  dir{dang:5.2f}deg  t0{dlt[8]:+.2f}  [{el:.0f}s]", flush=True)
np.savetxt(f"/tmp/t4_{os.environ.get('TAG','x')}_ev_{E0}.txt", np.array(rows), fmt="%.5f")
print(f"# SLICE[{E0}:{E0+EC}] saved", flush=True)
