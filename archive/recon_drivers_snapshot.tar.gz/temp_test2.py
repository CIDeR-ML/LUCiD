"""One overlap mode per run (env): PRED_TEMP (''/None or 0.1), OVERLAP (''=default, 'erf','logistic').
Reports gradient (charge NLL, meaningful position gradient) AD-vs-FD cosine+magnitude, and Hessian
(sum q) AD-vs-FD cosine, self-consistent SIREN truth, sanitizer bypassed.
Usage: CUDA_VISIBLE_DEVICES=g PRED_TEMP=0.1 OVERLAP=erf python temp_test2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True)
PT=os.environ.get('PRED_TEMP',''); temp=None if PT in ('','none','None') else float(PT)
OV=os.environ.get('OVERLAP','')
if OV: os.environ['OVERLAP_ANALYTIC']=OV   # the real flag read inside lucid/overlap.py
NKEYS=16; NPH=40000; SC=np.array(H.PARAM_SCALE)
S=PS.setup(event=0,nphot=NPH,truth_source='siren',pred_temperature=temp,truth_key=0)
ts=np.array(S['theta_star']); pred=S['pred']; oc=S['oc']
def cnll(th,k):
    _,_,_,q=pred(H.theta_to_track(th),k); return jnp.sum(q-oc*jnp.log(q+1e-8))
def sq(th,k):
    _,_,_,q=pred(H.theta_to_track(th),k); return jnp.sum(q)
gc=jax.jit(jax.grad(cnll)); lc=jax.jit(cnll); hess=jax.jit(jax.hessian(sq)); gsq=jax.jit(jax.grad(sq))
ks=[jax.random.PRNGKey(60000+i) for i in range(NKEYS)]
gbar=lambda fn,th: np.mean([np.array(fn(jnp.asarray(th),k)) for k in ks],0)
lbar=lambda th: np.mean([float(lc(jnp.asarray(th),k)) for k in ks])
# GRADIENT (charge NLL) AD vs FD at a +0.3*scale x-offset
thg=ts.copy(); thg[1]+=0.3*SC[1]
gad=gbar(gc,thg)*SC
gfd=np.array([(lbar(thg+np.eye(7)[j]*0.4*SC[j])-lbar(thg-np.eye(7)[j]*0.4*SC[j]))/(2*0.4)*SC[j] for j in range(7)])
gcos=float(gad@gfd/(np.linalg.norm(gad)*np.linalg.norm(gfd)+1e-12)); gmag=np.linalg.norm(gad)/(np.linalg.norm(gfd)+1e-12)
# HESSIAN (sum q) AD vs FD at truth
Had=np.mean([np.array(hess(jnp.asarray(ts),k)) for k in ks],0)*np.outer(SC,SC)
Hfd=np.zeros((7,7))
for j in range(7): Hfd[:,j]=(gbar(gsq,ts+np.eye(7)[j]*0.3*SC[j])-gbar(gsq,ts-np.eye(7)[j]*0.3*SC[j]))/(2*0.3)*SC
Hfd=0.5*(Hfd+Hfd.T)
hcos=float(Had.ravel()@Hfd.ravel()/(np.linalg.norm(Had.ravel())*np.linalg.norm(Hfd.ravel())+1e-12))
pb=slice(1,6); hcos_pos=float(Had[pb,pb].ravel()@Hfd[pb,pb].ravel()/(np.linalg.norm(Had[pb,pb].ravel())*np.linalg.norm(Hfd[pb,pb].ravel())+1e-12))
print(f"MODE temp={PT or 'None'} overlap={OV or 'default'}: GRAD cos={gcos:.3f} mag={gmag:.3f} | HESS cos={hcos:.3f} pos-block cos={hcos_pos:.3f}", flush=True)
