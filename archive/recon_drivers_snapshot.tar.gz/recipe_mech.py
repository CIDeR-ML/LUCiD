"""Mechanism-driven recipe (from mechanism_diag): the charge SHAPE term is biased for vertex/direction
(vtx_perp -1.0m!), TIME is unbiased for vertex+dir+t0, total-charge is unbiased for energy.
=> energy<-total charge ; vertex+dir+t0<-TIME ; shape used ONLY to seed the basin (then dropped).
Stage0: shape+E (few steps, rough vertex). Stage1: E_tot + TIME-only, annealed TAU, many steps (NO shape).
Compares against keeping the shape term on. PhotonSim, cold start, N seeds.
Usage: CUDA_VISIBLE_DEVICES=g [MODE=drop|keep] python recipe_mech.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
MODE=os.environ.get('MODE','drop')          # drop = shape only in stage0; keep = shape in stage1 too
THR=float(os.environ.get('THR','4')); SC=np.array(H.PARAM_SCALE)
SEEDS=[int(x) for x in os.environ.get('SEEDS','1,2,3,4,5,6').split(',')]
SCHED=[float(x) for x in os.environ.get('SCHED','3,1.5,0.8,0.4,0.2').split(',')]
ST1=int(os.environ.get('ST1','80'))          # steps per TAU level in stage1
S=PS.setup(event=0,nphot=80_000,truth_source='photonsim',pred_temperature=0.1)
ts=np.array(S['theta_star'])
# stage0 grad: shape + total energy (wT small)
g0=jax.jit(jax.grad(lambda th,k: (lambda r:(100*r[0]+r[1]))(PS.make_loss_sep(S,wE=100,wS=1,wT=0.0,TAU=1.0,THR=THR)(th,k))))
# stage1 grads per TAU: total energy + time (+ shape if MODE=keep)
wS1 = 1.0 if MODE=='keep' else 0.0
g1={tau: jax.jit(jax.grad(lambda th,k,t=tau: PS.make_loss_sep(S,wE=100,wS=wS1,wT=1.0,TAU=t,THR=THR)(th,k)[3]))
    for tau in SCHED}
def gnlm(theta,gfn,steps,tag=0,LR=0.4,LM=0.05,tail=30):
    T=[]
    for s in range(steps):
        kk=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in kk]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st)
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t):return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t):return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
print(f"RECIPE MODE={MODE} (shape in stage1={MODE=='keep'}) sched={SCHED} ST1={ST1}",flush=True)
Vs=[];Ds=[];Es=[];Tt=[]
for sd in SEEDS:
    rng=np.random.default_rng(sd)
    th=jnp.array(ts+rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
    th=gnlm(th,g0,70,tag=1)                                  # stage0: shape+E -> rough basin
    v0=vtx(th)
    for j,tau in enumerate(SCHED): th=gnlm(th,g1[tau],ST1,tag=2+j)   # stage1: E+time(+shape if keep)
    Vs.append(vtx(th));Ds.append(deg(th));Es.append(Ep(th));Tt.append(float(th[6]-ts[6]))
    print(f"  seed {sd}: stage0_vtx={v0:.0f}cm -> vtx={vtx(th):5.1f}cm E={Ep(th):+.1f}% dir={deg(th):.2f}deg t0={Tt[-1]:+.2f}",flush=True)
print(f"RECIPE SUMMARY MODE={MODE}: vtx={np.mean(Vs):.1f}+-{np.std(Vs):.1f}cm (med {np.median(Vs):.1f}) "
      f"dir={np.mean(Ds):.2f}+-{np.std(Ds):.2f}deg E={np.mean(Es):+.1f}+-{np.std(Es):.1f}% t0={np.mean(Tt):+.2f}ns",flush=True)
