"""Does CRN finite-difference converge to AD as the step shrinks? If yes, the pathwise AD
gradient is correct and the earlier mismatch was finite-step grid-reassignment jumps (which
vanish as h->0). Test on clean params (z, energy) at temperature=1.0 (smooth overlap)."""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import poisson_nll, first_arrival_nll

K, NPHOT = 7, 30_000
pred = H.build_predictor(temperature=1.0, K=K, n_photons=NPHOT)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 0.0])
oc, ot, hit = H.gen_truth(truth, theta_star, jax.random.PRNGKey(7))
key = jax.random.PRNGKey(123)

def charge_loss(th):
    _, _, _, q = pred(H.theta_to_track(th), key)
    return jnp.sum(poisson_nll(oc, q))

def time_loss(th):
    lw, ft, fi, _ = pred(H.theta_to_track(th), key)
    return jnp.sum(jnp.where(hit, first_arrival_nll(lw, ft, fi, ot, 1.5, ND), 0.0))

theta0 = theta_star + 0.3 * H.PARAM_SCALE
eye = np.eye(7)
for nm, lf in [('charge', charge_loss), ('time', time_loss)]:
    L = jax.jit(lf)
    g_ad = np.array(jax.jit(jax.grad(lf))(theta0))
    print(f"\n== {nm} : FD convergence to AD as h->0 ==", flush=True)
    for pi, pname in [(3, 'z'), (0, 'energy'), (4, 'polar')]:
        print(f"  param {pname:6s}  AD={g_ad[pi]:+.4f}", flush=True)
        for hf in [3e-2, 1e-2, 3e-3, 1e-3, 3e-4]:
            hh = hf * float(H.PARAM_SCALE[pi])
            fd = (float(L(theta0 + hh * eye[pi])) - float(L(theta0 - hh * eye[pi]))) / (2 * hh)
            print(f"     h={hf:.0e}*scale  FD={fd:+.4f}   FD/AD={fd/(g_ad[pi]+1e-9):+.2f}", flush=True)
