"""END-TO-END v3: charge-geometry longitudinal vertex (breaks the timing degeneracy) -> refiner.
v2 proved the longitudinal-vertex<->t0 is an EXACT timing degeneracy (shift V along d by eps, t0 by eps/c =>
all Cherenkov arrival times invariant). Timing fixes TRANSVERSE vertex + direction only; the LONGITUDINAL
vertex must come from CHARGE geometry: the vertex is the UPSTREAM EDGE of Cherenkov emission. Recipe:
  1. direction d = charge-weighted ring axis sum q*unit(PMT-centroid)  [iterate 2x: recompute axis from V]
  2. vertex line passes through the charge centroid Cq along d
  3. longitudinal lambda = low-quantile of emission coord s* = (P-Cq).d - a_perp/sqrt(n^2-1)  (track START)
  4. t0 = low-quantile of (t_obs - [a_par + a_perp*sqrt(n^2-1)]/c)  at the fixed vertex  (early/direct edge)
  5. energy from total charge
Then the lE+lT_gd sigma-annealed refiner polishes. Env: TRUTH TTS_NS NKG SPS WT TKS EVENT NW QL_LON QL_T0.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 python endtoend3.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000'))
WT = float(os.environ.get('WT', '1.0')); THR = float(os.environ.get('THR', '4.0'))
NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '16')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0'))
NW = float(os.environ.get('NW', '1.34')); QL_LON = float(os.environ.get('QL_LON', '0.04')); QL_T0 = float(os.environ.get('QL_T0', '0.08'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)
C = 0.299792; G = float(np.sqrt(NW ** 2 - 1.0)); COT = 1.0 / G  # sqrt(n^2-1), cot(theta_c)=1/sqrt(n^2-1)
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = np.array(det.all_points)

def wquantile(x, w, qf):
    o = np.argsort(x); xs = x[o]; ws = w[o]; cw = np.cumsum(ws) / (ws.sum() + 1e-9)
    return float(np.interp(qf, cw, xs))

def axis_from(V, P, q):
    dv = P - V[None, :]; dv = dv / (np.linalg.norm(dv, axis=1, keepdims=True) + 1e-9)
    ax = (q[:, None] * dv).sum(0); return ax / (np.linalg.norm(ax) + 1e-9)

def geom_seed(oc, ot, hi):
    hm = np.array(hi); P = DP[hm]; tobs = np.array(ot)[hm]; q = np.array(oc)[hm]
    Cq = (q[:, None] * P).sum(0) / q.sum()                      # charge centroid (on the track axis)
    d = axis_from(Cq, P, q)                                     # rough direction
    V = Cq.copy()
    for _ in range(2):                                          # iterate direction<->longitudinal vertex
        a = P - V[None, :]; apar = a @ d; aperp = np.sqrt(np.maximum((a * a).sum(1) - apar ** 2, 1e-9))
        s_emit = apar - aperp * COT                             # emission coord from V (vertex at s=0)
        lam = wquantile(s_emit, q, QL_LON)                      # upstream edge -> track start
        V = V + lam * d
        d = axis_from(V, P, q)                                  # refine axis from the updated vertex
    # t0 from the Cherenkov wavefront at the fixed vertex (early/direct edge)
    a = P - V[None, :]; apar = a @ d; aperp = np.sqrt(np.maximum((a * a).sum(1) - apar ** 2, 1e-9))
    t0 = wquantile(tobs - (apar + aperp * G) / C, q, QL_T0)
    polar = float(np.arccos(np.clip(d[2], -1, 1))); azim = float(np.arctan2(d[1], d[0]))
    E = float(estimate_muon_energy_from_photon_count(float(q.sum())))
    return np.array([E, V[0], V[1], V[2], polar, azim, t0])

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, qq = pred(H.theta_to_track(theta), key); sumq = jnp.sum(qq); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WT * lT
gfn = jax.jit(jax.grad(loss))

def refine(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g
            mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
def lon(t):  # signed longitudinal vertex error along truth direction
    dt = np.array([np.sin(ts[4])*np.cos(ts[5]), np.sin(ts[4])*np.sin(ts[5]), np.cos(ts[4])])
    return float(((np.array(t)-ts)[1:4] @ dt) * 100)
def report(tag, th): return f"{tag}: vtx={vtx(th):6.1f}cm (lon={lon(th):+6.0f}) dir={degf(th):5.2f}deg t0_err={abs(th[6]-ts[6]):5.2f}ns E_err={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"

print(f"# ENDTOEND3 TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} NW={NW} QL_LON={QL_LON} QL_T0={QL_T0} (charge-geom longitudinal seed -> refiner)", flush=True)
print(f"#   truth theta = {ts}", flush=True)
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0 = geom_seed(oc, ot, hi); thf = refine(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    print(f"  key {tk}  {report('SEED ', th0)}", flush=True)
    print(f"  key {tk}  {report('FINAL', thf)}", flush=True)
SE = np.array([[vtx(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():6.1f}cm dir={SE[:,1].mean():5.2f}deg t0={SE[:,2].mean():5.2f}ns E={SE[:,3].mean():5.1f}%", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():6.1f}cm dir={FE[:,1].mean():5.2f}deg t0={FE[:,2].mean():5.2f}ns E={FE[:,3].mean():5.1f}%  TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
