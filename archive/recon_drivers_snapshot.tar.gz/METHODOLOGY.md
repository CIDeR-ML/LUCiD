# Reconstruction methodology — full record

Track reconstruction in LUCiD (SK water-Cherenkov, units m / ns / MeV). Goal: fit a charged-track's
9 parameters from per-PMT (charge, first-arrival time) against a differentiable photon simulator.

## 1. The two forward modes (what is "truth" vs "predictor")

The SAME factory (`setup_event_simulator`) builds both; they differ only in three flags.

| stage            | TRUTH (the "data")                    | PREDICTOR (the differentiable model)     |
|------------------|---------------------------------------|------------------------------------------|
| emission         | SIREN (`is_data=False`) or PhotonSim (`is_data=True`) | SIREN (always)            |
| propagator       | `use_expected_value=False` (sampling: hard Bernoulli scatter/reflect/absorb/detect; one quantum) | `use_expected_value=True` (expected / implicit-capture: continuous Rao-Blackwellised deposits) |
| overlap          | `temperature=None` (hard top-hat)     | `temperature=0.1` (soft Gaussian, needed for the position gradient) |
| readout          | `hit_mode='realistic'` → `make_hits_data` (Bernoulli QE coin + hard first-arrival `segment_min` + per-photon TTS) | `hit_mode='per_photon'` → `make_hits_likelihood` (continuous per-photon `log_w`, times, and per-PMT `total_charge`) |

Shared (identical code): SIREN ray gen, photon-number normalization `N(E)`, emission times
`predict_t0(distance)`, per-photon optics (scatter/abs/mie/qe from medium at wavelength), the
geometry / sensor-cell intersection, the K-iteration `lax.scan`. Full 22-part enumeration in
`COMPONENTS.md`.

Key constraints (always): K≥8 scatter iterations, `max_sensors_per_cell` (MAXCELL) ≥16. Truth time
in the detector frame (t0 added). Use GPUs (never CPU); never two jobs on one GPU.

## 2. Track parameterization

9-vector `th9 = [E, x, y, z, s_t, c_t, s_p, c_p, t0]` with the direction built from **sin/cos** pairs:
`d = [sinθ·cosφ, sinθ·sinφ, cosθ]`, each (s,c) renormalized to its unit circle, then
`θ = atan2(s_t,c_t)`, `φ = atan2(s_p,c_p)`. Reason: raw (polar, azim) had a spurious azimuth
sign-flip "kink" that was a poorly-conditioned-coordinate + noise artifact, not a physical ridge;
sin/cos removes it and gives a reliable gradient sign. (Quaternions also work but are over-parameterized;
sin/cos is the natural minimal choice.)

`SCALE9 = [50 MeV, 0.2 m, 0.2 m, 0.2 m, 0.02, 0.02, 0.02, 0.02, 0.2 ns]` — per-parameter step
scales; the optimizer works in `z = (th9 − th9_0)/SCALE9` so all directions are comparable.

## 3. The loss — count-conditioned Poisson first-arrival

Detected photons at PMT i form an inhomogeneous Poisson process with rate
`r_i(t) = Σ_j w_ij · N(t; τ_ij, σ²)` where w_ij = per-photon QE-weighted detection weight,
τ_ij = predicted arrival time, σ = per-photon time resolution (TTS).

Define per PMT:
- total / expected charge   `μ_i = Σ_j w_ij`   ( = R_i(∞) )
- cumulative rate to t       `R_i(t) = Σ_j w_ij · Φ((t − τ_ij)/σ)`,  Φ(x)=½(1+erf(x/√2))
- NORMALIZED survival        `S_i(t) = 1 − R_i(t)/μ_i`   (fraction arriving after t; amplitude-independent)

FACTORIZE the per-PMT likelihood (the central idea):
    L_i = Poisson(n_i ; μ_i)          [CHARGE: the count]
        × order-statistic(t_i | n_i, S_i)   [TIME: the first-arrival, conditioned on the OBSERVED n_i]

CHARGE term (per PMT, summed over ALL sensors):
    nll_charge_i = μ_i − n_i · log μ_i           (Poisson NLL, const dropped)

TIME term (only over hit PMTs, oc>0): given n_i iid draws from f=r/μ, P(first arrival > t) = S(t)^n.
Binned with width Δ around the observed time t_i:
    P(t_i ∈ [t−Δ/2, t+Δ/2]) = S_lo^{n} − S_hi^{n},   S_lo=S(t_i−Δ/2), S_hi=S(t_i+Δ/2)
    nll_time_i = −n·log S_lo − log1mexp( n·(log S_hi − log S_lo) )
where `log1mexp(a)=log(1−exp(a))` computed stably (a≤−1e-7; branch at −log2:
`a>−0.693 → log(−expm1(a))` else `log1p(−exp(a))`).

Total loss = Σ_i nll_charge_i + Σ_{i: n_i>0} nll_time_i.

### What this fixed vs the OLD loss
- OLD `first_arrival_nll` (order statistic with the PREDICTED count N_s=μ, not the observed n) biased
  the fit by +188 MeV / −0.58 m: using predicted μ in the time rate adds a spurious −log μ that
  the joint MLE drives to μ≈n+1 per lit PMT. The count-conditioned form (observed n, NORMALIZED
  survival) removes that. Validated: argmin sits at truth for charge (E, vertex mm-cm), energy exact.
- `counts_loss` NORMALIZATION (dividing by Σ true) kills the energy constraint — use the raw Poisson NLL.

## 4. Hyperparameters

| symbol | value | meaning |
|--------|-------|---------|
| σ (SIGMA / LOSS_SIGMA) | 2.5 ns (TTS); 0.15 in the TTS=0 study | per-photon time resolution in S(t); MATCH to the truth TTS |
| Δ (DELTA) | 1.0 ns | first-arrival time bin width (result is Δ-INSENSITIVE) |
| K | 8 | scatter/bounce iterations (truth & predictor; ≥8 required) |
| MAXCELL | 16 | max sensors per geometry cell (≥16 required; 4 truncates charge ~10% & breaks the Hessian) |
| temperature | 0.1 (pred), None (truth) | soft-overlap σ = 0.1·sensor_radius; needed for the charge→position gradient |
| NPH | 500,000 | photons per event (truth & predictor) — bugs hide at 50k |
| OVERLAP_RENORM | 1.009 (SK) | soft-overlap charge renormalization constant (FIX #1) |
| Adam lr | 3e-2 | in SCALED params |
| STEPS | 180 | Adam steps per event |
| NKEYS | 4 (fit) | predictor keys averaged per gradient (common random numbers) |
| TTS_NS (env) | 2.5 | per-photon TTS in the truth sample engine (read at import → set per-process) |

## 5. The two FIXES (the substantive findings)

### FIX #1 — soft-overlap renormalization (forward)   `lucid/overlap.py`, env `OVERLAP_RENORM`
The soft overlap f(d) = mass of a σ-Gaussian (centered at the photon) inside the sensor disk.
Convolution conserves the integral ONLY if all the spread is captured; the fraction landing in the
GAPS between sensors (SK ~40% photocoverage) is LOST → the soft total UNDER-counts the hard top-hat by
~1% (worse where coverage is sparse). A single GLOBAL constant C = hard_total/soft_total (=1.009 for
SK) multiplies the soft `overlap_prob` (interp + cubic branches). It is a pure SCALE → the position
gradient DIRECTION is unchanged (verified: dLoss/dz +303.6→+304.7). Default `OVERLAP_RENORM=1.0`
(OFF, byte-identical to production). C is per-DETECTOR (recalibrate for HK/WCTE).
Effect: total charge 0.992→1.0005, charge-only energy argmin +12→+3.5 MeV.

### FIX #2 — amplitude detach in the time term (loss)   env `AMP_DETACH`
The first-arrival TIME term must constrain arrival TIMES (geometry, direction, t0) — NOT photon
counts (energy/charge is the CHARGE term's job). But the survival S=1−R/μ carries the amplitude
(the weights w_ij in R and the total μ), so it injects an energy gradient through dμ/dE; root-caused
(`loss_timeenergy2.py`): time-only energy argmin −190 MeV with the amplitude live, +0.0 with it
detached. FIX: stop-gradient the WHOLE amplitude — both the per-photon weights `ww` in R AND `μ` in
the denominator — while keeping the arrival times `ft` LIVE:
    wR  = stop_gradient(ww);   muS = stop_gradient(mu)
    S_lo = (muS − segment_sum(wR·Φ(t−Δ/2)))/muS ;  S_hi = (muS − segment_sum(wR·Φ(t+Δ/2)))/muS
The time term then has NO amplitude gradient → energy/charge-neutral, constrains only timing/geometry.
WARNING: detaching μ ALONE (leaving R's weights live = inconsistent survival) BLOWS UP to +214 MeV /
+20% — the two MUST be detached together.
Effect (Tier-5, 20 SIREN events, both fixes on): energy −12.9→+2.8 MeV, vertex RMS 13→8.5 cm,
direction 0.54°→0.26°. Clean time↔charge factorization: charge→energy+longitudinal; time→transverse+dir+t0.

## 6. The optimizer

Per event: Adam (`optax.adam(3e-2)`) for STEPS=180 in scaled params z, starting from truth (to isolate
the loss/forward from the seeder/basin). Gradient = mean over NKEYS=4 predictor keys (common random
numbers reduce the per-step Monte-Carlo noise). `t0` is a FREE parameter (absorbs the TTS first-arrival
order-statistic offset; a fixed/external t0 instead converts that ~0.5 ns into ~0.12 m of vertex bias).

## 7. Code changed (all env-gated, default OFF / byte-identical to production)

- `lucid/overlap.py`            — `OVERLAP_RENORM` multiplier on the soft overlap (FIX #1).
- `loss_t5.py` / `loss_t4.py`   — `AMP_DETACH` (FIX #2), `MU_DETACH` (the broken variant, kept as a warning),
                                  `LOSS_SIGMA`, `TAG`; the count-conditioned loss `loss_one`.
- `lucid/simulation/photon_step.py`   — `PSTEP_DBG=detect_hard` diagnostic (refuted scatter-RB hypothesis).
- `lucid/simulation/sensor_response.py` — `LIK_CHG_NOTIME`, `DATA_CHG_NOTIME` diagnostics (both refuted).

TODO: port FIX #1 + FIX #2 into the PRODUCTION loss (`lucid/losses.py` / `recon_harness.make_loss`).

## 8. Methodology principles (hard-won; ignore at your peril)

- **GRID-MIN, not a wide global parabola.** A least-squares parabola over a wide window on a weakly-curved
  ASYMMETRIC profile reports a spurious vertex (~4 cm here). Use the grid minimum or a LOCAL 3-point
  parabola at the min. (This artifact masqueraded as a "6 cm structural cause" for a long time.)
- **Matched-key self-consistency is CIRCULAR.** Predictor reconstructing its own realization is exactly
  the truth by Gibbs — it tests nothing. The real test is predictor vs the SAMPLE-engine truth, with
  INDEPENDENT key sets, at HIGH statistics; then a residual that shrinks as 1/√N is noise (not structural).
- **obs as JITTED ARGUMENTS**, never `jit(make_loss(obs))` in a loop (recompiles the 500k forward, ~16 s/event).
- **`jax.lax.map`, not `vmap`,** for the per-time-grid survival (vmap materializes the 64M-photon erf array
  ×grid → 200 GB OOM). For the joint-fit gradient, cap NREAL/NKEYS (vmap-over-realizations grad OOMs).
- **Per-event INTEGER-count obs** for gradients (a fractional mean-of-counts in S^n misleads).
- **PhotonSim**: FIXED photon buffer (400k ≥ max event 361,751) + `photon_data['N']` mask, pad by TILING
  real photons (valid geometry, zeroed by the intensity mask) → no per-event recompile from variable counts.
  True track from photon ORIGINS: SVD principal axis (oriented by emission-TIME correlation, not a z-sign
  heuristic), vertex = min-projection origin, energy = PrimaryEnergy.
- **Engine toggles in SEPARATE processes** (monkeypatching a shared `custom_vjp` mid-process collides with
  JAX's primal-jaxpr cache → false "byte-identical"). cwd must be `LUCiD_recon`.

## 9. The investigation arc & final results

Started from "TTS=0 + SIREN should reconstruct perfectly."
1. **Loss form**: the OLD order-stat time term biased +188 MeV/−0.58 m → replaced by the count-conditioned
   Poisson first-arrival (above), which is exactly unbiased.
2. **"−6 cm structural charge bias"**: did NOT exist — it was the parabola-fit artifact + finite-sample
   key-noise. The charge forward is self-consistent (grid-min at truth; diff-engine residual →0 as 1/√N).
3. **Real FIX #1**: soft-overlap ~1% under-count → `OVERLAP_RENORM`.
4. **Real FIX #2**: the time term's amplitude coupling pulled energy −1.2% (masked by #1's under-count) →
   `AMP_DETACH`.

Final realized residuals (20 SIREN / 10 PhotonSim events; both fixes on; fit from truth):

| truth     | TTS | energy   | vtx systematic | |vtx| RMS | dir    | t0       |
|-----------|-----|----------|----------------|----------|--------|----------|
| SIREN     | 2.5 | +0.26 %  | 2.4 cm         | 8.5 cm   | 0.26°  | −0.61 ns |
| SIREN     | 0   | +0.21 %  | 1.7 cm         | 7.0 cm   | 0.52°  | −0.09 ns |
| PhotonSim | 2.5 | −0.21 %  | 3.7 cm         | 18.1 cm  | 1.77°  | −0.16 ns |
| PhotonSim | 0   | +0.22 %  | 1.7 cm         | 7.4 cm   | 0.81°  | −0.02 ns |

Reading: energy unbiased (~0.2%, TTS- and truth-independent). Vertex SYSTEMATIC ~1.7–3.7 cm (≈unbiased);
the |vtx| RMS is per-event CHARGE SHOT-NOISE. The realistic ~18 cm PhotonSim vertex is DOMINATED by the
2.5 ns detector TTS (→7.4 cm at TTS=0), NOT the SIREN-vs-GEANT emission gap. The t0 offset is purely the
TTS first-arrival order-statistic (collapses at TTS=0). Remaining frontier = SIREN emitter direction
fidelity (PhotonSim dir 0.81° vs SIREN 0.52° at TTS=0).
