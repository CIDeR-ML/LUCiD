"""LOCAL STRUCTURE near the minimum (TTS smearing on). For each term (lE,lS,lT), over M data realizations
at truth, compute the score (gradient). Reports:
 1. per-term gradient MEAN (bias) and per-term Fisher = cov(score) (curvature).
 2. per-term gradient ALIGNMENT cos(g_a, g_b) per data key (do terms AGREE on the descent direction near
    the min, or conflict = model mismatch?).
 3. COMBINED Fisher eigenVECTORS: the soft (degenerate) directions = poorly-determined param combos, with
    their CRB (1/sqrt(eig)) and physical composition.
 4. which TERM constrains each eigendirection: v^T F_term v for term in {E,S,T} along each combined eigenvector
    -> shows if e.g. charge breaks a timing degeneracy.
Set TTS_NS, TAU on cmdline. Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 TAU=2.5 python local_struct.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True, linewidth=170)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '150000'))
M = int(os.environ.get('M', '48')); TAU = float(os.environ.get('TAU', '2.5')); THR = float(os.environ.get('THR', '4.0'))
NAMES = H.PARAM_NAMES; SC = np.array(H.PARAM_SCALE)
S = PS.setup(event=0, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = jnp.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def fa_shape(lw, ft, fi, tobs, tau):
    t_obs = tobs[fi]; x = (t_obs - ft) / tau
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.where(empty, 0.0, -lf - (Ns - 1.0) * l1mf)
def mk(term):
    def f(theta, key, oc, ot, hi):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
        if term == 'E': return ((sumq - sumobs) / sumobs) ** 2 * 100.0
        if term == 'S': return -jnp.sum(oc * jnp.log(q / (sumq + 1e-8) + 1e-8)) / sumobs * 100.0
        tmask = hi & (oc >= THR); return jnp.sum(jnp.where(tmask, fa_shape(lw, ft, fi, ot - theta[6], TAU), 0.0))
    return jax.jit(jax.grad(f))
gE, gS, gT = mk('E'), mk('S'), mk('T')
GE, GS, GT = [], [], []
for m in range(M):
    oc, ot, hi = regen(3000 + m); pk = jax.random.PRNGKey(m)
    GE.append(np.array(gE(ts, pk, oc, ot, hi)) * SC); GS.append(np.array(gS(ts, pk, oc, ot, hi)) * SC); GT.append(np.array(gT(ts, pk, oc, ot, hi)) * SC)
GE, GS, GT = np.array(GE), np.array(GS), np.array(GT)
print(f"# LOCAL STRUCTURE TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} TAU={TAU} M={M} (scaled units)", flush=True)

# 1. per-term bias + diag Fisher
for nm, G in [('lE', GE), ('lS', GS), ('lT', GT)]:
    mean = G.mean(0); F = (G.T @ G) / M
    print(f"[{nm}] |grad_mean|/|SE|: " + " ".join(f"{NAMES[i]}={mean[i]/(G[:,i].std()/np.sqrt(M)+1e-9):+.0f}" for i in range(7)), flush=True)

# 2. per-term gradient alignment (mean cos over data keys) -> do terms agree on direction?
def algn(A, B):
    c = [A[k] @ B[k] / (np.linalg.norm(A[k]) * np.linalg.norm(B[k]) + 1e-12) for k in range(M)]
    return np.mean(c)
print(f"# term-gradient alignment (per-key cos, +1 agree / -1 conflict): "
      f"lS.lT={algn(GS,GT):+.2f}  lE.lT={algn(GE,GT):+.2f}  lE.lS={algn(GE,GS):+.2f}", flush=True)

# 3+4. combined Fisher eigenvectors + per-term contribution. focus on lE+lT (timing-led) and lE+lS+lT.
for combo, Gc in [('lE+lT', GE + GT), ('lE+lS+lT', GE + GS + GT)]:
    F = (Gc.T @ Gc) / M; FE = (GE.T @ GE) / M; FS = (GS.T @ GS) / M; FT = (GT.T @ GT) / M
    ev, V = np.linalg.eigh(F + 1e-9 * np.trace(F) * np.eye(7))
    print(f"\n=== {combo}: Fisher eigenmodes (soft->stiff). CRB_along = 1/sqrt(eig) in scaled units ===", flush=True)
    for j in range(7):
        v = V[:, j]; crb = 1 / np.sqrt(max(ev[j], 1e-12))
        comp = " ".join(f"{NAMES[i]}{v[i]:+.2f}" for i in range(7) if abs(v[i]) > 0.25)
        # which term constrains this direction
        cE = v @ FE @ v; cS = v @ FS @ v; cT = v @ FT @ v
        print(f"  mode{j} eig={ev[j]:.2e} CRB~{crb:.2f} | [{comp}] | term-curv E={cE:.1e} S={cS:.1e} T={cT:.1e}", flush=True)
