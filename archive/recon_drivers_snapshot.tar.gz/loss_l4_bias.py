"""LOSS L4 (motivated by L2 negative curvature) — IS THE LOSS MINIMUM AT THE TRUTH?

L2 found NEGATIVE clean-profile geometry curvature at theta_true. Two causes: (a) the single truth
realization best-fits ~16cm off (per-event noise, B9), or (b) genuine LOSS BIAS (expected loss minimized
away from truth). Distinguish by using the TRUTH MEAN (averaged over NTRUTH realizations) as the
observation, then profiling the loss around theta_true and locating the per-parameter argmin.
  argmin ~ theta_true (within the per-event floor) -> unbiased; negative curvature was per-event noise.
  argmin shifted -> LOSS BIAS (a real loss problem, independent of optimizer).

Runs charge-only (WT=0) and/or charge+time (WT=1). Env: NPHOT NKEYS NTRUTH WT NPTS SPAN.
Usage: CUDA_VISIBLE_DEVICES=g WT=0 python loss_l4_bias.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '48'))
NTRUTH = int(os.environ.get('NTRUTH', '48')); WT = float(os.environ.get('WT', '0'))
NPTS = int(os.environ.get('NPTS', '21')); SPANF = float(os.environ.get('SPAN', '4.0'))
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '8')); TEMP = float(os.environ.get('TEMP', '0.1'))
PN = H.PARAM_NAMES; PS = np.asarray(H.PARAM_SCALE)
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
print(f"# L4 loss-min-at-truth?  NPH={NPH} NKEYS={NKEYS} NTRUTH={NTRUTH} WT={WT} K={K} MAXCELL={MC} TEMP={TEMP}", flush=True)
pred = H.build_predictor(temperature=TEMP, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
# TRUTH MEAN over NTRUTH realizations
cs, tsa = [], []
for s in range(NTRUTH):
    c, t = jax.lax.stop_gradient(tsim(H.theta_to_track(jnp.asarray(theta_true)), jax.random.PRNGKey(10000 + s)))
    cs.append(np.asarray(c)); tsa.append(np.where(np.asarray(c) > 0, np.asarray(t), np.nan))
oc = jnp.asarray(np.mean(cs, 0))
ot = jnp.asarray(np.nan_to_num(np.nanmean(tsa, 0)))
hit = jnp.asarray(np.mean(cs, 0) > 1e-6)
print(f"# truth mean over {NTRUTH} realizations: tot {float(oc.sum()):.1f}  litPMT {int(hit.sum())}", flush=True)
loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=WT)
lossj = jax.jit(loss); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def argmin_offset(i):
    span = SPANF * PS[i]; sv = np.linspace(-span, span, NPTS)
    prof = np.array([np.mean([float(lossj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(prof)); lo = max(0, j - 2); hi = min(NPTS, j + 3)
    a, b, c = np.polyfit(sv[lo:hi], prof[lo:hi], 2)
    smin = -b / (2 * a) if a > 0 else sv[j]
    return smin, prof, sv, (a > 0)
print(f"#  param  grp   argmin_offset[param units]   [/PARAM_SCALE]   curvature_min?", flush=True)
for i, nm in enumerate(PN):
    grp = 'S' if nm in ('energy', 't0') else 'G'
    smin, prof, sv, ismin = argmin_offset(i)
    unit = {'energy': 'MeV', 'x': 'm', 'y': 'm', 'z': 'm', 'polar': 'rad', 'azim': 'rad', 't0': 'ns'}[nm]
    print(f"#  {nm:6s} {grp}    {smin:+10.4f} {unit:5s}        {smin/PS[i]:+7.3f}        {'min' if ismin else 'NOT-min(saddle/max)'}", flush=True)
print(f"# VERDICT: argmin_offset ~ 0 (within per-event floor: x/y/z ~0.16m, see B9) => loss UNBIASED; large", flush=True)
print(f"#   consistent offset => LOSS BIAS. NOT-min => theta_true is a saddle/max of the (soft,expected) loss.", flush=True)
