#!/usr/bin/env python3
"""Position dependence of the SIREN/GEANT4 total-charge over-light (hard predictor, overlap off).
Reads /tmp/cmp_pos_*.npz: muG, muS, th9 (vertex in m). Correlates ratio with R, |z|, wall dist, total light."""
import glob,numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
RT,HZ=16.962,18.189
D=[np.load(f) for f in sorted(glob.glob('/tmp/cmp_pos_*.npz'))]
v=np.array([d['th9'][1:4] for d in D])
R=np.hypot(v[:,0],v[:,1]); Z=np.abs(v[:,2]); wall=np.minimum(RT-R,HZ-Z)
ratio=np.array([float(d['muS'].sum())/float(d['muG'].sum()) for d in D])
octot=np.array([float(d['muG'].sum()) for d in D])
olp=(ratio-1)*100
print(f'N={len(D)}  over-light mean {olp.mean():+.2f}%')
for nm,x in [('R (m)',R),('|z| (m)',Z),('wall dist (m)',wall),('total light',octot)]:
    c=np.corrcoef(x,olp)[0,1]; print(f'  corr(over-light, {nm:14s}) = {c:+.3f}')
fig,ax=plt.subplots(2,2,figsize=(12,9))
for a,(nm,x) in zip(ax.ravel(),[('vertex R (m)',R),('vertex |z| (m)',Z),('distance to wall (m)',wall),('total detected charge',octot)]):
    a.scatter(x,olp,s=20,alpha=0.6); a.axhline(0,color='k',lw=0.6,ls=':')
    if len(x)>2:
        b=np.polyfit(x,olp,1); xs=np.linspace(x.min(),x.max(),20); a.plot(xs,np.polyval(b,xs),'r-',label=f'slope {b[0]:+.3f}/unit, corr {np.corrcoef(x,olp)[0,1]:+.2f}')
    a.set_xlabel(nm); a.set_ylabel('over-light (S/G - 1) [%]'); a.legend(fontsize=9); a.grid(alpha=0.3)
fig.suptitle(f'Position dependence of SIREN total over-light (hard, overlap off, {len(D)} events)',fontsize=13)
fig.tight_layout(rect=[0,0,1,0.97]); fig.savefig('recon_plots/overlight_position.png',dpi=110); print('wrote overlight_position.png')
