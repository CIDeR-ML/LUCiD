"""TIER 2a — FORWARD timing residual: EXPECTED predictor vs SAMPLE engine at theta_true.
Tier 1 proved the loss form is exactly unbiased; the -0.14 m must be a forward mismatch.
Here truth is the ACTUAL sample engine (make_hits_data: hard first-arrival + Bernoulli QE + TTS),
NOT the predictor's own model. Compare its per-PMT (count, first-arrival time) to the predictor's
count-conditioned model at the SAME theta_true:
  CHARGE: sample mean count vs predictor mu (per occupancy bucket).
  TIME  : (a) PIT  F=1-S(t_obs)^n with predictor S, observed n -> mean should be 0.5; <0.5 = sample EARLIER.
          (b) physical offset  <t_sample> - <model first-arrival mean>  (ns), bucketed by occupancy.
Quantifies the systematic forward time offset that the loss (using the predictor model) must absorb by
moving vtx/E/t0 -> the source of the -0.14 m.
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t2a.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '40'))
K = 8; MC = 16; SIGMA = 2.5; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
print(f"# T2a EXPECTED vs SAMPLE  NPH={NPH} NREAL={NREAL} TTS={os.environ['TTS_NS']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk = sc2track(jnp.asarray(th9_true))

# ---- predictor model at theta_true (forward KEY0) ----
log_w, ft, fi, tot = [np.asarray(a) for a in jax.lax.stop_gradient(pred(trk, jax.random.PRNGKey(0)))]
w = np.exp(np.clip(log_w, -60, 20)); mu = np.asarray(tot)
lit = mu > 1e-6
_W = jnp.asarray(w); _FT = jnp.asarray(ft); _FI = jnp.asarray(fi)
SH = jax.jit(lambda ot_pmt: jax.ops.segment_sum(_W * 0.5 * (1.0 + erf((ot_pmt[_FI] - _FT) / (SIGMA * SQ))), _FI, num_segments=ND))  # R(t_obs) per PMT, ot_pmt len ND
# model first-arrival MEAN per PMT via unconditional Poisson survival S(t)=exp(-R(t)), ALL PMTs at once:
# R[g,p] = segment_sum over photons of w*Phi((tgrid[g]-ft)/sqrt2 sigma); E[t_first|det] = sum t*f / sum f, f=-dS/dt.
tgrid = jnp.asarray(np.linspace(np.nanpercentile(ft, 0.05) - 15, np.nanpercentile(ft, 99.95) + 40, 800))
@jax.jit
def model_tmean_all():
    Rg = jax.lax.map(lambda t: jax.ops.segment_sum(_W * 0.5 * (1.0 + erf((t - _FT) / (SIGMA * SQ))), _FI, num_segments=ND), tgrid)  # (G,ND) sequential, no 800x photon blowup
    S = jnp.exp(-Rg)                                                  # (G,ND)
    f = jnp.clip(-jnp.gradient(S, axis=0), 0.0, None)                 # first-arrival density (uniform grid -> dt cancels)
    Z = jnp.sum(f, axis=0)
    return jnp.where(Z > 1e-6, jnp.sum(tgrid[:, None] * f, axis=0) / jnp.maximum(Z, 1e-6), jnp.nan)
model_tm = np.asarray(model_tmean_all())                             # (ND,)

# ---- sample engine realizations ----
sc = np.zeros((NREAL, ND)); st_ = np.full((NREAL, ND), np.nan)
for r in range(NREAL):
    c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r)))
    c = np.asarray(c); t = np.asarray(t); sc[r] = c; st_[r] = np.where(c > 0, t, np.nan)
samp_count = sc.mean(0); samp_tmean = np.nanmean(st_, 0)

# PIT: F = 1 - S(t_obs)^n with observed n, per detection (use sample's own count that realization)
pit = []
for r in range(NREAL):
    det = np.where(sc[r] > 0)[0]
    if det.size == 0: continue
    Rt = np.asarray(SH(jnp.asarray(np.nan_to_num(st_[r]))))[det]
    Sv = np.clip((mu[det] - Rt) / np.maximum(mu[det], 1e-8), 1e-9, 1.0)
    pit.append(1.0 - Sv ** sc[r][det])
pit = np.concatenate(pit)
print(f"#  lit PMTs(model)={lit.sum()}  PIT mean={pit.mean():.3f} (0.5=match; <0.5 sample EARLIER than model)  std={pit.std():.3f}", flush=True)

# bucket by occupancy
edges = [0.05, 0.2, 0.5, 1.0, 2.0, 100]
print(f"#  occ-bucket |  Npmt | <count>samp/mu | <t>samp | <t>model | dt(samp-model) ns", flush=True)
dt_all = samp_tmean - model_tm
glob = np.nanmedian(dt_all[lit])                                      # global offset (t0-absorbable)
for lo, hi in zip(edges[:-1], edges[1:]):
    sel = np.where((mu > lo) & (mu <= hi))[0]
    if sel.size == 0: continue
    ds = samp_tmean[sel]; tm = model_tm[sel]; ok = np.isfinite(ds) & np.isfinite(tm)
    dt = np.nanmean((ds - tm)[ok])
    print(f"#  {lo:4.2f}-{hi:<5.2f}| {sel.size:5d} | {samp_count[sel].mean():.3f}/{mu[sel].mean():.3f} | "
          f"{np.nanmean(ds):+7.2f} | {np.nanmean(tm):+7.2f} | {dt:+6.3f} | resid(dt-glob) {dt-glob:+6.3f}", flush=True)
print(f"#  GLOBAL dt (median over lit) = {glob:+.3f} ns  -> the t0-absorbable part; the per-bucket resid is what biases vtx/E.", flush=True)
print(f"# READ: PIT={pit.mean():.3f}<0.5 sample EARLIER. If resid(dt-glob) is FLAT~0 => offset is global t0 (harmless);", flush=True)
print(f"#       if resid VARIES with occupancy => position-correlated forward mismatch => biases vtx/E (the -0.14 m).", flush=True)
