"""Clean single-photon -> single-sensor overlap gradient (no averaging, tiny shift so no grid
jump). Separates the overlap MATH gradient from the grid candidate-lookup leak."""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.propagation.base import compute_sensor_intersections_base
from lucid.simulation.optics import normalize as _n
GEOM = 'config/SK_geom_config.json'
np.set_printoptions(precision=4, suppress=True)

dg = DetectorGeometry.from_config(GEOM, temperature=1.0, max_sensors_per_cell=4)
propagate = dg.propagator
sp = np.array(dg.sensor_points)
sensor_radius = float(getattr(dg, 'sensor_radius', 0.254))

# Aim a photon from near center toward a chosen sensor; offset origin perpendicular so the
# closest-approach distance (hence overlap weight) is sensitive to the origin.
s = jnp.array(sp[5000])
O0 = jnp.array([0.5, -0.3, 0.4])
D = _n(s - O0)

def full_weight(O):
    r = propagate(O[None, :], D[None, :])
    return jnp.sum(r['sensor_weights'])

print("== Full propagate (with grid lookup): d(total weight)/d(origin) ==", flush=True)
g_ad = np.array(jax.grad(full_weight)(O0))
h = 5e-4
g_fd = np.array([(float(full_weight(O0.at[i].add(h))) - float(full_weight(O0.at[i].add(-h)))) / (2 * h)
                 for i in range(3)])
print(f"  AD={g_ad}  FD={g_fd}  cos={np.dot(g_ad,g_fd)/(np.linalg.norm(g_ad)*np.linalg.norm(g_fd)+1e-12):+.3f}"
      f"  |AD|/|FD|={np.linalg.norm(g_ad)/(np.linalg.norm(g_fd)+1e-12):.3f}", flush=True)

# Direct overlap (bypass grid): force the chosen sensor index, compute weight directly.
def make_overlap_prob(sigma):
    def f(distance):
        return jnp.exp(-distance**2 / (2 * sigma**2))
    return f
overlap_prob = make_overlap_prob(1.0 * sensor_radius)
sidx = jnp.array([[5000]])   # (n_rays=1, 1 slot) -> we call per-slot

def direct_weight(O):
    w, t, si, nn, ins, pts = compute_sensor_intersections_base(
        jnp.array([5000]), jnp.array(sp), sensor_radius,
        O[None, :], D[None, :], dg.detector.bounds_check, overlap_prob)
    return jnp.sum(w)

print("\n== Direct overlap (no grid): d(weight on sensor 5000)/d(origin) ==", flush=True)
g_ad2 = np.array(jax.grad(direct_weight)(O0))
g_fd2 = np.array([(float(direct_weight(O0.at[i].add(h))) - float(direct_weight(O0.at[i].add(-h)))) / (2 * h)
                  for i in range(3)])
print(f"  AD={g_ad2}  FD={g_fd2}  cos={np.dot(g_ad2,g_fd2)/(np.linalg.norm(g_ad2)*np.linalg.norm(g_fd2)+1e-12):+.3f}"
      f"  |AD|/|FD|={np.linalg.norm(g_ad2)/(np.linalg.norm(g_fd2)+1e-12):.3f}", flush=True)
print("\nIf DIRECT matches FD but FULL does not -> the grid candidate-lookup stop_gradient is the leak.", flush=True)
