"""sin/cos 4-param ANGLE rep: theta9=[E,x,y,z, s_t,c_t, s_p,c_p, t0]; direction d=[s_t c_p, s_t s_p, c_t]
(each (s,c) renormalized to its unit circle). Run the FULL analysis: per-param profile smoothness + AD/profile
ratio, at an OFFSET center (non-trivial grad) with MEAN obs. Compares to raw azim (KINKY) and quaternion (smooth).
Discriminator: sin/cos keeps the SAME phi-tangent as azim -> if azim kink is real-in-phi, s_p/c_p inherit it.
Env: NPHOT NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_sincos.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NKEYS = int(os.environ.get('NKEYS', '8')); K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
ASC = 0.02
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, ASC, ASC, ASC, ASC, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    theta = jnp.arctan2(st, ct); phi = jnp.arctan2(sp, cp)         # smooth round-trip -> d=[st cp, st sp, ct]
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=theta, phi=phi, t0=th9[8])
print(f"# SIN/COS angle rep  NPH={NPH} NKEYS={NKEYS}  th9_true(angles)={th9_true[4:8]}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
cs, ts = [], []
for s in range(12):
    cc, tt2 = jax.lax.stop_gradient(truth(sc2track(jnp.asarray(th9_true)), jax.random.PRNGKey(900 + s)))
    cs.append(np.asarray(cc)); ts.append(np.where(np.asarray(cc) > 0, np.asarray(tt2), np.nan))
oc = jnp.asarray(np.mean(cs, 0)); hit = jnp.asarray(np.mean(cs, 0) > 1e-6); ot = jnp.asarray(np.nan_to_num(np.nanmean(ts, 0)))
def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def core(th9, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key)
    w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - th9[8])[fi]; mu = jnp.maximum(tot, 1e-8)
    def Rof(x): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf((x - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rof(tobs - DELTA / 2)) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rof(tobs + DELTA / 2)) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(hit & (oc > 0), -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
gradf = jax.jit(jax.grad(core, argnums=0)); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
for i, nm in enumerate(NAMES):
    c0 = th9_true + 3.0 * SCALE9[i] * np.eye(9)[i]
    sv = np.linspace(-6 * SCALE9[i], 6 * SCALE9[i], 33); j0 = 16; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(core(jnp.asarray(c0 + s * np.eye(9)[i]), k)) for k in keys]) for s in sv])
    sl = {wv: (prof[j0 + wv] - prof[j0 - wv]) / (2 * wv * dg) for wv in [1, 2, 4, 8]}
    gAD = np.mean([np.asarray(gradf(jnp.asarray(c0), k))[i] for k in keys])
    kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
    ratio = gAD / (sl[4] + 1e-30)
    print(f"#  {nm:6s} AD {gAD:+11.1f} prof {sl[1]:+9.1f}/{sl[2]:+9.1f}/{sl[4]:+9.1f}/{sl[8]:+9.1f}  {'KINKY' if kinky else f'smooth AD/prof {ratio:+.2f}'}", flush=True)
print(f"# READ: are s_p/c_p (phi-circle) SMOOTH (sin/cos fixes it) or KINKY (azim phi-kink is real, only quaternion axes avoided it)?", flush=True)
