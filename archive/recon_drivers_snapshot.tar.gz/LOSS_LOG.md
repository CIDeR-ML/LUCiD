# Loss-interrogation run log

One record per run (LOSS_PLAN.md). Full param block + DELTA from previous run. AD/FD comparisons use
common random numbers (same key for ±h and AD) averaged over NKEYS. θ_true = [1050,0,0,0,0.6,0.8,0].
Canonical block: θ_eval, K, MAXCELL, TEMP(overlap), NKEYS, FD-frac(h/PARAM_SCALE), tau_time,
w_charge/w_time, truth source, n_photons, seeds, OVERLAP_ANALYTIC.

---

### L1.0/L1.1 baseline — AD vs FD gradient   [2026-06-04]

PURPOSE: FD-step validation + baseline AD-vs-FD gradient of the recon loss, scalar vs geometry groups.
PARAMS: θ_eval = θ_true + [E+50, x+0.10m, polar+0.0175rad, t0+0.5ns] (non-trivial grad); K=8, MAXCELL=8,
  TEMP=0.1, NKEYS=24 (CRN), FD-frac swept {1e-3..1e-1}, tau_time=1.5, w_charge=w_time=1.0,
  truth=SIREN self-consistent (seed 777), NPHOT=50000, AD/FD keys 0..23.
DELTA: first loss-study run (baseline).

RESULT:
  AD per-key cosine vs mean-AD: median 0.477, min -0.942  -> AD gradient HEAVY-TAILED over keys (24 too few).
  FD h-plateau cos(AD,FD): frac 1e-3 +0.21 | 3e-3 +0.89 | 1e-2 -0.98 | 3e-2 -0.10 | 1e-1 -0.70  -> NO stable plateau.
  per-param (frac 1e-2): t0 relErr 0.06% (AD -203.09 vs FD -202.96); energy 81%; geometry x/y/z/polar/azim
    87-118% with OPPOSITE SIGNS. SCALAR(E,t0) cos +1.0000 ; GEOMETRY cos -0.9818.

VERDICT (provisional): gradient splits by group — SCALAR (t0 exact, energy direction ok) TRUSTWORTHY;
  GEOMETRY (x,y,z,polar,azim) AD disagrees with FD (opposite sign), FD itself h-unstable, AD heavy-tailed
  over keys. Matches [[recon-track-hessian-breakers]] (geometry differentiability is the problem). MUST
  resolve real-pathology vs under-averaging -> NKEYS sweep {96,288} + knobs (temp 0.3, MAXCELL 16, K=2) running.
---

### L1.2 — NKEYS + knob sweep (AD vs FD gradient)   [2026-06-04]

PURPOSE: resolve geometry-gradient real-vs-noise; find knobs that help. CORRECTS the baseline: picking
the plateau frac by best GEOMETRY cosine (small h), not frac=1e-2 (which is kink-crossing -> false -0.98).
PARAMS: θ_eval as L1.1; NKEYS swept {96,288}; one-knob: TEMP{0.1,0.3}, MAXCELL{8,16}, K{8,2}. NPHOT=50000,
  FD-frac swept, plateau = best-geom-cos frac.
DELTA vs L1.1: NKEYS 24->{96,288}; added TEMP/MAXCELL/K single-knob variants; plateau-frac selection fixed.

RESULT (cos_GEOM at plateau, ||AD||/||FD|| at small h, per-key min-cos):
  K8 MC8 T0.1 NKEYS96 : cos_GEOM +0.935 (frac1e-3) ; ||AD||/||FD|| 0.009 ; per-key median 0.555 min -0.921
  K8 MC8 T0.1 NKEYS288: cos_GEOM +0.904 (frac3e-3) ; ||AD||/||FD|| 0.038 ; per-key median 0.371 min -0.929
  K8 MC8 T0.3 NKEYS96 : cos_GEOM +0.667 (WORSE)    ; over-smoothing hurts direction
  K8 MC16 T0.1 NKEYS96: cos_GEOM +0.911 (~same as MC8)
  K2 MC8 T0.1 NKEYS96 : cos_GEOM +0.762 best (NEGATIVE at small h) -> K=2 messier
  ALL runs: SCALAR cos +0.98-1.0 ; t0 relErr <1% ; energy direction ok but magnitude unreliable.

VERDICT: CORRECTED picture — geometry gradient DIRECTION agrees with FD at small h (cos ~0.90-0.93 @ K8),
  NOT opposite (earlier -0.98 was a kink-crossing-h artifact). The issue is MAGNITUDE: ||AD||/||FD|| ~0.01-0.06
  for geometry (AD appears 15-100x too small), but this may be FD-noise-inflated (CRN imperfect for geometry).
  Knobs: more keys stabilizes mean (per-key tail persists); temp 0.3 WORSE; MC16~MC8; K2 worse. SCALAR solid.
  -> L1.3 clean-profile test (noise-averaged L(s) slope vs AD) to settle the magnitude.
---

### L2 — Hessian quality @theta_true (baseline + knob sweep)   [2026-06-04]

PURPOSE: AD Hessian eigenstructure, symmetry, per-key spread, and AD-diagonal vs clean-profile curvature.
PARAMS: θ_eval=θ_true; loss=charge+time (w=1,1, tau 1.5); truth SIREN self-consistent SINGLE key 777;
  NKEYS=64; HFRAC=0.05 (profile 2nd-deriv step); NPHOT=50000. Sweep: baseline(K8,MC8,T0.1), MC16, K2, T0.3.
DELTA vs L1: observable = Hessian (was gradient); θ_eval=θ_true (was θ_true+δ); jax.hessian + profile 2nd-deriv.

RESULT (consistent across knobs unless noted):
  symmetry ||H-H^T||/||H|| = 0.000 (AD Hessian symmetric).
  eigenvalues span ~1e10-1e11 condition; SOFTEST always energy (eig ~0.008-0.015), STIFFEST always polar (~1e8-1e9).
  PER-KEY Hessian wildly INDEFINITE: min eigenvalue -1e9 to -5e9 across keys -> only PD after ~64-key averaging.
  DIAGONAL AD/profile-curvature ratio:  t0 = 1.00 (EXACT) everywhere ; energy ~0.00-0.06 (AD ~100x TOO SMALL) ;
    geometry x/y/z/polar/azim = wrong sign / wild magnitude (-1.4,-3.2,+6.6,-10.7,-39 baseline; similar/worse other knobs).
  CLEAN-PROFILE geometry curvature is NEGATIVE at θ_true for x,y,polar,azim (CONSISTENT across knobs, same truth key 777).
  temp=0.3: mean Hessian NOT PD (min eig -3.0e7 in the polar/angle direction) -> more smoothing -> indefinite.
  K=2, MC16: same qualitative picture (t0 exact, energy soft, geometry AD-curvature unreliable).

VERDICT: AD Hessian is symmetric but TRUSTWORTHY ONLY for t0 (ratio 1.00). energy curvature 100x underestimated;
  GEOMETRY curvature unreliable in AD (wrong sign vs clean profile) and per-key indefinite (needs heavy averaging);
  condition ~1e10 (energy soft / polar stiff) => raw-Hessian Newton is ill-posed. CRITICAL: clean-profile geometry
  curvature NEGATIVE at θ_true -> θ_true may not be the loss min in geometry. Test bias vs per-event-noise next (L4).
---

### L1.3 — clean profile vs AD, all 7 params, multi-scale slopes   [2026-06-04]

PURPOSE: settle the AD-magnitude question per param via noise-averaged 1D profiles; classify smooth vs kinky.
PARAMS: θ_eval=θ_true+δ (as L1.1); NKEYS=96 (CRN); NPTS=33; SPAN=6×PARAM_SCALE; slopes at w=1,2,4,8 grid
  steps (→s=0); K=8 MC8 TEMP0.1 NPHOT=50000; figure _l1_profiles.png.
DELTA vs L1.2: per-param clean PROFILE slope (not noisy FD); all 7 params; multi-scale slope consistency.

RESULT (AD vs profile slope; slope consistency across scale):
  t0    : AD -202.1, slopes all -202.1  -> SMOOTH, AD EXACT (1.00)
  x     : AD +429,  slopes 304/426/434/452 (~consistent ~430) -> SMOOTH, AD 0.99
  z     : AD +630,  slopes 763/775/752/725 (consistent) -> SMOOTH, AD 0.84
  y     : AD +292,  slopes 374/388/382/356 (consistent) -> SMOOTH, AD 0.76
  energy: AD +0.54, slopes 0.6-0.8 (consistent) -> SMOOTH, AD 0.84
  polar : AD +2169, slopes +400/-373/+792/+417  SIGN-FLIPPING -> KINKY, AD inconsistent (2.74x coarse)
  azim  : AD -546,  slopes +367/-213/-125/-1236 SIGN-FLIPPING -> KINKY, AD inconsistent (4.38x coarse)

VERDICT: CLEAN per-param map. SMOOTH + AD-accurate (0.76-1.0x): t0, x, y, z, energy. KINKY + AD-unreliable:
  polar, azim (the two ANGLES) — loss surface non-smooth (slopes flip sign across scale), AD gradient
  inconsistent with any finite-scale slope. The broken gradient is SPECIFICALLY the angular params.
  Physical: rotating the track sweeps the ring across PMT/cell boundaries (kinky); translating is smoother.
---

### L4 — IS THE LOSS MIN AT THE TRUTH? (charge-only vs charge+time, truth MEAN)   [2026-06-04]

PURPOSE: distinguish L2's negative-curvature = per-event noise vs genuine LOSS BIAS, using the truth MEAN
(48 realizations) as the observation and locating the per-param loss argmin.
PARAMS: θ_true; truth mean over NTRUTH=48 SIREN realizations (seeds 10000..); predictor NKEYS=48; profile
  ±4×PARAM_SCALE, 21 pts, parabola argmin; K8 MC8 TEMP0.1 NPHOT=50000; WT(time weight) ∈ {0, 1}, w_charge=1.
DELTA vs L2: observable = loss ARGMIN offset (was Hessian); truth MEAN (was single key 777); profile-argmin.

RESULT — argmin offset from truth:
  CHARGE-only (WT=0): energy +3.9 MeV(+0.08σ) | x +1.2mm | y +4.3mm | z -1.4cm | polar +0.0004 | azim -0.0004 | (t0 flat, undefined)
    => CHARGE LOSS UNBIASED: min AT truth (pos mm-cm << 16cm per-event floor; angles ~0.02deg; energy exact).
    => L2 negative geometry curvature was the SINGLE truth-key-777 per-event offset, NOT loss bias.
  FULL charge+time (WT=1): energy -163 MeV(-3.3σ) | x -0.66m | y -0.53m | z -0.75m | polar +0.006 | azim -0.014 | t0 +1.33ns
    => TIME TERM BIASES the fit ~0.5-0.75 m + 163 MeV off truth (energy DOWN, vertex BACKWARD = time-charge coupling).

VERDICT: CHARGE loss = the trustworthy unbiased workhorse (min at truth). TIME term (first_arrival_nll, tau 1.5,
  vs mean-first-arrival obs) is the LOSS PROBLEM — biases position/energy by ~3σ. This is the A7 loss-level
  timing caveat made concrete. Next: WHY is the time term biased (soft-min early bias? obs construction?
  predict_t0 vs truth timing?) and how to reweight/reformulate it before combining.
---

### L1.4 — EXACT SOURCE of the gradient mismatch (K/term decomp + stop_gradient ablation)   [2026-06-04]

PURPOSE: pinpoint the source of y/z/energy magnitude underestimate + polar/azim kinkiness.
METHOD: forward loss is sg-INDEPENDENT (sg = identity forward) so the clean profile slope is the SAME
ground truth for every flag; only AD changes. Ablate each stop_gradient (separate processes), + K{1,8} ×
term{charge,full} decomp + angle smoothness vs temp/MAXCELL. eval@θ0, NKEYS=48, NPHOT=50000.
Added default-OFF diag toggles: photon_step.py norm_live (restore reflection-normal grad), dpos_live
(restore free-path grad in scatter_pos); simulator.py T0_LIVE (restore predict_t0 grad). (cont_sg/scat_sg existed.)

RESULT — AD/profile ratio (baseline K8 full): y 0.63, z 0.76, x 0.38, energy 0.48, polar 2.35, azim KINKY.
  norm_live @K8: geometry EXPLODES to 1e10-1e11 (x,y,z,polar,azim); energy unchanged 0.48.
  norm_live @K1: NO explosion (y 1.30, x 0.77) ~ baseline-K1  => explosion is MULTI-BOUNCE (Igehy 1/r compounding).
  dpos_live: IDENTICAL to baseline (free-path detach = NO effect).
  cont_sg (remove survival grad): IDENTICAL to baseline (survival chain = NO effect).
  T0_LIVE (remove predict_t0 sg): energy 0.48 -> 0.53 only (+0.05); y/z/x/angles UNCHANGED.
  K decomp (full): x ratio K1 0.77 -> K8 0.38 (multi-bounce WORSENS geometry); y K1 1.30 -> K8 0.63.
  angle smoothness: temp 0.1 KINKY; temp 0.6 -> polar SMOOTH, azim still kinky; MAXCELL 32 (temp0.1) -> still KINKY.

VERDICT — EXACT SOURCES:
  (1) GEOMETRY x/y/z underestimate = `normal_refl = sg(normal)` reflection-normal detach. NECESSARY stabilizer:
      restoring it EXPLODES the gradient 1e8x via multi-bounce Igehy 1/r_sensor compounding (harmless at K=1).
      The 0.4-0.8x underestimate is the unavoidable COST; multi-bounce worsens it. Free-path & survival detaches: NOT sources.
  (2) ANGLES polar/azim kinky = FORWARD non-smoothness (sg-independent) from INSUFFICIENT OVERLAP SMOOTHING:
      higher temperature smooths it (polar at 0.6), MAXCELL does not. Trades against forward charge fidelity (A4: temp 0.3 -> -2.7% charge).
  (3) ENERGY underestimate (0.48) = mostly SIREN-emission-gradient softness + softest-direction noise; predict_t0 sg
      is a MINOR contributor (+0.05). NOT a photon_step stop_gradient.
---

### L4b — WHY the time term biases (skeptical decomposition, K=8 MAXCELL=16)   [2026-06-04]

PURPOSE: find the real source of the time-term bias, skeptical of my own loss + obs construction + forward.
PARAMS: K=8 MAXCELL=16 (physical config, K>=6 required), temp 0.1, NPHOT=50000, tau 1.5; truth = SIREN sample.

(1) LOSS READ: poisson_nll (counts_loss) is NORMALIZED (sum(nll)/sum(true)) -> O(1); first_arrival_nll is
    summed RAW over ~6000 sensors -> O(1e4-1e5). => with w=1,1 the TIME term outweighs charge ~1e4-1e5x;
    the unbiased charge term is ignored. first_arrival_nll = -log_w_total - log_f - (N_s-1)log(1-F).

(2) 3-TERM DECOMP (mean-obs): magnitudes @truth charge 1.1 | t_count 11346 | t_density 75124 (DOMINANT) |
    t_tail -1032. argmin: charge x -0.004/z -0.005/E +9 (UNBIASED). t_count argmin at GRID EDGE -0.80 (RUNAWAY:
    -log_w_total rewards charge unboundedly, no interior min). t_density x -0.28/z -0.80/E -169. all time terms biased.

(3) HONEST PER-EVENT (12 single events): charge x bias -0.007m std 0.153 (UNBIASED, std=per-event noise);
    full charge+time x bias -0.579m std 0.159, E -222MeV std 47 -> bias REAL & CONSISTENT every event (not a mean-obs artifact).

(4) FORWARD RESIDUAL (pred soft-min - truth hard-min @truth): median -24ns but OCCUPANCY-SPLIT:
    occ<1 -38ns (n=3957) | occ1-3 -8.7ns | occ3-8 -4ns. The huge residual is almost ALL in DIM PMTs (occ<1),
    whose first-arrival is physically UNRELIABLE -> the order-stat loss includes them with NO threshold.

VERDICT (skeptical): the -0.58m "bias" is the ORDER-STAT loss (first_arrival_nll) being a BAD LOSS for the
    wrong reasons: (a) scale mismatch (normalized charge vs raw time), (b) -log_w_total RUNAWAY, (c) (N_s-1)
    charge-amplification, (d) tau 1.5 < TTS 2.5 too sharp, (e) NO charge threshold so dim-PMT (-38ns) first-arrivals
    dominate. NOT a statement about physics. => build a PHYSICAL first-arrival loss (predicted-first vs observed-first,
    Gaussian/robust, width~TTS, charge-thresholded) and re-test bias BEFORE any AD=FD proof. (loss_cleantime.py)
---

### L4c — PRINCIPLED time term: Poisson first-arrival likelihood (TTS-convolved)   [2026-06-04]

DERIVATION: detected photons at PMT i = inhomogeneous Poisson process, rate lambda_i(t)=sum_j w_ij delta(t-tau_ij)
(w_ij = qe-weighted detection weight, sum_j w_ij = mu_i). TTS convolves the rate: r_i(t)=sum_j w_ij N(t;tau_ij,sigma^2).
First-arrival (time-to-first-event) density: p(t_i)=r_i(t_i) exp(-R_i(t_i)), R_i(t)=sum_j w_ij Phi((t-tau_ij)/sigma).
  NLL_time_i = -log r_i(t_i) + R_i(t_i)   [-log(rate at t_i) + expected #photons before t_i]
JOINT (coherent, same NLL units, NO arbitrary weight): L = sum_i [mu_i - n_i log mu_i] (RAW Poisson) + sum_i NLL_time_i.
WHY it fixes the order-stat: that used fixed-N (N_s-1) exponent -> pathological for dim PMTs (N_s<1); Poisson form
exp(-sum w Phi) well-behaved for all mu; TTS = the kernel sigma; mu shared with charge term (no -log_w_total runaway).

PARAMS: K=8 MAXCELL=16, truth TTS_NS=2.5, sigma=2.5, NPHOT=50000, NKEYS=16, per-event argmin over NEV=12.

RESULT (per-event x/energy bias +/- std):
  charge                : x -0.007 std 0.153 | E +43  std 102   (unbiased backbone)
  order-stat (OLD,bad)  : x -0.58  std 0.16  | E -222 std 47     (BAD LOSS)
  soft-min Gaussian     : x -0.04  std 0.37  | E +92  std 109    (less pos-bias but crude/noisy)
  Poisson FA time-only  : x -0.42  std 0.22  | E -9   std 137
  Poisson FA JOINT      : x -0.22  std 0.17  | E +7   std 58      <-- energy FIXED + tightened; pos bias HALVED
  (THR0 == THR3: Poisson form naturally robust to dim PMTs, no threshold needed.)

VERDICT: the Poisson first-arrival likelihood is the correct FORM (the user's "full likelihood given the
  distribution + TTS"). It FIXES energy (-222->+7, std 102->58) and HALVES position bias (-0.58->-0.22m) vs the
  order-stat, with natural dim-PMT robustness. CONFIRMS the order-stat was the bad loss biasing for wrong reasons.
  REMAINING: -0.22m position bias (> 0.15m charge floor) -> decompose (rate vs survival), sigma sweep, and
  check for a genuine SIM-vs-TRUTH forward timing residual (in progress). THEN AD=FD on this loss.
---

### L4d — root of the Poisson-FA residual bias: survival term + forward early-edge residual   [2026-06-04]

PARAMS: K=8 MAXCELL=16, TTS 2.5, sigma sweep, per-event (single-realization obs) argmin x.

BIAS DECOMP (per-event x bias, time term only): time-RATE(-log r) x +0.28 | time-SURVIVAL(+R) x -1.88 |
  full -0.42. => the SURVIVAL term (+R = expected #photons before t_obs) carries the bias.
SIGMA sweep (full time): 1.5 -> -0.17 | 2.5 -> -0.42 | 4 -> -0.63 | 6 -> -0.75 | 10 -> -0.72. Bias GROWS
  with sigma (broad sigma counts photons AFTER t_obs as 'before' via Phi(small neg) ~ 0.5) -> not a width fix.

FORWARD EARLY-EDGE (R(t_obs) should = 1 by Poisson time-change theorem, mean-obs): occ1-3 R=1.02 (ok),
  occ3-8 R=2.55 (2.5x TOO HIGH). => predictor OVER-POPULATES the early time edge at well-lit PMTs.
  MECHANISM (candidate): expected/implicit-capture engine deposits qe-weight at early direct hits that the
  hard-sampled truth (first QE success, often after reflection) does not -> SIM-vs-TRUTH forward TIMING residual.

AD=FD on Poisson FA joint: BAD (x AD -2447 vs profile +889 wrong sign; t0 wrong sign) -> the survival/-log r
  early-tail floor + geometry truncation break the gradient. NOT proof-ready as implemented.

CAVEAT (skeptical): R(t_obs) used t_obs=MEAN of first-arrivals; R(E[min]) != E[R(min)] (Jensen) -> confirming
  with PER-REALIZATION R (in progress) before calling it a forward bug vs a mean-obs artifact.

INTERIM VERDICT: order-stat loss = bad (wrong form, -0.58m). Poisson first-arrival = correct FORM (fixes
  energy, halves pos bias, dim-PMT robust). Residual -0.22m traced to the SURVIVAL term sensing a forward
  early-edge timing residual (expected-vs-sample engine), NOT a loss-form defect. AD=FD needs numerical work.
---

### L4e — self-consistency: decompose the Poisson-FA residual bias   [2026-06-04]

PARAMS: K=8 MAXCELL=16 TTS 2.5 sigma 2.5; predictor expected; truth via EXPECTED engine (use_expected_value=True,
  hit_mode realistic) vs SAMPLE engine (build_truth_sim). Per-event JOINT x argmin over 12 events.
RESULT: EXPECTED-engine truth x bias -0.137 std 0.223 | SAMPLE-engine truth x bias -0.217 std 0.168.
  => the -0.22m DECOMPOSES: ~0.08m = expected-vs-sample ENGINE timing residual (forward); ~0.14m REMAINS
     self-consistent = finer first-arrival-MODEL/TTS residual (truth = min of Bernoulli-detected TTS-smeared
     photons; model = first-arrival of the qe-weighted Poisson rate convolved with TTS; equal for ideal Poisson,
     not exactly for finite Bernoulli-thinned realizations).

=== L4 (time-term) FULL CHAIN — "what it is" ===
1. The earlier "-0.7m timing bias" was the ORDER-STAT first_arrival_nll = a BAD LOSS (fixed-N (N_s-1) exponent
   pathological for dim PMTs, -log_w_total RUNAWAY, tau 1.5 < TTS 2.5). NO physics conclusion valid from it.
2. CORRECT FORM = Poisson first-arrival likelihood: NLL_i = -log[sum_j w_ij N(t_i;tau_ij,sigma^2)] + sum_j w_ij Phi((t_i-tau_ij)/sigma),
   joint with RAW Poisson charge. Fixes energy (-222->+7 MeV, std 102->58), dim-PMT robust (no threshold needed),
   pos bias -0.58 -> -0.22m.
3. Residual -0.22m: SURVIVAL term (+R) sensing (a) ~0.08m expected-vs-sample engine timing residual + (b) ~0.14m
   first-arrival-model/TTS residual (self-consistent). Down to ~charge-floor (0.15m) level.
4. OPEN/GATE: AD=FD on the Poisson FA is currently BROKEN (early-tail -log r floor + survival gradient x geometry
   truncation -> wrong signs). Must fix the numerics before this loss is usable for the AD=FD proof.
---

### L4f — RESOLVED time term: BINNED Poisson first-arrival likelihood (well-conditioned, AD=FD clean)   [2026-06-04]

PROBLEM: point-pdf Poisson FA had AD=FD BROKEN specifically in the RATE term -log r(t_obs) (debug: rate x
AD/FD=0.01, survival x AD/FD=1.15, t0 fine) — t_obs sits on the early tail where the Gaussian kernel gradient
vanishes at its peak (locally flat AD, finite FD captures photon crossings). 

FIX (principled, not a hack): integrate the pdf over a TTS-width BIN -> uses ONLY the smooth survival R (CDF),
never the point rate. P(first in [t-D/2,t+D/2]) = exp(-R(t-D/2)) - exp(-R(t+D/2)).
  NLL_time_i = R(t_obs-D/2) - log1mexp(-(R(t_obs+D/2)-R(t_obs-D/2))),  R(t)=sum_j w_ij Phi((t-tau_ij)/sigma)
  (log1mexp input clamped <= -1e-7 for BOTH branches -> no jnp.where double-NaN). sigma=TTS=2.5, D=1.0ns, raw Poisson charge.

RESULT (K=8 MC=16 TTS 2.5):
  AD=FD (D=1.0): x AD/prof 0.99, energy 1.01, t0 0.66, y/z 1.3, polar 1.47, azim 1.75 -> RIGHT SIGN + magnitude
    (the 1.3-1.7 is the usual geometry-gradient normal-detach level, NOT a loss pathology). PROOF-READY.
  BIAS (D=1.0, per-event 12): joint x -0.202 std 0.138 | energy +2.6 std 49.3 (UNBIASED + TIGHT).
  D sweep: D=0.5 energy std 103 (noisier), D=1.0 energy std 49 (BEST), D=2.5 energy +130 std 348 (washed) -> D~1ns sweet spot.

VERDICT: the time-term question is SETTLED. Correct form = BINNED Poisson first-arrival likelihood (R-only, TTS-bin),
  which is (a) the exact first-in-TTS-bin probability, (b) dim-PMT robust (Poisson, no N_s-1), (c) energy-UNBIASING,
  (d) AD=FD CLEAN. The order-stat first_arrival_nll was the bad loss (-0.58m, wrong reasons). Residual position bias
  -0.20m = the forward engine/first-arrival-model timing residual (self-consistent -0.14m), a SEPARATE issue from the
  loss form. => proofs (AD=FD, bias, CRB, optimizer) should use THIS loss, not the order stat.
---

### L5 — NPH-dependent ENERGY bias bug + the count-conditioned fix + a SPEED bug   [2026-06-04]

SPEED BUG (profiled, prof_time.py): the loss scripts did `jax.jit(make(oc,ot,hit))` INSIDE the event loop
-> each event bakes new obs into a fresh closure -> JAX RECOMPILES the whole 500k forward (~16s) EVERY event.
build_pred 8s + build_truth 2s + first loss compile 16s (one-time); cached eval 0.14s; but jit(make(NEW obs)) = 15.8s
(recompile) while obs-as-ARGUMENTS new-obs = 0.14s. FIX: pass oc/ot/hit as jitted-function ARGS, compile once.
=> the slowness was recompilation, NOT the 500k photons (0.14s/call). All loss scripts refactored to obs-as-args.

ENERGY BUG (revealed by going to realistic NPH=500k; invisible at 50k where energy +-50 MeV noise): the binned
Poisson FA used the PREDICTED mu in the rate -> -log r contains -log mu -> joint MLE of mu ~ n_i+1 per lit PMT
-> over many lit PMTs (more at high NPH) the total charge/ENERGY is pulled high.
  OLD loss @500k: charge x +0.015 energy +11.6+-1.8 (FINE) ; JOINT x +0.083 energy +188.1+-10.3 (BAD, time adds +176).
  (@50k both ~0 in +-50 noise -> the 50k 'energy unbiased' was a noise artifact.)

FIX = factorize L_i = Poisson(n_i;mu)[charge] x order-stat(t_i | OBSERVED n_i, NORMALIZED density)[time]:
  S(t) = 1 - R(t)/mu  (survival SHAPE -> ENERGY-INDEPENDENT since energy scales all w_j together)
  NLL_time_i = -log[ S(t-D/2)^n_i - S(t+D/2)^n_i ] = -n_i log S_lo - log1mexp(n_i (log S_hi - log S_lo))
  -> energy comes ONLY from charge; dim-PMT safe (observed n_i>=1, no negative exponent). The original
  first_arrival_nll's core error was using PREDICTED N_s=mu here instead of OBSERVED n_i.
  First check @500k NEV=4: corrected JOINT energy +43 (vs old +188) -> ~145 MeV of the bias removed. Re-running NEV=12.

### L5b — corrected loss AD=FD RESOLVED (per-event integer-count, not mean-obs)   [2026-06-04]

The mean-obs AD=FD test fed a FRACTIONAL averaged n into S^n -> false wrong-signs. Per SINGLE integer-count event
(SINGLE_OBS=1, 500k, NKEYS=6): energy AD/prof 1.00 (CLEAN - the energy fix holds at gradient level), z 0.87, polar 1.64,
t0 1.17 (all fine); x/y/azim KINKY = the FORWARD overlap/geometry non-smoothness (same as L1), NOT a loss-form issue.

=> RESOLVED time term = count-conditioned binned order statistic with normalized survival (loss_cond.py):
   S(t)=1-R(t)/mu (energy-independent); NLL_time_i = -log[S(t-D/2)^n_i - S(t+D/2)^n_i], n_i=OBSERVED count.
   Energy-unbiased (charge -1.1, joint +37 vs old +188) AND AD=FD-clean for energy/z/polar/t0. Remaining: +37 energy
   forward residual + kinky x/y/azim (overlap non-smoothness). Loss FORM now settled; the test must use per-event integer n.

### L5c — WHY "kinky"? (clean test: offset center + mean obs + charge-vs-time split)   [2026-06-04]

The corrected-loss "kinky x/y/azim" was partly a TEST ARTIFACT: AD=FD/profile evaluated AT theta_true (the loss MIN)
with a SINGLE noisy event -> gradient ~0, sign dominated by per-event noise -> looks kinky. Proper test = OFFSET center
(theta_true + 3*scale per param, non-trivial gradient) + MEAN obs (12 realizations, kills per-event noise), charge vs time:
  x   charge 543/543/529/483 SMOOTH | time 1190/992/809/785 SMOOTH
  y   charge SMOOTH | time SMOOTH ;  z charge SMOOTH | time 2001/1944/1886/1785 SMOOTH
  polar charge SMOOTH | time 3390/3762/2289/596 smooth-ish (decreasing) ; azim charge SMOOTH | time -1287/+1888/+1142/+917 KINKY

ANSWER: x/y/z are NOT genuinely kinky (artifact of testing at-the-min single-event). Only the ANGLES (azim clearly,
polar borderline) are kinky, and ONLY in the TIME term: as the track rotates the Cherenkov ring sweeps across the
PMT/overlap-cell discretization; the soft overlap (temp 0.1) smooths the CHARGE assignment (azim charge smooth) but the
FIRST-ARRIVAL is a DISCRETE selection (which photon is earliest per PMT) that jumps as the ring sweeps -> time term kinky
in azimuth. Same ring-sweep non-smoothness as L1, localized to first-arrival selection. => only azim/polar gradients need
care (smoothing the first-arrival selection); x/y/z/energy/t0 are smooth and AD=FD-clean.

### L6 — 4-PARAM angle representation (sin/cos vs quaternion vs polar/azim)   [2026-06-04]

Tested replacing (polar,azim) with 4-param direction reps; loss = corrected count-conditioned joint @500k,
offset-center + mean-obs (12 real) profile + AD/profile per param. theta_to_track is the "where" (direction
computed directly, no atan2 round-trip issue away from pole).
  RAW azim: KINKY (finest-scale sign-flip -1287/+1888).
  QUATERNION q=[w,x,y,z] -> d (polynomial): all 4 q-params SMOOTH (no sign-flip); gradients large (~40k vs azim ~1k).
  SIN/COS [s_t,c_t,s_p,c_p] -> d=[s_t c_p, s_t s_p, c_t]: ALL params SMOOTH (incl s_p/c_p phi-circle), AD/prof
    energy .57 x 1.30 y .61 z .99 s_t 1.32 c_t .64 s_p .16 c_p 1.86 t0 1.01.

VERDICT: BOTH 4-param reps REMOVE the azim sign-flip. => the azim 'kink' was a POORLY-CONDITIONED COORDINATE +
  NOISE effect (raw azim grad is SMALL due to sin(theta) tangent scaling ~1k -> finest-scale noise ~3k flips the
  SIGN), NOT a physical ridge on S^2 (a real ridge would be inherited by any smooth reparam). Earlier 'azim genuinely
  kinky' (L1/L5c) was OVER-STATED. SIN/COS is the right choice (natural = emission angles, decoupled theta/phi,
  polynomial direction, no roll gauge; quaternion entangles + carries a useless roll DOF). REMAINING: angle gradient
  MAGNITUDE still uneven (s_p .16 / c_p 1.86) = the normal-detach geometry-gradient issue [[recon-track-hessian-breakers]],
  distributed across the new params; the 4-param rep fixes SIGN reliability, not magnitude. => adopt sin/cos for the optimizer.
