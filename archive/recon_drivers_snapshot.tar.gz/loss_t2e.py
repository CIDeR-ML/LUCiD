"""TIER 2e — is the +4ns low-occ late bias the predictor's sub-threshold LATE TAIL?
EXP (expected) has CONTINUOUS weights kept down to 1e-10 (make_hits_likelihood); the truth/SAMP is BINARY
(weights 0 or ~qe) so tiny late grazing deposits are realized only rarely, and make_hits_data thresholds
at 1e-5. So the predictor's rate R(t) may carry a late low-weight tail the truth can't have.
Test: sweep a weight threshold T on the EXP per-slot weights, recompute the per-PMT RATE mean time, compare
to SAMP. If dt(EXP-SAMP) -> 0 as T rises to ~1e-5, the late low-weight tail is the cause (a loss-side /
make_hits threshold fix, no propagator change). Also report the late-tail weight fraction per bucket.
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t2e.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '24'))
K = 8; MC = 16
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
trk = sc2track(jnp.asarray(th9_true))
print(f"# T2e late-tail threshold sweep  NPH={NPH} NREAL={NREAL}", flush=True)
def build(use_ev):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
        use_expected_value=use_ev, hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS,
        default_detector_params=True, particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
EXP = build(True); SAMP = build(False); ND = H.num_detectors(EXP)

# EXP raw per-slot arrays (one call)
lw_e, t_e, idx_e, _ = [np.asarray(a) for a in jax.lax.stop_gradient(EXP(trk, jax.random.PRNGKey(0)))]
w_e = np.where(lw_e > -50, np.exp(np.clip(lw_e, -50, 20)), 0.0)
def exp_rate_moments(thr):
    m = w_e > thr
    sw = np.zeros(ND); swt = np.zeros(ND)
    np.add.at(sw, idx_e[m], w_e[m]); np.add.at(swt, idx_e[m], (w_e * t_e)[m])
    return sw, swt
# SAMP rate (binary, averaged) via jit
@jax.jit
def rate_moments(out):
    lw, t, idx, tot = out
    w = jnp.where(lw > -50, jnp.exp(jnp.clip(lw, -50, 20)), 0.0)
    return jax.ops.segment_sum(w, idx, num_segments=ND), jax.ops.segment_sum(w * t, idx, num_segments=ND)
sw_s = np.zeros(ND); swt_s = np.zeros(ND)
for r in range(NREAL):
    a, b = rate_moments(jax.lax.stop_gradient(SAMP(trk, jax.random.PRNGKey(1000 + r))))
    sw_s += np.asarray(a); swt_s += np.asarray(b)
sw_s /= NREAL; swt_s /= NREAL
mt_s = np.where(sw_s > 1e-9, swt_s / np.maximum(sw_s, 1e-12), np.nan)

sw_e0, _ = exp_rate_moments(0.0)                                   # occupancy reference (full)
edges = [0.05, 0.2, 0.5, 1.0, 2.0, 100]
THRS = [0.0, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3]
# late-tail weight fraction per bucket (weight below 1e-5 / total)
sw_lo, _ = exp_rate_moments(1e-5)
print(f"#  occ-bucket | Npmt | <1e-5-tail wfrac | " + " | ".join(f"dt@T={t:g}" for t in THRS), flush=True)
mt_e = {t: (lambda sw, swt: np.where(sw > 1e-9, swt / np.maximum(sw, 1e-12), np.nan))(*exp_rate_moments(t)) for t in THRS}
for lo, hi in zip(edges[:-1], edges[1:]):
    sel = np.where((sw_e0 > lo) & (sw_e0 <= hi))[0]
    if sel.size == 0: continue
    tailfrac = 1.0 - sw_lo[sel].sum() / max(sw_e0[sel].sum(), 1e-9)
    dts = []
    for t in THRS:
        ok = np.isfinite(mt_e[t][sel]) & np.isfinite(mt_s[sel])
        dts.append(np.nanmean((mt_e[t][sel] - mt_s[sel])[ok]))
    print(f"#  {lo:4.2f}-{hi:<5.2f}| {sel.size:5d} | {tailfrac:14.3f} | " + " | ".join(f"{d:+7.3f}" for d in dts), flush=True)
print(f"# READ: if dt -> 0 as T rises to ~1e-5 => the sub-1e-5 late tail in the predictor rate is the cause", flush=True)
print(f"#       (fix = threshold/clip predictor weights to the truth's support). If dt persists => not the tail.", flush=True)
