"""DETERMINISTIC single-key Hessian h-convergence. With ONE fixed key the predictor f(theta) is
deterministic (no Monte-Carlo noise), so for a C2 function FD(h) -> AD as h->0 (error O(h^2)). Where
FD fails to converge to AD localizes a KINK. oc = q(truth,key0) same key => residual 0 at truth =>
Hessian = 2 J^T J (Gauss-Newton), clean and deterministic.
Usage: CUDA_VISIBLE_DEVICES=g MAXCELL=8 KK=1 OVERLAP_ANALYTIC=cubic KEY=0 python hess_det.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
import recon_harness as H, recon_ps_setup as PS
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPH', '40000')); K = int(os.environ.get('KK', '8')); MAXCELL = int(os.environ.get('MAXCELL', '16'))
assert K >= 8, "truth/predictor must use K>=8 (user constraint: truth is always K>=8, multi-candidate cells)"
KEY = int(os.environ.get('KEY', '0')); OV = os.environ.get('OVERLAP_ANALYTIC', '(none)')
SC = np.array(H.PARAM_SCALE); NAMES = H.PARAM_NAMES
pred_baked = H.build_predictor(temperature=0.1, K=K, n_photons=NPH)
DP0 = pred_baked.default_detector_params
pred = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False,
    use_expected_value=True, hit_mode='per_photon', max_sensors_per_cell=MAXCELL, physics_config=H.PHYS,
    default_detector_params=False, particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
ts = np.array([1050., 0., 0., 0., 0.6, 0.8, 0.])
key = jax.random.PRNGKey(KEY)
oc = jax.lax.stop_gradient(pred(H.theta_to_track(jnp.asarray(ts)), DP0, key)[3])
def L(theta):
    q = pred(H.theta_to_track(theta), DP0, key)[3]
    return jnp.sum((q - oc) ** 2)
gfn = jax.jit(jax.grad(L))
# Hessian column-by-column via HVP (jvp of grad) -> only gradient-memory, no jax.hessian 7x blowup.
def hvp(x, v): return jax.jvp(jax.grad(L), (x,), (v,))[1]
hvp_j = jax.jit(hvp)
Had = np.zeros((7, 7))
for j in range(7):
    Had[:, j] = np.array(hvp_j(jnp.asarray(ts), jnp.asarray(np.eye(7)[j]))) * SC * SC[j]
Had = 0.5 * (Had + Had.T)
print(f"=== DETERMINISTIC single-key Hessian  K={K} maxcell={MAXCELL} overlap={OV} key={KEY} ===", flush=True)
print(f"AD diag: {np.diag(Had)}", flush=True)
hs = [0.3, 0.1, 0.03, 0.01, 0.003, 0.001]
print(f"{'h':>7} " + " ".join(f"{n:>9}" for n in NAMES) + "   relerr", flush=True)
for h in hs:
    Hfd = np.zeros((7, 7))
    for j in range(7):
        d = h * SC[j]
        Hfd[:, j] = (np.array(gfn(jnp.asarray(ts + np.eye(7)[j] * d))) -
                     np.array(gfn(jnp.asarray(ts - np.eye(7)[j] * d)))) / (2 * h) * SC
    Hfd = 0.5 * (Hfd + Hfd.T)
    rel = np.linalg.norm(Had - Hfd) / (np.linalg.norm(Hfd) + 1e-12)
    gb = slice(1, 6)   # geometry block x,y,z,polar,azim (exclude energy[0] score term + t0[6] flat)
    grel = np.linalg.norm(Had[gb, gb] - Hfd[gb, gb]) / (np.linalg.norm(Hfd[gb, gb]) + 1e-12)
    gpe = np.abs(np.diag(Had)[gb] - np.diag(Hfd)[gb]) / (np.abs(np.diag(Hfd)[gb]) + 1e-9) * 100
    print(f"{h:>7} " + " ".join(f"{v:>9.2f}" for v in np.diag(Hfd)) + f"   {rel:.3f}  GEOMrel={grel:.3f} geomdiag%={np.array2string(gpe,precision=0)}", flush=True)
print("(FD diag per h above; compare to AD diag. Smooth => converges to AD as h->0.)", flush=True)
