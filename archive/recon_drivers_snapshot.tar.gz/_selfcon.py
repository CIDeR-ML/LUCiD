import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.simulation.simulator import setup_event_simulator
from lucid.losses import segment_logsumexp
NPH=50000; NKEYS=16; NEV=12; SIGMA=2.5; K=8
PS=np.asarray(H.PARAM_SCALE); tt=np.array([1050.,0,0,0,0.6,0.8,0.])
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH)
# TRUTH using the SAME EXPECTED engine (use_expected_value=True) + hard realistic detection:
truth_exp=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=0.1,K=K,is_data=False,use_expected_value=True,
  hit_mode='realistic',max_sensors_per_cell=16,physics_config=H.PHYS,default_detector_params=True,
  particle='muon',wavelength_mode=True)
# sample-engine truth (for comparison)
truth_smp=H.build_truth_sim(K=K,n_photons=NPH)
ND=H.num_detectors(pred); keys=[jax.random.PRNGKey(s) for s in range(NKEYS)]
LOGN_C=float(np.log(SIGMA*np.sqrt(2*np.pi))); SQ=float(np.sqrt(2.))
def make(oc,ot,hit,wt):
    oc=jax.lax.stop_gradient(oc);ot=jax.lax.stop_gradient(ot);hit=jax.lax.stop_gradient(hit)
    def loss(th,key):
        lw,ft,fi,tot=pred(H.theta_to_track(th),key); d=(ot-th[6])[fi]-ft
        lr=segment_logsumexp(lw+(-0.5*(d/SIGMA)**2-LOGN_C),fi,ND)
        R=jax.ops.segment_sum(jnp.exp(lw)*0.5*(1+erf(d/(SIGMA*SQ))),fi,num_segments=ND)
        lr=jnp.maximum(lr,-60.); empty=lr<=-59.; usable=hit&(~empty)
        time=jnp.sum(jnp.where(usable,-lr+R,0.)); mu=jnp.maximum(tot,1e-8)
        return jnp.sum(mu-oc*jnp.log(mu))+wt*time
    return loss
def argmin(lj,i=1):
    sv=np.linspace(-4*PS[i],4*PS[i],15)
    c=np.array([np.mean([float(lj(jnp.asarray(tt+s*np.eye(7)[i]),k)) for k in keys]) for s in sv])
    j=int(np.argmin(c));lo=max(0,j-2);hi=min(15,j+3);a,b,_=np.polyfit(sv[lo:hi],c[lo:hi],2)
    return (-b/(2*a) if a>0 else sv[j])
for nm,tsim in [('EXPECTED-engine truth',truth_exp),('SAMPLE-engine truth',truth_smp)]:
    bx=[]
    for ev in range(NEV):
        oc,ot,hit=H.gen_truth(tsim,jnp.asarray(tt),jax.random.PRNGKey(5000+ev))
        bx.append(argmin(jax.jit(make(oc,ot,hit,1.0))))
    bx=np.array(bx); print(f"# {nm:24s}: JOINT x bias {bx.mean():+.3f} std {bx.std():.3f} m",flush=True)
print("# READ: EXPECTED-engine truth ~0 bias => the -0.22m is the expected-vs-SAMPLE engine forward timing residual, not the loss.")
