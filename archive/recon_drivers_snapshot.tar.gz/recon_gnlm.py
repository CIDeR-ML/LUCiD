"""GN-LM reconstruction: empirical-Fisher / Gauss-Newton metric F=E[g g^T] + Levenberg-Marquardt
diagonal ridge + eigenvalue clipping + Polyak tail (the calibration optimizer) on the TUNED recon
loss (raw Poisson charge NLL + first_arrival_nll, WT/TAU best config) with the now-correct AD
gradient (DiCE emission sampler + straight-through overlap). Demonstrates parameter COUPLING via the
full off-diagonal metric inverse. Usage: CUDA_VISIBLE_DEVICES=g [WT TAU OFF] python recon_gnlm.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import poisson_nll, first_arrival_nll
np.set_printoptions(precision=4, suppress=True)

K, NPHOT = 7, 50_000
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
NK = int(os.environ.get('NK', '6')); STEPS = int(os.environ.get('STEPS', '160'))
LR = float(os.environ.get('LR', '0.4')); LM = float(os.environ.get('LM', '0.05'))
OFF = float(os.environ.get('OFF', '0.6')); TAIL = int(os.environ.get('TAIL', '45'))
WT = float(os.environ.get('WT', '0.03')); TAU = float(os.environ.get('TAU', '4.0'))
SCALE = np.array(H.PARAM_SCALE)
theta_star = np.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 5.0])

pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(truth, jnp.array(theta_star), jax.random.PRNGKey(SEED))
ocf = jax.lax.stop_gradient(oc); otf = jax.lax.stop_gradient(ot); hitf = jax.lax.stop_gradient(hit)
SUMOBS = float(jnp.sum(oc))

def loss(theta, key):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    c = jnp.sum(q - ocf * jnp.log(q + 1e-8)) / SUMOBS * 100.0          # raw Poisson NLL (energy scale)
    t = jnp.sum(jnp.where(hitf, first_arrival_nll(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
    return c + WT * t
gfn = jax.jit(jax.grad(loss))

rng = np.random.default_rng(SEED)
theta = jnp.array(theta_star + rng.uniform(-1, 1, 7) * OFF * SCALE)
print(f"SEED={SEED} OFF={OFF} WT={WT} TAU={TAU}", flush=True)
tail = []
for s in range(STEPS):
    keys = jax.random.split(jax.random.PRNGKey(31 * SEED + s), NK)
    G = np.stack([np.array(gfn(theta, k)) * SCALE for k in keys])      # normalized grads
    g = G.mean(0); F = (G.T @ G) / NK
    d = np.clip(np.diag(F), 1e-12, None)
    Fr = F + LM * np.diag(d) + 1e-9 * np.eye(7) * (d.max() + 1e-12)
    ev, V = np.linalg.eigh(Fr)
    ev = np.clip(ev, 2e-2 * ev.max(), None)                            # eigenvalue clip
    step = np.clip(V @ np.diag(1.0 / ev) @ V.T @ g, -0.35, 0.35) * SCALE
    theta = theta - LR * jnp.array(step)
    if s >= STEPS - TAIL:
        tail.append(np.array(theta))
    if (s + 1) % 40 == 0:
        print(f"  step {s+1}: |dθ|/scale = {np.abs(np.array(theta)-theta_star)/SCALE}", flush=True)
pa = np.mean(tail, 0); err = (pa - theta_star)
U = ['MeV', 'm', 'm', 'm', 'rad', 'rad', 'ns']
print("GNLM " + str(SEED) + " " + " ".join(f"{pa[i]:.4f}" for i in range(7))
      + " | err " + " ".join(f"{err[i]:+.3g}{U[i]}" for i in range(7)), flush=True)
