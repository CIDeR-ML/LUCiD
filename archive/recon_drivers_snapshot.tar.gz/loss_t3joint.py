"""TIER 3 joint — does the forward bias MATTER once t0 is FREE? The 1D profiles show t0 wants -0.55ns
and vtx ~few cm, but t0 is degenerate with vertex-along-track (0.55ns ~ 0.12m). Joint-fit ALL 9 params
(count-conditioned loss, REAL sample-engine truth) from truth with Adam, average over keys -> where does it
converge? If t0 absorbs ~-0.55ns and the ORTHOGONAL vertex residual stays small (~few cm, < 16cm floor),
the implicit-capture forward bias is harmless for recon. Compare baseline vs PSTEP_DBG=detect_hard.
Env: NPHOT NREAL NKEYS STEPS PSTEP_DBG.  Usage: CUDA_VISIBLE_DEVICES=g [PSTEP_DBG=detect_hard] python loss_t3joint.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np, optax
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '32'))
NKEYS = int(os.environ.get('NKEYS', '4')); STEPS = int(os.environ.get('STEPS', '400'))
K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
print(f"# T3joint  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS} STEPS={STEPS} PSTEP_DBG={os.environ.get('PSTEP_DBG','')}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk = sc2track(jnp.asarray(th9_true))
OC = np.zeros((NREAL, ND)); OT = np.zeros((NREAL, ND))
for r in range(NREAL):
    c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r)))
    OC[r] = np.asarray(c); OT[r] = np.where(np.asarray(c) > 0, np.asarray(t), 0.0)
OC = jnp.asarray(OC); OT = jnp.asarray(OT); KEYS = jnp.stack([jax.random.PRNGKey(s) for s in range(NKEYS)])

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
def cheaploss(ww, ft, fi, tot, t0, oc, ot):
    tobs = (ot - t0)[fi]; mu = jnp.maximum(tot, 1e-8)
    Rlo = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs - DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Rhi = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs + DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rlo) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rhi) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(oc > 0, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
@jax.jit
def loss_one(th9, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key); ww = jnp.exp(jnp.clip(log_w, -60, 20))
    return jnp.mean(jax.vmap(lambda oc, ot: cheaploss(ww, ft, fi, tot, th9[8], oc, ot))(OC, OT))
gradone = jax.jit(jax.value_and_grad(loss_one))
def loss_and_grad(th9):                                            # average over keys in a python loop (low memory)
    L = 0.0; G = jnp.zeros(9)
    for s in range(NKEYS):
        l, g = gradone(th9, jax.random.PRNGKey(s)); L = L + l; G = G + g
    return L / NKEYS, G / NKEYS

# Adam in SCALED params (z = (th9-true)/SCALE9) so steps are comparable across params
opt = optax.adam(3e-2); z = jnp.zeros(9); st = opt.init(z)
SC = jnp.asarray(SCALE9); T0 = jnp.asarray(th9_true)
for i in range(STEPS):
    th = T0 + z * SC; lv, g = loss_and_grad(th); g = g * SC
    upd, st = opt.update(g, st); z = optax.apply_updates(z, upd)
    if i % 50 == 0 or i == STEPS - 1:
        th = np.asarray(T0 + z * SC); print(f"#  step {i:4d} loss {float(lv):.1f}  off-truth: " +
            " ".join(f"{NAMES[j]}={th[j]-th9_true[j]:+.3f}" for j in [0,1,2,3,8]), flush=True)
th = np.asarray(T0 + z * SC); d = th - th9_true
vtx = float(np.sqrt(d[1]**2 + d[2]**2 + d[3]**2))
print(f"#  FINAL off-truth: E={d[0]:+.1f}MeV  vtx=({d[1]:+.3f},{d[2]:+.3f},{d[3]:+.3f})m |vtx|={vtx:.3f}m  t0={d[8]:+.3f}ns", flush=True)
print(f"#  READ: |vtx| residual after t0 absorbs => is the forward bias within the ~16cm photon floor (harmless)?", flush=True)
