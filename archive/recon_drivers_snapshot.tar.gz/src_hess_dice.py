"""Isolation test for the SIREN-source energy 2nd-order (autodiff Hessian vs FD).

Three objectives over the SIREN source outputs, wrt p=[origin(3),dir(3),energy]:
  (A) bare  sum(rays)+sum(origins)+sum(weights)            -- NOT dice-weighted (the original src_hess.py f)
  (B) DiCE  sum( g(rays,origins) * dice_score )            -- proper magic-box weighted deposit-like scalar
  (C) DiCE  with a sensor-like nonlinear g                 -- a smooth function of the per-photon ray/origin

For (B)/(C) we re-derive the dice_score inside the test so the objective is genuinely (-)-weighted:
this tells us whether the energy 2nd-order is broken only because sum(rays) lacks the score (A), or
genuinely lost even for a score-weighted quantity (the systematic-resample shift) (B/C).

Env: SIREN_CONTINUOUS=0|1 selects the discrete vs continuous inverse-CDF sampler.
Usage: CUDA_VISIBLE_DEVICES=g SIREN_CONTINUOUS=0 python src_hess_dice.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.siren.core import create_photonsim_siren_grid, SIREN
from lucid.siren.training.inference import SIRENPredictor
from lucid.sources.siren_rays import (photonsim_differentiable_get_rays,
                                       normalize_inputs_jit, denormalize_log_predictions,
                                       generate_random_cone_vectors)
from lucid.utils import unpack_photonsim_params, normalize
np.set_printoptions(precision=3, suppress=True, linewidth=140)

CONT = os.environ.get('SIREN_CONTINUOUS', '0') == '1'
NPHOT = int(os.environ.get('NPHOT', '40000'))
print(f"SIREN_CONTINUOUS={int(CONT)}  NPHOT={NPHOT}")

dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
pp = unpack_photonsim_params('muon', dg.medium.material)
pr = SIRENPredictor(pp['siren_model_path']); grid = create_photonsim_siren_grid(pr)
na, nb, nc = pp['num_seeds']; mp = pr.params; key = jax.random.PRNGKey(0)
d0 = np.array([np.sin(0.6)*np.cos(0.8), np.sin(0.6)*np.sin(0.8), np.cos(0.6)])
p0 = jnp.array([0., 0., 0., d0[0], d0[1], d0[2], 1050.0])
SCp = np.array([0.2, 0.2, 0.2, 0.05, 0.05, 0.05, 50.0])

(n_bins, energy_min, energy_max, angle_min, angle_max, distance_min, distance_max,
 angle_bins, distance_bins, angle_dist_grid, angle_mesh, distance_mesh, log_min, log_max) = grid
angle_dist_mesh = jnp.array(angle_dist_grid)
n_grid = angle_dist_mesh.shape[0]
model = SIREN(hidden_features=256, hidden_layers=3, out_features=1)


def dice_deposit(p, nonlinear=False):
    """A genuinely DiCE-(magic-box)-weighted deposit-like scalar over the SIREN emission.

    Re-implements the sampler's emission (matching siren_rays.py), then forms
        sum_i  g_i * dice_score_i
    so the score-function correction is applied per photon. g_i is a smooth function of the
    photon ray direction and origin (a stand-in for a downstream deposit). When CONT, the
    sampling is continuous (dice_score=1, gradient pathwise); else discrete (score carries it).
    """
    track_origin, track_direction, energy = p[:3], p[3:6], p[6]
    k = key
    k, subkey = jax.random.split(k)
    eg = jnp.stack([jnp.full_like(angle_mesh, energy).ravel(), angle_mesh.ravel(), distance_mesh.ravel()], axis=1)
    ng = normalize_inputs_jit(eg, energy_min, energy_max, angle_min, angle_max, distance_min, distance_max)
    log_pred, _ = model.apply(mp, ng)
    density = jnp.clip(denormalize_log_predictions(jnp.squeeze(log_pred), log_max, log_min), 1e-12, None)
    p_emit = density / jnp.sum(density)
    k, sk = jax.random.split(k)
    cdf = jnp.cumsum(p_emit)
    u0 = jax.random.uniform(sk, ()) / NPHOT
    us = u0 + jnp.arange(NPHOT) / NPHOT
    idx = jnp.clip(jnp.searchsorted(cdf, us), 0, n_grid - 1)
    logp = jnp.log(p_emit[idx])
    if CONT:
        hi = jnp.clip(idx, 0, n_grid - 1); lo = jnp.clip(idx - 1, 0, n_grid - 1)
        cdf_lo = jnp.where(idx <= 0, 0.0, cdf[lo]); cdf_hi = cdf[hi]
        frac = jnp.clip((us - cdf_lo) / (cdf_hi - cdf_lo + 1e-12), 0.0, 1.0)
        sad = (1.0 - frac[:, None]) * angle_dist_mesh[lo] + frac[:, None] * angle_dist_mesh[hi]
        dice_score = jnp.ones(NPHOT)
    else:
        sad = angle_dist_mesh[idx]
        dice_score = jnp.exp(logp - jax.lax.stop_gradient(logp))
    sampled_angle, sampled_dist = sad[:, 0], sad[:, 1]
    # (skip stratified jitter here -- deterministic emission is enough to probe the energy 2nd-order)
    k, sub2 = jax.random.split(subkey)
    rv = generate_random_cone_vectors(track_direction, sampled_angle, NPHOT, sub2)
    ranges = sampled_dist / 1000.0
    ro = jnp.ones((NPHOT, 3)) * track_origin[None, :] + ranges[:, None] * normalize(track_direction[None, :])
    if nonlinear:
        # smooth nonlinear "deposit": depends on ray z-projection and origin distance from a point
        g = jnp.exp(-((rv[:, 2] - 0.7) ** 2)) * (1.0 + jnp.sum(ro ** 2, axis=1))
    else:
        g = jnp.sum(rv, axis=1) + jnp.sum(ro, axis=1)
    return jnp.sum(g * dice_score)


def bare_sum(p):
    rv, ro, w = photonsim_differentiable_get_rays(p[:3], p[3:6], p[6], NPHOT, grid, mp, key, na, nb, nc)
    return jnp.sum(rv) + jnp.sum(ro) + jnp.sum(w)


def hess_vs_fd(f, label):
    Had = np.array(jax.hessian(f)(p0)) * np.outer(SCp, SCp)
    gf = jax.jit(jax.grad(f))
    Hfd = np.zeros((7, 7))
    for j in range(7):
        d = 0.3 * SCp[j]
        Hfd[:, j] = (np.array(gf(p0.at[j].add(d))) - np.array(gf(p0.at[j].add(-d)))) / (2 * 0.3) * SCp
    Hfd = 0.5 * (Hfd + Hfd.T)
    finite = bool(np.isfinite(Had).all())
    rel = np.linalg.norm(Had - Hfd) / (np.linalg.norm(Hfd) + 1e-9)
    cos = float(Had.ravel() @ Hfd.ravel() / (np.linalg.norm(Had.ravel()) * np.linalg.norm(Hfd.ravel()) + 1e-12))
    # energy-row-specific metrics
    er_ad, er_fd = Had[6], Hfd[6]
    er_rel = np.linalg.norm(er_ad - er_fd) / (np.linalg.norm(er_fd) + 1e-9)
    er_cos = float(er_ad @ er_fd / (np.linalg.norm(er_ad) * np.linalg.norm(er_fd) + 1e-12))
    pw_rel = np.linalg.norm(Had[:6, :6] - Hfd[:6, :6]) / (np.linalg.norm(Hfd[:6, :6]) + 1e-9)
    print(f"\n=== {label} (finite={finite}) ===")
    print("  diag autodiff:", np.diag(Had))
    print("  diag FD      :", np.diag(Hfd))
    print(f"  FULL   rel={rel:.4f}  cos={cos:.4f}")
    print(f"  PATHW  (6x6 origin+dir) rel={pw_rel:.4f}")
    print("  energy-row autodiff:", er_ad)
    print("  energy-row FD      :", er_fd)
    print(f"  ENERGY-ROW  rel={er_rel:.4f}  cos={er_cos:.4f}")
    return er_cos, er_rel


print("\n############ Objective A: bare sum(rays)+sum(origins)+sum(weights) (NOT dice-weighted) ############")
hess_vs_fd(bare_sum, "A: bare_sum")
print("\n############ Objective B: DiCE-weighted linear deposit  sum(g*dice_score) ############")
hess_vs_fd(lambda p: dice_deposit(p, nonlinear=False), "B: dice linear")
print("\n############ Objective C: DiCE-weighted nonlinear deposit  sum(g(ray,origin)*dice_score) ############")
hess_vs_fd(lambda p: dice_deposit(p, nonlinear=True), "C: dice nonlinear")
