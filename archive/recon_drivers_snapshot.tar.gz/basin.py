"""BASIN OF ATTRACTION study. Robust Adam optimizer on the recipe loss (lE energy + WT*lT_gd Gaussian
first-arrival, sigma-ANNEALED). Offset ONE parameter (PIDX) from truth by a list of values (others at
truth), optimize, report the FINAL error -> the capture range for that parameter. Answers: does it always
converge from nearby? how far before it breaks? per parameter.
Env: TRUTH TTS_NS PIDX(0=E,1..3=xyz,4=polar,5=azim,6=t0) OFFS(csv physical) NKG SPS WT SIGEND TKS
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 PIDX=4 OFFS=0.035,0.087,0.175,0.35,0.7 python basin.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000'))
WT = float(os.environ.get('WT', '1.0')); THR = float(os.environ.get('THR', '4.0'))
NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '18')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0'))
PIDX = int(os.environ.get('PIDX', '4')); OFFS = [float(x) for x in os.environ.get('OFFS', '0.035,0.087,0.175,0.35,0.7').split(',')]
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi); NAMES = H.PARAM_NAMES
SIGSCHED = [s for s in [30, 15, 8, 4, SIGEND] if s >= SIGEND] + ([] if SIGEND in [30, 15, 8, 4] else [SIGEND])
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WT * lT
gfn = jax.jit(jax.grad(loss))

def optimize(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g
            mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
unit = {0: 'MeV', 1: 'm', 2: 'm', 3: 'm', 4: 'deg', 5: 'deg', 6: 'ns'}[PIDX]
cvt = deg if PIDX in (4, 5) else 1.0
print(f"# BASIN TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} param={NAMES[PIDX]} SIGSCHED={SIGSCHED} NKG={NKG} SPS={SPS} (offset 1 param, others at truth)", flush=True)
for off in OFFS:
    fin = []
    for tk in TKS:
        oc, ot, hi = regen(tk)
        th0 = ts.copy(); th0[PIDX] += off
        th = optimize(th0, oc, ot, hi, tk)
        fin.append((abs(th[PIDX] - ts[PIDX]) * cvt, vtx(th), degf(th)))
    F = np.array(fin)
    print(f"  start_offset={off * cvt:+7.2f}{unit}: final |{NAMES[PIDX]}_err|={F[:,0].mean():6.2f}{unit}  vtx={F[:,1].mean():5.1f}cm  dir={F[:,2].mean():5.2f}deg  (converged={'YES' if F[:,1].mean()<20 and F[:,2].mean()<2 else 'NO '})", flush=True)
