"""ALIGNMENT B4 (corrected) — emission TIME model: PhotonSim t_emit(distance) vs SIREN predict_t0(distance).

The SIREN path does NOT use emission time 0: simulator adds t0 = predict_t0(distance_to_vertex, energy)
(a learned deterministic baseline). So the right check is whether predict_t0(d) reproduces PhotonSim's
per-photon emission time as a function of distance-to-vertex d, and how much per-photon SPREAD remains
(the stochastic part a deterministic t0 cannot capture -> a timing-resolution floor SIREN omits).

PhotonSim: per-photon (distance d = |origin - vertex|, emission time t). Bin by d; mean & within-bin std.
SIREN: predict_t0(d_mm, energy, *t0_params).  Compare de-meaned trends + residual spread.
Env: NEV ENERGY.  Usage: CUDA_VISIBLE_DEVICES=g python align_b2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.sources.siren_rays import predict_t0
from lucid.utils import unpack_t0_params
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NEV = int(os.environ.get('NEV', '5')); ENERGY = float(os.environ.get('ENERGY', '1050'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
t0p = unpack_t0_params('muon', 'water')

D_p, T_p = [], []
for ev in range(NEV):
    raw = read_photon_data_from_photonsim(ROOT, ev)
    P = np.asarray(raw['photon_origins']) / 100.0
    _, _, vt = np.linalg.svd(P - P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx = P.mean(0) + ((P - P.mean(0)) @ d0).min() * d0
    D_p.append(np.linalg.norm(P - vtx, axis=1)); T_p.append(np.asarray(raw['photon_times']))
D_p = np.concatenate(D_p); T_p = np.concatenate(T_p)            # d[m], t[ns]

# SIREN deterministic baseline over the distance range (predict_t0 wants mm)
dgrid = np.linspace(np.percentile(D_p, 1), np.percentile(D_p, 99), 60)
pt0 = jax.vmap(predict_t0, in_axes=(0, None, None, None, None, None, None, None, None))
t0_siren = np.asarray(pt0(jnp.asarray(dgrid * 1000.0), ENERGY, *t0p))

# PhotonSim mean & within-bin spread vs distance
edges = np.linspace(D_p.min(), np.percentile(D_p, 99), 40); cen = 0.5 * (edges[:-1] + edges[1:])
idx = np.digitize(D_p, edges) - 1; mean_t = np.full(len(cen), np.nan); res_t = np.full(len(cen), np.nan)
for i in range(len(cen)):
    m = idx == i
    if m.sum() > 30: mean_t[i] = T_p[m].mean(); res_t[i] = T_p[m].std()
# align zero-points (compare distance-DEPENDENCE; predict_t0 has its own absolute offset)
ok = np.isfinite(mean_t)
ps_dm = mean_t[ok] - np.nanmean(mean_t[ok])
si_interp = np.interp(cen[ok], dgrid, t0_siren); si_dm = si_interp - si_interp.mean()
trend_rmse = np.sqrt(np.nanmean((ps_dm - si_dm) ** 2))
print(f"# B4 emission-time model  NEV={NEV}  photons={len(D_p)}", flush=True)
print(f"# PhotonSim t_emit: overall mean {T_p.mean():.2f} ns  std {T_p.std():.2f} ns", flush=True)
print(f"# distance-dependence (de-meaned): PhotonSim spans {ps_dm.min():.2f}..{ps_dm.max():.2f} ns ; "
      f"SIREN predict_t0 spans {si_dm.min():.2f}..{si_dm.max():.2f} ns ; trend RMSE {trend_rmse:.2f} ns", flush=True)
print(f"# WITHIN-distance-bin residual spread (stochastic, NOT captured by deterministic predict_t0): "
      f"median {np.nanmedian(res_t):.2f} ns  (this is the per-photon emission-time jitter SIREN omits)", flush=True)

fig, ax = plt.subplots(1, 2, figsize=(13, 5))
ax[0].plot(cen[ok], ps_dm, 'C0-o', ms=3, label='PhotonSim mean t_emit (de-meaned)')
ax[0].plot(cen[ok], si_dm, 'C1-', lw=2, label='SIREN predict_t0 (de-meaned)')
ax[0].set_xlabel('distance to vertex [m]'); ax[0].set_ylabel('Δ emission time [ns]')
ax[0].set_title(f'emission-time trend vs distance (RMSE {trend_rmse:.2f} ns)'); ax[0].legend()
ax[1].plot(cen[ok], res_t[ok], 'C0-o', ms=3); ax[1].set_xlabel('distance to vertex [m]')
ax[1].set_ylabel('within-bin std of t_emit [ns]')
ax[1].set_title('per-photon emission-time spread SIREN OMITS (deterministic t0)')
plt.tight_layout(); plt.savefig('_alignB_t0.png', dpi=90); print("# saved _alignB_t0.png", flush=True)
