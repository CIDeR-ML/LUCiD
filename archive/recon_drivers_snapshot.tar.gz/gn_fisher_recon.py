"""PHASE 2 — CONSISTENT FISHER-GN recon optimizer (calibration-inspired, verified PSD metric).
Metric (PSD by construction, NO eigen-clip): F = Jmu^T diag(1/mu) Jmu  (charge Fisher)  +  Jl^T Jl  (time
empirical Fisher = sum of per-PMT time-NLL score outer products). Both Jacobians via FD (jacfwd blocked by DiCE
custom_vjp). Built CONSISTENTLY with the gradient on the SAME fixed key set each step (recomputed every step -> no
stale-Hessian drift). Damping = Marquardt LAM*diag(F) (scale-invariant). Step dth=-(F+LAM diag F)^-1 g, optional
safety step-clip. Readout = min||g|| iterate (NOT min-loss, NOT raw-final). No clip, no SCALE9 metric, no line search.
Vary truth position+angle (RANDOMIZE). Env: OPTMODE START_OFF RANDOMIZE LAM NITERS NKEYS READOUT STEPCLIP EVENT_* TAG.
Usage: CUDA_VISIBLE_DEVICES=0 RANDOMIZE=1 EVENT_START=0 EVENT_COUNT=8 python gn_fisher_recon.py
"""
import os,time
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=3, suppress=True, linewidth=170)
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NBUF=400_000
MC=int(os.environ['MAXCELL']); K=8; SIGMA=float(os.environ.get('LOSS_SIGMA','2.5')); DELTA=float(os.environ.get('DELTA','1.0')); SQ=float(np.sqrt(2.0))
OCC_GATE=float(os.environ.get('OCC_GATE','0'))   # >0: time term only on PMTs with charge<=OCC_GATE (low-occupancy first-arrival cleaner)
OCC_MIN=float(os.environ.get('OCC_MIN','0'))     # >0: time term only on PMTs with charge>=OCC_MIN -> EXCLUDE dim scattered-light PMTs (predictor mistimes them by +40ns); direct-light PMTs match data
CGATE=float(os.environ.get('CGATE','0'))         # >0: time term only on PMTs where |mu-oc|<CGATE*sqrt(mu) (charge-consistent geometry)
NPHP=int(os.environ.get('NPHOT_PRED','500000')); NKEYS=int(os.environ.get('NKEYS','4')); NITERS=int(os.environ.get('NITERS','60'))
LAM=float(os.environ.get('LAM','0.01')); STEPCLIP=float(os.environ.get('STEPCLIP','0.5')); READOUT=os.environ.get('READOUT','ming')  # ming|polyak|final
START_OFF=float(os.environ.get('START_OFF','0')); START_PIDX=int(os.environ.get('START_PIDX','3')); RANDOMIZE=int(os.environ.get('RANDOMIZE','0'))
T0_JIT=float(os.environ.get('T0_JIT','0'))    # truth t0 ~ U(-T0_JIT,T0_JIT) ns (shift observed times) AND start fit t0 at 0 -> honest t0 recovery
E_STJIT=float(os.environ.get('E_STJIT','0'))  # start fit ENERGY at true +/- U(-E_STJIT,E_STJIT) MeV (truth E fixed=gun 1050) -> honest E recovery/basin
JIT_ALL=float(os.environ.get('JIT_ALL','0'))  # realistic from-scratch: start ALL 9 params offset by JIT_ALL*SCALE9*U(-1,1) (E~50,vtx~0.2m,ang~0.02,t0~0.2ns per unit)
BJIT=int(os.environ.get('BJIT','0'))          # BASIN jitter: start FURTHER from truth for ALL params, each within its measured basin (independent per-param magnitudes)
BJIT_V=float(os.environ.get('BJIT_V','5.0'))  # vertex offset max (m) [basin 100% to 10m]
BJIT_E=float(os.environ.get('BJIT_E','400'))  # energy offset max (MeV) [basin +-900]
BJIT_D=float(os.environ.get('BJIT_D','12'))   # direction offset max (deg) [basin ~25deg]
BJIT_T=float(os.environ.get('BJIT_T','15'))   # t0 offset max (ns) [basin ~20-40ns]
DIR_OFF=float(os.environ.get('DIR_OFF','0'))  # start DIRECTION rotated DIR_OFF deg about a random perpendicular axis (vertex/E/t0 at truth) -> angular capture radius
E_OFF=float(os.environ.get('E_OFF','0'))      # start ENERGY offset truth +/- E_OFF MeV (random sign) -> energy capture radius
T0_OFF=float(os.environ.get('T0_OFF','0'))    # truth t0 = +/-T0_OFF ns (shift times), start fit t0 at 0 -> t0 capture radius
E0=int(os.environ.get('EVENT_START','0')); EC=int(os.environ.get('EVENT_COUNT','8')); FIDR=12.; FIDZ=12.; TRACE=int(os.environ.get('TRACE','0'))
NPHOT_EV=int(os.environ.get('NPHOT_EV','100'))   # base photon-events in ROOT; ev cycles mod this (distinct geom/start/detection per ev)
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); FDH=0.4*SCALE9; NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def th9dir(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=np.hypot(st,ct); npp=np.hypot(sp,cp); st,ct,sp,cp=st/nt,ct/nt,sp/npp,cp/npp
    return np.array([st*cp,st*sp,ct])
def _rotax(u,deg):
    a=np.radians(deg); ca,sa=np.cos(a),np.sin(a); u=u/np.linalg.norm(u)
    ux=np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]]); return np.eye(3)*ca+sa*ux+(1-ca)*np.outer(u,u)
def rand_tf(raw,ev):
    rng=np.random.default_rng(100003+ev); beta=np.degrees(np.arccos(rng.uniform(-1,1))); al=rng.uniform(0,2*np.pi)
    axis=np.array([-np.sin(al),np.cos(al),0.]); rr=FIDR*np.sqrt(rng.uniform()); ph=rng.uniform(0,2*np.pi)
    sh=np.array([rr*np.cos(ph),rr*np.sin(ph),rng.uniform(-FIDZ,FIDZ)])*100.0
    raw=dict(raw); O=np.asarray(raw['photon_origins']).astype(float); D=np.asarray(raw['photon_directions']).astype(float); R=_rotax(axis,beta); c=O.mean(0)
    raw['photon_origins']=(O-c)@R.T+c+sh; raw['photon_directions']=D@R.T; return raw,beta
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); C=P-P.mean(0)
    _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d; proj=-proj
    vtx=P.mean(0)+proj.min()*d; pol=float(np.arccos(np.clip(d[2],-1,1))); az=float(np.arctan2(d[1],d[0]))
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]),d
print(f"# GN_FISHER OPT consistent Fisher-GN  LAM={LAM} READOUT={READOUT} NITERS={NITERS} NKEYS={NKEYS} startoff={START_OFF} RAND={RANDOMIZE} T0_JIT={T0_JIT} E_STJIT={E_STJIT}",flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
PRED_TEMP=float(os.environ.get('PRED_TEMP','0.1'))
TOT_N_SCALE=float(os.environ.get('TOT_N_SCALE','1.0'))   # scale predicted total charge (== scaling SIREN tot_n_photons norm): test the +2% emission-count over-prediction fix
pred=H.build_predictor(temperature=PRED_TEMP,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def perpmt(t9,oc,ot,key):   # returns (mu per-PMT, time-NLL per-PMT)
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot*TOT_N_SCALE,1e-8); muS=jax.lax.stop_gradient(jnp.maximum(tot,1e-8))  # mu=SCALED (charge); muS=UNSCALED so time survival S=(muS-R)/muS stays consistent with ww (scale-invariant timing)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    tmask=oc>0
    if OCC_MIN>0:  tmask=tmask&(oc>=OCC_MIN)                                    # exclude dim scattered-light PMTs (mistimed +40ns); keep direct-light PMTs
    if OCC_GATE>0: tmask=tmask&(oc<=OCC_GATE)                                   # occupancy gate: time only on low-occ PMTs (cleaner 1st-arrival)
    if CGATE>0:    tmask=tmask&(jnp.abs(muS-oc)<CGATE*jnp.sqrt(jnp.maximum(muS,1.)))  # charge-consistency gate: time only where charge matches
    tnll=jnp.where(tmask,-n*jnp.log(Slo)-log1mexp(a),0.)
    return mu, tnll
CLOSS=os.environ.get('CLOSS','poisson')          # charge loss form: poisson | sqmse | anscombe | mse
EDETACH=int(os.environ.get('EDETACH','0'))       # 1: energy gradient comes ONLY from TOTAL charge magnitude; per-PMT shape term has energy DETACHED (so the diffuse-ring shape mismatch biases geometry but can't drag E)
EDET_W=float(os.environ.get('EDET_W','1.0'))     # weight on the total-magnitude energy term
def chargeloss(mu,oc):
    if CLOSS=='sqmse':    return jnp.sum((jnp.sqrt(mu)-jnp.sqrt(jnp.maximum(oc,0)))**2)            # variance-stabilized, gentle on under-pred ring
    if CLOSS=='anscombe': return jnp.sum((2*jnp.sqrt(mu+0.375)-2*jnp.sqrt(jnp.maximum(oc,0)+0.375))**2)
    if CLOSS=='mse':      return 0.5*jnp.sum((mu-oc)**2)                                            # raw least-squares (no variance weighting)
    return jnp.sum(mu-oc*jnp.log(mu))                                                              # poisson NLL (default)
def _chargeterm(t9,oc,ot,key):
    mu,tnll=perpmt(t9,oc,ot,key)                       # SINGLE forward eval
    if not EDETACH: return chargeloss(mu,oc),tnll
    S=jnp.sum(mu); n=jnp.sum(oc)                       # Poisson factorization: total(energy) x shape(geometry)
    mu_shape=mu*jax.lax.stop_gradient(n/jnp.maximum(S,1e-8))  # renorm to data total, factor DETACHED -> shape term E-grad ~0 (amplitude cancels)
    Ltot=EDET_W*(S-n*jnp.log(jnp.maximum(S,1e-8)))     # total magnitude -> the ONLY energy gradient
    return chargeloss(mu_shape,oc)+Ltot, tnll
T0_PRIOR=float(os.environ.get('T0_PRIOR','0'))   # >0: Gaussian prior t0~N(0,sigma_ns) -> breaks the t0<->longitudinal degeneracy (justified when t0 known from trigger)
TW=float(os.environ.get('TW','1.0'))             # global time-term weight (vs charge)
TROBUST=os.environ.get('TROBUST','none')         # per-PMT robust: none|clip|huber|trim (down-weight outlier-time PMTs = mis-timed scattered photons)
TCAP=float(os.environ.get('TCAP','8.0'))         # threshold for clip/huber/trim (per-PMT tnll units)
def time_term(tnll):                              # robust aggregation of per-PMT time-NLL
    if TROBUST=='clip':   t=jnp.minimum(tnll,TCAP)                                 # cap -> outliers get zero gradient
    elif TROBUST=='huber':t=jnp.where(tnll<=TCAP,tnll,TCAP+2.0*(jnp.sqrt(jnp.maximum(TCAP*tnll,0.0))-TCAP))  # quad->sqrt(linear-ish) above
    elif TROBUST=='trim': t=jnp.where(tnll<=TCAP,tnll,0.0)                         # drop PMTs above threshold entirely
    else:                 t=tnll
    return TW*jnp.sum(t)
@jax.jit
def lossf(t9,oc,ot,key):
    Lc,tnll=_chargeterm(t9,oc,ot,key); pr=0.5*(t9[8]/T0_PRIOR)**2 if T0_PRIOR>0 else 0.0; return Lc+time_term(tnll)+pr
@jax.jit
def lossf_c(t9,oc,ot,key): Lc,_=_chargeterm(t9,oc,ot,key); return Lc   # charge-only
@jax.jit
def lossf_t(t9,oc,ot,key): _,tn=perpmt(t9,oc,ot,key); return time_term(tn)                # time-only (robust)
gradf=jax.jit(jax.grad(lossf)); gradf_c=jax.jit(jax.grad(lossf_c)); gradf_t=jax.jit(jax.grad(lossf_t))
def G(th,oc,ot): return np.mean([np.asarray(gradf(jnp.asarray(th),oc,ot,k)) for k in KEYS],0)
def AL(th,oc,ot): return float(np.mean([float(lossf(jnp.asarray(th),oc,ot,k)) for k in KEYS]))
def fisher(th,oc,ot):   # PSD GN metric, consistent (same KEYS), FD jacobians
    mu0=np.mean([np.asarray(perpmt(jnp.asarray(th),oc,ot,k)[0]) for k in KEYS],0); mu0=np.maximum(mu0,1e-8)
    Jm=np.zeros((ND,9)); Jl=np.zeros((ND,9))
    for j in range(9):
        h=FDH[j]; ej=np.eye(9)[j]
        mp,lp=[np.mean([np.asarray(x) for x in xs],0) for xs in zip(*[perpmt(jnp.asarray(th+h*ej),oc,ot,k) for k in KEYS])]
        mm,lm=[np.mean([np.asarray(x) for x in xs],0) for xs in zip(*[perpmt(jnp.asarray(th-h*ej),oc,ot,k) for k in KEYS])]
        Jm[:,j]=(mp-mm)/(2*h); Jl[:,j]=(lp-lm)/(2*h)
    Fc=(Jm/np.sqrt(mu0)[:,None]).T@(Jm/np.sqrt(mu0)[:,None]); Ft=Jl.T@Jl
    F=Fc+Ft
    if T0_PRIOR>0: F[8,8]+=1.0/T0_PRIOR**2   # prior curvature -> metric pins t0, breaking the t0<->lon flat direction
    return F
KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
REFRESH=int(os.environ.get('REFRESH','1'))   # recompute Fisher every REFRESH steps
ADAPT=int(os.environ.get('ADAPT','0')); LAM0=float(os.environ.get('LAM0','1.0'))  # ADAPT=1: |g|-based adaptive Levenberg-Marquardt
LAM_HI=float(os.environ.get('LAM_HI','0')); LAM_DECAY=float(os.environ.get('LAM_DECAY','0.85'))  # LAM_HI>0: anneal lam from LAM_HI -> LAM (robust far -> precise near)
LR=float(os.environ.get('LR','1.0'))            # step multiplier: LR>1 amplifies the under-shooting GN step for fast far descent (min-|g| catches overshoot)
RIDGE_I=float(os.environ.get('RIDGE_I','0'))    # additive Levenberg floor: RIDGE_I*median(diagF)*I -> floors the FLAT (longitudinal) eigenvalue (lam*diagF cannot)
NOCLIP=int(os.environ.get('NOCLIP','0'))         # 1: drop the step-clip entirely (rely on RIDGE_I to bound the flat direction)
PRECOND=int(os.environ.get('PRECOND','1'))       # 1: SCALE9-precondition the GN solve so energy isn't frozen by the position-dominated raw Fisher
ESWEEP=int(os.environ.get('ESWEEP','0'))         # 1: instead of fitting, sweep E (all else at truth) -> loss/grad curves -> E-bias source
ESWEEP_N=int(os.environ.get('ESWEEP_N','41')); ESWEEP_W=float(os.environ.get('ESWEEP_W','200'))  # grid points, +/- half-width MeV
ZESWEEP=int(os.environ.get('ZESWEEP','0'))       # 1: 2D charge-loss sweep over (longitudinal vtx along track dir, E) -> vtx<->E coupling / induced E-bias
LOSSCHK=int(os.environ.get('LOSSCHK','0'))       # 1: after the full fit, compare loss(truth) vs loss(fit) + E-argmin at truth-geom vs fit-geom -> real min vs optimizer artifact
GRADCHK=int(os.environ.get('GRADCHK','0'))       # 1: AT TRUTH decompose the pushing gradient -> charge vs time per param + per-PMT charge residual by hit-time (which part of the loss displaces the fit)
DATA_NKEY=int(os.environ.get('DATA_NKEY','1'))   # >1: average data charge over N detection realizations -> expected-value data (tests whether the bias is single-event Poisson noise vs SIREN mean)
SELFDATA=int(os.environ.get('SELFDATA','0'))     # 1: data charge = SIREN's OWN mean mu(truth) -> self-consistency: if fit recovers truth, loss+optimizer UNBIASED, all real bias = GEANT4-event-vs-SIREN-mean
CMP=int(os.environ.get('CMP','0')); CMP_NG=int(os.environ.get('CMP_NG','16'))  # 1: dump SIREN mean vs GEANT4 mean per-PMT charge (CMP_NG detection realizations) -> direct distribution comparison
ZSWEEP_W=float(os.environ.get('ZSWEEP_W','0.6'))  # +/- half-width along track (m)
HIST=int(os.environ.get('HIST','0'))             # 1: record full per-iteration parameter trajectory in LAST_TRAJ (th9) + LAST_GN
LAST_TRAJ=[]; LAST_GN=[]
def fit(oc,ot,start,ref=None):
    global LAST_TRAJ,LAST_GN
    th=np.array(start,dtype=float); best=(1e18,th.copy()); acc=np.zeros(9); na=0; F=None
    traj=[th.copy()]; gns=[]
    g=G(th,oc,ot); gn=float(np.linalg.norm(g*SCALE9)); lm=LAM0
    for it in range(NITERS):
        if F is None or it%REFRESH==0: F=fisher(th,oc,ot)
        if not ADAPT:
            laL=max(LAM, LAM_HI*(LAM_DECAY**it)) if LAM_HI>0 else LAM   # annealed damping
            if PRECOND:   # solve in SCALE9-scaled coords so all params are O(1); else raw F is position-dominated and FREEZES energy
                S=SCALE9; Fs=S[:,None]*F*S[None,:]; gs=S*g                # scaled Fisher (O(1) entries) + scaled gradient
                lam=laL*np.diag(Fs); rI=RIDGE_I*np.median(np.clip(np.diag(Fs),1e-12,None))*np.eye(9)
                du=-LR*np.linalg.solve(Fs+np.diag(lam)+rI+1e-9*np.eye(9),gs); raw=S*du
            else:
                lam=laL*np.diag(F); rI=RIDGE_I*np.median(np.clip(np.diag(F),1e-12,None))*np.eye(9)
                raw=-LR*np.linalg.solve(F+np.diag(lam)+rI+1e-9*np.eye(9),g)
            dth=raw if NOCLIP else np.clip(raw,-STEPCLIP*SCALE9,STEPCLIP*SCALE9)
            th=th+dth; g=G(th,oc,ot); gn=float(np.linalg.norm(g*SCALE9))
        else:   # |g|-LM: accept if ||g|| drops (targets g=0, no flat-dir stall); else raise damping
            dth=np.clip(-np.linalg.solve(F+lm*np.diag(np.clip(np.diag(F),1e-12,None))+1e-9*np.eye(9),g),-STEPCLIP*SCALE9,STEPCLIP*SCALE9)
            thn=th+dth; gnw=G(thn,oc,ot); gnn=float(np.linalg.norm(gnw*SCALE9))
            if gnn<gn: th=thn; g=gnw; gn=gnn; lm=max(lm*0.6,1e-3); F=fisher(th,oc,ot) if REFRESH==1 else F
            else: lm=min(lm*2.5,1e4)
        if gn<best[0]: best=(gn,th.copy())
        if it>=NITERS//2: acc+=th; na+=1
        if HIST: traj.append(th.copy()); gns.append(gn)
        if TRACE and (it%10==0 or it==NITERS-1):
            r=ref if ref is not None else start; dv=np.sqrt(((th-r)[1:4]**2).sum())*100
            print(f"#   it{it:3d} |g|={gn:7.1f} dvtx={dv:6.2f}cm | Eres={th[0]-r[0]:+7.1f} gE={g[0]:+.3g} FEE={F[0,0]:.3g} dthE={dth[0]:+.3g}",flush=True)
    LAST_TRAJ=traj; LAST_GN=gns
    if READOUT=='ming': return best[1]
    if READOUT=='polyak': return acc/max(na,1)
    return th
rows=[]
for ev in range(E0,E0+EC):
    t0=time.time()
    re=ev%NPHOT_EV   # cycle the 100 base photon-events; ev still drives RANDOMIZE geom + start + detection -> distinct fit per ev
    if RANDOMIZE: raw,beta=rand_tf(read_photon_data_from_photonsim(ROOT,re),ev)
    else: raw=read_photon_data_from_photonsim(ROOT,re); beta=-1
    th9,d=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
    c,t=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev),pd)); oc_np=np.asarray(c); ot_np=np.where(oc_np>0,np.asarray(t),0.)
    if DATA_NKEY>1:   # average charge over many detection realizations -> EXPECTED-value data (removes single-event detection Poisson noise)
        oc_np=np.mean([np.asarray(jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev+9173*j),pd))[0]) for j in range(DATA_NKEY)],0)
        ot_np=np.where(oc_np>0,ot_np,0.)
    if SELFDATA:   # SIREN's own mean as the charge data -> isolates loss/optimizer bias from GEANT4-vs-SIREN-mean
        oc0=jnp.asarray(oc_np); ot0=jnp.asarray(ot_np)
        oc_np=np.mean([np.asarray(perpmt(jnp.asarray(th9),oc0,ot0,k)[0]) for k in KEYS],0); ot_np=np.where(oc_np>0,ot_np,0.)
    rj=np.random.default_rng(200003+ev); DT0=rj.uniform(-T0_JIT,T0_JIT) if T0_JIT>0 else 0.0; Eoff=rj.uniform(-E_STJIT,E_STJIT) if E_STJIT>0 else 0.0
    if T0_OFF>0: DT0=T0_OFF*rj.choice([-1.,1.])   # fixed-magnitude t0 capture offset
    if BJIT>0: DT0=rj.uniform(-BJIT_T,BJIT_T)      # basin t0 offset
    if T0_JIT>0 or T0_OFF>0 or BJIT>0: ot_np=np.where(oc_np>0, ot_np+DT0, 0.); th9[8]=DT0   # truth t0 = DT0 (shifted times)
    oc=jnp.asarray(oc_np); ot=jnp.asarray(ot_np)
    if BJIT>0:   # FURTHER-from-truth start, each param within its basin (independent magnitudes)
        start=th9.copy()
        vd=rj.uniform(-1,1,3); vd=vd/(np.linalg.norm(vd)+1e-12); start[1:4]=th9[1:4]+vd*rj.uniform(0,BJIT_V)   # random 3D vertex offset
        start[0]=th9[0]+rj.uniform(-BJIT_E,BJIT_E)                                                              # energy
        ax=np.cross(d,rj.uniform(-1,1,3)); ax=ax/(np.linalg.norm(ax)+1e-12); dv=_rotax(ax,rj.uniform(0,BJIT_D))@d  # rotate dir
        p2=np.arccos(np.clip(dv[2],-1,1)); a2=np.arctan2(dv[1],dv[0]); start[4:8]=[np.sin(p2),np.cos(p2),np.sin(a2),np.cos(a2)]
        start[8]=0.0; soff=float(np.linalg.norm((start-th9)[1:4]))*100                                          # truth t0=DT0, start t0 at 0
    elif JIT_ALL>0:
        start=(th9 + JIT_ALL*SCALE9*rj.uniform(-1,1,9)).copy(); soff=float(np.sqrt(((start-th9)[1:4]**2).sum()))*100  # ALL params offset; soff=start vtx err (cm)
    else:
        start=th9 + START_OFF*SCALE9*np.eye(9)[START_PIDX]; start=start.copy(); start[0]=th9[0]+Eoff; soff=START_OFF*SCALE9[START_PIDX]*100
        if E_OFF>0: start[0]=th9[0]+E_OFF*rj.choice([-1.,1.])   # energy capture offset
        if DIR_OFF>0:                                            # rotate start direction by DIR_OFF deg about a random perpendicular axis
            ax=np.cross(d, rj.uniform(-1,1,3)); ax=ax/(np.linalg.norm(ax)+1e-12); dv=_rotax(ax,DIR_OFF)@d
            p2=np.arccos(np.clip(dv[2],-1,1)); a2=np.arctan2(dv[1],dv[0]); start[4:8]=[np.sin(p2),np.cos(p2),np.sin(a2),np.cos(a2)]
        if T0_JIT>0 or T0_OFF>0: start[8]=0.0
    if GRADCHK:   # AT TRUTH: which part of the loss pushes the fit off-truth?
        gc=np.mean([np.asarray(gradf_c(jnp.asarray(th9),oc,ot,k)) for k in KEYS],0)*SCALE9   # scaled charge grad (loss change per natural step)
        gt=np.mean([np.asarray(gradf_t(jnp.asarray(th9),oc,ot,k)) for k in KEYS],0)*SCALE9   # scaled time grad
        mu0=np.mean([np.asarray(perpmt(jnp.asarray(th9),oc,ot,k)[0]) for k in KEYS],0)
        resid=oc_np-mu0                                  # data - pred per PMT (>0 = SIREN UNDER-predicts)
        hit=oc_np>0; tt=ot_np-th9[8]                     # hit-time relative to t0 (early=forward/near-vtx, late=back/scattered)
        np.savez(f"/tmp/grad_{os.environ.get('TAG','x')}_{ev}.npz",gc=gc,gt=gt,mu0=mu0,oc=oc_np,resid=resid,tt=tt,hit=hit,nm=np.array(NM),th9=th9,d=d)
        # residual by hit-time tercile
        th=tt[hit]; rs=resid[hit]; q=np.quantile(th,[1/3,2/3]) if hit.sum()>3 else [0,0]
        early=rs[th<q[0]].sum(); mid=rs[(th>=q[0])&(th<q[1])].sum(); late=rs[th>=q[1]].sum()
        gp=' '.join(f'{NM[i]}:{gc[i]:+.1f}/{gt[i]:+.1f}' for i in range(9))
        print(f"#  ev{ev:3d} grad(C/T scaled) {gp} | resid sum {resid.sum():+.0f} (early{early:+.0f} mid{mid:+.0f} late{late:+.0f}) [{time.time()-t0:.0f}s]",flush=True)
        continue
    if CMP:   # DIRECT SIREN-vs-GEANT4 mean comparison (per-PMT expected charge), both at truth
        muG=np.mean([np.asarray(jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev+9173*j),pd))[0]) for j in range(CMP_NG)],0)  # GEANT4 expected
        muS=np.mean([np.asarray(perpmt(jnp.asarray(th9),oc,ot,k)[0]) for k in KEYS],0)   # SIREN expected
        tt=ot_np-th9[8]                                                                   # per-PMT hit time rel t0
        np.savez(f"/tmp/cmp_{os.environ.get('TAG','x')}_{ev}.npz",muG=muG,muS=muS,tt=tt,th9=th9)
        sel=(muG>0.01)|(muS>0.01); c=np.corrcoef(muG[sel],muS[sel])[0,1] if sel.sum()>2 else 0
        print(f"#  ev{ev:3d} totG{muG.sum():.0f} totS{muS.sum():.0f} ratioS/G{muS.sum()/max(muG.sum(),1):.4f} | hitG{int((muG>0.5).sum())} hitS{int((muS>0.5).sum())} corr{c:.4f} [{time.time()-t0:.0f}s]",flush=True)
        continue
    if ZESWEEP:   # 2D charge-loss over (longitudinal vtx, E); d = unit track dir
        Eg=th9[0]+np.linspace(-ESWEEP_W,ESWEEP_W,ESWEEP_N); Zg=np.linspace(-ZSWEEP_W,ZSWEEP_W,ESWEEP_N)
        L=np.zeros((ESWEEP_N,ESWEEP_N))
        for iz,dz in enumerate(Zg):
            for ie,E in enumerate(Eg):
                te=th9.copy(); te[0]=float(E); te[1:4]=th9[1:4]+dz*d; tj=jnp.asarray(te)
                L[iz,ie]=float(np.mean([float(lossf_c(tj,oc,ot,k)) for k in KEYS]))
        iz,ie=np.unravel_index(np.argmin(L),L.shape); ieZ=np.argmin(L[iz]); ieT=np.argmin(L[ESWEEP_N//2])
        np.savez(f"/tmp/zesw_{os.environ.get('TAG','x')}_{ev}.npz",E=Eg-th9[0],Z=Zg*100,L=L,Etrue=th9[0])
        print(f"#  ev{ev:3d} 2Dargmin dz{Zg[iz]*100:+.0f}cm dE{Eg[ie]-th9[0]:+.0f}MeV | E@truthZ{Eg[ieT]-th9[0]:+.0f} E@argminZ{Eg[ieZ]-th9[0]:+.0f} MeV [{time.time()-t0:.0f}s]",flush=True)
        continue
    if ESWEEP:
        Eg=th9[0]+np.linspace(-ESWEEP_W,ESWEEP_W,ESWEEP_N); Lc=[];Lt=[];dLcE=[];dLtE=[];mut=[]
        for E in Eg:
            te=th9.copy(); te[0]=float(E); tj=jnp.asarray(te)
            Lc.append(float(np.mean([float(lossf_c(tj,oc,ot,k)) for k in KEYS])))
            Lt.append(float(np.mean([float(lossf_t(tj,oc,ot,k)) for k in KEYS])))
            dLcE.append(float(np.mean([float(gradf_c(tj,oc,ot,k)[0]) for k in KEYS])))
            dLtE.append(float(np.mean([float(gradf_t(tj,oc,ot,k)[0]) for k in KEYS])))
            mut.append(float(np.mean([float(perpmt(tj,oc,ot,k)[0].sum()) for k in KEYS])))   # total predicted charge at E
        Lc,Lt,dLcE,dLtE,mut=map(np.array,(Lc,Lt,dLcE,dLtE,mut))
        mu0=np.mean([np.asarray(perpmt(jnp.asarray(th9),oc,ot,k)[0]) for k in KEYS],0)
        amC=Eg[np.argmin(Lc)]-th9[0]; amT=Eg[np.argmin(Lc+Lt)]-th9[0]
        octot=oc_np.sum(); Etm=float(np.interp(octot,mut,Eg))-th9[0] if mut[0]<octot<mut[-1] else np.nan  # E where total pred = total data
        np.savez(f"/tmp/esw_{os.environ.get('TAG','x')}_{ev}.npz",E=Eg,Etrue=th9[0],Lc=Lc,Lt=Lt,dLcE=dLcE,dLtE=dLtE,mut=mut,mutot=float(mu0.sum()),octot=float(octot))
        print(f"#  ev{ev:3d} Etrue{th9[0]:.0f} ratio{mu0.sum()/max(octot,1):.4f} | Eargmin shape{amC:+.0f} | E_TOTMATCH{Etm:+.0f} MeV (total-charge only) [{time.time()-t0:.0f}s]",flush=True)
        continue
    th=fit(oc,ot,start,ref=th9); dlt=th-th9
    if HIST: np.savez(f"/tmp/hist_{os.environ.get('TAG','x')}_{ev}.npz",traj=np.array(LAST_TRAJ),gn=np.array(LAST_GN),truth=th9,start=np.asarray(start),tdir=d)
    dvtx=float(np.sqrt((dlt[1:4]**2).sum())); dd=th9dir(th); dang=float(np.degrees(np.arccos(np.clip(np.dot(dd,d),-1,1))))
    dlon=float(abs(np.dot(dlt[1:4],d))); dtra=float(np.sqrt(max(dvtx**2-dlon**2,0))); pol=float(np.degrees(np.arccos(np.clip(d[2],-1,1))))
    if LOSSCHK:   # is the -40 a real lower-loss point (coupling) or the optimizer missing truth?
        def AVL(fn,tt): return float(np.mean([float(fn(jnp.asarray(tt),oc,ot,k)) for k in KEYS]))
        def Eargmin(base):   # E-argmin of charge loss with the OTHER params held at `base`
            Eg=th9[0]+np.linspace(-200,200,41); Ls=[]
            for E in Eg: te=np.array(base,float); te[0]=float(E); Ls.append(AVL(lossf_c,te))
            return Eg[int(np.argmin(Ls))]-th9[0]
        Lc_tru=AVL(lossf_c,th9); Lc_fit=AVL(lossf_c,th); Lt_tru=AVL(lossf_t,th9); Lt_fit=AVL(lossf_t,th)
        Ltot_tru=Lc_tru+Lt_tru; Ltot_fit=Lc_fit+Lt_fit
        print(f"#  ev{ev:3d} Efit{dlt[0]:+.0f} vtx{dvtx*100:.0f}cm dir{dang:.1f} | Ltot truth{Ltot_tru:.1f} fit{Ltot_fit:.1f} d{Ltot_fit-Ltot_tru:+.2f} | Lc d{Lc_fit-Lc_tru:+.2f} Lt d{Lt_fit-Lt_tru:+.2f} | Eargmin@truthGeom{Eargmin(th9):+.0f} @fitGeom{Eargmin(th):+.0f} [{time.time()-t0:.0f}s]",flush=True)
        continue
    rows.append([ev,dlt[0],dlt[1],dlt[2],dlt[3],dvtx,dang,dlt[8],pol,dlon,dtra]); el=time.time()-t0
    print(f"#  ev{ev:3d} pol{pol:4.0f} soff{soff:5.0f}cm E{dlt[0]:+7.1f} |vtx|{dvtx*100:5.1f}cm (lon{dlon*100:5.1f} tra{dtra*100:5.1f}) dir{dang:5.2f} t0{dlt[8]:+.2f} [{el:.0f}s]",flush=True)
np.savetxt(f"/tmp/gf_{os.environ.get('TAG','x')}_{E0}.txt",np.array(rows),fmt="%.5f")
print("# DONE",flush=True)
