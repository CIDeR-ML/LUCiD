#!/usr/bin/env python3
"""
recon_export.py — dump ONE recon_dataset.json for the tablet recon viewer (viewer/recon_viewer.html).

Emits geometry (in all_points / sim order — fixes the positions_mm scramble bug) + a curated set of
events, each with: truth/fit track, per-PMT data charge, F convergence frames of sim charge + sim
track pose, the sim-data diff, a static photon cloud, and the optimizer trajectory metadata.

Reuses gn_fisher_recon.py's machinery via the same import trick as hitdump.py. Requires a GPU/JAX
environment (it runs the forward simulator). The optimizer TRAJECTORY is read from saved HIST npz
files (study1k_trajectories/ or bjstudy_trajectories/, keys: traj,gn,truth,start,tdir) so the
convergence is the real fit, not a re-run.

Usage:
    python recon_export.py --trajdir bjstudy_trajectories --events 0:clean,1:typical,501:wander \
                           --frames 14 --nphot 400 --out recon_dataset.json
"""
import os, sys, glob, json, argparse
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4')
os.environ.setdefault('OVERLAP_RENORM','1.0'); os.environ.setdefault('PRED_TEMP','0.1')
os.environ.setdefault('TOT_N_SCALE','0.982'); os.environ.setdefault('NPHOT_EV','100')

ap = argparse.ArgumentParser()
ap.add_argument('--trajdir', default='bjstudy_trajectories',
                help='dir with HIST npz files (hist_*_<ev>.npz: traj,gn,truth,start,tdir)')
ap.add_argument('--events', default='0:clean,1:typical,501:wander',
                help='comma list of <ev>[:tag]')
ap.add_argument('--frames', type=int, default=50, help='frames placed over the motion span (viewer interpolates between them)')
ap.add_argument('--allframes', action='store_true', help='save EVERY optimizer iteration up to best_iter (maximally smooth; files are small)')
ap.add_argument('--nphot', type=int, default=400, help='photon-cloud subsample per event')
ap.add_argument('--qthresh', type=float, default=0.4, help='min PE to store a PMT (sparsity)')
ap.add_argument('--out', default='recon_dataset.json')
ap.add_argument('--npz', default='config/sk_geometry.npz')
args = ap.parse_args()

# ---- bring in the pipeline (defines pred, data_sim, sc2, th9dir, derive_truth, pad_event,
#      rand_tf, read_photon_data_from_photonsim, KEYS, ROOT, NPHOT_EV, ND) ----
exec(open('gn_fisher_recon.py').read().split('rows=[]')[0])
import numpy as np, jax, jax.numpy as jnp
from lucid.geometry.cylinder import Cylinder

# ---- geometry in all_points (sim) order — THE fix for the positions_mm scramble ----
det = Cylinder.from_pmt_file(args.npz)
POS = np.asarray(det.all_points, dtype=float)                       # (Nsensor,3) meters, sim order
CASE = [int(det.ID_to_case[i]) for i in range(len(POS))]
geo_npz = np.load(args.npz)
RAD = float(geo_npz['radius']); HALFH = float(geo_npz['height']) / 2.0
SR = float(geo_npz['sensor_radius']) if 'sensor_radius' in geo_npz.files else 0.254
assert POS.shape[0] == ND, f"geometry/sim sensor mismatch {POS.shape[0]} vs {ND}"

def r3(a): return [round(float(x), 3) for x in a]
def r4(a): return [round(float(x), 4) for x in a]

def simcharge(th9):
    return np.mean([np.asarray(pred(sc2(jnp.asarray(th9)), k)[3]) for k in KEYS], 0)

def sparse(q):
    idx = np.where(q > args.qthresh)[0]
    return {"idx": idx.astype(int).tolist(),
            "val": [round(float(v), 2) for v in q[idx]]}

def find_hist(ev):
    for f in glob.glob(os.path.join(args.trajdir, f'*_{ev}.npz')):
        return f
    return None

def export_event(ev, tag):
    # truth + data (deterministic given ev seed, matches the HIST run's frame)
    re = ev % int(os.environ['NPHOT_EV'])
    raw, beta = rand_tf(read_photon_data_from_photonsim(ROOT, re), ev)
    th9, d = derive_truth(raw); pd, n = pad_event(raw)
    c, t = jax.lax.stop_gradient(data_sim(sc2(jnp.asarray(th9)), jax.random.PRNGKey(7000 + ev), pd))
    oc = np.asarray(c)

    # trajectory (real optimizer path)
    hf = find_hist(ev)
    if hf is None:
        print(f"  [warn] no HIST for ev {ev} in {args.trajdir}; using start=end=truth (no convergence)")
        traj = np.stack([th9, th9]); best = 1
    else:
        H = np.load(hf); traj = np.asarray(H['traj']); gn = np.asarray(H['gn'])
        best = int(np.argmin(gn)) + 1
    def _dir(th):                                              # unit dir from th9 sin/cos (atan2 robust to non-norm)
        tt = np.arctan2(th[4], th[5]); pp = np.arctan2(th[6], th[7])
        return np.array([np.sin(tt)*np.cos(pp), np.sin(tt)*np.sin(pp), np.cos(tt)])
    if args.allframes:
        fidx = np.arange(0, min(best + 1, len(traj)))          # every iteration up to convergence (big)
    else:
        # motion-adaptive: place frames only where params still MOVE (skip the converged tail)
        vb, db, Eb = traj[best, 1:4], _dir(traj[best]), traj[best, 0]
        mot = np.array([max(np.linalg.norm(traj[i, 1:4]-vb)/0.02,                       # >2 cm
                            np.degrees(np.arccos(np.clip(_dir(traj[i])@db, -1, 1)))/0.5, # >0.5 deg
                            abs(traj[i, 0]-Eb)/20.0)                                      # >20 MeV
                        for i in range(best+1)])
        moving = np.where(mot > 1.0)[0]
        conv = int(moving[-1])+1 if len(moving) else min(best, 8); conv = min(conv, best)
        fidx = np.unique(np.linspace(0, conv, args.frames).round().astype(int))
        if best not in fidx: fidx = np.append(fidx, best)       # always end on the best fit
        print(f"    motion span 0..{conv} (best_iter {best}) -> {len(fidx)} frames", flush=True)
    fidx = np.unique(fidx[fidx < len(traj)])

    frames = []
    for i in fidx:
        th = traj[i]; q = simcharge(th)
        frames.append({"vtx": r3(th[1:4]), "dir": r4(np.asarray(th9dir(jnp.asarray(th)))),
                       "E": round(float(th[0]), 1), "q": sparse(q)})
    end = traj[best] if best < len(traj) else traj[-1]
    end_dir = np.asarray(th9dir(jnp.asarray(end)))
    sim_last = simcharge(end)
    diff = sim_last - oc
    didx = np.where(np.abs(diff) > args.qthresh)[0]

    # photons: truth emission origins (cm->m), subsampled — static cloud, like the segments
    po = np.asarray(raw['photon_origins'], dtype=float) / 100.0
    if po.shape[0] > args.nphot:
        sel = np.random.default_rng(ev).choice(po.shape[0], args.nphot, replace=False); po = po[sel]

    vtx_cm = float(np.linalg.norm(end[1:4] - th9[1:4]) * 100)
    dir_deg = float(np.degrees(np.arccos(np.clip(float(np.dot(end_dir, d)), -1, 1))))
    return {
        "id": int(ev), "tag": tag,
        "truth": {"E": round(float(th9[0]), 1), "vtx": r3(th9[1:4]), "dir": r4(d), "t0": round(float(th9[8]), 3)},
        "fit":   {"E": round(float(end[0]), 1), "vtx": r3(end[1:4]), "dir": r4(end_dir), "t0": round(float(end[8]), 3)},
        "errors": {"vtx_cm": round(vtx_cm, 1), "dir_deg": round(dir_deg, 2),
                   "E": round(float(end[0] - th9[0]), 1), "t0_ns": round(float(end[8] - th9[8]), 2)},
        "data": {"q": sparse(oc)},
        "frames": frames,
        "diff": {"idx": didx.astype(int).tolist(), "val": [round(float(v), 2) for v in diff[didx]]},
        "photons": [r3(p) for p in po],
        "best_iter": best,
    }

events = []
for tok in args.events.split(','):
    ev_s, _, tag = tok.partition(':'); ev = int(ev_s)
    print(f"event {ev} ({tag or '-'}) ...", flush=True)
    events.append(export_event(ev, tag or str(ev)))

dataset = {
    "meta": {"detector": "SK", "units": "m,ns,MeV", "track_length_m": 4.7,
             "n_events": len(events), "source": args.trajdir},
    "geom": {"radius": round(RAD, 4), "halfheight": round(HALFH, 4), "sensor_radius": round(SR, 4),
             "pmt_pos": [r3(p) for p in POS], "pmt_case": CASE},
    "events": events,
}
with open(args.out, 'w') as f:
    json.dump(dataset, f, separators=(',', ':'))
mb = os.path.getsize(args.out) / 1e6
print(f"wrote {args.out}  ({len(events)} events, {len(POS)} PMTs, {mb:.1f} MB)")
