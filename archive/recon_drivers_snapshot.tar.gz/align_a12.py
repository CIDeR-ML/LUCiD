"""ALIGNMENT A1/A2 — photon-iteration STEP unit test (no pipeline).

Feeds IDENTICAL per-photon step inputs to BOTH step functions and averages each over
N_AVG keys, then compares the per-step expectations:
  A1  E[detect deposit] = E[detect_prob * reflection_attenuation]   (the per-step charge)
  A2  E[continuing_factor]                                          (the inter-step survival)
  +   E[new_time]

TRUE  = photon_iteration_sample          (hard Bernoulli detect/absorb)
SIM   = photon_iteration_update_factors  (continuous expected weights, DiCE)

Known difference: SIM is the per-step EXPECTED value, TRUE is the hard MC realization.
They must agree IN EXPECTATION (Mie off). Disagreement beyond the MC floor (~1/sqrt(N_AVG))
= an unintended step-level mismatch.

Params recorded by the run: Mie off (mie_scatter_length from config, g=0), optics from
SK_physics_config @400nm, both wall (hit_sensor=False) and sensor (hit_sensor=True) cases,
swept over surface_distance Dd. Env: NAVG, DEV.  Usage: CUDA_VISIBLE_DEVICES=g python align_a12.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.photon_step import photon_iteration_sample, photon_iteration_update_factors
from lucid.detector_params import load_detector_params
np.set_printoptions(precision=5, suppress=True, linewidth=160)

NAVG = int(os.environ.get('NAVG', '200000'))
PHYS = 'config/SK_physics_config.json'
C = 0.299792458 / 1.34                                   # m/ns in water (n~1.34) — value irrelevant to alignment
dp = load_detector_params(PHYS, scalar_ref_wavelength=400.0)
L_S = float(dp.scatter_length); L_A = float(dp.absorption_length)
L_M = float(dp.mie_scatter_length); G = float(dp.g)
R_W = float(dp.wall_reflection_rate); R_S = float(dp.sensor_reflection_rate)
print(f"# A1/A2 STEP UNIT TEST  NAVG={NAVG}", flush=True)
print(f"# OPTICS@400nm: scatter_length={L_S:.3f}m  absorption_length={L_A:.3f}m  "
      f"mie_scatter_length={L_M:.3e}m  g={G}  wall_refl={R_W:.4f}  sensor_refl={R_S:.4f}", flush=True)

# fixed geometry for the step (only Dd varies); normal points outward (geometry convention)
pos = jnp.array([0.0, 0.0, 0.0]); direction = jnp.array([0.0, 0.0, 1.0]); normal = jnp.array([0.0, 0.0, 1.0])
t0 = jnp.array(0.0)

def step_outputs(fn, Dd, hit_sensor, keys):
    """vmap fn over keys at fixed Dd; return averaged (detect_deposit, continuing, new_time)."""
    def one(key):
        out = fn(pos, direction, t0, jnp.array(Dd), normal,
                 jnp.array(L_S), jnp.array(L_M), jnp.array(G), jnp.array(R_W), jnp.array(R_S),
                 jnp.array(L_A), jnp.array(hit_sensor), key, C)
        new_pos, new_dir, new_time, detect_prob, refl_atten, cont, logp = out
        return jnp.array([detect_prob * refl_atten, cont, new_time])
    return jnp.mean(jax.vmap(one)(keys), axis=0)

DDS = [0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 24.0, 32.0, 40.0]
key0 = jax.random.PRNGKey(0)
for hs, tag in [(False, 'WALL  (hit_sensor=False)'), (True, 'SENSOR(hit_sensor=True )')]:
    r = R_S if hs else R_W
    print(f"\n# === {tag}  reflection_rate={r:.4f} ===", flush=True)
    print(f"#  Dd[m]   detect: TRUE      SIM    relErr  |  continuing: TRUE     SIM    relErr  |  analytic detect=exp(-Dd/Ls)(1-r)exp(-Dd/La)", flush=True)
    maxrel_d = 0.0; maxrel_c = 0.0
    for Dd in DDS:
        keys = jax.random.split(jax.random.fold_in(key0, int(Dd*1000)), NAVG)
        dT, cT, tT = [float(x) for x in step_outputs(photon_iteration_sample, Dd, hs, keys)]
        dS, cS, tS = [float(x) for x in step_outputs(photon_iteration_update_factors, Dd, hs, keys)]
        ana = np.exp(-Dd/L_S)*(1-r)*np.exp(-Dd/L_A)
        rd = abs(dT-dS)/(abs(dS)+1e-12); rc = abs(cT-cS)/(abs(cS)+1e-12)
        maxrel_d = max(maxrel_d, rd); maxrel_c = max(maxrel_c, rc)
        print(f"#  {Dd:5.1f}   {dT:.6f}  {dS:.6f}  {rd:6.1%}  |  {cT:.6f}  {cS:.6f}  {rc:6.1%}  |  {ana:.6f}", flush=True)
    print(f"#  -> max relErr  detect={maxrel_d:.2%}  continuing={maxrel_c:.2%}   (MC floor ~ 1/sqrt(NAVG) = {1/np.sqrt(NAVG):.2%})", flush=True)
print(f"\n# VERDICT: if relErr <= ~few x MC floor for all Dd -> TRUE and SIM agree per step in expectation (Mie off).", flush=True)
