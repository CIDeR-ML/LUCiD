# Loss interrogation plan — BEFORE the optimizer

The forward model is aligned (`ALIGNMENT_FINDINGS.md`). The recon lever is the loss/optimizer. Before
touching the optimizer we characterize the LOSS itself: is its gradient trustworthy (AD vs FD), is its
curvature usable (Hessian quality), and is its minimum where it should be (CRB / conditioning / basin).
A bad optimizer cannot be diagnosed on top of an untrustworthy gradient — so this comes first.

The recon parameter vector θ = [energy, x, y, z, polar, azim, t0] (MeV, m, m, m, rad, rad, ns), natural
scales PARAM_SCALE=[50,0.2,0.2,0.2,0.02,0.02,0.2]. Two groups matter separately:
  • SCALAR group: energy, t0 (no geometry) — expected well-behaved.
  • GEOMETRY group: x,y,z,polar,azim — the photon trajectories depend on these through ray-geometry
    intersection, hard scatter/reflect branches, overlap cell assignment → the suspected AD-Hessian breakers
    (memory [[recon-track-hessian-breakers]]: AD Hessian EXACT for optical, BROKEN for track; dominant
    breaker maxcell truncation, residual multi-bounce K).

The loss (recon_harness.make_loss): charge Poisson-NLL + first-arrival time NLL (configurable w_charge,
w_time, tau_time). It is STOCHASTIC in the predictor key → all AD/FD comparisons use COMMON RANDOM NUMBERS
(same key for ±h and the AD eval) and average over NKEYS to tame per-key heavy tails.

## Stage L1 — AD vs FD GRADIENT quality   (this is step 1)
GOAL: where does jax.grad of the loss match central finite differences? Per-parameter cosine, magnitude
ratio, relative error; separated by SCALAR vs GEOMETRY group.
- L1.0 FD validation FIRST: sweep the FD step h (as a fraction of PARAM_SCALE) to find the stable plateau
  per parameter (too small → noise, too large → truncation/branch-crossing). The FD is only ground truth on
  its plateau. (Memory: geometry FD diverges as h→0 for K≥2 — quantify per param.)
- L1.1 baseline (K=8, MAXCELL=8, temp=0.1, NKEYS≥48): AD vs FD grad on the plateau, per param.
- L1.2 KNOB SWEEPS (one at a time):
    K ∈ {1,2,4,8}          (multi-bounce kink accumulation)
    MAXCELL ∈ {4,8,16,32}  (overlap-truncation breaker)
    temperature ∈ {0.05,0.1,0.3}  (overlap softness — consistency of forward/backward smoothing)
    NKEYS ∈ {1,16,48,96}   (per-key heavy tail → how much averaging to trust the mean gradient)
    OVERLAP_ANALYTIC cubic vs default (memory: cubic restores curvature)
    w_charge/w_time, tau_time (loss-term knobs)
- L1.3 evaluate at θ_true+δ (non-trivial gradient) AND near θ_true; report where AD is trustworthy.
DELIVERABLE: a per-parameter map of AD-gradient trust vs knobs; the config where the gradient is reliable.

## Stage L2 — HESSIAN quality   (step 2)
GOAL: is the curvature usable for Newton/Gauss-Newton/CRB? AD Hessian (jax.hessian) vs FD Hessian
(central difference of the AD gradient, on its plateau).
- L2.1 symmetry ‖H−Hᵀ‖/‖H‖; eigenvalues (PD? negative? near-zero degeneracies); condition number.
- L2.2 AD-vs-FD Hessian agreement, element-wise and on eigenpairs, by param block (scalar vs geometry).
- L2.3 same KNOB SWEEPS as L1 (K, MAXCELL, temp, NKEYS, cubic). Identify which knob fixes/breaks each block.
- L2.4 Gauss-Newton vs full Hessian: GN = JᵀJ (from the residual Jacobian) drops the Σr∇²r term; compare
  GN (PSD by construction) to the AD Hessian — does GN sidestep the geometry breakers?
DELIVERABLE: the regime (knobs, param block) where the Hessian is trustworthy, and whether GN is the
robust route when the full AD Hessian is broken.

## Later stages (after L1/L2 establish a trustworthy gradient+curvature)
- L3 CRB / Fisher conditioning at θ_true (per-param σ, correlations, the degenerate directions).
- L4 loss-term structure: charge-vs-time weighting, tau_time, thresholding — profile each term's 1D/2D
  landscape (bias, basin width) on ≥20 events; the loss-level timing alignment open from A7.
- L5 basin of attraction (capture radius per param) — but only AFTER the gradient/Hessian are trusted.
- THEN the optimizer (staging, step sizes, preconditioning by the L2/L3 curvature).

## Logging
Every run appended to `LOSS_LOG.md`: full param block (θ_eval, K, MAXCELL, temp, NKEYS, h, tau_time,
w_charge/w_time, truth source, n_photons, seeds) + DELTA from previous run + result + verdict. Same
discipline as RUN_LOG.md. One controlled change per run; never a single-key conclusion.
