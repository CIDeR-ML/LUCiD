"""Aggregate /tmp/qK_<K>.npy into a K-convergence table: total-charge fraction AND per-sensor pattern
error vs the converged reference (largest K). The pattern error is what track recon actually sees."""
import numpy as np, glob, re
files = sorted(glob.glob('/tmp/qK_*.npy'), key=lambda f: int(re.search(r'qK_(\d+)', f).group(1)))
Ks = [int(re.search(r'qK_(\d+)', f).group(1)) for f in files]
qs = {K: np.load(f) for K, f in zip(Ks, files)}
Kref = max(Ks); qref = qs[Kref]; sref = qref.sum()
print(f"reference K={Kref}  sumq={sref:.1f}  sensors_lit={(qref>0.01).sum()}")
print(f"{'K':>3} {'sumq':>9} {'tot%':>7} {'patt_L2_err':>12} {'max_sensor_err':>15} {'lit%':>7}")
for K in Ks:
    q = qs[K]
    tot = q.sum() / sref * 100
    pat = np.linalg.norm(q - qref) / (np.linalg.norm(qref) + 1e-12) * 100
    lit = qref > 0.01
    msen = np.max(np.abs(q[lit] - qref[lit]) / (qref[lit] + 1e-9)) * 100
    litpct = (q > 0.01).sum() / (q.shape[0]) * 100
    print(f"{K:>3} {q.sum():>9.1f} {tot:>6.2f}% {pat:>11.2f}% {msen:>14.1f}% {litpct:>6.1f}%")
