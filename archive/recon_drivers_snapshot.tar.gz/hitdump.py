#!/usr/bin/env python3
"""Generate per-PMT charge maps for event displays: truth(data), sim@start, sim@end. Uses saved start/end params."""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('OVERLAP_RENORM','1.0')
os.environ.setdefault('PRED_TEMP','0.1'); os.environ.setdefault('TOT_N_SCALE','0.982'); os.environ.setdefault('NPHOT_EV','100')
exec(open('gn_fisher_recon.py').read().split('rows=[]')[0])
import numpy as np, jax, jax.numpy as jnp
geo=np.load('config/sk_geometry.npz'); POS=geo['positions_mm']/1000.0  # m
def simcharge(th9):
    tot=np.mean([np.asarray(pred(sc2(jnp.asarray(th9)),k)[3]) for k in KEYS],0); return tot
for ev,tag in [(250,'clean'),(5,'typical'),(19,'wander')]:
    re=ev%100; raw,beta=rand_tf(read_photon_data_from_photonsim(ROOT,re),ev); th9,d=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
    c,t=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev),pd)); oc=np.asarray(c)
    # start/end from saved trajectory (find the chunk file)
    import glob
    hf=[f for f in glob.glob('/tmp/hist_study_*.npz') if f.endswith(f'_{ev}.npz')][0]
    H=np.load(hf); start=H['start']; gn=H['gn']; traj=H['traj']; end=traj[int(np.argmin(gn))+1]
    cs=simcharge(start); ce=simcharge(end)
    np.savez(f'/tmp/disp_{tag}.npz',oc=oc,sim_start=cs,sim_end=ce,pos=POS,truth=th9,start=start,end=end,tdir=d)
    dv=np.linalg.norm(end[1:4]-th9[1:4])*100; dvs=np.linalg.norm(start[1:4]-th9[1:4])*100
    print(f'{tag} ev{ev}: lit={int((oc>0.5).sum())} | startVtxErr={dvs:.0f}cm endVtxErr={dv:.0f}cm | totC data={oc.sum():.0f} start={cs.sum():.0f} end={ce.sum():.0f}',flush=True)
print('done')
