"""4-PARAM (quaternion) direction vs (polar,azim) — does it smooth the angle gradient?
Replace the 2 spherical angles with a 4-vector quaternion q -> direction d(q) (smooth polynomial, no
coordinate singularity). 2 of the 4 q-DOF are gauge (|q|, roll-about-d) -> profile flat; the other 2 carry
the direction. Profile each q-param (offset center, mean obs, joint corrected loss) and check smoothness vs
the KINKY azim baseline. theta9 = [E,x,y,z, q0,q1,q2,q3, t0]. Env: NPHOT NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_quat.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NKEYS = int(os.environ.get('NKEYS', '8')); K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
d_true = np.array([np.sin(POL) * np.cos(AZ), np.sin(POL) * np.sin(AZ), np.cos(POL)])
# q_true: shortest-arc quaternion rotating zhat -> d_true
ax = np.cross([0, 0, 1.0], d_true); ax = ax / (np.linalg.norm(ax) + 1e-12); al = np.arccos(np.clip(d_true[2], -1, 1))
q_true = np.array([np.cos(al / 2)] + list(np.sin(al / 2) * ax))            # [w,x,y,z]
th9_true = np.array([1050.0, 0, 0, 0, q_true[0], q_true[1], q_true[2], q_true[3], 0.0])
QSC = 0.01                                                                  # quat-param scale ~ 0.02 rad direction (match azim)
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, QSC, QSC, QSC, QSC, 0.2])
def quat_dir(q):
    q = q / (jnp.linalg.norm(q) + 1e-12); w, x, y, z = q[0], q[1], q[2], q[3]
    return jnp.array([2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y)])
def q2track(th9):
    d = quat_dir(th9[4:8]); theta = jnp.arccos(jnp.clip(d[2], -1.0, 1.0)); phi = jnp.arctan2(d[1], d[0])
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=theta, phi=phi, t0=th9[8])
print(f"# QUATERNION direction  NPH={NPH} NKEYS={NKEYS}  q_true={q_true}  (QSC={QSC})", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
cs, ts = [], []
for s in range(12):
    cc, tt2 = jax.lax.stop_gradient(truth(q2track(jnp.asarray(th9_true)), jax.random.PRNGKey(900 + s)))
    cs.append(np.asarray(cc)); ts.append(np.where(np.asarray(cc) > 0, np.asarray(tt2), np.nan))
oc = jnp.asarray(np.mean(cs, 0)); hit = jnp.asarray(np.mean(cs, 0) > 1e-6); ot = jnp.asarray(np.nan_to_num(np.nanmean(ts, 0)))
def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def core(th9, key):
    log_w, ft, fi, tot = pred(q2track(th9), key)
    w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - th9[8])[fi]; mu = jnp.maximum(tot, 1e-8)
    def Rof(x): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf((x - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rof(tobs - DELTA / 2)) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rof(tobs + DELTA / 2)) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(hit & (oc > 0), -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def slopes(i):
    c0 = th9_true + 3.0 * SCALE9[i] * np.eye(9)[i]
    sv = np.linspace(-6 * SCALE9[i], 6 * SCALE9[i], 33); j0 = 16; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(core(jnp.asarray(c0 + s * np.eye(9)[i]), k)) for k in keys]) for s in sv])
    # direction change to flag gauge vs effective
    d0 = np.asarray(quat_dir(jnp.asarray(th9_true[4:8]))); d1 = np.asarray(quat_dir(jnp.asarray((th9_true + SCALE9[i] * np.eye(9)[i])[4:8]))) if i in (4, 5, 6, 7) else d0
    ddir = np.linalg.norm(d1 - d0)
    return {wv: (prof[j0 + wv] - prof[j0 - wv]) / (2 * wv * dg) for wv in [1, 2, 4, 8]}, ddir
for i, nm in [(4, 'q0'), (5, 'q1'), (6, 'q2'), (7, 'q3')]:
    sl, ddir = slopes(i); kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
    print(f"#  {nm} (|Δdir|/step {ddir:.4f}) slopes w1/2/4/8 {sl[1]:+9.1f} {sl[2]:+9.1f} {sl[4]:+9.1f} {sl[8]:+9.1f}  {'KINKY' if kinky else 'smooth'}", flush=True)
print(f"# READ: gauge q-params -> |Δdir|~0 + flat; effective q-params carry the angle gradient -> SMOOTH (vs azim KINKY) => reparam helps.", flush=True)
