"""Joint staged GN-LM reconstruction at the CLEAN shifted/rotated PhotonSim track (recon_ps_setup).
Stage 1: charge-dominated (WT=0) -> energy + rough pos/dir.  Stage 2: full loss (WT,TAU), energy frozen.
Reports the achievable recon and decomposes the residual into the systematic floor (loss-surface min)
vs the statistical scatter. Usage: CUDA_VISIBLE_DEVICES=g [WT TAU STW] python recon_ps_run.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
WT, TAU = float(os.environ.get('WT', '0.05')), float(os.environ.get('TAU', '1.5'))
THR = float(os.environ.get('THR', '0.0'))
SC = np.array(H.PARAM_SCALE)

_PT = os.environ.get('PRED_TEMP', '')
S = PS.setup(event=0, nphot=80_000, truth_source=os.environ.get('TRUTH_SOURCE', 'photonsim'),
             pred_temperature=float(_PT) if _PT else None)
theta_star = np.array(S['theta_star'])
_lf = PS.make_loss(S, WT=WT, TAU=TAU, THR=THR)          # built OUTSIDE jit
_lc = PS.make_loss(S, WT=0.0, TAU=TAU, THR=THR)
gfull = jax.jit(jax.grad(lambda th, k: _lf(th, k)[2]))
gchrg = jax.jit(jax.grad(lambda th, k: _lc(th, k)[2]))

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=45, tag=0):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T = []
    for s in range(steps):
        keys = jax.random.split(jax.random.PRNGKey(101 + 7919*tag + s), 6)
        G = np.stack([np.array(gfn(theta, k)) * SC for k in keys])
        g = G.mean(0); F = (G.T @ G) / 6
        dd = np.clip(np.diag(F), 1e-12, None)
        ev, V = np.linalg.eigh(F + LM*np.diag(dd) + 1e-9*np.eye(7)*(dd.max()+1e-12))
        ev = np.clip(ev, 2e-2*ev.max(), None)
        step = np.clip(V @ np.diag(1/ev) @ V.T @ g, -0.35, 0.35) * SC
        theta = theta - LR * jnp.array(step * (1 - fr))
        if s >= steps - tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))

rng = np.random.default_rng(SEED)
theta0 = jnp.array(theta_star + rng.uniform(-1, 1, 7) * np.array([3, 1.5, 1.5, 1.5, 0.15, 0.15, 3]) * SC)
t1 = gnlm(theta0, gchrg, 90, tag=1)                       # energy from charge
t2 = gnlm(t1, gfull, 120, freeze=[0], tag=2)              # pos/dir/t0, energy frozen
pa = np.array(t2); err = pa - theta_star
def dirv(p): return np.array([np.sin(p[4])*np.cos(p[5]), np.sin(p[4])*np.sin(p[5]), np.cos(p[4])])
ang = float(np.degrees(np.arccos(np.clip(dirv(pa) @ dirv(theta_star), -1, 1))))
U = ['MeV','m','m','m','rad','rad','ns']
print(f"PSRUN seed={SEED} PT={_PT or 'hard'} WT={WT} TAU={TAU} THR={THR} "
      f"E1={float(t1[0]):.0f}", flush=True)
print("  recovered " + " ".join(f"{pa[i]:.4f}" for i in range(7)), flush=True)
print("  err       " + " ".join(f"{err[i]:+.3g}{U[i]}" for i in range(7)), flush=True)
print(f"  => energy {err[0]/theta_star[0]*100:+.1f}%  vertex {np.linalg.norm(err[1:4])*100:.1f}cm  "
      f"direction {ang:.2f}deg  t0 {err[6]:+.2f}ns", flush=True)
