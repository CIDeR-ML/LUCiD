"""Combine the two wins: total-charge ENERGY (unbiased) + tau_SMOOTH-smoothed scale-invariant SHAPE
(energy-decoupled AND smooth landscape -> vertex/dir) + tau_TIME first-arrival (longitudinal/dir/t0).
Head-to-head vs separated(no smoothing) and smoothed-Poisson. Scan tau_SMOOTH. PhotonSim, cold start.
Usage: CUDA_VISIBLE_DEVICES=g TAU_SMOOTH=2 [WS=1 WT=0.03 WE=100] python combo_test.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True)
TS = float(os.environ.get('TAU_SMOOTH', '2.0'))
wE=float(os.environ.get('WE','100')); wS=float(os.environ.get('WS','1')); wT=float(os.environ.get('WT','0.03'))
THR=float(os.environ.get('THR','4')); STEPS=int(os.environ.get('STEPS','90'))
SEEDS=[int(x) for x in os.environ.get('SEEDS','1,2,3,4,5,6,7,8').split(',')]
SCHED=[float(x) for x in os.environ.get('SCHED','2,1,0.5').split(',')]
SC=np.array(H.PARAM_SCALE)
S=PS.setup(event=0,nphot=80_000,truth_source='photonsim',pred_temperature=0.1)
ts=np.array(S['theta_star']); pred=S['pred']; oc=jnp.asarray(S['oc']); SUMOBS=S['sumobs']
hitf=S['hit']; otf=S['ot']; ND=S['ND']; tmask=jax.lax.stop_gradient(hitf&(oc>=THR))
if TS>0:
    dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4)
    sp=jnp.asarray(np.array(dg.sensor_points)); a=jnp.sum(sp**2,1); Gm=sp@sp.T
    d2=jnp.clip(a[:,None]+a[None,:]-2*Gm,0.0,None); W=jnp.exp(-d2/(2*TS**2)); W=W/(jnp.sum(W,0,keepdims=True)+1e-8)
    ocsm=W@oc
def shape_term(q):
    if TS>0:
        qs=W@q; os_=ocsm
    else:
        qs=q; os_=oc
    phat=qs/(jnp.sum(qs)+1e-8)                     # scale-invariant -> no energy gradient
    return -jnp.sum(os_*jnp.log(phat+1e-8))/SUMOBS*100.0
from lucid.losses import first_arrival_nll
def first_arrival_shape(lw,ft,fi,tobs,tau):
    return PS.first_arrival_shape(lw,ft,fi,tobs,tau,ND)
def mkgrad(tau):
    def loss(th,k):
        lw,ft,fi,q=pred(H.theta_to_track(th),k)
        lE=((jnp.sum(q)-SUMOBS)/SUMOBS)**2*100.0
        lS=shape_term(q)
        lT=jnp.sum(jnp.where(tmask,first_arrival_shape(lw,ft,fi,otf-th[6],tau),0.0))
        return wE*lE+wS*lS+wT*lT
    return jax.jit(jax.grad(loss))
gtot={tau:mkgrad(tau) for tau in SCHED}
def gnlm(theta,gfn,steps,tag=0,LR=0.4,LM=0.05,tail=30):
    T=[]
    for s in range(steps):
        kk=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in kk]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st)
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t):return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t):return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
print(f"COMBO tau_smooth={TS} sched={SCHED} wE={wE} wS={wS} wT={wT}",flush=True)
Vs=[];Ds=[];Es=[];Tt=[]
for sd in SEEDS:
    rng=np.random.default_rng(sd)
    th=jnp.array(ts+rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
    for j,tau in enumerate(SCHED): th=gnlm(th,gtot[tau],STEPS,tag=2+j)
    Vs.append(vtx(th));Ds.append(deg(th));Es.append(Ep(th));Tt.append(float(th[6]-ts[6]))
    print(f"  seed {sd}: vtx={vtx(th):5.1f}cm E={Ep(th):+.1f}% dir={deg(th):.2f}deg t0={Tt[-1]:+.2f}",flush=True)
print(f"COMBO SUMMARY tau_smooth={TS}: vtx={np.mean(Vs):.1f}+-{np.std(Vs):.1f}cm (med {np.median(Vs):.1f}) "
      f"dir={np.mean(Ds):.2f}+-{np.std(Ds):.2f}deg E={np.mean(Es):+.1f}+-{np.std(Es):.1f}% t0={np.mean(Tt):+.2f}ns",flush=True)
