"""CRB floor over loss-term COMBINATIONS at realistic TTS. At truth, over M DATA realizations, get per-term
scores g_E,g_S,g_T; for each combination form F = cov(sum of terms) and CRB = sqrt(diag(F^-1)). Reports the
theoretical minimum (E%, vtx cm, dir deg, t0 ns) per combo. Vary EVENT / POLAR / AZIM to check across tracks.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 EVENT=0 python crb_combos.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True, linewidth=160)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '150000'))
M = int(os.environ.get('M', '64')); TAU = float(os.environ.get('TAU', '2.5')); THR = float(os.environ.get('THR', '4.0'))
EVENT = int(os.environ.get('EVENT', '0')); POLAR = float(os.environ.get('POLAR', '0.6')); AZIM = float(os.environ.get('AZIM', '0.8'))
VX = float(os.environ.get('VX', '0')); VY = float(os.environ.get('VY', '0')); VZ = float(os.environ.get('VZ', '0'))
NAMES = H.PARAM_NAMES; SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1, target_vtx=(VX, VY, VZ), target_polar=POLAR, target_azim=AZIM)
ts = jnp.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def fa_shape(lw, ft, fi, tobs, tau):
    t_obs = tobs[fi]; x = (t_obs - ft) / tau
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.where(empty, 0.0, -lf - (Ns - 1.0) * l1mf)
def mk(term):
    def f(theta, key, oc, ot, hi):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
        if term == 'E': return ((sumq - sumobs) / sumobs) ** 2 * 100.0
        if term == 'S': return -jnp.sum(oc * jnp.log(q / (sumq + 1e-8) + 1e-8)) / sumobs * 100.0
        tmask = hi & (oc >= THR); return jnp.sum(jnp.where(tmask, fa_shape(lw, ft, fi, ot - theta[6], TAU), 0.0))
    return jax.jit(jax.grad(f))
gE, gS, gT = mk('E'), mk('S'), mk('T')
GE, GS, GT = [], [], []
for m in range(M):
    oc, ot, hi = regen(5000 + m); pk = jax.random.PRNGKey(m)
    GE.append(np.array(gE(ts, pk, oc, ot, hi)) * SC); GS.append(np.array(gS(ts, pk, oc, ot, hi)) * SC); GT.append(np.array(gT(ts, pk, oc, ot, hi)) * SC)
GE, GS, GT = np.array(GE), np.array(GS), np.array(GT)

def crbline(name, G):
    F = (G.T @ G) / M; F = F + 1e-7 * np.trace(F) * np.eye(7)
    c = np.sqrt(np.clip(np.diag(np.linalg.inv(F)), 0, None))
    vtx = np.sqrt(sum((c[i] * SC[i]) ** 2 for i in [1, 2, 3])) * 100
    dr = np.sqrt(sum((c[i] * SC[i]) ** 2 for i in [4, 5])) * deg
    print(f"  {name:14s}: E={c[0]*SC[0]/float(ts[0])*100:5.1f}%  vtx={vtx:6.1f}cm  dir={dr:5.2f}deg  t0={c[6]*SC[6]:5.2f}ns", flush=True)
print(f"# CRB COMBOS TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} EVENT={EVENT} POLAR={POLAR} AZIM={AZIM} vtx=({VX},{VY},{VZ}) M={M} nhit={S['nhit']}", flush=True)
crbline('lE+lT', GE + GT)
crbline('lE+lS+lT', GE + GS + GT)
crbline('lE+lS', GE + GS)
crbline('lT only', GT)
crbline('lS only', GS)
