#!/usr/bin/env python3
"""Parameter residual distributions, finalized config, 1-sigma jitter start, high stats."""
import glob,re,numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rows=[]
for f in sorted(glob.glob('/tmp/mg_dist1s_*.log')):
    for l in open(f):
        m=re.search(r'E\s*([+-][0-9.]+)\s+\|vtx\|\s*([0-9.]+)cm \(lon\s*([0-9.]+) tra\s*([0-9.]+)\).*dir\s*([0-9.]+).*t0\s*([+-][0-9.]+)',l)
        if m: rows.append([float(x) for x in m.groups()])
a=np.array(rows); E,V,LON,TRA,D,T=a.T
rms=lambda x:np.sqrt((x**2).mean()); p68=lambda x:np.percentile(np.abs(x),68)
panels=[('energy residual (MeV)',E,True),('|vertex| (cm)',V,False),('longitudinal (cm)',LON,False),
        ('transverse (cm)',TRA,False),('direction (deg)',D,False),('t0 residual (ns)',T,True)]
fig,axes=plt.subplots(2,3,figsize=(15,9)); axes=axes.ravel()
for ax,(lab,x,signed) in zip(axes,panels):
    ax.hist(x,bins=24,color='C0',edgecolor='k',alpha=0.8)
    med=np.median(x); ax.axvline(med,color='r',lw=1.5,label=f'med {med:+.2f}' if signed else f'med {med:.2f}')
    ax.axvline(np.percentile(np.abs(x),68)*(1 if not signed else 1),color='orange',ls='--',lw=1.3,label=f'p68 {p68(x):.2f}')
    if signed: ax.axvline(0,color='k',lw=0.6,ls=':')
    ax.set_xlabel(lab); ax.set_ylabel('events'); ax.set_title(f'{lab.split(" (")[0]}: med={np.median(x):+.2f} rms={rms(x):.2f} p68={p68(x):.2f}',fontsize=10)
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
fig.suptitle(f'Parameter residual distributions  (finalized loss, 1-sigma jitter start, N={len(a)})',fontsize=13)
fig.tight_layout(rect=[0,0,1,0.97]); fig.savefig('recon_plots/distributions_1sigma.png',dpi=110)
print(f'N={len(a)}')
print(f"E   : bias {E.mean():+.1f} rms {rms(E):.1f} ({rms(E)/1050*100:.1f}%) p68 {p68(E):.1f}")
print(f"vtx : med {np.median(V):.1f} rms {rms(V):.1f} p68 {p68(V):.1f} (lon rms {rms(LON):.1f} / tra rms {rms(TRA):.1f})")
print(f"dir : med {np.median(D):.2f} rms {rms(D):.2f} p68 {p68(D):.2f}")
print(f"t0  : bias {T.mean():+.2f} rms {rms(T):.2f} p68 {p68(T):.2f}")
print('wrote distributions_1sigma.png')
