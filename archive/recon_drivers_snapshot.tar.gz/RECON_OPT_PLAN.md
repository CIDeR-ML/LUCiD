# Recon optimizer + HP plan — systematic, verification-gated (2026-06-08)

Goal: reach the realistic-mix floor (~14.5 cm median / ~17.5 RMS, PhotonSim GEANT4 TTS=2.5) **from far away**
and **robustly**, by SIMPLIFYING the optimizer (calibration-inspired consistent Fisher-GN) — but VERIFYING every
transferred assumption because recon ≠ calibration. Vary truth POSITION + ANGLE in every analysis (isotropic dir +
fiducial shift, `RANDOMIZE=1`) to avoid tunnel vision. FD jacobians where jacfwd is blocked by the DiCE custom_vjp.

## Baseline numbers (locked, this session)
- Realistic mix (N=80, full loss, gnrec+Polyak, from-truth): median 14.5 / mean 16.0 / RMS 17.5 / 68th 17.8 cm;
  slanted(60-90°) 14.0, near-vertical(0-30°) 16.4.
- Attribution (vtx cm): PS charge 56 / time 29 / full 18 ; SN charge 8 / time 13 / full 11.
- Shot-noise removed: charge-only 48->248 (systematic), full 18->32 => BIAS-limited not shot.
- CRB (info bound): charge+time ~3 cm => trough is bias-limited, ~3 cm headroom.
- Emission systematic ~3-5%/bin (Pearson 0.54σ); optimizer basin gnrec 15 m SIREN / ~10 m PhotonSim.

## What may DIFFER from calibration (the verification targets)
1. Loss form: calib √-MSE (JᵀWJ natural PSD); recon Poisson charge (clean Fisher) + ORDER-STAT time (NOT
   least-squares; time FD Hessian was indefinite in crb_long). => the PSD GN metric for TIME is unverified.
2. jacfwd BLOCKED (custom_vjp) -> FD jacobians (noisier/slower) everywhere.
3. recon model is BIASED (SIREN≠GEANT4) -> g=0/MLE = the DISPLACED argmin, not truth. Optimizer fixes REACHING it
   (basin/robustness); the argmin-vs-truth gap (~14 cm) is bias -> needs info/likelihood/prior, NOT the optimizer.
4. Degeneracy is geometry-dependent (rotates with track angle), not a clean 2-param degeneracy.

## Sufficient statistics
A/B gates on a FIXED CRN event set (per-event diff low-variance): ~12-16 varied events. Absolute resolution
(median unc ≈1.25σ/√N): ~50 events. Use 16 for gates, ~50 for final claims. ALWAYS vary angle+position.

## PHASES (each has a pass/fail gate)

### Phase 0 — lock the derived HPs by proof  [RUNNING: DELTA sweep]
- DELTA {0.5,1,2,4}: full-loss from-truth on 16 CRN varied events. GATE: resolution flat -> fix DELTA.
- OVERLAP_RENORM: = analytic hard/soft total ratio; sweep {1.0,1.009,1.02} -> affects ENERGY only, vtx insensitive
  (global charge scale absorbed by E). GATE: derived, function of temp -> fix. [Batch 2]
- MAXCELL: matched truth=pred A/B at MC 4 vs 16. GATE: recon identical -> fix at 4. [Batch 2]

### Phase 1 — the TIME-term PSD GN metric (the risk gate)  [RUNNING: time_fisher_psd.py]
Candidate PSD metrics at truth, varied events: charge Fisher Jμᵀdiag(1/μ)Jμ (PSD); time FD Hessian (may be
indefinite); time SCORE COVARIANCE E_data[g gᵀ] (empirical Fisher, PSD by construction). GATE: if full
charge+score-cov has 0 negative eigenvalues across varied events -> NO eigen-clip needed (calib recipe transfers).
Else -> minimal clip on the time block / better PSD construction.

### Phase 2 — build consistent Fisher-GN, verify each mechanism (6 events, from truth AND far)
2a consistency cures the flat-trough wander (H & g on SAME key, refresh H WITH g). 2b min‖g‖ vs Polyak vs final.
2c Marquardt λ·diag(H) ridge-robust (sweep λ). 2d scale-free (drop SCALE9, Jacobi metric). 2e no line search
(stalls on flat dir per calib §5).

### Phase 3 — A/B new optimizer vs gnrec on CRN set (floor + basin + robustness), ALL-param CRB-normalized metric.
GATE: match floor AND widen/equal basin AND reduce spread. Else keep gnrec, adopt min‖g‖/consistency piecemeal.

### Phase 4 — temp{0.05,0.1}↔OVERLAP study; then the tiny residual HPO (SIGMA,CW,NITERS,λ,NKEYS,seeder) on
multi-param score from far. Add the charge-coarse grid SEEDER (the real "from far" lever).

### Phase 5 — push floor <14 cm via INFORMATION (separating bias from info): de-biased first-arrival likelihood
(order-stat/TTS correction; naive window FAILED), better emitter, or a PRIOR on the flat direction (calib MAP analogue).

### Phase 2/3 Batch 2 basin A/B (PhotonSim, varied pos+angle, CRN, min||g||)
  Fisher-GN floor: median 9.5 RMS 13.0 cm 12/12 -> BEATS gnrec floor (14.5/17.5)! cleaner estimator (min||g|| reaches stationary pt).
  Fisher-GN 5m: 0/12 (167cm) ; 10m: 0/12 (957cm) ; REFRESH=1 also fails -> NOT caching. Minimal lam=0.01 pure-GN OVERSHOOTS far out.
  => Fisher-GN = mirror of gnrec: TIGHT FLOOR / NARROW BASIN. Fix = |g|-based adaptive LM (raise lam when ||g|| doesnt drop). [Batch 3]

### Batch 3/4 KEY FINDINGS (random pos+angle far starts)
  - gnrec ALSO fails from random-10m (200-994cm) -> generic far start beyond ALL local optimizers. "From far" NEEDS A SEEDER.
  - adaptive |g|-reject FREEZES (fake 0.9cm from truth, stuck-at-start from far). Honest floor = fixed-lam 9.5cm.
  - Fisher-GN fixed-lam=0.01 floor median 9.5 RMS 13 -> BEATS gnrec floor via min||g|| (cleaner stationary-pt estimator).
  - PIVOT: use Fisher-GN(min||g||) for the FLOOR; build a charge-coarse SEEDER for from-far. Map local basin next.

### Batch 5 FLOOR A/B + local basin (identical CRN events 0-11, varied pos+angle)
  FLOOR: Fisher-GN min|g| median 9.5/RMS13.0 vs gnrec Polyak median 15.3/RMS16.7 -> Fisher-GN WINS floor (1.6x).
  Local basin Fisher-GN: 0m=9.5 1m=14.6 2.5m=22.6 5m=40.5(6/12) -- residual degrades w/ distance (flat trough, far->worse stationary pt).
  gnrec 2.5m=16.6 -> gnrec MORE robust to start distance than Fisher-GN. Neither crosses random 10m.
  STRATEGY: SEEDER (within ~1-2m) -> Fisher-GN(min|g|) polish to ~10-15cm. Build charge-grid seeder.

### Batch 6 Phase-0 CLOSEOUT (PASS, all derived HPs fixed) + seeder
  OVERLAP 1.0/1.009/1.02: vtx 9.9/9.5/9.9 INSENSITIVE; E -4/-4/-10 -> derived, fix 1.009.
  MAXCELL 4/8/16: vtx 9.5/9.4/12.1 (4=8, 16 within noise) -> cancels, fix 4.
  CHARGE-grid seeder FAILED (seed err median 885cm) -> Cherenkov ring degenerate in vtxxdir. Need TIMING multilateration seed.

### Batch 9 MULTI-PARAM A/B (Fisher-GN min|g| vs gnrec Polyak) — Fisher-GN WINS ALL PARAMS
  Fisher-GN(48ev): vtx 11.2/RMS15.1 dir 1.28 E_RMS 9MeV t0 0.37ns
  gnrec(24ev):     vtx 13.8/RMS15.2 dir 1.81 E_RMS 30MeV t0 0.39ns  -> Fisher-GN better vtx/dir, ENERGY 3.3x better.
  Robustness: min|g|~Polyak (both good); LAM 0.003/0.01/0.05 -> vtx 9.8/9.5/9.5 RIDGE-ROBUST (not tuned). Calibration recipe CONFIRMED.
  DELIVERABLE: Fisher-GN(consistent Fisher metric, NO clip, NO SCALE9, lam*diag ridge, min|g|) simpler AND better than gnrec on every param.

### Phase 5 (variance levers) + CAMPAIGN CONCLUSION
  NPHP 0.5M->1.5M: vtx 9.5->12.5 WORSE (sharpens biased argmin); NKEYS8/NITERS200 no help. FLOOR IS BIAS-LIMITED.
  Honest Fisher-GN floor ~11-12cm (500k noise-masks to ~9.5). Below needs emitter fidelity / de-biased time likelihood, not compute.

## CAMPAIGN BOTTOM LINE
  WINNER OPTIMIZER = Fisher-GN: consistent PSD Fisher metric (charge JmuT diag(1/mu) Jmu + time SCORE-COV, both FD),
   lam*diag(F) Marquardt ridge (ridge-robust, not tuned), NO eigen-clip, NO SCALE9, min||g|| readout. Simpler than gnrec
   (dropped clip/ridge-eps/damp/TR/scales) AND beats it on EVERY param: vtx 11.2 vs 13.8, dir 1.28 vs 1.81, E 9 vs 30MeV(3.3x), t0~tie.
  Phase0 HPs fixed (DELTA1/OVERLAP1.009-derived/MAXCELL4-cancels); temp0.1 fine. Floor bias-limited ~11cm (CRB~3cm, gap=emission+time bias).
  FROM-FAR: local basin Fisher-GN ~2.5m; no local method crosses random 10m; track-vertex seeding (charge/timing) FAILED -> fiTQun-class effort needed.

### DEFINITIVE NUMBERS (large N)
  Fisher-GN floor random pos+angle (96ev): median 13.0 RMS 15.4 68pct 15.9 cm.
  Fisher-GN VERTICAL-gun floor (16ev): median 10.9 RMS 12.0 -> vs historical gnrec vertical ~18cm = 40% BETTER on worst-case geometry.
  Full-loss-grid seeder FAILED too (seed 1281cm) -> all 3 seeders fail; track-vertex seeding is fiTQun-class (out of scope). CONCLUDED.

### DEFINITIVE 96-event matched A/B (varied pos+angle)
  Fisher-GN: vtx 13.0/RMS15.4/68=15.9 dir 1.34 E_RMS 10 t0 0.40 | gnrec: vtx 14.8/17.5/17.8 dir 1.78 E_RMS 30 t0 0.47.
  Fisher-GN BETTER ON ALL: vtx -12%, dir -25%, E -3x, t0 -15%. FINAL.

### Batch D: lambda-anneal + fine basin map
  lambda-ANNEAL (HI 3/10) does NOT extend basin: 5m 3/12 (worse than fixed 6/12), 10m fail. NO optimizer trick extends basin.
  Fine basin (fixed-lam min|g|): 0m=9.5 1m=14.6 1.5m=18.1 2.5m=22.6 3.5m=27.8 5m=40.5(6/12). ~+5cm/m; floor-quality needs seed <1m.
  => FROM-FAR is purely a SEEDER problem (optimizer exhausted). Seed must be <1m for floor, <3.5m for any capture.

### Batch F/G — KEY CORRECTION: far starts are SLOW-CONVERGING, not stuck (trace_far.py + plots)
  ev2 10m trajectory MONOTONICALLY descends: vtx 999->313cm over 400 iters, loss 33642->18930, STILL going (|g| stays high=on slope).
  So "10m fails" was NITERS too small (120-200). Descent is STEP-CLIP-limited (STEPCLIP 0.5*SC=10cm/iter, path not straight -> ~1.7cm/iter -> ~600-1000 iters from 10m).
  0/2.5/5m converge (5m->17cm biased argmin, loss 15090<truthstart 15150). BASIN IS WIDE, just SLOW -> confirm NITERS=1000 from 10m reaches floor; larger STEPCLIP speeds far descent.
  REFRESH 12=30 (cached Fisher fine); resolution POSITION-INDEPENDENT (center=mid=wall ~10.3cm).

### CONVERGENCE CORRECTION (E problem, prompted by "do you vary E/t0") + multi-GPU launcher
  CRITICAL: NITERS=80 floor was UNDER-CONVERGED esp. for ENERGY. Same 16ev start@truth, NITERS 80/250/400:
    E_bias -5.3/-14.6/-20.6 (RMS 7.7/20.3/26.7, still drifting); vtx 10.5/11.5/10.6 (stable); dir 1.48/1.81/1.89 (worsens); t0 ~0.35 stable.
  => loss-min ENERGY is BIASED ~-2.4% by emission (precise CRB 1.3MeV but realized ~25MeV scatter). The "9MeV" was a transient under-converged artifact.
  READOUT=final (E+-300 start): E_bias +0.8 UNBIASED, RMS 24.9 -> energy is the SOFT param; use READOUT=final (unbiased), accept ~25MeV(2.4%).
  CAVEAT: earlier absolute E (and somewhat dir) numbers were under-converged; Fisher-GN-vs-gnrec E 3x "win" is a convergence/readout artifact (vtx/dir win holds).
  TIMING: ~0.85 s/iter/event (Fisher-GN, REFRESH=12, 500k ph) + ~5-6min one-time compile. NITERS 80=68s 250=207 300=248 400=333 per event.
  LAUNCHER mgpu.py: auto-detects free GPUs, splits events (and --cases) across all, pools jobs, aggregates all-param resolution. ~Nx faster for large N.
