"""DIAGNOSTIC 1: per-term x per-parameter 1D loss landscape (no optimization). For each term (lE total
charge, lS scale-inv shape, lT count-decoupled first-arrival) scan each of the 7 params over a wide range
from truth, averaged over NK predictor keys. Extract per (term,param):
  bias   = argmin offset (param units) -> model-mismatch bias (0 = unbiased)
  info   = curvature at truth (finite-diff 2nd deriv) -> which term constrains which param
  basin  = is the scanned-min a single basin reachable downhill from BOTH edges? (mono-decreasing to min)
  pull   = (edge value - min value)/|min value| -> constraint strength (0 = flat/no info)
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim python scan.py
  RECON_K=8 MAXCELL=16 OVERLAP_ANALYTIC=cubic SIREN_IMPORTANCE=1
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True, linewidth=160)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '100000'))
NK = int(os.environ.get('NK', '6')); TAU = float(os.environ.get('TAU', '0.3')); THR = float(os.environ.get('THR', '4.0'))
TK = int(os.environ.get('TK', '0')); NPTS = int(os.environ.get('NPTS', '25'))
S = PS.setup(event=0, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
oc, ot, hi = regen(TK)
NAMES = H.PARAM_NAMES

def fa_shape(lw, ft, fi, tobs, tau):
    t_obs = tobs[fi]; x = (t_obs - ft) / tau
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0)
    lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.where(empty, 0.0, -lf - (Ns - 1.0) * l1mf)

def terms(theta, key):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    phat = q / (sumq + 1e-8)
    lS = -jnp.sum(oc * jnp.log(phat + 1e-8)) / sumobs * 100.0
    tmask = hi & (oc >= THR)
    lT = jnp.sum(jnp.where(tmask, fa_shape(lw, ft, fi, ot - theta[6], TAU), 0.0))
    return jnp.array([lE, lS, lT])
tfn = jax.jit(terms)
ks = [jax.random.PRNGKey(4000 + i) for i in range(NK)]
def tval(theta):
    return np.mean([np.array(tfn(jnp.asarray(theta), k)) for k in ks], 0)

# scan ranges per param (wide enough to see basins): E +-50%, vtx +-3m, dir +-0.35rad(~20deg), t0 +-5ns
RANGE = np.array([0.5 * ts[0], 3.0, 3.0, 3.0, 0.35, 0.35, 5.0])
TNAMES = ['lE', 'lS', 'lT']
print(f"# SCAN TRUTH={TRUTH} TK={TK} NK={NK} NPTS={NPTS} K={PS.K}  (per term x param: bias info basin pull)", flush=True)
truth_vals = tval(ts)
print(f"# truth term values: lE={truth_vals[0]:.3f} lS={truth_vals[1]:.3f} lT={truth_vals[2]:.3f}", flush=True)
for j in range(7):
    offs = np.linspace(-RANGE[j], RANGE[j], NPTS)
    curves = np.array([tval(ts + np.eye(7)[j] * d) for d in offs])    # (NPTS, 3)
    line = f"{NAMES[j]:>7} (range +-{RANGE[j]:.3g}): "
    for t in range(3):
        c = curves[:, t]; imin = int(np.argmin(c)); bias = offs[imin]
        mid = NPTS // 2
        h = offs[1] - offs[0]
        info = (c[mid + 1] - 2 * c[mid] + c[mid - 1]) / h ** 2          # curvature at truth
        # basin: monotone-decreasing from each edge toward imin?
        left_mono = np.all(np.diff(c[:imin + 1]) <= 1e-9) if imin > 0 else True
        right_mono = np.all(np.diff(c[imin:]) >= -1e-9) if imin < NPTS - 1 else True
        basin = 'CVX' if (left_mono and right_mono) else 'multi'
        pull = (max(c[0], c[-1]) - c[imin]) / (abs(c[imin]) + 1e-9)
        line += f"| {TNAMES[t]} bias={bias:+.3g} info={info:+.2g} {basin} pull={pull:.2g} "
    print(line, flush=True)
