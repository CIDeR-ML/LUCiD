"""First-order check: AD grad vs FD grad for the propagator scalar (should MATCH)."""
import os
os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE','false')
import numpy as np, jax, jax.numpy as jnp
exec(open('prop_hess_test.py').read().split('# ───────────────────────── AD Hessian')[0])
# grad FD
gfn = jax.jit(jax.grad(scalar_from_results))
g_ad = np.array(gfn(p0))
n=6; eye=np.eye(n,dtype=np.float32); FD=1e-3
g_fd=np.zeros(n)
for j in range(n):
    vp=float(scalar_from_results(p0+jnp.asarray(eye[j]*FD)))
    vm=float(scalar_from_results(p0-jnp.asarray(eye[j]*FD)))
    g_fd[j]=(vp-vm)/(2*FD)
num=np.linalg.norm(g_ad-g_fd); den=np.linalg.norm(g_fd)
cos=float((g_ad@g_fd)/(np.linalg.norm(g_ad)*np.linalg.norm(g_fd)+1e-30))
np.set_printoptions(precision=3,suppress=True,linewidth=160)
print("g_ad",g_ad); print("g_fd",g_fd)
print(f"GRAD relative={num/den:.4f} cosine={cos:.4f}")
