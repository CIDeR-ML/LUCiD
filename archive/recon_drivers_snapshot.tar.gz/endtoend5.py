"""END-TO-END v5: FULLY DIFFERENTIABLE pipeline. probe_lon showed the missing wide longitudinal gradient
is a DIFFERENTIABLE loss: lCEN = (model charge-centroid - observed centroid) projected on the track axis
(argmin exactly at truth, unbiased ~10cm, wide +-5m). So:
  SEED (differentiable, model-free wavefront): grad-descent on Cherenkov-wavefront pinball
        t_exp = t0 + [a_par + a_perp*sqrt(n^2-1)]/c  for (V,d,t0); longitudinal lightly anchored to the
        charge centroid (the degenerate DOF) so it doesn't wander -- lCEN fixes longitudinal in the refiner.
  REFINER (differentiable): lE + WCEN*lCEN + WT*lT_gd, sigma-annealed. lCEN supplies the wide longitudinal
        pull (resolves the longitudinal<->t0 degeneracy, stops drift); lT_gd does fine transverse+dir+t0.
Env: TRUTH TTS_NS NKG SPS WT WCEN TKS EVENT NW SEED_STEPS WREG. Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 python endtoend5.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
WT = float(os.environ.get('WT', '1.0')); WCEN = float(os.environ.get('WCEN', '3.0')); WREG = float(os.environ.get('WREG', '2.0'))
NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '16')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0'))
NW = float(os.environ.get('NW', '1.34')); SEED_STEPS = int(os.environ.get('SEED_STEPS', '250'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)
C = 0.299792; G = float(np.sqrt(NW ** 2 - 1.0))
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points))

def dvec(pol, az): return jnp.array([jnp.sin(pol) * jnp.cos(az), jnp.sin(pol) * jnp.sin(az), jnp.cos(pol)])

# ---------- differentiable model-free wavefront seed (V,d,t0); longitudinal anchored ----------
def seed_loss(par, P, tobs, q, V0, tau):
    V = par[:3]; d = dvec(par[3], par[4]); t0 = par[5]
    a = P - V[None, :]; apar = a @ d; aperp = jnp.sqrt(jnp.maximum(jnp.sum(a * a, 1) - apar ** 2, 1e-9))
    r = tobs - (t0 + (apar + aperp * G) / C)
    pin = jnp.maximum(tau * r, (tau - 1.0) * r)
    anchor = ((V - V0) @ d) ** 2                                   # pin longitudinal near centroid (degenerate DOF)
    return jnp.sum(q * pin) / (jnp.sum(q) + 1e-9) + WREG * anchor
sgrad = jax.jit(jax.grad(seed_loss))

def geom_seed(oc, ot, hi):
    hm = np.array(hi); P = DP[jnp.array(hm)]; tobs = jnp.array(np.array(ot)[hm]); q = jnp.array(np.array(oc)[hm])
    Pn = np.array(P); qn = np.array(q)
    V0 = (qn[:, None] * Pn).sum(0) / qn.sum()
    dv = Pn - V0[None, :]; dv = dv / (np.linalg.norm(dv, axis=1, keepdims=True) + 1e-9)
    ax = (qn[:, None] * dv).sum(0); ax = ax / (np.linalg.norm(ax) + 1e-9)
    par = jnp.array([V0[0], V0[1], V0[2], float(np.arccos(np.clip(ax[2], -1, 1))), float(np.arctan2(ax[1], ax[0])),
                     float(np.median(np.array(tobs) - np.linalg.norm(Pn - V0[None, :], axis=1) / (C / NW)))])
    V0j = jnp.array(V0); psc = np.array([0.2, 0.2, 0.2, 0.02, 0.02, 0.2]); m = np.zeros(6); v = np.zeros(6); b1, b2 = 0.9, 0.999
    for t in range(1, SEED_STEPS + 1):
        tau = 0.5 if t < SEED_STEPS // 3 else 0.25
        g = np.array(sgrad(par, P, tobs, q, V0j, tau)) * psc
        m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g; mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
        par = par - 0.04 * jnp.array(mh / (np.sqrt(vh) + 1e-8) * psc)
    par = np.array(par); E = float(estimate_muon_energy_from_photon_count(float(qn.sum())))
    return np.array([E, par[0], par[1], par[2], par[3], par[4], par[5]])

# ---------- differentiable refiner: lE + WCEN*lCEN + WT*lT_gd ----------
def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    d = dvec(theta[4], theta[5])
    cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / sumobs
    lCEN = ((cen_p - cen_o) @ d) ** 2 * 100.0                      # longitudinal charge-centroid mismatch
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WCEN * lCEN + WT * lT
gfn = jax.jit(jax.grad(loss))

def refine(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g; mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t): return float(np.degrees(np.arccos(np.clip(np.array(dvec(t[4], t[5])) @ np.array(dvec(ts[4], ts[5])), -1, 1))))
def lon(t): return float(((np.array(t) - ts)[1:4] @ np.array(dvec(ts[4], ts[5]))) * 100)
def report(tag, th): return f"{tag}: vtx={vtx(th):6.1f}cm (lon={lon(th):+6.0f}) dir={degf(th):5.2f}deg t0_err={abs(th[6]-ts[6]):5.2f}ns E_err={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"

print(f"# ENDTOEND5 TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} NW={NW} WCEN={WCEN} WT={WT} WREG={WREG} (differentiable wavefront seed + lE+lCEN+lT_gd refiner)", flush=True)
print(f"#   truth theta = {ts}", flush=True)
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0 = geom_seed(oc, ot, hi); thf = refine(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    print(f"  key {tk}  {report('SEED ', th0)}", flush=True)
    print(f"  key {tk}  {report('FINAL', thf)}", flush=True)
SE = np.array([[vtx(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():6.1f}cm dir={SE[:,1].mean():5.2f}deg t0={SE[:,2].mean():5.2f}ns E={SE[:,3].mean():5.1f}%", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():6.1f}cm dir={FE[:,1].mean():5.2f}deg t0={FE[:,2].mean():5.2f}ns E={FE[:,3].mean():5.1f}%  TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
