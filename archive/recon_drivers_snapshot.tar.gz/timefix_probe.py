"""PROTOTYPE FIX (a): build the first-arrival survival from DIRECT (early-window) photons, not the full arrival
mixture (which includes the late scattered/reflected tail -> +3.7ns occupancy-dependent lateness -> z/t0 bias).
Per PMT keep only photons with ft <= ftmin_sensor + W in R(t) and in the survival amplitude muS. Sweep W and
measure, at the truth, the TIME-only gradient norm (the bias proxy; ->0 if fixed) and t0-argmin, for SIREN
self-consistency(SN, isolates loss form) AND PhotonSim(PS, must not get WORSE). W=inf reproduces the current loss.
Env: EVENT NPHP NKEYS.  Usage: CUDA_VISIBLE_DEVICES=0 EVENT=0 python timefix_probe.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=3, suppress=True, linewidth=170)
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NBUF=400_000
MC=int(os.environ['MAXCELL']); K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0))
EV=int(os.environ.get('EVENT','0')); NKEYS=int(os.environ.get('NKEYS','8')); NPHP=int(os.environ.get('NPHP','1500000'))
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); C=P-P.mean(0)
    _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d; proj=-proj
    vtx=P.mean(0)+proj.min()*d; pol=float(np.arccos(np.clip(d[2],-1,1))); az=float(np.arctan2(d[1],d[0]))
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]),d
POL,AZ=0.05,0.8; th9_sn=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
print(f"# TIMEFIX_PROBE ev{EV} NPHP={NPHP} NKEYS={NKEYS}",flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
truth_sn=H.build_truth_sim(K=K,n_photons=NPHP); pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def time_loss(t9,oc,ot,key,W):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]
    ftmin=jax.ops.segment_min(ft,fi,num_segments=ND)                       # earliest model photon per PMT
    within=jax.lax.stop_gradient((ft<=ftmin[fi]+W).astype(ft.dtype))       # direct-light window mask
    wR=ww*within; muS=jax.lax.stop_gradient(jnp.maximum(jax.ops.segment_sum(wR,fi,num_segments=ND),1e-8))
    Rlo=jax.ops.segment_sum(wR*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(wR*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
gtime=jax.jit(jax.grad(time_loss))
KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
# datasets at truth
rawP=read_photon_data_from_photonsim(ROOT,EV); th9P,dP=derive_truth(rawP); pdP,_=pad_event(rawP); T0P=jnp.asarray(th9P)
cP,tP=jax.lax.stop_gradient(data_sim(sc2(T0P),jax.random.PRNGKey(7000+EV),pdP)); ocP=jnp.asarray(np.asarray(cP)); otP=jnp.asarray(np.where(np.asarray(cP)>0,np.asarray(tP),0.))
T0S=jnp.asarray(th9_sn); cS,tS=jax.lax.stop_gradient(truth_sn(sc2(T0S),jax.random.PRNGKey(9000))); ocS=jnp.asarray(np.asarray(cS)); otS=jnp.asarray(np.where(np.asarray(cS)>0,np.asarray(tS),0.))
def tgrad_norm(T0,oc,ot,W):
    g=np.mean([np.asarray(gtime(T0,oc,ot,k,float(W)))*SCALE9 for k in KEYS],0)
    return np.linalg.norm(g), g[3], g[8]   # |g|, z-comp, t0-comp
def t0argmin(T0,oc,ot,W):
    dts=np.linspace(-2.5,1.5,21)
    L=[np.mean([float(time_loss(T0.at[8].set(float(dt)),oc,ot,k,float(W))) for k in KEYS]) for dt in dts]
    return dts[int(np.argmin(L))]
print("#\n# TIME-only gradient at truth & t0-argmin vs WINDOW (W=1e9 = current loss):",flush=True)
print("#  W(ns) | SN: |g_time|  g_z     g_t0   t0argmin || PS: |g_time|  g_z     g_t0   t0argmin",flush=True)
for W in [1e9, 30., 15., 8., 5., 3.]:
    sn=tgrad_norm(T0S,ocS,otS,W); sa=t0argmin(T0S,ocS,otS,W)
    ps=tgrad_norm(T0P,ocP,otP,W); pa=t0argmin(T0P,ocP,otP,W)
    print(f"#  {W:5.0f} | {sn[0]:9.1f} {sn[1]:+7.1f} {sn[2]:+7.1f} {sa:+7.2f}  || {ps[0]:9.1f} {ps[1]:+7.1f} {ps[2]:+7.1f} {pa:+7.2f}",flush=True)
print("# DONE",flush=True)
