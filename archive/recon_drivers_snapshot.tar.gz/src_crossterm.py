"""DEFINITIVE energy 2nd-order test, deterministic emission (no jitter), fine-FD reference.
Splits the energy Hessian row into the CROSS block d2/dE d(dir) and the DIAGONAL d2/dE2.
Compares discrete (DiCE score) vs the dice-weighted objective, to answer:
  (a) cross-term lost only because bare sum(rays) isn't dice-weighted?  -> dice-weighted cross matches FD
  (b) systematic-resample shift genuinely lost even when dice-weighted?  -> dice-weighted cross/diag fails
Run: CUDA_VISIBLE_DEVICES=g SIREN_CONTINUOUS=0|1 python src_crossterm.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.siren.core import create_photonsim_siren_grid, SIREN
from lucid.siren.training.inference import SIRENPredictor
from lucid.sources.siren_rays import (normalize_inputs_jit, denormalize_log_predictions,
                                       generate_random_cone_vectors)
from lucid.utils import unpack_photonsim_params, normalize
np.set_printoptions(precision=4, suppress=True, linewidth=140)
CONT = os.environ.get('SIREN_CONTINUOUS', '0') == '1'
NPHOT = int(os.environ.get('NPHOT', '40000'))
print(f"SIREN_CONTINUOUS={int(CONT)} NPHOT={NPHOT}")
dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
pp = unpack_photonsim_params('muon', dg.medium.material)
pr = SIRENPredictor(pp['siren_model_path']); grid = create_photonsim_siren_grid(pr)
mp = pr.params; key = jax.random.PRNGKey(0)
d0 = np.array([np.sin(0.6)*np.cos(0.8), np.sin(0.6)*np.sin(0.8), np.cos(0.6)])
p0 = jnp.array([0., 0., 0., d0[0], d0[1], d0[2], 1050.0])
SCp = np.array([0.2, 0.2, 0.2, 0.05, 0.05, 0.05, 50.0])
(n_bins, energy_min, energy_max, angle_min, angle_max, distance_min, distance_max,
 angle_bins, distance_bins, angle_dist_grid, angle_mesh, distance_mesh, log_min, log_max) = grid
adm = jnp.array(angle_dist_grid); n_grid = adm.shape[0]
model = SIREN(hidden_features=256, hidden_layers=3, out_features=1)


def dep(p):
    to, td, E = p[:3], p[3:6], p[6]
    k = key; k, subkey = jax.random.split(k)
    eg = jnp.stack([jnp.full_like(angle_mesh, E).ravel(), angle_mesh.ravel(), distance_mesh.ravel()], axis=1)
    ng = normalize_inputs_jit(eg, energy_min, energy_max, angle_min, angle_max, distance_min, distance_max)
    lp, _ = model.apply(mp, ng)
    density = jnp.clip(denormalize_log_predictions(jnp.squeeze(lp), log_max, log_min), 1e-12, None)
    p_emit = density / jnp.sum(density)
    k, sk = jax.random.split(k); cdf = jnp.cumsum(p_emit)
    u0 = jax.random.uniform(sk, ()) / NPHOT; us = u0 + jnp.arange(NPHOT) / NPHOT
    idx = jnp.clip(jnp.searchsorted(cdf, us), 0, n_grid - 1)
    logp = jnp.log(p_emit[idx])
    if CONT:
        hi = jnp.clip(idx, 0, n_grid - 1); lo = jnp.clip(idx - 1, 0, n_grid - 1)
        cdf_lo = jnp.where(idx <= 0, 0.0, cdf[lo]); cdf_hi = cdf[hi]
        frac = jnp.clip((us - cdf_lo) / (cdf_hi - cdf_lo + 1e-12), 0.0, 1.0)
        sad = (1.0 - frac[:, None]) * adm[lo] + frac[:, None] * adm[hi]; dice = jnp.ones(NPHOT)
    else:
        sad = adm[idx]; dice = jnp.exp(logp - jax.lax.stop_gradient(logp))
    sa, sd = sad[:, 0], sad[:, 1]
    k, sub2 = jax.random.split(subkey)
    rv = generate_random_cone_vectors(td, sa, NPHOT, sub2)
    ro = jnp.ones((NPHOT, 3)) * to[None, :] + (sd / 1000.0)[:, None] * normalize(td[None, :])
    g = jnp.sum(rv, axis=1) + jnp.sum(ro, axis=1)
    return jnp.sum(g * dice)


gf = jax.jit(jax.grad(dep))
Had = np.array(jax.hessian(dep)(p0)) * np.outer(SCp, SCp)
# fine, RICHARDSON-extrapolated FD of the energy row for stability
def fd_row(fr):
    j = 6; d = fr * SCp[j]
    return (np.array(gf(p0.at[j].add(d))) - np.array(gf(p0.at[j].add(-d)))) / (2 * fr) * SCp
# cross block = indices 3,4,5 (dir); diagonal = index 6
print("CROSS  d2/dE d(dir)   autodiff:", Had[6, 3:6])
for fr in [0.2, 0.05]:
    print(f"CROSS  d2/dE d(dir)   FD({fr}) :", fd_row(fr)[3:6])
print("DIAG   d2/dE2         autodiff:", Had[6, 6])
for fr in [0.2, 0.05]:
    print(f"DIAG   d2/dE2         FD({fr}) :", fd_row(fr)[6])
cad = Had[6, 3:6]; cfd = fd_row(0.05)[3:6]
print(f"CROSS cos={float(cad@cfd/(np.linalg.norm(cad)*np.linalg.norm(cfd)+1e-12)):.4f}  "
      f"rel={np.linalg.norm(cad-cfd)/(np.linalg.norm(cfd)+1e-9):.4f}")
