"""Reconstruction harness for the ported implicit/DiCE step.

Flat 7-vector track parameterization  theta = [energy, x, y, z, polar, azim, t0]
(energy MeV; position m; angles rad; t0 ns), a configurable-hyperparameter combined
loss (charge Poisson-NLL + first-arrival time NLL + optional vertex term), and a
data-like truth generator. Reused by the gradient/Hessian, CRB, and optimizer studies.

Build the simulators ONCE (compilation is expensive) and pass them in.
"""
import os
import jax, jax.numpy as jnp
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import ParticleParams
from lucid.losses import poisson_nll, first_arrival_nll

GEOM = 'config/SK_geom_config.json'
PHYS = 'config/SK_physics_config.json'

PARAM_NAMES = ['energy', 'x', 'y', 'z', 'polar', 'azim', 't0']

# Reasonable physical scales for each param (for finite-difference steps / normalization)
PARAM_SCALE = jnp.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.2])   # MeV, m, m, m, rad, rad, ns


def theta_to_track(theta):
    """Flat 7-vector -> ParticleParams."""
    return ParticleParams(
        energy=theta[0],
        position=theta[1:4],
        theta=theta[4],
        phi=theta[5],
        t0=theta[6],
    )


def build_predictor(temperature=0.1, K=7, n_photons=50_000, wavelength_mode=True,
                    pos_grad_threshold=None, n_grad_iters=None):
    """Differentiable implicit per-photon predictor (track mode, wavelength mode on).

    temperature=0.1 -> SOFT Gaussian-acceptance overlap weight (sigma=0.1*sensor_radius), a
    CONSISTENT forward/backward smoothing. This replaces the hard-step + sigmoid straight-through
    (temperature=None), whose forward-hard/backward-soft mismatch crippled the charge->position
    gradient to ~15% of the true (finite-difference) magnitude and could sign-flip it. With temp=0.1
    the AD gradient matches FD (cosine 0.96-0.999, magnitude 0.76-0.85) while forward occupancy is
    preserved (Sq ratio ~0.96). See RECON_PHOTONSIM_ANALYSIS.md sec 6. pos/dir gradients flow all K
    iterations by default (grad-iters at max), as required for track reconstruction.
    """
    if pos_grad_threshold is None:
        pos_grad_threshold = K
    if n_grad_iters is None:
        n_grad_iters = K
    return setup_event_simulator(
        GEOM, n_photons=n_photons, temperature=temperature, K=K,
        is_data=False, use_expected_value=True, hit_mode='per_photon',
        max_sensors_per_cell=int(os.environ.get('MAXCELL', '4')),
        physics_config=PHYS, default_detector_params=True,
        particle='muon', wavelength_mode=wavelength_mode,
        pos_grad_threshold=pos_grad_threshold, n_grad_iters=n_grad_iters)


def build_truth_sim(K=7, n_photons=50_000, wavelength_mode=True, apply_smearing=False):
    """Data-like (sampling) truth: hard first-arrival + Bernoulli QE (make_hits_data).
    temperature=None -> hard overlap (matches the predictor)."""
    return setup_event_simulator(
        GEOM, n_photons=n_photons, temperature=None, K=K,
        is_data=False, use_expected_value=False, hit_mode='realistic',
        max_sensors_per_cell=int(os.environ.get('MAXCELL', '4')),
        physics_config=PHYS, default_detector_params=True,
        particle='muon', wavelength_mode=wavelength_mode, apply_smearing=apply_smearing)


def gen_truth(truth_sim, theta_true, key):
    """Generate a data-like observed (counts, sanitized first-arrival times)."""
    counts, times = jax.lax.stop_gradient(truth_sim(theta_to_track(theta_true), key))
    hit = counts > 0
    times = jnp.where(hit, times, 0.0)            # empty sensors -> 0 (no inf sentinel)
    return counts, times, hit


def num_detectors(sim):
    return int(sim.default_detector_params.qe_corrections.shape[0])


def make_loss(predictor, obs_counts, obs_times, hit_mask, num_det,
              tau_time=1.5, w_charge=1.0, w_time=1.0):
    """Combined loss(theta, key) -> scalar, with configurable hyperparameters.

    charge: Poisson-NLL over all sensors.
    time:   order-statistic first-arrival NLL over truth-hit sensors (empty-segment safe).
    """
    obs_counts = jax.lax.stop_gradient(obs_counts)
    obs_times = jax.lax.stop_gradient(obs_times)
    hit_mask = jax.lax.stop_gradient(hit_mask)

    def loss(theta, key):
        log_w, flat_times, flat_idx, total_charge = predictor(theta_to_track(theta), key)
        charge = jnp.sum(poisson_nll(obs_counts, total_charge))
        # t0 (theta[6]) shifts the observed times so it is a fittable global time offset
        # (the prediction's own t0 is a detached predict_t0; the free t0 absorbs the offset).
        obs_shifted = obs_times - theta[6]
        nll = first_arrival_nll(log_w, flat_times, flat_idx, obs_shifted, tau_time, num_det)
        time = jnp.sum(jnp.where(hit_mask, nll, 0.0))
        return w_charge * charge + w_time * time
    return loss
