"""ISOLATED overlap test (no geometry): does each overlap mode carry value, gradient, AND curvature?
Ground truth = integral_f_of_d (the smooth 2D Gaussian-over-disk quadrature the lookup is built from);
it is C-inf in d, so autodiff THROUGH it gives the exact value, 1st, and 2nd derivative.
For each mode compare, over the transition region d in [r-3s, r+3s]:
  - value max-abs error vs the exact integral
  - 1st-deriv AD vs exact (cosine + rel err over the sweep)
  - 2nd-deriv AD vs exact  <-- the curvature test (interp C0 should give ~0; cubic/erf should match)
Usage: CUDA_VISIBLE_DEVICES=g python overlap_iso.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.overlap import create_overlap_prob, integral_f_of_d
np.set_printoptions(precision=3, suppress=True, linewidth=140)
r = 0.25; sigma = 0.1 * r                                   # ~20-inch PMT radius; temp=0.1 -> sigma=0.1 r
tv = jnp.linspace(0, 2 * jnp.pi, 4000); rv = jnp.linspace(0, r, 4000)
ref = lambda d: integral_f_of_d(d, r, sigma, tv, rv)
ref1 = jax.grad(ref); ref2 = jax.grad(jax.grad(ref))
ds = list(jnp.linspace(r - 3 * sigma, r + 3 * sigma, 25))

def cr(a, b):
    a = np.asarray(a); b = np.asarray(b)
    return (float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12)),
            float(np.linalg.norm(a - b) / (np.linalg.norm(b) + 1e-12)))

vr = np.array([float(ref(d)) for d in ds])
d1r = np.array([float(ref1(d)) for d in ds])
d2r = np.array([float(ref2(d)) for d in ds])

print(f"r={r} sigma={sigma}  sweep d in [{float(ds[0]):.3f},{float(ds[-1]):.3f}]  (25 pts)")
print(f"{'mode':8s} {'val_maxerr':>11s} | {'d1_cos':>7s} {'d1_rel':>7s} | {'d2_cos':>7s} {'d2_rel':>7s}  {'<- curvature':>14s}")
for mode in ['', 'cubic', 'erf']:
    os.environ['OVERLAP_ANALYTIC'] = mode
    o = create_overlap_prob(sigma, r, use_cache=False)
    o1 = jax.grad(o); o2 = jax.grad(jax.grad(o))
    v = np.array([float(o(d)) for d in ds])
    d1 = np.array([float(o1(d)) for d in ds])
    d2 = np.array([float(o2(d)) for d in ds])
    c1, e1 = cr(d1, d1r); c2, e2 = cr(d2, d2r)
    print(f"{mode or 'interp':8s} {np.max(np.abs(v - vr)):11.2e} | {c1:7.4f} {e1:7.3f} | {c2:7.4f} {e2:7.3f}", flush=True)
print("\nexact d2 (curvature) sample:", d2r[::6])
