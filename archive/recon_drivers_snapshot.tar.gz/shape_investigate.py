"""Investigate WHY the charge-shape term is so biased (vtx_perp -1.0 m). Hypotheses:
 (a) predicted vs observed charge CENTROID offset at truth (a systematic the shape term tries to cancel);
 (b) the scale-invariant MULTINOMIAL is one-sided -- dominated by the missed low-occupancy ring-tail
     sensors -> AMPLIFIES the ring-width bias vs a two-sided Poisson / smoothed Poisson.
Compares, along the perpendicular vertex axis, the argmin of: raw per-sensor Poisson, multinomial(scale-inv),
smoothed Poisson (tau=2). Decomposes the multinomial penalty by observed-occupancy bin.
Usage: CUDA_VISIBLE_DEVICES=g python shape_investigate.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=4, suppress=True)
NK=8
S=PS.setup(event=0,nphot=80_000,truth_source='photonsim',pred_temperature=0.1)
ts=np.array(S['theta_star']); pred=S['pred']; oc=np.array(S['oc']); SUMOBS=S['sumobs']
dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4)
sp=np.array(dg.sensor_points)
# smoothing matrix tau=2
spj=jnp.asarray(sp); a=jnp.sum(spj**2,1); Gm=spj@spj.T
d2=jnp.clip(a[:,None]+a[None,:]-2*Gm,0.,None); W=jnp.exp(-d2/(2*2.0**2)); W=W/(jnp.sum(W,0,keepdims=True)+1e-8)
ocs=np.array(W@jnp.asarray(oc))
def qpred(theta):
    return np.mean([np.array(jax.jit(pred)(H.theta_to_track(jnp.asarray(theta)),jax.random.PRNGKey(9000+k))[3]) for k in range(NK)],0)

# (a) centroid offset at truth
q0=qpred(ts)
cen=lambda w: (w[:,None]*sp).sum(0)/(w.sum()+1e-9)
co,cp=cen(oc),cen(q0)
pol,az=ts[4],ts[5]; dvec=np.array([np.sin(pol)*np.cos(az),np.sin(pol)*np.sin(az),np.cos(pol)])
perp=np.array([-dvec[1],dvec[0],0.0]); perp/=np.linalg.norm(perp)
print(f"=== (a) centroid @ truth ===")
print(f"  obs  centroid = {co}")
print(f"  pred centroid = {cp}")
print(f"  offset (pred-obs) = {cp-co}  |.|={np.linalg.norm(cp-co):.3f} m  along-perp={ (cp-co)@perp:+.3f} m  along-track={(cp-co)@dvec:+.3f} m")
print(f"  Sigma q_pred={q0.sum():.0f}  Sigma oc={oc.sum():.0f}  ratio={q0.sum()/oc.sum():.4f}")

# (b) per-term argmin along perp axis
def shift(o): t=ts.copy(); t[1:4]=ts[1:4]+o*perp; return t
offs=np.linspace(-1.2,1.2,17)
Qs=[qpred(shift(o)) for o in offs]
def L_poiss(q): return np.sum(q - oc*np.log(q+1e-8))
def L_multinom(q): p=q/(q.sum()+1e-8); return -np.sum(oc*np.log(p+1e-8))
def L_smooth(q): qs=np.array(W@jnp.asarray(q)); return np.sum(qs - ocs*np.log(qs+1e-8))
def amin(ys):
    j=int(np.argmin(ys))
    if 0<j<len(ys)-1:
        A,B,C=ys[j-1],ys[j],ys[j+1]; den=A-2*B+C
        return offs[j]+(0.5*(A-C)/den if abs(den)>1e-9 else 0)*(offs[1]-offs[0])
    return offs[j]
print(f"\n=== (b) vtx_perp argmin per charge-term ===")
print(f"  raw Poisson      argmin = {amin([L_poiss(q) for q in Qs]):+.3f} m")
print(f"  multinomial      argmin = {amin([L_multinom(q) for q in Qs]):+.3f} m")
print(f"  smoothed Poisson argmin = {amin([L_smooth(q) for q in Qs]):+.3f} m")

# (c) decompose multinomial penalty by observed occupancy at truth
print(f"\n=== (c) multinomial penalty -oc*log(phat) by obs-occupancy bin @ truth ===")
p0=q0/q0.sum(); term=-oc*np.log(p0+1e-8)
bins=[(0,0.5),(0.5,1.5),(1.5,3.5),(3.5,8.5),(8.5,1e9)]
print(f"  {'occ_bin':>10} {'n_sens':>7} {'sum_oc':>8} {'sum_penalty':>12} {'mean_phat':>10}")
for lo,hi in bins:
    m=(oc>=lo)&(oc<hi)&(oc>0)
    if m.sum()==0: continue
    print(f"  {f'{lo}-{hi}':>10} {int(m.sum()):>7} {oc[m].sum():>8.0f} {term[m].sum():>12.0f} {p0[m].mean():>10.2e}")
# how many obs sensors have predicted ~zero (missed by the narrow ring)?
miss=(oc>0)&(q0< q0[oc>0].mean()*0.05)
print(f"  obs sensors with pred<5% of mean (missed): {int(miss.sum())} of {int((oc>0).sum())}, "
      f"carrying {term[miss].sum():.0f} of {term[oc>0].sum():.0f} total penalty")
