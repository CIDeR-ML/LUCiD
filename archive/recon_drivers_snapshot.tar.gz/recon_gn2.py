"""Joint-Fisher (Gauss-Newton) optimizer against the CONSTRUCTIVE Gaussian first-arrival likelihood lT_gd.
Metric = per-sensor score outer product: J = d(per-sensor NLL)/dtheta (jacfwd, 7 jvps); F = J^T J (proper
Fisher, well-scaled, handles vertex<->direction coupling); g = J^T 1 (= total timing gradient). Geometry
(x,y,z,polar,azim,t0) via the LM-damped GN step; ENERGY via scalar total-charge match. Realistic starts,
NO grid search. Reports achieved resolution vs the per-fit Fisher CRB. TTS via env TTS_NS (per-photon).
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 SIG=2.5 EVENT=0 python recon_gn2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW          # bypass custom_vjp so jacfwd works (1st order)
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000'))
SIG = float(os.environ.get('SIG', '2.5')); THR = float(os.environ.get('THR', '4.0'))
NKG = int(os.environ.get('NKG', '3')); STEPS = int(os.environ.get('STEPS', '40'))
LAM = float(os.environ.get('LAM', '0.3')); LRg = float(os.environ.get('LRg', '0.7'))
EVENT = int(os.environ.get('EVENT', '0')); POLAR = float(os.environ.get('POLAR', '0.6')); AZIM = float(os.environ.get('AZIM', '0.8'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3,4,5,6,7').split(',')]
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1, target_polar=POLAR, target_azim=AZIM)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def nll_vec(theta, key, oc, ot, hi, sig):
    """per-sensor lT_gd NLL (Gaussian first-arrival, width sig, count-decoupled). sig ANNEALED for basin."""
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI)
    log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    nll = -lf - (Ns - 1.0) * l1mf
    return jnp.where((hi & (oc >= THR)) & (~empty), nll, 0.0)
Jfn = jax.jit(jax.jacfwd(nll_vec, argnums=0))
SIGSCHED = [float(x) for x in os.environ.get('SIGSCHED', '30,15,8,4,2.5').split(',')]
SPS = int(os.environ.get('SPS', '14'))   # GN steps per sigma stage
qsum = jax.jit(lambda th, k: jnp.sum(pred(H.theta_to_track(th), k)[3]))

STARTW = float(os.environ.get('STARTW', '1.0')); CLIP = float(os.environ.get('CLIP', '0.4'))
START = np.array([200., 0.5, 0.5, 0.5, 0.15, 0.15, 3.0]) * STARTW   # +-200MeV,+-0.5m,+-8.6deg,+-3ns
def gn_fit(oc, ot, hi, th0, seed):
    th = np.array(th0, float); ocn = np.array(oc); sumobs = ocn.sum(); Flast = np.eye(6); st = 0
    for sig in SIGSCHED:                                  # ANNEAL: wide sigma (basin) -> sharp (CRB)
        for s in range(SPS):
            Fg = np.zeros((6, 6)); gg = np.zeros(6); Ecorr = []
            for j in range(NKG):
                k = jax.random.PRNGKey(700 + 53 * seed + 5 * st + j)
                J = np.array(Jfn(jnp.asarray(th), k, oc, ot, hi, sig))[:, 1:] * SC[1:]
                Fg += J.T @ J; gg += J.sum(0)
                Ecorr.append(sumobs / (float(qsum(jnp.asarray(th), k)) + 1e-6))
            Fg /= NKG; gg /= NKG; Flast = Fg; st += 1
            dd = np.clip(np.diag(Fg), 1e-9, None)
            step = np.linalg.solve(Fg + LAM * np.diag(dd) + 1e-9 * np.eye(6) * dd.max(), gg)
            th[1:] = th[1:] - LRg * np.clip(step, -CLIP, CLIP) * SC[1:]
            th[0] = th[0] * float(np.mean(Ecorr))
    return th, Flast

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def Ep(t): return float((t[0] - ts[0]) / ts[0] * 100)
def degf(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
rows = []
print(f"# GN2 (lT_gd) TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} SIG={SIG} EVENT={EVENT} NKG={NKG} STEPS={STEPS} LAM={LAM} (REALISTIC starts)", flush=True)
for tk in TKS:
    oc, ot, hi = regen(tk)
    rng = np.random.default_rng(1000 + tk)
    th0 = ts + rng.uniform(-1, 1, 7) * START; th0[0] = 800.0
    th, F = gn_fit(oc, ot, hi, th0, tk)
    r = (Ep(th), vtx(th), degf(th), float(th[6] - ts[6])); rows.append(r)
    c = np.sqrt(np.clip(np.diag(np.linalg.inv(F + 1e-6 * np.trace(F) * np.eye(6))), 0, None))
    cv = np.sqrt(sum((c[i] * SC[1 + i]) ** 2 for i in [0, 1, 2])) * 100
    print(f"  tk={tk}: E={r[0]:+6.1f}% vtx={r[1]:5.1f}cm dir={r[2]:5.2f}deg t0={r[3]:+5.2f}ns  [Fisher-CRB vtx~{cv:.1f}cm]", flush=True)
A = np.array(rows)
print(f"RESULT GN2 lT_gd TRUTH={TRUTH} EVENT={EVENT} | E bias={A[:,0].mean():+.1f}% res={A[:,0].std():.1f}% | "
      f"vtx {A[:,1].mean():.1f}+-{A[:,1].std():.1f}cm | dir {A[:,2].mean():.2f}+-{A[:,2].std():.2f}deg | "
      f"t0 bias={A[:,3].mean():+.2f} res={A[:,3].std():.2f}ns", flush=True)
