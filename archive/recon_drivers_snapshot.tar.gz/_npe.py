import os; os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.simulation.simulator import setup_event_simulator
NKEYS=3; NEV=4; SIGMA=2.5; DELTA=1.0; K=8; MC=16; SQ=float(np.sqrt(2.))
PS=np.asarray(H.PARAM_SCALE); tt=np.array([1050.,0,0,0,0.6,0.8,0.]); track=H.theta_to_track(jnp.asarray(tt))
def log1mexp(a):
    a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
def run(NPH):
    pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); ND=H.num_detectors(pred)
    truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=K,is_data=False,use_expected_value=False,
        hit_mode='realistic',max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
    keys=[jax.random.PRNGKey(s) for s in range(NKEYS)]
    def make(oc,ot,hit,wt):
        oc=jax.lax.stop_gradient(oc);ot=jax.lax.stop_gradient(ot);hit=jax.lax.stop_gradient(hit)
        def loss(th,key):
            lw,ft,fi,tot=pred(H.theta_to_track(th),key); w=jnp.exp(jnp.clip(lw,-60,20)); tob=(ot-th[6])[fi]
            def Rof(x): return jax.ops.segment_sum(w*0.5*(1+erf((x-ft)/(SIGMA*SQ))),fi,num_segments=ND)
            Rlo=Rof(tob-DELTA/2); dR=jnp.maximum(Rof(tob+DELTA/2)-Rlo,1e-12)
            time=jnp.sum(jnp.where(hit&(dR>1e-9),Rlo-log1mexp(-dR),0.)); mu=jnp.maximum(tot,1e-8)
            return jnp.sum(mu-oc*jnp.log(mu))+wt*time
        return loss
    def am(lj,i):
        sv=np.linspace(-4*PS[i],4*PS[i],15)
        c=np.array([np.mean([float(lj(jnp.asarray(tt+s*np.eye(7)[i]),k)) for k in keys]) for s in sv])
        j=int(np.argmin(c));lo=max(0,j-2);hi=min(15,j+3);a,b,_=np.polyfit(sv[lo:hi],c[lo:hi],2)
        return (-b/(2*a) if a>0 else sv[j])
    out={}
    for tag,wt in [('charge',0.),('joint',1.)]:
        ex,ee=[],[]
        for ev in range(NEV):
            oc,ot=jax.lax.stop_gradient(truth(track,jax.random.PRNGKey(7*ev+1))); hit=oc>0; ot=jnp.where(hit,ot,0.)
            lj=jax.jit(make(oc,ot,hit,wt)); ex.append(am(lj,1)); ee.append(am(lj,0))
        out[tag]=(np.mean(ex),np.std(ex)/np.sqrt(NEV),np.mean(ee),np.std(ee)/np.sqrt(NEV))
    for tag in ['charge','joint']:
        x,xe,e,ee=out[tag]; print(f"#  NPH={NPH:7d} {tag:6s}: x {x:+.3f}+/-{xe:.3f} | energy {e:+7.1f}+/-{ee:.1f}",flush=True)
for NPH in [50000,500000]: run(NPH)
print("# READ: if joint energy bias grows with NPH but charge stays ~0 -> the TIME term's -log(mu) over lit PMTs over-pulls energy.")
