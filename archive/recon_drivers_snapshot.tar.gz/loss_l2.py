"""LOSS L2 — HESSIAN quality of the recon loss at theta_true (the minimum; curvature for CRB/Newton).

H_AD = mean over NKEYS of jax.hessian(loss)(theta_true, key). Reports:
  - eigenvalues (sorted), PD? condition number, symmetry ||H-H^T||/||H|| ;
  - per-key eigenvalue spread (heavy-tail diagnostic) ;
  - DIAGONAL H_ii (AD) vs clean noise-averaged PROFILE second derivative (ground truth) per param,
    split SCALAR(energy,t0) vs GEOMETRY(x,y,z,polar,azim) ;
  - which params dominate the smallest (degenerate) and largest eigen-directions.
Env: NPHOT NKEYS RECON_K MAXCELL TEMP HFRAC.  Usage: CUDA_VISIBLE_DEVICES=g python loss_l2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '64'))
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '8')); TEMP = float(os.environ.get('TEMP', '0.1'))
HFRAC = float(os.environ.get('HFRAC', '0.05'))                      # FD step for profile 2nd-deriv (frac of PARAM_SCALE)
PN = H.PARAM_NAMES; PS = np.asarray(H.PARAM_SCALE)
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
print(f"# L2 Hessian @theta_true  NPH={NPH} NKEYS={NKEYS} K={K} MAXCELL={MC} TEMP={TEMP} HFRAC={HFRAC}", flush=True)
pred = H.build_predictor(temperature=TEMP, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(777))
loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=1.0)
lossj = jax.jit(loss); hessj = jax.jit(jax.hessian(loss))
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
th0 = jnp.asarray(theta_true)

Hk = np.stack([np.asarray(hessj(th0, k)) for k in keys])            # (NKEYS,7,7)
H_AD = Hk.mean(0)
Hsym = 0.5 * (H_AD + H_AD.T)
asym = np.linalg.norm(H_AD - H_AD.T) / (np.linalg.norm(H_AD) + 1e-30)
ev = np.linalg.eigvalsh(Hsym)
# per-key smallest/largest eigenvalue spread
evk = np.array([np.linalg.eigvalsh(0.5 * (Hk[i] + Hk[i].T)) for i in range(NKEYS)])
print(f"# symmetry ||H-H^T||/||H|| = {asym:.3f}  (0=symmetric)", flush=True)
print(f"# eigenvalues (sym): {ev}", flush=True)
print(f"# PD? {'YES' if ev.min() > 0 else 'NO (min '+format(ev.min(),'+.3g')+')'}  | condition {ev.max()/ (abs(ev.min())+1e-30):.3e}", flush=True)
print(f"# per-key eigenvalue range: min-eig median {np.median(evk[:,0]):+.3g} (min {evk[:,0].min():+.3g}); max-eig median {np.median(evk[:,-1]):.3g}", flush=True)

# clean profile 2nd derivative (diagonal ground truth), CRN over keys
print(f"# DIAGONAL H_ii: AD vs clean-profile 2nd-deriv (HFRAC={HFRAC}):", flush=True)
print(f"#   {'param':6s} {'grp':3s} {'H_AD_ii':>12s} {'H_prof_ii':>12s} {'ratio':>8s}", flush=True)
for i, nm in enumerate(PN):
    grp = 'S' if nm in ('energy', 't0') else 'G'
    h = HFRAC * PS[i]; ep = np.eye(7)[i] * h
    L0 = np.mean([float(lossj(th0, k)) for k in keys])
    Lp = np.mean([float(lossj(jnp.asarray(theta_true + ep), k)) for k in keys])
    Lm = np.mean([float(lossj(jnp.asarray(theta_true - ep), k)) for k in keys])
    hp = (Lp - 2 * L0 + Lm) / (h ** 2)
    print(f"#   {nm:6s} {grp:3s} {H_AD[i,i]:+12.3f} {hp:+12.3f} {H_AD[i,i]/(hp+1e-30):+8.2f}", flush=True)
# eigenvector composition of the softest and stiffest directions
w, V = np.linalg.eigh(Hsym)
print(f"# softest eigvec (eig {w[0]:+.3g}) param weights: " + " ".join(f"{PN[j]}:{V[j,0]:+.2f}" for j in range(7)), flush=True)
print(f"# stiffest eigvec (eig {w[-1]:.3g}) param weights: " + " ".join(f"{PN[j]}:{V[j,-1]:+.2f}" for j in range(7)), flush=True)
print(f"# VERDICT: H trustworthy where symmetric + PD + AD/profile diagonal ~1 + low per-key spread; flag broken blocks.", flush=True)
