"""ALIGNMENT Part B (B1-B6) — PhotonSim GEANT4 emission vs SIREN surrogate emission.

Extracts, in each source's TRACK frame, the directly comparable emission quantities:
  longitudinal s = (origin-vertex).dir  | transverse r = |perp|  | cos(theta) = dir_photon.dir_track
plus PhotonSim-only emission time and wavelength (SIREN sets emission time=0 and samples wavelength
downstream, so those are LUCiD-modeled, not SIREN). Energy matched at 1050 MeV.

PhotonSim: read_photon_data_from_photonsim over NEV events; track frame from SVD of origins (as recon).
SIREN: photonsim_differentiable_get_rays at track_origin=0, dir=+z, weighted histograms by photon_weight.

Outputs summary stats + a 6-panel comparison PNG.
Env: NEV NPHOT_SIREN ENERGY.  Usage: CUDA_VISIBLE_DEVICES=g python align_b.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.sources.siren_rays import photonsim_differentiable_get_rays
from lucid.utils import unpack_photonsim_params
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NEV = int(os.environ.get('NEV', '5')); NPH_S = int(os.environ.get('NPHOT_SIREN', '200000'))
ENERGY = float(os.environ.get('ENERGY', '1050'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'

# ---------- SIREN emission ----------
pp = unpack_photonsim_params('muon', 'water')
spred = SIRENPredictor(pp['siren_model_path']); grid = create_photonsim_siren_grid(spred); mp = spred.params
tdir = jnp.array([0.0, 0.0, 1.0]); torig = jnp.array([0.0, 0.0, 0.0])
sdirs, sorig, sw = photonsim_differentiable_get_rays(torig, tdir, ENERGY, NPH_S, grid, mp,
    jax.random.PRNGKey(0), *pp['num_seeds'])
sdirs = np.asarray(sdirs); sorig = np.asarray(sorig); sw = np.asarray(sw)
d = np.array([0.0, 0, 1.0])
s_s = (sorig - np.array([0., 0, 0])) @ d
perp = sorig - np.outer(s_s, d); r_s = np.linalg.norm(perp, axis=1)
cos_s = sdirs @ d
print(f"# SIREN: Nphot={len(sw)} sum_w={sw.sum():.1f}  s[m] mean {np.average(s_s,weights=sw):.3f} "
      f"P95 {np.percentile(s_s,95):.3f}  r[m] mean {np.average(r_s,weights=sw):.4f}  "
      f"cosθ mean {np.average(cos_s,weights=sw):.4f} (θc=acos(1/1.34)={np.degrees(np.arccos(1/1.34)):.1f}°)", flush=True)

# ---------- PhotonSim emission ----------
S_p, R_p, COS_p, T_p, WL_p = [], [], [], [], []
for ev in range(NEV):
    raw = read_photon_data_from_photonsim(ROOT, ev)
    P = np.asarray(raw['photon_origins']) / 100.0; D = np.asarray(raw['photon_directions'])
    _, _, vt = np.linalg.svd(P - P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx = P.mean(0) + ((P - P.mean(0)) @ d0).min() * d0
    s = (P - vtx) @ d0; rp = np.linalg.norm((P - vtx) - np.outer(s, d0), axis=1); cs = D @ d0
    S_p.append(s); R_p.append(rp); COS_p.append(cs)
    T_p.append(np.asarray(raw['photon_times']))
    if 'wavelengths' in raw: WL_p.append(np.asarray(raw['wavelengths']))
S_p = np.concatenate(S_p); R_p = np.concatenate(R_p); COS_p = np.concatenate(COS_p); T_p = np.concatenate(T_p)
WL_p = np.concatenate(WL_p) if WL_p else None
print(f"# PhotonSim({NEV} ev): Nphot={len(S_p)} (~{len(S_p)//NEV}/ev)  s[m] mean {S_p.mean():.3f} P95 {np.percentile(S_p,95):.3f}  "
      f"r[m] mean {R_p.mean():.4f}  cosθ mean {COS_p.mean():.4f}  t[ns] mean {T_p.mean():.2f} spread {T_p.std():.2f}", flush=True)
print(f"# YIELD: PhotonSim ~{len(S_p)//NEV}/ev vs SIREN sum_w·norm scaling (compare shapes; abs yield set by tot_n_photons norm)", flush=True)

# ---------- figure ----------
fig, ax = plt.subplots(2, 3, figsize=(16, 9))
def H(a, x, w, bins, rng, lbl, c): a.hist(x, bins=bins, range=rng, weights=w, density=True, histtype='step', color=c, lw=2, label=lbl)
smax = max(np.percentile(S_p, 99), np.percentile(s_s, 99))
H(ax[0,0], S_p, None, 80, (S_p.min(), smax), 'PhotonSim', 'C0'); H(ax[0,0], s_s, sw, 80, (S_p.min(), smax), 'SIREN', 'C1')
ax[0,0].set_title('longitudinal s = (origin-vtx)·d  [m]'); ax[0,0].legend(); ax[0,0].set_xlabel('s [m]')
rmax = max(np.percentile(R_p, 99), np.percentile(r_s, 99))
H(ax[0,1], R_p, None, 80, (0, rmax), 'PhotonSim', 'C0'); H(ax[0,1], r_s, sw, 80, (0, rmax), 'SIREN', 'C1')
ax[0,1].set_title('transverse r  [m]'); ax[0,1].legend(); ax[0,1].set_xlabel('r [m]')
H(ax[0,2], COS_p, None, 80, (-1, 1), 'PhotonSim', 'C0'); H(ax[0,2], cos_s, sw, 80, (-1, 1), 'SIREN', 'C1')
ax[0,2].axvline(1/1.34, color='k', ls='--', lw=1, label='cosθc'); ax[0,2].set_title('cosθ to track (Cherenkov cone)'); ax[0,2].legend(); ax[0,2].set_xlabel('cosθ')
ax[1,0].hist(T_p, bins=100, range=(np.percentile(T_p,0.5), np.percentile(T_p,99.5)), density=True, color='C0', histtype='step', lw=2)
ax[1,0].axvline(0, color='C1', ls='--', label='SIREN emit t=0'); ax[1,0].set_title('PhotonSim emission time [ns]  (SIREN=0)'); ax[1,0].legend(); ax[1,0].set_xlabel('t [ns]')
if WL_p is not None:
    ax[1,1].hist(WL_p, bins=100, range=(np.percentile(WL_p,0.5), np.percentile(WL_p,99.5)), density=True, color='C0', histtype='step', lw=2)
    ax[1,1].set_title('PhotonSim wavelength [nm]  (SIREN: sampled downstream)'); ax[1,1].set_xlabel('λ [nm]')
else:
    ax[1,1].text(0.5, 0.5, 'no wavelengths in ROOT', ha='center')
hb = ax[1,2].hist2d(S_p, COS_p, bins=60, range=[[S_p.min(), smax], [0, 1]], density=True, cmap='Blues')
ax[1,2].set_title('PhotonSim joint (s, cosθ)'); ax[1,2].set_xlabel('s [m]'); ax[1,2].set_ylabel('cosθ')
plt.tight_layout(); plt.savefig('_alignB_emission.png', dpi=90); print("# saved _alignB_emission.png", flush=True)
