"""ALIGNMENT A0+A3 — full per-PMT forward CHARGE: current DiCE vs refactor-v2 STE vs sample truth.

Same SIREN source + same key + same baked optics (MIE FORCED OFF, mie_scatter_length=1e9) through
THREE forward engines, compared per-PMT at K in {1,8}:
  q_dice  : photon_iteration_update_factors  (CURRENT, DiCE hard-sample + continuous weights)
  q_ste   : photon_iteration_update_factors  (REFACTOR-V2 STE mean-field, monkeypatched in)
  q_samp  : photon_iteration_sample          (TRUE/data engine, averaged over keys)

Expectations (derived):
  K=1  -> q_dice == q_ste  byte-identical (deposit uses no engine-specific RNG)  == A0 prop/emission identity
  K>=2 -> q_dice ~ q_samp  (both unbiased MC: expected-weight vs hard) ; q_ste DIVERGES (mean-field
          survival double-counts both branches on every photon).

Env: NPHOT NKG NKT MAXCELL DEV.  Usage: CUDA_VISIBLE_DEVICES=g python align_a3.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.photon_step as PS
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NPH = int(os.environ.get('NPHOT', '100000')); NKG = int(os.environ.get('NKG', '4'))
NKT = int(os.environ.get('NKT', '8')); MAXCELL = int(os.environ.get('MAXCELL', '8'))
KS = [1, 8]
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))

# ---- refactor-v2 STE update_factors, verbatim body, adapted to 14-arg / 7-tuple (ignores Mie) ----
from lucid.simulation.optics import (normalize, compute_reflection_direction,
    sample_cosine_hemisphere, sample_scatter_distance, compute_scatter_direction)
def OLD_update_factors(position, direction, time, surface_distance,
        normal, scatter_length, mie_scatter_length, g, wall_reflection_rate, sensor_reflection_rate,
        absorption_length, hit_sensor, rng_key, speed_of_light):
    k1, k2, k3 = jax.random.split(rng_key, 3)
    reflection_rate = jnp.where(hit_sensor, sensor_reflection_rate, wall_reflection_rate)
    scatter_distance = sample_scatter_distance(surface_distance, scatter_length, k2)
    ratio = surface_distance / scatter_length
    reach_surface_prob = jnp.exp(-ratio); scatter_prob = -jnp.expm1(-ratio)
    reflect_prob = reach_surface_prob * reflection_rate
    detect_prob = reach_surface_prob * (1 - reflection_rate)
    reflection_attenuation = jnp.exp(-surface_distance / absorption_length)
    scatter_attenuation = jnp.exp(-scatter_distance / absorption_length)
    probs = jnp.array([reach_surface_prob, scatter_prob])
    probs_normalized = probs / (jnp.sum(probs) + 1e-10)
    u = jax.random.uniform(k1)
    hard_choice = (u < probs_normalized[0]).astype(jnp.float32)
    hard_weights = jnp.array([hard_choice, 1.0 - hard_choice])
    action_weights = hard_weights - jax.lax.stop_gradient(probs_normalized) + probs_normalized
    surface_weight = action_weights[0]; scatter_weight = action_weights[1]
    epsilon = 1e-4
    normal_refl = jax.lax.stop_gradient(normal); inward_normal = -normal_refl
    surface_pos = position + surface_distance * normalize(direction) + epsilon * normalize(inward_normal)
    scatter_pos = position + scatter_distance * normalize(direction)
    specular_dir = compute_reflection_direction(direction, normal_refl)
    diffuse_dir = sample_cosine_hemisphere(inward_normal, k3)
    reflection_dir = jnp.where(hit_sensor, specular_dir, diffuse_dir)
    scatter_dir = compute_scatter_direction(direction, k3)
    new_pos = surface_weight * surface_pos + scatter_weight * scatter_pos
    new_dir = normalize(surface_weight * reflection_dir + scatter_weight * scatter_dir)
    continuing_factor = reflect_prob * reflection_attenuation + scatter_prob * scatter_attenuation
    distance_traveled = surface_weight * surface_distance + scatter_weight * scatter_distance
    new_time = time + distance_traveled / speed_of_light
    return new_pos, new_dir, new_time, detect_prob, reflection_attenuation, continuing_factor, jnp.zeros_like(new_time)

# ---- baked optics with MIE OFF (no full compile needed to build the DetectorParams) ----
NUM_SENSORS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NUM_SENSORS)
dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A3 NPH={NPH} NKG={NKG} NKT={NKT} MAXCELL={MAXCELL} NUM_SENSORS={NUM_SENSORS}  MIE OFF (L_M=1e9)", flush=True)
print(f"# optics: L_scat={float(dp.scatter_length):.1f} L_abs={float(dp.absorption_length):.1f} "
      f"wall_refl={float(dp.wall_reflection_rate):.3f} sensor_refl={float(dp.sensor_reflection_rate):.3f} qe={float(dp.qe):.3f}", flush=True)

def build_exp(K):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False,
        use_expected_value=True, hit_mode='per_photon', max_sensors_per_cell=MAXCELL,
        physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
        pos_grad_threshold=K, n_grad_iters=K)
def build_samp(K):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
        use_expected_value=False, hit_mode='realistic', max_sensors_per_cell=MAXCELL,
        physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
        apply_smearing=False)

def avg_charge(fn, nkeys, idx):
    return np.mean([np.asarray(jax.lax.stop_gradient(fn(track, jax.random.PRNGKey(s)))[idx]) for s in range(nkeys)], 0)

def cmp(a, b, name):
    tot_a, tot_b = a.sum(), b.sum()
    d = np.abs(a - b); rel = d.sum() / (b.sum() + 1e-9)
    lit = (a > 1e-6) | (b > 1e-6)
    cc = np.corrcoef(a[lit], b[lit])[0, 1] if lit.sum() > 2 else float('nan')
    print(f"#   {name:18s} tot {tot_a:10.2f} vs {tot_b:10.2f} (Δtot {100*(tot_a-tot_b)/(tot_b+1e-9):+5.1f}%)  "
          f"sum|Δ|/tot {rel:6.2%}  max|Δ| {d.max():.4f}  corr {cc:.5f}  litPMT {int(lit.sum())}", flush=True)

# DiCE predictors first (trace BEFORE patching the global)
preds_dice = {}
for K in KS:
    preds_dice[K] = build_exp(K); _ = preds_dice[K](track, jax.random.PRNGKey(0))[3].block_until_ready()
    print(f"# built+traced DiCE K={K}", flush=True)
# patch in the refactor-v2 STE engine, then build the STE predictors
PS.photon_iteration_update_factors = OLD_update_factors
preds_ste = {}
for K in KS:
    preds_ste[K] = build_exp(K); _ = preds_ste[K](track, jax.random.PRNGKey(0))[3].block_until_ready()
    print(f"# built+traced STE  K={K}", flush=True)
# sample/truth engine (does not use update_factors; patch irrelevant)
sims_samp = {K: build_samp(K) for K in KS}

for K in KS:
    qd = avg_charge(preds_dice[K], NKG, 3)
    qs = avg_charge(preds_ste[K], NKG, 3)
    qt = avg_charge(sims_samp[K], NKT, 0)
    print(f"\n# ===== K={K} =====", flush=True)
    cmp(qd, qs, 'DiCE vs STE')        # K=1: identical (==A0); K=8: engine divergence
    cmp(qd, qt, 'DiCE vs SAMPLE')     # current predictor vs truth — should agree all K
    cmp(qs, qt, 'STE  vs SAMPLE')     # refactor-v2 predictor vs truth — diverges at K=8
print(f"\n# A0 check = 'DiCE vs STE' at K=1 (sum|Δ|/tot should be ~0 -> propagation+emission+deposit identical).", flush=True)
print(f"# A3 verdict: which engine matches the SAMPLE truth at K=8, and how big is the DiCE<->STE forward-charge change.", flush=True)
