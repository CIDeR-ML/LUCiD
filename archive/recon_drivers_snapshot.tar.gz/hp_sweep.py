"""Hyperparameter sweep for the temp=0.1 staged GN-LM recon: time TAU x time-sensor THReshold x WT.
Builds the setup ONCE, then loops HP combos (only the full-loss grad recompiles per combo; the charge
grad is shared). Staged: charge->energy, then full(WT,TAU,THR) freeze energy. Reports vertex/dir/E/t0.
Usage: CUDA_VISIBLE_DEVICES=g [TRUTH_SOURCE=siren|photonsim] [WT=0.05] [SEEDS=1,2,3] python hp_sweep.py TAU0[,TAU1]
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

SRC   = os.environ.get('TRUTH_SOURCE', 'siren')
WT    = float(os.environ.get('WT', '0.05'))
SEEDS = [int(x) for x in os.environ.get('SEEDS', '1,2,3').split(',')]
THRS  = [float(x) for x in os.environ.get('THRS', '0,2,4').split(',')]
TAUS  = [float(x) for x in sys.argv[1].split(',')]
SC = np.array(H.PARAM_SCALE)

_PT = os.environ.get('PRED_TEMP', '')
S = PS.setup(event=0, nphot=80_000, truth_source=SRC,
             pred_temperature=float(_PT) if _PT else 0.1)
theta_star = np.array(S['theta_star'])
# forward charge fidelity at truth (drives the energy normalization offset)
_, _, _, _q0 = jax.jit(S['pred'])(H.theta_to_track(jnp.array(theta_star)), jax.random.PRNGKey(0))
print(f"PRED_TEMP={_PT or '0.1'}  pred_Sq@truth/obs ratio = {float(jnp.sum(_q0))/S['sumobs']:.4f}", flush=True)
_lc = PS.make_loss(S, WT=0.0, TAU=4.0, THR=0.0)         # built OUTSIDE jit (tmask stays concrete)
gchrg = jax.jit(jax.grad(lambda th, k: _lc(th, k)[2]))
print(f"=== HP sweep  TRUTH={SRC}  WT={WT}  nhit={S['nhit']} sumobs={S['sumobs']:.0f} ===", flush=True)

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=45, tag=0):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T = []
    for s in range(steps):
        keys = jax.random.split(jax.random.PRNGKey(101 + 7919*tag + s), 6)
        G = np.stack([np.array(gfn(theta, k)) * SC for k in keys])
        g = G.mean(0); F = (G.T @ G) / 6
        dd = np.clip(np.diag(F), 1e-12, None)
        ev, V = np.linalg.eigh(F + LM*np.diag(dd) + 1e-9*np.eye(7)*(dd.max()+1e-12))
        ev = np.clip(ev, 2e-2*ev.max(), None)
        step = np.clip(V @ np.diag(1/ev) @ V.T @ g, -0.35, 0.35) * SC
        theta = theta - LR * jnp.array(step * (1 - fr))
        if s >= steps - tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))

def dirv(p): return np.array([np.sin(p[4])*np.cos(p[5]), np.sin(p[4])*np.sin(p[5]), np.cos(p[4])])

for TAU in TAUS:
    for THR in THRS:
        mk = PS.make_loss(S, WT=WT, TAU=TAU, THR=THR)    # built OUTSIDE jit
        ntm = PS.n_time_sensors(S, THR)
        gfull = jax.jit(jax.grad(lambda th, k: mk(th, k)[2]))
        Vs=[]; Ds=[]; Es=[]; Ts=[]
        for seed in SEEDS:
            rng = np.random.default_rng(seed)
            th0 = jnp.array(theta_star + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
            t1 = gnlm(th0, gchrg, 90, tag=1)
            t2 = np.array(gnlm(t1, gfull, 120, freeze=[0], tag=2))
            err = t2 - theta_star
            Vs.append(np.linalg.norm(err[1:4])*100)
            Ds.append(np.degrees(np.arccos(np.clip(dirv(t2)@dirv(theta_star),-1,1))))
            Es.append(err[0]/theta_star[0]*100); Ts.append(err[6])
        print(f"TAU={TAU:4.2f} THR={THR:4.1f} (ntime={ntm:4d}): "
              f"vertex {np.mean(Vs):5.1f}+-{np.std(Vs):4.1f}cm  dir {np.mean(Ds):.2f}deg  "
              f"E {np.mean(Es):+.1f}%  t0 {np.mean(Ts):+.2f}ns   seeds_vtx={np.array(Vs).round(1)}", flush=True)
