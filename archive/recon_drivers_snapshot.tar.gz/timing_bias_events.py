"""TIMING-TERM numerical check over MANY events (mirror of charge_bias_events.py for the charge term).
The CRB says timing wants THR=0 (all sensors) but is blind to BIAS; dim sensors have noisy first-arrivals,
so under PhotonSim mismatch the robust THR may be > 0. Measures, per (TAU, THR), the timing-term argmin
BIAS + SCATTER over N events along the axes timing constrains: TRANSVERSE vertex, DIRECTION, t0
(longitudinal held at truth -> the lon<->t0 degeneracy is broken, t0 well-posed).

Predicted (lw,ft,fi) grids are event-independent -> cached ONCE; only observed (oc,ot) regenerated per event.
pred + data_sim built ONCE. Env: NPHOT NKG NKT NEV.  Usage: CUDA_VISIBLE_DEVICES=g python timing_bias_events.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
np.set_printoptions(precision=3, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKT = int(os.environ.get('NKT', '4')); NEV = int(os.environ.get('NEV', '20'))
NW = float(os.environ.get('NW', '1.34')); K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '16'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
C = 0.299792; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2*np.pi)
TGT_VTX = np.array([0.0, 0.0, 0.0]); TGT_POL = 0.6; TGT_AZ = 0.8
ts = np.array([1050.0, 0.0, 0.0, 0.0, TGT_POL, TGT_AZ, 0.0])

def _rod(v, ax, an):
    ax = ax/(np.linalg.norm(ax)+1e-12); return v*np.cos(an)+np.cross(ax, v)*np.sin(an)+ax*(ax@v)*(1-np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins'])/100.0; _, _, vt = np.linalg.svd(P-P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0@dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax/(np.linalg.norm(ax)+1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(TGT_VTX-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHOT)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(pred); det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(pol, az): return np.array([np.sin(pol)*np.cos(az), np.sin(pol)*np.sin(az), np.cos(pol)])
d_true = dvec(ts[4], ts[5]); e_perp = np.cross(d_true, np.array([0, 0, 1.0])); e_perp /= np.linalg.norm(e_perp)
dummy = H.theta_to_track(jnp.array(ts))
predf = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key))

def timing_decoupled(lw, ft, fi, tobs_sensor, hi, oc, sig, thr):
    tobs = tobs_sensor[fi]; x = (tobs-ft)/sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw-lwt[fi]
    log_dens = -0.5*x**2-jnp.log(sig*SQ2PI); log1mF = jnp.log(jnp.clip(0.5*(1.0+jax.lax.erf(-x/SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn+log_dens, fi, ND); l1mf = segment_logsumexp(lwn+log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF+1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.sum(jnp.where((hi & (oc >= thr)) & (~empty), -lf-(Ns-1.0)*l1mf, 0.0))

# predicted-times grids (event-independent), cached once: TRANS (vertex along e_perp), DIR (polar shift)
lamT = np.unique(np.concatenate([np.arange(-1.0, 1.001, 0.04), np.arange(-0.08, 0.0801, 0.01)]))
lamD = np.linspace(-0.12, 0.12, 49)   # polar-angle shift (rad)
def predict(theta): lw, ft, fi, _ = predf(jnp.array(theta), jax.random.PRNGKey(123)); return (np.array(lw), np.array(ft), np.array(fi))
GR = {'TRANS': [predict(ts + np.array([0, e_perp[0]*l, e_perp[1]*l, e_perp[2]*l, 0, 0, 0])) for l in lamT],
      'DIR':   [predict(ts + np.array([0, 0, 0, 0, l, 0, 0])) for l in lamD]}
P0 = predict(ts)                                          # at truth, for the t0 axis (pred is t0-independent)
lamt0 = np.linspace(-6, 6, 61)
print(f"# TIMING-BIAS-EVENTS NEV={NEV} NPHOT={NPHOT} NKT={NKT} ND={ND}", flush=True)

def argmin_native(grid, lam, oc, ot, hi, sig, thr, t0shift):
    vals = [float(timing_decoupled(jnp.array(g[0]), jnp.array(g[1]), jnp.array(g[2]), jnp.array(ot)-t0shift, hi, oc, sig, thr)) for g in grid]
    j = int(np.argmin(vals)); lo = max(0, j-2); hi2 = min(len(lam), j+3); a, b, _ = np.polyfit(lam[lo:hi2], vals[lo:hi2], 2)
    return (-b/(2*a) if a > 0 else lam[j])

CFG = [(1.5, 0.0), (1.5, 4.0), (1.5, 10.0), (2.5, 0.0), (2.5, 4.0), (2.5, 10.0)]
res = {c: {'TRANS': [], 'DIR': [], 'T0': []} for c in CFG}
for ev in range(NEV):
    pd = photon_data_for(ev)
    oc, ot = jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev), pd)); hi = oc > 0
    oc = np.array(oc); ot = np.array(ot); hi = np.array(hi)
    ocj = jnp.array(oc); otj = jnp.array(ot); hij = jnp.array(hi)
    for (sig, thr) in CFG:
        res[(sig, thr)]['TRANS'].append(argmin_native(GR['TRANS'], lamT, ocj, ot, hij, sig, thr, 0.0)*100)
        res[(sig, thr)]['DIR'].append(np.degrees(argmin_native(GR['DIR'], lamD, ocj, ot, hij, sig, thr, 0.0)))
        # t0 axis: pred fixed at truth, vary observed shift
        vals = [float(timing_decoupled(jnp.array(P0[0]), jnp.array(P0[1]), jnp.array(P0[2]), otj-t0, hij, ocj, sig, thr)) for t0 in lamt0]
        jj = int(np.argmin(vals)); lo = max(0, jj-2); h2 = min(len(lamt0), jj+3); a, b, _ = np.polyfit(lamt0[lo:h2], vals[lo:h2], 2)
        res[(sig, thr)]['T0'].append(-b/(2*a) if a > 0 else lamt0[jj])
    print(f"#   ev{ev:2d} done", flush=True)

for axis, unit in [('TRANS', 'cm'), ('DIR', 'deg'), ('T0', 'ns')]:
    print(f"\n# TIMING term, {axis} axis over {NEV} events: bias  scatter  RMS  [{unit}]   (TAU=sig, THR=charge-thresh)", flush=True)
    print(f"#   {'sig':>4s} {'THR':>5s} {'bias':>8s} {'scatter':>8s} {'RMS':>8s}", flush=True)
    for (sig, thr) in CFG:
        a = np.array(res[(sig, thr)][axis]); print(f"#   {sig:4.1f} {thr:5.1f} {a.mean():+8.2f} {a.std():8.2f} {np.sqrt(a.mean()**2+a.std()**2):8.2f}", flush=True)
print(f"\n# CRB said THR=0 best (most info); if a THR>0 row has lower RMS here, that is the BIAS-ROBUST optimum the CRB can't see.", flush=True)
