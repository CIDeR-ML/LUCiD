"""Proper GAUSS-NEWTON / Fisher-scoring reconstruction (no grid search). Metric = observed Fisher built
from the model-output Jacobian J=d(q, t_pred)/dtheta (7 forward-mode jvps), NOT the gradient-noise cov.
  charge: Poisson Fisher  Fq = Jq^T diag(1/q) Jq,  grad gq = Jq^T (1 - oc/q)
  time:   Gaussian Fisher  Ft = Jt^T diag(w_i/sig^2) Jt on the per-sensor MEAN arrival time (model-indep)
  energy: scalar total-charge match  E <- E * sumobs/sumq  (shape-robust; the +15.7% per-sensor bias is a
          real likelihood-min bias, so energy must be the 0th moment) -> decoupled, no separate optimizer.
Geometry step (vertex,dir,t0) = (F + lam diag F)^-1 g, properly scaled so it converges from REALISTIC
starts via gradient info alone. diag(F^-1) = CRB. Reports per-key MLE from realistic +-8.6deg / +-0.5m starts.
Env: TRUTH NPHOT TKS NKG STEPS WT(time) SIGT LAM LRg  + RECON_K MAXCELL OVERLAP_ANALYTIC SIREN_IMPORTANCE
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim python recon_gn.py
"""
import os, jax, jax.numpy as jnp, numpy as np
# bypass the reverse-mode-only custom_vjp NaN sanitizer so jacfwd (forward-mode Jacobian) works (1st order)
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '100000'))
NKG = int(os.environ.get('NKG', '4')); STEPS = int(os.environ.get('STEPS', '40'))
WT = float(os.environ.get('WT', '1.0')); SIGT = float(os.environ.get('SIGT', '2.0'))
LAM = float(os.environ.get('LAM', '0.1')); LRg = float(os.environ.get('LRg', '0.7'))
CHGEOM = float(os.environ.get('CHGEOM', '0'))   # weight of (biased) charge-shape in the geometry step; 0=timing-only
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3,4,5,6,7').split(',')]
SC = np.array(H.PARAM_SCALE)
POLAR = float(os.environ.get('POLAR', '0.6')); AZIM = float(os.environ.get('AZIM', '0.8'))
EVENT = int(os.environ.get('EVENT', '0'))
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1, target_polar=POLAR, target_azim=AZIM)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

TAUSM = float(os.environ.get('TAUSM', '3.0'))   # soft-min temperature for the predicted FIRST-arrival
def model(theta, key):
    """per-sensor predicted (charge q, SOFT-MIN first-arrival time t_pred, weight-sum sw). Soft-min (not
    mean) to match the observed FIRST-arrival (segment_min); a mean-time model would bias the vertex."""
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    w = jnp.exp(jnp.clip(lw, -50.0, 10.0))
    sw = jax.ops.segment_sum(w, fi, ND)
    # STABLE weighted soft-min: subtract the per-sensor min time before exp (else exp(-100ns/3) underflows
    # -> 0/0 garbage). tmin via segment_min on valid photons; gathered back per photon.
    big = jnp.where(w > 1e-12, ft, jnp.inf)
    tmin = jax.ops.segment_min(big, fi, ND)
    tmin = jnp.where(jnp.isfinite(tmin), tmin, 0.0)
    a = w * jnp.exp(-jnp.clip((ft - tmin[fi]) / TAUSM, 0.0, 60.0))   # in [0,1], earliest photons ~1
    sa = jax.ops.segment_sum(a, fi, ND); sat = jax.ops.segment_sum(a * ft, fi, ND)
    tpred = sat / (sa + 1e-12)                                    # soft first-arrival (stable)
    return q, tpred, sw
# Jacobian of [q, tpred] wrt theta (2*ND, 7) via forward mode (7 jvps)
def stacked(theta, key):
    q, tpred, sw = model(theta, key)
    return jnp.concatenate([q, tpred]), sw
Jfn = jax.jit(jax.jacfwd(lambda th, k: stacked(th, k)[0]))
valfn = jax.jit(lambda th, k: stacked(th, k))

def gn_fit(oc, ot, hi, th0, seed):
    th = np.array(th0, dtype=float)
    ocn = np.array(oc); otn = np.array(ot); hin = np.array(hi).astype(float); sumobs = ocn.sum()
    for s in range(STEPS):
        ks = [jax.random.PRNGKey(900 + 31 * seed + s * 5 + j) for j in range(NKG)]
        Fg = np.zeros((6, 6)); gg = np.zeros(6); Ecorr = []
        for k in ks:
            J = np.array(Jfn(jnp.asarray(th), k))                 # (2ND,7)
            (cat, sw) = valfn(jnp.asarray(th), k); cat = np.array(cat); sw = np.array(sw)
            q = cat[:ND]; tpred = cat[ND:]
            Jq = J[:ND]; Jt = J[ND:]
            Jq = Jq[:, 1:] * SC[1:]; Jt = Jt[:, 1:] * SC[1:]      # geometry cols (1..6), scaled
            qs = np.clip(q, 1e-6, None)
            # charge Poisson for GEOMETRY: gated OFF by default (CHGEOM=0) -- the charge SHAPE is
            # model-mismatch biased (lS); geometry comes from TIMING. Energy uses the total-charge scalar.
            if CHGEOM > 0:
                wq = 1.0 / qs
                gg += CHGEOM * (Jq.T @ (1.0 - ocn / qs)); Fg += CHGEOM * (Jq.T @ (wq[:, None] * Jq))
            # time Gaussian on hit sensors (weighted by charge sw)
            res_t = hin * (tpred - (otn - th[6]))
            wt = hin * sw / (SIGT ** 2)
            gg += WT * (Jt.T @ (res_t / (SIGT ** 2))); Fg += WT * (Jt.T @ (wt[:, None] * Jt))
            Ecorr.append(sumobs / (q.sum() + 1e-6))
        Fg /= NKG; gg /= NKG
        dd = np.clip(np.diag(Fg), 1e-9, None)
        step = np.linalg.solve(Fg + LAM * np.diag(dd) + 1e-9 * np.eye(6) * dd.max(), gg)
        step = np.clip(step, -0.4, 0.4) * SC[1:]
        th[1:] = th[1:] - LRg * step
        th[0] = th[0] * float(np.mean(Ecorr))                     # energy scalar match
    return th, Fg

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def Ep(t): return float((t[0] - ts[0]) / ts[0] * 100)
def deg(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
def t0e(t): return float(t[6] - ts[6])

START = np.array([200., 0.5, 0.5, 0.5, 0.15, 0.15, 3.0])  # realistic: +-200MeV,+-0.5m,+-8.6deg,+-3ns
rows = []
print(f"# GN TRUTH={TRUTH} NPHOT={NPHOT} NKG={NKG} STEPS={STEPS} WT={WT} SIGT={SIGT} LAM={LAM} LRg={LRg} "
      f"start={list(START)} (REALISTIC, NO grid search) K={PS.K}", flush=True)
for tk in TKS:
    oc, ot, hi = regen(tk)
    rng = np.random.default_rng(1000 + tk)
    th0 = ts + rng.uniform(-1, 1, 7) * START
    th0[0] = 800.0                                          # neutral energy start (lE-equiv scalar fixes it)
    th, F = gn_fit(oc, ot, hi, th0, tk)
    r = (Ep(th), vtx(th), deg(th), t0e(th)); rows.append(r)
    crb = np.sqrt(np.clip(np.diag(np.linalg.inv(F + 1e-6 * np.eye(6) * np.trace(F))), 0, None))  # SCALE units
    crb_vtx = np.sqrt(sum((crb[i] * SC[1 + i]) ** 2 for i in [0, 1, 2])) * 100
    crb_dir = np.sqrt(sum((crb[i] * SC[1 + i]) ** 2 for i in [3, 4])) * 180 / np.pi
    print(f"  tk={tk}: E={r[0]:+6.1f}% vtx={r[1]:5.1f}cm dir={r[2]:5.2f}deg t0={r[3]:+5.2f}ns  "
          f"[CRB vtx~{crb_vtx:.1f}cm dir~{crb_dir:.2f}deg]", flush=True)
A = np.array(rows)
print(f"RESULT GN TRUTH={TRUTH} | E bias={A[:,0].mean():+.1f}% res={A[:,0].std():.1f}% | "
      f"vtx {A[:,1].mean():.1f}+-{A[:,1].std():.1f}cm | dir {A[:,2].mean():.2f}+-{A[:,2].std():.2f}deg | "
      f"t0 bias={A[:,3].mean():+.2f} res={A[:,3].std():.2f}ns", flush=True)
