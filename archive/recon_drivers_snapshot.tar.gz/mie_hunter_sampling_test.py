"""Rigorous comparison of SIREN emission-sampling methods.

Two distinct observables / ground truths:

  RENORMALIZED   O_norm(E) = sum_grid p(E) g / sum_grid p(E)
                 (what sample_methods.py calls O_exact; methods that divide by sum w target this)

  DENSITY-WEIGHTED (occupancy-preserving, == real siren_rays forward)
                 O_dw(E)   = sum_grid p(E)^2 g / sum_grid p(E)
                 The real photonsim_differentiable_get_rays returns UN-renormalized weights:
                 Nphot photons drawn ~ p, each carrying weight ~ p  ->  per-photon E[w g] over
                 the sampling measure p/sum p equals sum p^2 g / sum p.  Total charge magnitude
                 = Nphot * (sum p^2 / sum p).  This is the forward that MUST be preserved.

Each method estimates one of these with Nphot draws; its key-averaged AD gradient is compared
to the AD gradient of the corresponding exact observable.

We report, per method, against the GROUND TRUTH IT TARGETS:
  forward mean & relative forward error, dO/dE mean, grad/truth ratio, grad std (over NK keys),
  compile s, run ms.  Lower grad std + ratio==1 + forward preserved == better.
"""
import os, time, jax, jax.numpy as jnp, numpy as np
from functools import partial
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
from lucid.sources.siren_rays import normalize_inputs_jit, denormalize_log_predictions
from lucid.siren.core import SIREN
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=4, suppress=True)

pp = unpack_photonsim_params('muon', 'water')
predictor = SIRENPredictor(pp['siren_model_path'])
td = create_photonsim_siren_grid(predictor)
mparams = predictor.params
(n_bins, e_min, e_max, a_min, a_max, d_min, d_max, a_bins, d_bins,
 angle_dist_grid, angle_mesh, distance_mesh, log_min, log_max) = td
ADG = jnp.asarray(angle_dist_grid)          # (n_grid, 2): (angle, dist[mm]); angle SLOW, dist FAST
n_grid = ADG.shape[0]
ang_grid = ADG[:, 0]; dist_grid = ADG[:, 1]
NA = int(n_bins); ND = int(n_bins)          # 250 x 250 regular mesh
a_axis = jnp.asarray(a_bins)                # (NA,)
d_axis = jnp.asarray(d_bins)                # (ND,)
_model = SIREN(hidden_features=256, hidden_layers=3, out_features=1)

@jax.jit
def density_grid(E):
    grid = jnp.stack([jnp.full((n_grid,), E), ang_grid, dist_grid], axis=1)
    ng = normalize_inputs_jit(grid, e_min, e_max, a_min, a_max, d_min, d_max)
    w, _ = _model.apply(mparams, ng)
    dens = denormalize_log_predictions(jnp.squeeze(w), log_max, log_min)
    return jnp.clip(dens, 1e-12, None)

L_ABS_MM = 4000.0
g_grid = jnp.exp(-dist_grid / L_ABS_MM)     # observable proxy: longitudinal-geometry sensitive
g_mat  = g_grid.reshape(NA, ND)             # [i_angle, j_dist]

E0 = jnp.array(1050.0); NPHOT = 20000
sg = jax.lax.stop_gradient
E_REF = jnp.array(1050.0)

# ----------------------------------------------------------------------------- ground truths
def O_norm(E):
    d = density_grid(E)
    return jnp.sum(d * g_grid) / jnp.sum(d)
def O_dw(E):
    d = density_grid(E)
    return jnp.sum(d * d * g_grid) / jnp.sum(d)

truthO_norm = float(O_norm(E0)); truthG_norm = float(jax.grad(O_norm)(E0))
truthO_dw   = float(O_dw(E0));   truthG_dw   = float(jax.grad(O_dw)(E0))
print(f"n_grid={n_grid}  NA={NA} ND={ND}  Nphot={NPHOT}  E0={float(E0)}", flush=True)
print(f"GT RENORMALIZED   O={truthO_norm:.6f}   dO/dE={truthG_norm:.6e}", flush=True)
print(f"GT DENSITY-WEIGHT O={truthO_dw:.6f}   dO/dE={truthG_dw:.6e}\n", flush=True)

# ============================================================================= METHODS
# Each returns its forward estimate.  'gt' tags which ground truth it targets.

# --- A: current-style (detached selection, weight carries grad). RENORM target.
@jax.jit
def method_A(E, key):
    d = density_grid(E); p = sg(d) / jnp.sum(sg(d))
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=p)
    w = d[idx]
    return jnp.sum(w * g_grid[idx]) / jnp.sum(w)

# --- A_dw: current-style but DENSITY-WEIGHTED forward (no renorm). DW target.
#     mean over photons of w*g where w=d[idx], idx~p detached.  E[w g] = sum p^2 g / sum p.
@jax.jit
def method_A_dw(E, key):
    d = density_grid(E); p = sg(d) / jnp.sum(sg(d))
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=p)
    w = d[idx]
    return jnp.mean(w * g_grid[idx])

# --- C: DiCE score (REINFORCE), renormalized. RENORM target.
@jax.jit
def method_C(E, key):
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))
    return jnp.mean(g_grid[idx] * score)

# --- C_dw: DiCE on the density-weighted forward. DW target.
#     O_dw = E_{x~p}[ p(x) g(x) ].  Pathwise weight w=p plus score on the p-measure.
@jax.jit
def method_C_dw(E, key):
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))
    f = d[idx] * g_grid[idx]                     # pathwise integrand (weight = density)
    return jnp.mean(f * score)

# --- C_dw_bl: DiCE + control-variate baseline (Rao-Blackwellized). DW target.
#     baseline b = running mean of f (detached) reduces score variance.
@jax.jit
def method_C_dw_bl(E, key):
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))
    f = d[idx] * g_grid[idx]
    b = sg(jnp.mean(f))                          # control variate (baseline)
    # pathwise mean of f  +  score*(f - b) for the discrete part
    return jnp.mean(f) + jnp.mean(sg(f - b) * (score - 1.0))

# --- B_flat: naive flattened 1D inverse-CDF (the known-biased baseline). RENORM target.
@jax.jit
def method_B_flat(E, key):
    d = density_grid(E); cdf = jnp.cumsum(d) / jnp.sum(d)
    u = jax.random.uniform(key, (NPHOT,))
    g_s = jnp.interp(u, cdf, g_grid)
    return jnp.mean(g_s)

# --- F: PROPER factored 2D reparameterized inverse-CDF. RENORM target.
#     p(angle,dist|E) = p(angle|E) p(dist|angle,E).  Sample angle via 1D inverse-CDF on the
#     distance-marginal, then dist via the conditional inverse-CDF.  Pathwise in E, preserves joint.
#     g is interpolated bilinearly at the continuous (angle,dist) sample -> pathwise gradient.
@jax.jit
def _factored_2d_sample(E, key):
    D = density_grid(E).reshape(NA, ND)              # [i_angle, j_dist]
    # angle marginal and its CDF (over angle axis), evaluated at angle bin centers a_axis
    m_ang = jnp.sum(D, axis=1)                        # (NA,)
    cdf_ang = jnp.cumsum(m_ang) / jnp.sum(m_ang)      # (NA,) right-edge CDF
    ka, kd = jax.random.split(key)
    ua = jax.random.uniform(ka, (NPHOT,))
    ang_s = jnp.interp(ua, cdf_ang, a_axis)           # sampled continuous angle
    # locate the lower angle bin for the conditional (use the sampled angle's bin)
    ia = jnp.clip(jnp.searchsorted(cdf_ang, ua), 0, NA - 1)
    # conditional dist CDF per chosen angle bin
    cdf_dist_full = jnp.cumsum(D, axis=1) / jnp.sum(D, axis=1, keepdims=True)   # (NA, ND)
    cdf_row = cdf_dist_full[ia]                        # (NPHOT, ND)
    ud = jax.random.uniform(kd, (NPHOT,))
    # per-row 1D inverse-CDF interp:  dist_s = interp(ud, cdf_row, d_axis) row-wise
    dist_s = jax.vmap(lambda c, u: jnp.interp(u, c, d_axis))(cdf_row, ud)
    return ang_s, dist_s

def _bilinear_g(ang_s, dist_s):
    # bilinear interpolation of g_mat at continuous (angle, dist) -> pathwise in the sample coords
    fa = jnp.clip((ang_s - a_axis[0]) / (a_axis[1] - a_axis[0]), 0, NA - 1.001)
    fd = jnp.clip((dist_s - d_axis[0]) / (d_axis[1] - d_axis[0]), 0, ND - 1.001)
    ia0 = jnp.floor(fa).astype(int); id0 = jnp.floor(fd).astype(int)
    ta = fa - ia0; tdd = fd - id0
    g00 = g_mat[ia0, id0]; g01 = g_mat[ia0, id0 + 1]
    g10 = g_mat[ia0 + 1, id0]; g11 = g_mat[ia0 + 1, id0 + 1]
    return ((1 - ta) * (1 - tdd) * g00 + (1 - ta) * tdd * g01
            + ta * (1 - tdd) * g10 + ta * tdd * g11)

@jax.jit
def method_F(E, key):
    ang_s, dist_s = _factored_2d_sample(E, key)
    return jnp.mean(_bilinear_g(ang_s, dist_s))

# --- E: fixed-proposal importance sampling, renormalized. RENORM target.
@jax.jit
def method_E(E, key):
    dref = sg(density_grid(E_REF)); pref = dref / jnp.sum(dref)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=pref)
    dE = density_grid(E)
    w = dE[idx] / dref[idx]
    return jnp.sum(w * g_grid[idx]) / jnp.sum(w)

# --- C_dw_strat: SYSTEMATIC (low-discrepancy) resampling + DiCE score + control-variate baseline.
#     Replaces iid random.choice with searchsorted(cdf, u0 + arange/N): one stratified sweep through
#     the CDF.  Kills the index-selection variance while keeping the score unbiased.  DW target.
#     ** BEST METHOD ** (forward exact, grad ratio ~1.00, ~7x lower variance than plain DiCE, no proposal).
@jax.jit
def method_C_dw_strat(E, key):
    d = density_grid(E); p = d / jnp.sum(d); cdf = jnp.cumsum(p)
    u0 = jax.random.uniform(key, ()) / NPHOT
    us = u0 + jnp.arange(NPHOT) / NPHOT
    idx = jnp.clip(jnp.searchsorted(cdf, us), 0, n_grid - 1)     # systematic resample
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))     # DiCE box
    f = d[idx] * g_grid[idx]                                     # pathwise integrand (weight=density)
    b = sg(jnp.mean(f))                                          # control-variate baseline
    return jnp.mean(f) + jnp.mean(sg(f - b) * (score - 1.0))

# --- E_dw: fixed-proposal IS, DENSITY-WEIGHTED forward. DW target.
#     sample x~pref(fixed); estimator = mean over photons of  (dE/pref_unnorm) * dE * g  ... derive:
#     O_dw = sum dE^2 g / sum dE.  Self-normalized IS under pref:
#       num = E_pref[ (dE/pref) dE g ] = sum dE^2 g ;  den = E_pref[ (dE/pref) dE ] = sum dE^2 ... NO.
#     We want sum dE^2 g / sum dE.  Write as ( sum dE^2 g / sum dE^2 ) * ( sum dE^2 / sum dE ).
#     Cleaner: importance ratio r = dE/dref.  Under x~pref (pref=dref/sum dref):
#       E_pref[ r * h(x) ] = sum (dE/dref) h dref / sum dref = sum dE h / sum dref.
#     Pick h = dE g:  num = sum dE^2 g / sum dref.   Pick h = 1: E_pref[r] = sum dE / sum dref.
#     So O_dw = E_pref[r dE g] / E_pref[r] = self-normalized.  Pathwise in dE (dref fixed).
@jax.jit
def method_E_dw(E, key):
    dref = sg(density_grid(E_REF)); pref = dref / jnp.sum(dref)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=pref)
    dE = density_grid(E)
    r = dE[idx] / dref[idx]
    num = jnp.mean(r * dE[idx] * g_grid[idx])
    den = jnp.mean(r)
    return num / den

# ============================================================================= EVAL
NK = 64
keys = jax.random.split(jax.random.PRNGKey(0), NK)

methods = [
    ('A current',   method_A,      'norm'),
    ('B_flat',      method_B_flat, 'norm'),
    ('C DiCE',      method_C,      'norm'),
    ('E fixedprop', method_E,      'norm'),
    ('F factor2D',  method_F,      'norm'),
    ('A_dw',        method_A_dw,   'dw'),
    ('C_dw',        method_C_dw,   'dw'),
    ('C_dw_bl',     method_C_dw_bl,'dw'),
    ('E_dw',        method_E_dw,   'dw'),
    ('C_dw_strat',  method_C_dw_strat, 'dw'),   # BEST
]

print(f"{'method':>12} {'gt':>5} {'O(mean)':>11} {'fwd err%':>9} {'dO/dE':>13} {'grad/truth':>11} {'grad std':>11} {'cmp s':>7} {'run ms':>7}", flush=True)
for name, fn, gt in methods:
    truthO = truthO_norm if gt == 'norm' else truthO_dw
    truthG = truthG_norm if gt == 'norm' else truthG_dw
    gfn = jax.jit(jax.grad(fn))
    t0 = time.time(); _ = float(fn(E0, keys[0])); _ = float(gfn(E0, keys[0])); tc = time.time() - t0
    t0 = time.time()
    Os = np.array([float(fn(E0, k)) for k in keys])
    Gs = np.array([float(gfn(E0, k)) for k in keys])
    tr = (time.time() - t0) / (2 * NK) * 1000
    rel = Gs.mean() / (truthG + 1e-30)
    fwd_err = (Os.mean() - truthO) / (abs(truthO) + 1e-30) * 100
    print(f"{name:>12} {gt:>5} {Os.mean():>11.5f} {fwd_err:>8.2f}% {Gs.mean():>13.4e} {rel:>10.3f}x {Gs.std():>11.4e} {tc:>7.2f} {tr:>7.2f}", flush=True)
