# BEST-CASE RECON RECIPE — full record of everything done & changed (2026-06-07)

SK water-Cherenkov, 1050 MeV muon, units m/ns/MeV. Track = 9 params. Everything below is the validated
best case; env-gated toggles default OFF (production byte-identical) unless noted.

## A. BEST RESULTS (the "best case")
| truth | TTS | MAXCELL | energy bias | vtx RMS | dir RMS | t0 |
|-------|-----|---------|-------------|---------|---------|-----|
| SIREN (matched) | 2.5 | 4 (truth=pred) | -0.06% | 7.0 cm | 0.21 deg | -0.53 ns |
| SIREN (matched) | 0   | 16 | +0.21% | 7.0 cm | 0.52 deg | -0.09 ns |
| PhotonSim (GEANT4) | 2.5 | 16 | -0.21% | 18.1 cm | 1.77 deg | -0.16 ns |
| PhotonSim (GEANT4) | 0   | 16 | +0.22% |  7.4 cm | 0.81 deg | -0.02 ns |
Vertex SYSTEMATIC bias ~1.7-3.7 cm (essentially unbiased); the RMS is per-event photon SHOT NOISE.
Realistic vertex resolution is TTS-DOMINATED (PhotonSim 7.4cm@TTS0 -> 18cm@TTS2.5), NOT loss/emission.
Energy is charge-driven & ~unbiased after the fixes. Direction floor = SIREN emitter fidelity vs GEANT4.
Optimizer basin: gnrec (GN + periodic Hessian recompute) captures the vertex CLEANLY from z+15m (the WHOLE SK
tank; vtx 7-10cm, dir <0.2deg from ANY start) — Adam fails by ~0.8m, plain fixed-Hessian GN fails by 8m. NO
failure point found within the tank. gnrec wins all 3: basin (>=15m) + floor (~7-9cm) + clean E (+5..+9).

## B. THE LOSS (count-conditioned Poisson first-arrival)
Per PMT i: detected photons ~ inhomogeneous Poisson, rate r(t)=sum_j w_j N(t;tau_j,sigma^2).
  mu_i = sum_j w_j (=expected charge)   R_i(t)=sum_j w_j Phi((t-tau_j)/sigma), Phi=0.5(1+erf(x/sqrt2))
  S_i(t)=1 - R_i(t)/mu_i  (NORMALIZED survival; amplitude-independent)
FACTORIZE:  L_i = Poisson(n_i;mu_i) [CHARGE] x order-stat(t_i | n_i, S_i) [TIME, conditioned on OBSERVED n_i]
  charge_nll = sum_i (mu_i - n_i*log mu_i)                                  (all sensors)
  time_nll   = -n*log S_lo - log1mexp(n*(log S_hi - log S_lo))             (hit PMTs; S_lo=S(t-D/2),S_hi=S(t+D/2))
    log1mexp(a)=log(1-exp(a)) stable: a<=-1e-7; a>-0.693 -> log(-expm1(a)) else log1p(-exp(a)).
  total loss = sum charge_nll + sum time_nll.
HYPERPARAMS: sigma=SIGMA=2.5 (=TTS), Delta=1.0 ns. (Delta-insensitive; sigma must MATCH the truth TTS.)
=> Replaces the OLD order-stat first_arrival_nll (used PREDICTED mu not observed n -> bias +188 MeV/-0.58 m).
   Do NOT normalize the charge term by sum(true) (kills the energy constraint).

### FIX #2 in the loss — AMP_DETACH (env AMP_DETACH=1)
The TIME term must constrain arrival TIMES (geometry/dir/t0), NOT photon counts (charge's job). The survival
S=1-R/mu carries the amplitude (weights w_j AND mu) -> injects d(mu)/dE -> pulls energy -1.2% (and inflates vtx).
FIX: detach the WHOLE amplitude in the survival, keep arrival times live:
    wR = stop_gradient(ww);  muS = stop_gradient(mu)
    R = segment_sum(wR*Phi(...));  S = (muS - R)/muS
=> clean time<->charge factorization (charge->E+longitudinal; time->transverse+dir+t0). Energy -12.9->+2.8 MeV,
   vtx 13->8.5cm, dir 0.54->0.26deg. ALSO halves the gradient variance. WARNING: detaching mu ALONE (R weights
   left live) BLOWS UP to +214 MeV -- must detach ww AND mu together.

## C. THE SIM / FORWARD
PREDICTOR: setup_event_simulator(is_data=False, use_expected_value=True, temperature=0.1, hit_mode='per_photon',
  K=8, max_sensors_per_cell=MC, n_photons=500000, wavelength_mode=True, particle='muon'). SIREN emission.
TRUTH:     setup_event_simulator(is_data=False, use_expected_value=False, temperature=None, hit_mode='realistic',
  same K/MC/NPH). Sample propagator (hard Bernoulli), make_hits_data (Bernoulli QE + hard first-arrival min + TTS).
  PhotonSim truth: is_data=True + read_photon_data_from_photonsim, FIXED 400k buffer + N-mask (pad by tiling).
TRACK PARAM: th9=[E,x,y,z, sin th,cos th, sin ph,cos ph, t0]; d=[st cp, st sp, ct] (each s,c renorm'd).
  SCALE9=[50,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]. (sin/cos replaced raw polar/azim -> removed the azimuth kink.)
CONSTRAINTS: K>=8 (truth & pred); times in detector frame; free t0 (absorbs TTS first-arrival order-stat offset).

### FIX #1 in the sim — OVERLAP_RENORM (env, lucid/overlap.py, default 1.0)
Soft Gaussian overlap loses each photon's spread into the inter-sensor GAPS (~40% SK coverage) -> ~1% charge
under-count -> energy. Multiply the soft overlap_prob by C = hard_total/soft_total = 1.009 (SK; per-detector).
Pure scale -> position-gradient direction unchanged. Total 0.992->1.0005, charge-only E +12->+3.5 MeV.

### MAXCELL = 4 (NEW default for recon)
The grid charge loss (3.6% @MC16, temp-independent, NOT overflow, lookup is geometrically EXACT per brute-force)
CANCELS when truth & predictor share MAXCELL. Matched MC=4 => E -0.06%/vtx 7.0cm/dir 0.21deg (== MC16). So run
MC=4 (6-8x cheaper). High MC only for ABSOLUTE charge vs real data (handled by OVERLAP_RENORM/charge calib).

## D. THE OPTIMIZER  ── WINNER = gnrec (Gauss-Newton + periodic Hessian recompute)
Metric = FD Hessian of the FULL loss (central-diff of the reverse-mode AD grad, key-avg; jax.hessian is
BROKEN/indefinite for geometry, jacfwd-Fisher blocked by custom_vjp). z-scaled, POSITIVE-eigenvalue-CLIPPED
(ev>=CLIP_FRAC*max|ev|), + ridge lambda=eps*median(diag). Step dz=-(Hz+lam I)^-1 gz, trust-region clip, damping.
COMMON KNOBS: CLIP_FRAC=0.05 (POSITIVE CLIP is ESSENTIAL — no-clip diverges on the indefinite directions),
  RIDGE_EPS=0.6 (mean~=median), DAMP=0.7, TR=0.3, NKEYS=6 (CRN), step in SCALED z=(th-th9)/SC. NITERS>=300.
**gnrec (BEST): recompute the FD Hessian every RECOMP=10 iters.** Gives ALL THREE at once, no schedules, one knob:
  - wide basin: clean capture from z+15m = the WHOLE SK tank (no failure found): floor 6/6 9cm; 5.2m 4/4 6.0cm;
    8m 7-10cm; 10m 8-9cm; 12.4m 10.3cm; 15m 10.0cm/dir0.07 — all vtx 7-10cm, dir <0.2deg. (Adam fails ~0.8m.)
  - tight floor: 7-9cm;  - clean energy bias (+5..+9 MeV, NO LM-style bias; only the extreme 15m start leaves ~2%).
  Refreshing curvature as the long 10-15m step descends keeps the metric valid the whole way down (fixed-H goes stale).
ALTERNATIVES: gn (FD Hessian computed ONCE, fixed) captures ~6m but dir/energy degrade far out (stale curvature,
  dir 0.50/E-12 @6m), FAILS @8m. lm (adaptive ridge) tightest floor (~2-5cm) but NARROW basin (fails >3.6m) AND an
  energy bias (-25 MeV). Adam = simplest floor (~8cm) but basin only ~0.8m. => use gnrec for robust capture + floor.

## E. CODE CHANGED (all env-gated, default OFF / byte-identical)
- lucid/overlap.py          : OVERLAP_RENORM multiplier on the soft overlap (FIX #1).
- loss_t5.py / loss_t4.py   : count-cond loss; AMP_DETACH (FIX #2); LOSS_SIGMA; PRED_TEMP; TRUTH_K/MC,PRED_K/MC
                              decoupling; TAG; TTS via TTS_NS; PhotonSim fixed-buffer loader (loss_t4).
- lucid/simulation/sensor_response.py, photon_step.py : diagnostic toggles (detect_hard, LIK_CHG_NOTIME,
                              DATA_CHG_NOTIME) -- all REFUTED hypotheses, default off.
- analysis: adfd_hessian.py (AD/FD+Hessian), gn_recon.py (GN), basin_check.py, charge_vs_mc.py, grid_occupancy.py,
  brute_force_charge.py, loss_t1/t1b/t2*/t3*/t5 (the diagnosis tiers). Logs: MISMATCH_PLAN.md, MAXCELL_PLAN.md,
  COMPONENTS.md, METHODOLOGY.md.
TODO (not yet done): port FIX#1+FIX#2 into the PRODUCTION loss (lucid/losses.py / recon_harness.make_loss).

## F. METHOD GOTCHAS
- GRID-MIN not a wide global parabola (wide parabola on an asymmetric weakly-curved profile fakes a ~4cm bias).
- Matched-key self-consistency is CIRCULAR; real test = predictor vs SAMPLE truth, independent keys, high stats.
- obs as JITTED ARGS (not jit(make(obs)) -> recompile). jax.lax.map not vmap for the time-grid (205GB OOM).
- jax.hessian OOMs at 64M photons -> use HVP or FD Hessian. jacfwd blocked by the DiCE custom_vjp (use FD).
- per-event fit cost = STEPS*NKEYS gradone (e.g. 180*4=720); run all 5 GPUs. MAXCELL=4 is ~6-8x cheaper.
