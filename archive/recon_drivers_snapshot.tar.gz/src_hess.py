"""Isolate: is the autodiff 2nd-order broken in the SIREN SOURCE (the DiCE emission sampler) or downstream?
Autodiff Hessian vs FD Hessian of a scalar over the SIREN source outputs, wrt p=[origin(3),dir(3),energy].
pathwise inputs (origin,dir) vs the DiCE/score input (energy via the density) reported separately.
Usage: CUDA_VISIBLE_DEVICES=g python src_hess.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.siren.core import create_photonsim_siren_grid
from lucid.siren.training.inference import SIRENPredictor
from lucid.sources.siren_rays import photonsim_differentiable_get_rays
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=3, suppress=True, linewidth=140)
dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4)
pp=unpack_photonsim_params('muon',dg.medium.material); pr=SIRENPredictor(pp['siren_model_path']); grid=create_photonsim_siren_grid(pr)
na,nb,nc=pp['num_seeds']; mp=pr.params; key=jax.random.PRNGKey(0)
d0=np.array([np.sin(0.6)*np.cos(0.8),np.sin(0.6)*np.sin(0.8),np.cos(0.6)])
p0=jnp.array([0.,0.,0., d0[0],d0[1],d0[2], 1050.0])
SCp=np.array([0.2,0.2,0.2, 0.05,0.05,0.05, 50.0])
def f(p):
    rv,ro,w=photonsim_differentiable_get_rays(p[:3], p[3:6], p[6], 80000, grid, mp, key, na,nb,nc)
    return jnp.sum(rv)+jnp.sum(ro)+jnp.sum(w)
Had=np.array(jax.hessian(f)(p0))*np.outer(SCp,SCp)
gf=jax.jit(jax.grad(f))
Hfd=np.zeros((7,7))
for j in range(7):
    d=0.3*SCp[j]
    Hfd[:,j]=(np.array(gf(p0.at[j].add(d)))-np.array(gf(p0.at[j].add(-d))))/(2*0.3)*SCp
Hfd=0.5*(Hfd+Hfd.T)
names=['ox','oy','oz','dx','dy','dz','E']
print("SOURCE Hessian (autodiff finite=%s):"%bool(np.isfinite(Had).all()))
print("  diag autodiff:", np.diag(Had))
print("  diag FD      :", np.diag(Hfd))
print(f"  relative ||ad-fd||/||fd|| = {np.linalg.norm(Had-Hfd)/(np.linalg.norm(Hfd)+1e-9):.4f}  cosine={float(Had.ravel()@Hfd.ravel()/(np.linalg.norm(Had.ravel())*np.linalg.norm(Hfd.ravel())+1e-12)):.4f}")
# energy row (the DiCE/score input) vs pathwise (origin/dir) blocks
print("  energy-row autodiff:", Had[6]); print("  energy-row FD      :", Hfd[6])
print(f"  pathwise block (origin+dir, 6x6) rel err = {np.linalg.norm(Had[:6,:6]-Hfd[:6,:6])/(np.linalg.norm(Hfd[:6,:6])+1e-9):.4f}")
