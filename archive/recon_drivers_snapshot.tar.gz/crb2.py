"""CRB cross-check: the Cramer-Rao bound = sqrt(diag(F^-1)) where F is the Fisher = score covariance
over DATA realizations at truth (the statistically correct CRB; first-order only, immune to the
trajectory-kink 2nd-order variance). Compares the theoretical floor to the achieved empirical resolution.
Score = grad of the Poisson charge NLL + first-arrival time NLL (the actual likelihood). Per-channel:
charge-only Fisher -> vtx/E floor; time-only -> dir/t0 floor; combined.
Config: K=8, maxcell=16, cubic, SIREN_IMPORTANCE (set on cmdline). Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim python crb2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import poisson_nll, first_arrival_nll
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '150000'))
M = int(os.environ.get('M', '40')); TAU = float(os.environ.get('TAU', '0.3')); NAMES = H.PARAM_NAMES
SC = np.array(H.PARAM_SCALE)
S = PS.setup(event=0, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = jnp.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def nll_charge(theta, key, ocf):
    _, _, _, q = pred(H.theta_to_track(theta), key)
    return jnp.sum(poisson_nll(ocf, q))
def nll_time(theta, key, otf, hitf):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    return jnp.sum(jnp.where(hitf, first_arrival_nll(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
gC = jax.jit(jax.grad(nll_charge)); gT = jax.jit(jax.grad(nll_time))

# score over M data realizations at truth (predictor key fixed per data key to isolate data fluctuation)
GC = []; GT = []
for m in range(M):
    oc, ot, hi = regen(1000 + m)
    pk = jax.random.PRNGKey(m)
    GC.append(np.array(gC(ts, pk, oc)) * SC)
    GT.append(np.array(gT(ts, pk, ot, hi)) * SC)
GC = np.array(GC); GT = np.array(GT)

def crb(G, idx):
    F = (G.T @ G) / G.shape[0]
    sub = np.ix_(idx, idx); Fs = F[sub]
    Fs = Fs + 1e-6 * np.trace(Fs) / len(idx) * np.eye(len(idx))   # tiny ridge for invertibility
    C = np.linalg.inv(Fs)
    return np.sqrt(np.clip(np.diag(C), 0, None))   # in SCALE units

pos = [1, 2, 3]; ang = [4, 5]
print(f"# CRB TRUTH={TRUTH} NPHOT={NPHOT} M={M} (units: SCALE = {list(SC)})", flush=True)
cb_c = crb(GC, [0, 1, 2, 3])      # charge: E + vertex
cb_t = crb(GT, [4, 5, 6])         # time: dir + t0
print(f"CHARGE Fisher CRB:  E={cb_c[0]*SC[0]:.1f}MeV ({cb_c[0]*SC[0]/float(ts[0])*100:.1f}%)  "
      f"vtx=sqrt(x2+y2+z2)={np.sqrt((cb_c[1]*SC[1])**2+(cb_c[2]*SC[2])**2+(cb_c[3]*SC[3])**2)*100:.1f}cm", flush=True)
deg_per_rad = 180/np.pi
print(f"TIME   Fisher CRB:  dir~{np.sqrt((cb_t[0]*SC[4])**2+(cb_t[1]*SC[5])**2)*deg_per_rad:.2f}deg  "
      f"t0={cb_t[2]*SC[6]:.2f}ns", flush=True)
# also full-7 combined (charge+time) Fisher
Gfull = GC + GT
cb_f = crb(Gfull, [0, 1, 2, 3, 4, 5, 6])
print(f"COMBINED 7-param CRB: E={cb_f[0]*SC[0]/float(ts[0])*100:.1f}%  "
      f"vtx={np.sqrt(sum((cb_f[i]*SC[i])**2 for i in [1,2,3]))*100:.1f}cm  "
      f"dir={np.sqrt(sum((cb_f[i]*SC[i])**2 for i in [4,5]))*deg_per_rad:.2f}deg  t0={cb_f[6]*SC[6]:.2f}ns", flush=True)
