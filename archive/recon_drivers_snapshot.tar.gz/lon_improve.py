"""CAN WE BEAT THE ~15cm CHARGE LONGITUDINAL FLOOR? Decompose & attack it. Over N PhotonSim events, the
charge longitudinal argmin for several ROBUST loss variants (vs plain Poisson), plus a bias-stability
(calibration) check and a per-event-error correlation (predictability) check.

Variants (per-PMT, mu=model mean, Q=observed):
  POISSON   sum 2[Q log(Q/mu) - (Q-mu)]  (deviance; argmin == Poisson NLL)
  TRIM10/20 trimmed deviance: drop the worst alpha-fraction of per-PMT deviances each lambda (robust to a
            SPARSE mismatch e.g. delta-ray/hot PMTs; no help if the mismatch is COHERENT across the ring)
  CAUCHY    sum log(1+(r/c)^2) on Pearson residual r=(Q-mu)/sqrt(mu+1) (redescending, down-weights outliers)
Then: (1) split-half bias stability -> is the +10cm calibratable?  (2) corr(lon error, total charge) ->
predictable/correctable?  mu(lambda) longitudinal grid is event-independent -> cached once.
Env: NPHOT NKG NKT NEV.  Usage: CUDA_VISIBLE_DEVICES=g python lon_improve.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.geometry import generate_detector
np.set_printoptions(precision=3, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKG = int(os.environ.get('NKG', '3'))
NKT = int(os.environ.get('NKT', '4')); NEV = int(os.environ.get('NEV', '25')); NW = float(os.environ.get('NW', '1.34'))
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '16'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
TGT_VTX = np.array([0.0, 0.0, 0.0]); TGT_POL = 0.6; TGT_AZ = 0.8; ts = np.array([1050.0, 0, 0, 0, TGT_POL, TGT_AZ, 0.0])

def _rod(v, ax, an):
    ax = ax/(np.linalg.norm(ax)+1e-12); return v*np.cos(an)+np.cross(ax, v)*np.sin(an)+ax*(ax@v)*(1-np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins'])/100.0; _, _, vt = np.linalg.svd(P-P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0@dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax/(np.linalg.norm(ax)+1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(TGT_VTX-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHOT)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(pred); det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(p, a): return np.array([np.sin(p)*np.cos(a), np.sin(p)*np.sin(a), np.cos(p)])
d_true = dvec(ts[4], ts[5]); dummy = H.theta_to_track(jnp.array(ts))
qof = jax.jit(lambda th, key: pred(H.theta_to_track(th), key)[3])
def mu_at(th): return np.mean([np.array(qof(jnp.array(th), jax.random.PRNGKey(1000+13*k))) for k in range(NKG)], 0)

lam = np.unique(np.concatenate([np.arange(-1.2, 1.201, 0.04), np.arange(-0.1, 0.1001, 0.01)]))
MU = np.stack([mu_at(ts + np.array([0, d_true[0]*l, d_true[1]*l, d_true[2]*l, 0, 0, 0])) for l in lam])
MU = np.clip(MU, 1e-8, None)
print(f"# LON-IMPROVE NEV={NEV} NPHOT={NPHOT} NKG={NKG} {len(lam)} lon pts", flush=True)

def dev(mu, Q):                              # per-PMT Poisson deviance (>=0)
    return 2*(np.where(Q > 0, Q*np.log(Q/mu), 0.0) - (Q-mu))
def argmin_cm(curve):
    j = int(np.argmin(curve)); lo = max(0, j-2); hi = min(len(lam), j+3); a, b, _ = np.polyfit(lam[lo:hi], curve[lo:hi], 2)
    return (-b/(2*a) if a > 0 else lam[j])*100
def L_poisson(Q): return np.array([dev(MU[i], Q).sum() for i in range(len(lam))])
def L_trim(Q, alpha):
    out = np.zeros(len(lam))
    for i in range(len(lam)):
        d = np.sort(dev(MU[i], Q)); out[i] = d[:int((1-alpha)*len(d))].sum()
    return out
def L_cauchy(Q, c=2.5):
    return np.array([np.sum(np.log(1 + (((Q-MU[i])/np.sqrt(MU[i]+1))/c)**2)) for i in range(len(lam))])
VAR = [('POISSON', lambda Q: L_poisson(Q)), ('TRIM10', lambda Q: L_trim(Q, 0.10)),
       ('TRIM20', lambda Q: L_trim(Q, 0.20)), ('CAUCHY', lambda Q: L_cauchy(Q))]

amins = {n: [] for n, _ in VAR}; totq = []
for ev in range(NEV):
    pd = photon_data_for(ev)
    Q = np.mean([np.array(jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev+j), pd))[0]) for j in range(NKT)], 0)
    totq.append(Q.sum())
    for name, fn in VAR: amins[name].append(argmin_cm(fn(Q)))
    print(f"#   ev{ev:2d}  " + "  ".join(f"{n}:{amins[n][-1]:+6.1f}" for n, _ in VAR), flush=True)

print(f"\n# CHARGE longitudinal over {NEV} events: bias  scatter  RMS  [cm]", flush=True)
for name, _ in VAR:
    a = np.array(amins[name]); print(f"#   {name:8s} bias {a.mean():+6.1f}  scatter {a.std():5.1f}  RMS {np.sqrt(a.mean()**2+a.std()**2):5.1f}", flush=True)

a = np.array(amins['POISSON']); h = len(a)//2
print(f"\n# (1) BIAS STABILITY (Poisson): half-A bias {a[:h].mean():+5.1f}  half-B bias {a[h:].mean():+5.1f}  "
      f"(close => stable => CALIBRATABLE -> residual scatter {a.std():.1f}cm)", flush=True)
tq = np.array(totq); cc = np.corrcoef(tq, a)[0, 1]
ac = a - np.polyval(np.polyfit(tq, a, 1), tq)              # linear de-trend by total charge
print(f"# (2) corr(lon err, total charge) = {cc:+.2f}; after linear correction by total-charge: scatter {a.std():.1f} -> {ac.std():.1f}cm", flush=True)
print(f"# BEST achievable longitudinal = min over (robust variant) of RMS, and after bias calibration ~ scatter.", flush=True)
