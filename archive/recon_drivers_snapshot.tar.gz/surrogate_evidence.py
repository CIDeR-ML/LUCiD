"""EVIDENCE: is the backward sigmoid surrogate in the hard overlap explicitly needed, or does the
charge->position gradient already flow through the DiCE emission score + smooth physics?

Arbiter = the CHARGE-ONLY gradient (WT=0), which is the contested pathway (charge constrains position).
 - SELF-CONSISTENT (SIREN truth = predictor): at truth the TRUE gradient is exactly 0. Any nonzero AD
   gradient at truth is surrogate-induced BIAS. From a +offset the gradient must be RESTORING (sign back
   toward truth) and should match the finite-difference (FD) gradient, which is surrogate-independent.
 - We compare ST_WIDTH_FRAC = {0 (pure hard, no surrogate), 0.2, 0.35} via env.

Usage: CUDA_VISIBLE_DEVICES=g ST_WIDTH_FRAC=w TRUTH_SOURCE=siren NKEYS=24 python surrogate_evidence.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=130)

NKEYS = int(os.environ.get('NKEYS', '24'))
SRC   = os.environ.get('TRUTH_SOURCE', 'siren')
STW   = os.environ.get('ST_WIDTH_FRAC', '0.35')
PT    = os.environ.get('PRED_TEMP', '')                 # '' -> hard; float -> soft overlap sigma=t*r
ptemp = float(PT) if PT else None
SC = np.array(H.PARAM_SCALE)

S = PS.setup(event=0, nphot=80_000, truth_source=SRC, pred_temperature=ptemp)
theta_star = np.array(S['theta_star'])
# CHARGE-ONLY loss (the contested pathway). WT=0 isolates charge->position.
closs = lambda th, k: PS.make_loss(S, WT=0.0, TAU=4.0)(th, k)[0]
gfn = jax.jit(jax.grad(closs))
lfn = jax.jit(closs)
keys = [jax.random.PRNGKey(7000 + k) for k in range(NKEYS)]
print(f"=== STW={STW}  PRED_TEMP={PT or 'hard'}  TRUTH={SRC}  NKEYS={NKEYS}  (charge-only gradient) ===", flush=True)
# forward fidelity: predicted total charge at truth vs observed (occupancy check)
_, _, _, q0 = jax.jit(S['pred'])(H.theta_to_track(jnp.array(theta_star)), jax.random.PRNGKey(0))
print(f"setup nhit={S['nhit']} sumobs={S['sumobs']:.0f}  pred_sum_q@truth={float(jnp.sum(q0)):.0f} "
      f"(ratio {float(jnp.sum(q0))/S['sumobs']:.3f})", flush=True)

def ad_grad(theta):
    G = np.stack([np.array(gfn(jnp.array(theta), k)) * SC for k in keys])
    return G.mean(0), G.std(0)/np.sqrt(NKEYS)

def fd_grad(theta, step=0.5):
    # central FD per param, matched keys, normalized to scale-units
    out = np.zeros(7)
    for i in range(7):
        vals = []
        for k in keys:
            hp = jnp.array(theta).at[i].add(step*SC[i]); hm = jnp.array(theta).at[i].add(-step*SC[i])
            vals.append((float(lfn(hp, k)) - float(lfn(hm, k))) / (2*step))
        out[i] = np.mean(vals)
    return out

# 1) at truth: self-consistent => true charge gradient ~ 0
g0, se0 = ad_grad(theta_star)
print("\n[at truth] charge-only AD gradient (self-consistent truth => should be ~0):")
print("  param ", "  ".join(f"{n:>7s}" for n in H.PARAM_NAMES))
print("  g_AD  ", "  ".join(f"{v:7.3f}" for v in g0))
print("  SE    ", "  ".join(f"{v:7.3f}" for v in se0))
print(f"  |g_pos(x,y,z)| = {np.linalg.norm(g0[1:4]):.3f}  (bias if >> SE)")

# 2) at +offset in each of x,y,z (one at a time): need RESTORING (+) gradient matching FD
for p in [1, 2, 3]:
    off = 4.0                                   # +4 scale-units (x,y,z: +0.8 m)
    th = theta_star.copy(); th[p] += off*SC[p]
    gad, sead = ad_grad(th)
    gfd = fd_grad(th)
    print(f"\n[+{off:.0f}*scale in {H.PARAM_NAMES[p]} (= +{off*SC[p]:.2f} m)] charge-only gradient:")
    print(f"  AD[{H.PARAM_NAMES[p]}] = {gad[p]:+.3f} +- {sead[p]:.3f}   FD[{H.PARAM_NAMES[p]}] = {gfd[p]:+.3f}   "
          f"(want > 0 = restoring; ratio AD/FD = {gad[p]/gfd[p] if abs(gfd[p])>1e-3 else np.nan:.2f})")
    print(f"  full vec AD: " + " ".join(f"{H.PARAM_NAMES[i][:3]}={gad[i]:+.2f}" for i in range(7)))
    print(f"  full vec FD: " + " ".join(f"{H.PARAM_NAMES[i][:3]}={gfd[i]:+.2f}" for i in range(7)))
    cos = float(gad@gfd/(np.linalg.norm(gad)*np.linalg.norm(gfd)+1e-12))
    print(f"  cosine(AD,FD) = {cos:.3f}")
