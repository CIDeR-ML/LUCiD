#!/usr/bin/env python3
"""Aggregate + plot the E-sweep (/tmp/esw_*.npz): loss(E) & dL/dE(E) curves, total-charge ratio, charge argmin.
Tests whether the energy bias is a forward total-light NORMALIZATION mismatch (SIREN over-lights per MeV)."""
import glob,os,numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'recon_plots'); os.makedirs(OUT,exist_ok=True)
F=sorted(glob.glob('/tmp/esw_esweep_*.npz'))
if not F: print('no esweep files'); raise SystemExit
D=[np.load(f) for f in F]
ratio=np.array([float(d['mutot'])/float(d['octot']) for d in D])
amC=np.array([float(d['E'][np.argmin(d['Lc'])]-d['Etrue']) for d in D])           # charge-loss argmin (what the fit follows, time E-grad detached)
amTot=np.array([float(d['E'][np.argmin(d['Lc']+d['Lt'])]-d['Etrue']) for d in D]) # total-loss argmin (if time NOT detached)
# zero-crossing of charge gradient = charge stationary point
def zc(E,g):
    s=np.where(np.diff(np.sign(g)))[0]
    if not len(s): return np.nan
    i=s[0]; return float(E[i]-g[i]*(E[i+1]-E[i])/(g[i+1]-g[i]))
gzC=np.array([zc(d['E'],d['dLcE'])-d['Etrue'] for d in D])
print(f'N={len(D)} events')
print(f'  total-charge ratio  mu_pred/q_data = {ratio.mean():.4f} +/- {ratio.std():.4f}  (=> SIREN over-lights {(ratio.mean()-1)*100:+.1f}% per MeV)')
print(f'  charge-loss argmin (E bias the fit follows) = {amC.mean():+.0f} +/- {amC.std():.0f} MeV  ({amC.mean()/1050*100:+.1f}%)')
print(f'  charge-grad zero-crossing                   = {np.nanmean(gzC):+.0f} MeV  (consistency check)')
print(f'  total-loss argmin (if time were live)       = {amTot.mean():+.0f} MeV')
print(f'  predicted: -ratio offset ~ {-(ratio.mean()-1)*1050:+.0f} MeV vs charge argmin {amC.mean():+.0f} MeV')

fig,ax=plt.subplots(2,2,figsize=(13,9))
# (a) charge loss vs E, each event normalized to its own min
for d in D:
    e=d['E']-d['Etrue']; L=d['Lc']-d['Lc'].min(); ax[0,0].plot(e,L,lw=0.8,alpha=0.55)
ax[0,0].axvline(0,color='k',lw=0.8,ls=':'); ax[0,0].axvline(amC.mean(),color='r',lw=1.5,label=f'mean argmin {amC.mean():+.0f} MeV')
ax[0,0].set_xlabel('E - E_true (MeV)'); ax[0,0].set_ylabel('charge loss - min'); ax[0,0].set_title('Charge loss vs E (per-event, min-subtracted)'); ax[0,0].legend(); ax[0,0].grid(alpha=0.3); ax[0,0].set_ylim(0,None)
# (b) charge gradient dLc/dE vs E
for d in D: ax[0,1].plot(d['E']-d['Etrue'],d['dLcE'],lw=0.8,alpha=0.55)
ax[0,1].axhline(0,color='k',lw=0.8,ls=':'); ax[0,1].axvline(0,color='k',lw=0.5,ls=':')
ax[0,1].set_xlabel('E - E_true (MeV)'); ax[0,1].set_ylabel('dL_charge/dE'); ax[0,1].set_title('Charge-loss gradient (zero-crossing = where fit lands)'); ax[0,1].grid(alpha=0.3)
# (c) ratio histogram
ax[1,0].hist(ratio,bins=12,color='C0',edgecolor='k'); ax[1,0].axvline(1.0,color='k',ls=':'); ax[1,0].axvline(ratio.mean(),color='r',lw=1.5,label=f'mean {ratio.mean():.4f}')
ax[1,0].set_xlabel('Sum mu_pred / Sum q_data  at truth'); ax[1,0].set_ylabel('events'); ax[1,0].set_title('Total-charge prediction ratio (>1 = SIREN over-lights)'); ax[1,0].legend(); ax[1,0].grid(alpha=0.3)
# (d) argmin vs ratio scatter — should follow E_bias ~ -(ratio-1)*E
ax[1,1].scatter((ratio-1)*100,amC,c='C0',label='charge argmin');
xs=np.linspace((ratio-1).min()*100,(ratio-1).max()*100,50); ax[1,1].plot(xs,-xs/100*1050,'r--',label='E_bias = -(ratio-1)*E_true')
ax[1,1].set_xlabel('over-light (ratio-1) [%]'); ax[1,1].set_ylabel('charge-loss argmin (MeV)'); ax[1,1].set_title('Energy bias tracks the over-light normalization'); ax[1,1].legend(); ax[1,1].grid(alpha=0.3)
fig.suptitle('E-bias source: forward total-light normalization (all other params at truth)',fontsize=13); fig.tight_layout(rect=[0,0,1,0.97])
fig.savefig(os.path.join(OUT,'esweep_bias.png'),dpi=110); print('wrote esweep_bias.png')
