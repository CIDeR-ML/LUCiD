"""Energy-SEPARATED loss test on PhotonSim:
(1) verify the decoupling -- the ENERGY component of grad(L_S) and grad(L_T) is ~0, grad(L_E) is not;
(2) cold-start annealed GN-LM recon with L = wE*L_E + wS*L_S + wT*L_T (energy driven by total charge only,
    vertex/dir/t0 by scale-invariant shape + count-decoupled time). Report vertex/E/dir/t0 vs the 48cm
    energy-coupled baseline. Usage: CUDA_VISIBLE_DEVICES=g python sep_test.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
THR = 4.0; SC = np.array(H.PARAM_SCALE)
SCHED = [float(x) for x in os.environ.get('SCHED', '2,1,0.5,0.3,0.2').split(',')]
STEPS = int(os.environ.get('STEPS', '70'))
wE = float(os.environ.get('WE', '100')); wS = float(os.environ.get('WS', '1')); wT = float(os.environ.get('WT', '0.03'))
S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star'])

# (1) decoupling check: energy component of each term's gradient at truth (avg over keys)
mk = PS.make_loss_sep(S, wE=1, wS=1, wT=1, TAU=0.3, THR=THR)
gE = jax.jit(jax.grad(lambda th,k: mk(th,k)[0]))
gS = jax.jit(jax.grad(lambda th,k: mk(th,k)[1]))
gT = jax.jit(jax.grad(lambda th,k: mk(th,k)[2]))
ks = [jax.random.PRNGKey(8000+i) for i in range(16)]
def emean(gf):
    G = np.stack([np.array(gf(jnp.array(ts),k))*SC for k in ks]); return G.mean(0), G.std(0)/4
if SEED == 1:
    for nm, gf in [('L_E', gE), ('L_S', gS), ('L_T', gT)]:
        g, se = emean(gf)
        print(f"  [{nm}] grad@truth: ENERGY={g[0]:+.3f}+-{se[0]:.3f}  |pos|={np.linalg.norm(g[1:4]):.3f}  "
              f"full={' '.join(f'{H.PARAM_NAMES[i][:3]}={g[i]:+.2f}' for i in range(7))}", flush=True)
    print("  => L_S, L_T ENERGY-gradient ~ 0 (separated); L_E carries energy.", flush=True)

# (2) cold-start recon with the separated loss, annealed TAU
gtot = {tau: jax.jit(jax.grad(lambda th,k,t=tau: PS.make_loss_sep(S, wE=wE, wS=wS, wT=wT, TAU=t, THR=THR)(th,k)[3]))
        for tau in SCHED}
def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr=np.zeros(7)
    if freeze:
        for i in freeze: fr[i]=1.0
    T=[]
    for s in range(steps):
        kk=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in kk]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st*(1-fr))
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t): return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t): return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
SEEDS = [int(x) for x in os.environ.get('SEEDS', str(SEED)).split(',')]
print(f"SEP sweep SCHED={SCHED} STEPS={STEPS} wE={wE} wS={wS} wT={wT}", flush=True)
Vs=[]; Ds=[]; Es=[]; Ts=[]
for sd in SEEDS:
    rng=np.random.default_rng(sd)
    th=jnp.array(ts + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
    for j,tau in enumerate(SCHED):
        th=gnlm(th, gtot[tau], STEPS, tag=2+j)
    Vs.append(vtx(th)); Ds.append(deg(th)); Es.append(Ep(th)); Ts.append(float(th[6]-ts[6]))
    print(f"  seed {sd}: vtx={vtx(th):5.1f}cm  E={Ep(th):+.1f}%  dir={deg(th):.2f}deg  t0={Ts[-1]:+.2f}ns", flush=True)
print(f"SEP SUMMARY vtx={np.mean(Vs):.1f}+-{np.std(Vs):.1f}cm (median {np.median(Vs):.1f}) "
      f"dir={np.mean(Ds):.2f}deg  E={np.mean(Es):+.1f}+-{np.std(Es):.1f}%  t0={np.mean(Ts):+.2f}ns", flush=True)
