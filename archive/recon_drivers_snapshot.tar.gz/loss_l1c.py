"""LOSS L1.3 — clean 1D loss PROFILE vs AD directional derivative (resolves the AD-magnitude question).

The 7-vector ||AD||/||FD|| ratio is confounded by FD noise (CRN doesn't fully cancel for geometry: a tiny
geometry step moves photons across overlap-cell boundaries -> discrete L jumps -> inflated FD at small h).
Fix: build a NOISE-AVERAGED 1D loss profile L(s) for each param (mean over NKEYS keys, COMMON keys across
all grid points s -> the profile is smooth, noise correlated out), then the profile's own slope at s=0 IS
the true expected gradient. Compare to the mean AD directional derivative at s=0, at multiple finite scales.
Also reveals the surface shape (smooth vs kinky) per parameter.

Scans energy / x / polar / t0 around theta0 = theta_true + displacement. Saves a 4-panel profile figure.
Env: NPHOT NKEYS RECON_K MAXCELL TEMP NPTS SPAN.  Usage: CUDA_VISIBLE_DEVICES=g python loss_l1c.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '96'))
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '8')); TEMP = float(os.environ.get('TEMP', '0.1'))
NPTS = int(os.environ.get('NPTS', '25')); SPANF = float(os.environ.get('SPAN', '6.0'))
PN = H.PARAM_NAMES; PS = np.asarray(H.PARAM_SCALE)
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0.0, 0.0, 0.0175, 0.0, 0.5])
theta0 = theta_true + delta
print(f"# L1.3 profile vs AD  NPH={NPH} NKEYS={NKEYS} K={K} MAXCELL={MC} TEMP={TEMP} NPTS={NPTS} SPAN={SPANF}xPARAM_SCALE", flush=True)
pred = H.build_predictor(temperature=TEMP, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(777))
loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=1.0)
lossj = jax.jit(loss); gradj = jax.jit(jax.grad(loss))
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
gAD = np.stack([np.asarray(gradj(jnp.asarray(theta0), k)) for k in keys]).mean(0)   # mean AD grad at theta0

PARAMS = list(zip(PN, range(7)))                                       # all 7
fig, ax = plt.subplots(2, 4, figsize=(20, 9))
j0 = NPTS // 2
print(f"#  param  grp     AD        slope@w(1,2,4,8 grid steps, ->s=0)            AD/coarse  converges?", flush=True)
for pi, (nm, i) in enumerate(PARAMS):
    grp = 'S' if nm in ('energy', 't0') else 'G'
    span = SPANF * PS[i]; svals = np.linspace(-span, span, NPTS); dgrid = svals[1] - svals[0]
    prof = np.array([np.mean([float(lossj(jnp.asarray(theta0 + s * np.eye(7)[i]), k)) for k in keys]) for s in svals])
    slopes = {w: (prof[j0 + w] - prof[j0 - w]) / (2 * w * dgrid) for w in [1, 2, 4, 8]}
    adv = gAD[i]
    conv = 'YES' if abs(adv / (slopes[1] + 1e-30) - 1) < 0.3 else 'no'   # does finest slope ~ AD?
    print(f"#  {nm:6s} {grp}  {adv:+10.2f}  " + " ".join(f"{slopes[w]:+10.1f}" for w in [1, 2, 4, 8]) +
          f"   {adv/(slopes[4]+1e-30):+7.2f}    {conv}", flush=True)
    a = ax[pi // 4, pi % 4]
    a.plot(svals / PS[i], prof, 'C0-o', ms=3, label='mean L(s)')
    a.plot(svals / PS[i], prof[j0] + adv * svals, 'C1--', lw=2, label=f'AD slope {adv:+.0f}')
    a.axvline(0, color='k', lw=0.5); a.set_title(f'{nm} ({grp}) AD/slope@4={adv/(slopes[4]+1e-30):+.2f}')
    a.set_xlabel(f'Δ{nm}/scale'); a.legend(fontsize=7)
    pr = float(np.ptp(prof)); a.set_ylim(prof.min() - 0.1 * (pr + 1e-9), prof.min() + 1.1 * (pr + 1e-9))
ax[1, 3].axis('off')
plt.tight_layout(); plt.savefig('_l1_profiles.png', dpi=85); print("# saved _l1_profiles.png", flush=True)
print(f"# VERDICT: AD/prof_coarse ~ 1 => AD matches the true (noise-averaged) slope; <<1 => AD underestimates;", flush=True)
print(f"#   profile shape shows whether the surface is smooth (clean slope) or kinky (AD-vs-FD ambiguity is real).", flush=True)
