#!/usr/bin/env python3
"""Per-PMT TIME forward comparison: EXPECTED (predictor per_photon ft distribution) vs TRUE (data hard first-arrival).
Is there a fundamental difference? Check: predicted first-arrival vs data, per-photon ft anomalies (zeroed scatter),
systematic offset, good vs wanderer events."""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.0')
os.environ.setdefault('PRED_TEMP','0.1'); os.environ.setdefault('TOT_N_SCALE','0.982')
exec(open('gn_fisher_recon.py').read().split('rows=[]')[0])
import numpy as np, jax, jax.numpy as jnp
def analyze(ev,lab):
    raw,beta=rand_tf(read_photon_data_from_photonsim(ROOT,ev),ev); th9,d=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
    c,t=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev),pd)); oc=np.asarray(c); ot=np.where(oc>0,np.asarray(t),0.)
    lw,ft,fi,tot=pred(sc2(jnp.asarray(th9)),KEYS[0]); ww=np.asarray(jnp.exp(jnp.clip(lw,-60,20))); ft=np.asarray(ft); fi=np.asarray(fi); tot=np.asarray(tot)
    # per-photon ft anomalies
    print(f'\n=== {lab} ev{ev} ===')
    print(f'  per-photon ft (predictor): min={ft.min():.1f} max={ft.max():.1f} | frac ft<1ns={np.mean(ft<1)*100:.1f}% frac ft>100ns={np.mean(ft>100)*100:.1f}% | ww>0 frac={np.mean(ww>1e-6)*100:.1f}%')
    # per-PMT predicted hard first-arrival = weighted min (use min over photons with ww>thr)
    ND_=len(tot); predmin=np.full(ND_,np.inf)
    sel=ww>1e-4
    np.minimum.at(predmin,fi[sel],ft[sel])
    lit=oc>0
    pm=predmin[lit]; dm=ot[lit]; ok=np.isfinite(pm)&(dm>0)
    res=dm[ok]-pm[ok]   # data first-arrival - predicted first-arrival
    print(f'  lit PMTs={lit.sum()} | DATA first-arrival: med={np.median(dm[ok]):.1f}ns | PRED min-ft: med={np.median(pm[ok]):.1f}ns')
    print(f'  RESIDUAL (data - pred first-arrival): mean={res.mean():+.2f} med={np.median(res):+.2f} std={res.std():.2f} ns | frac |res|>5ns={np.mean(np.abs(res)>5)*100:.1f}%')
    # split by occupancy
    occ=oc[lit][ok]
    for tag,m in [('dim(1-3PE)',(occ>=1)&(occ<3)),('mid(3-10)',(occ>=3)&(occ<10)),('bright(>10)',occ>=10)]:
        if m.sum(): print(f'    {tag:12s} N={m.sum():5d} residual mean={res[m].mean():+.2f} med={np.median(res[m]):+.2f} ns')
for ev,lab in [(41,'GOOD'),(24,'GOOD'),(19,'WANDER'),(31,'WANDER')]:
    analyze(ev,lab)
