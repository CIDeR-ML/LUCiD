# Alignment campaign — findings (TRUE vs SIM forward model)

Consolidated synthesis. Full per-run conditions in `RUN_LOG.md`; plan in `ALIGNMENT_PLAN.md`;
scripts `align_a12/a3b/a4/a4b/a7/a5/a6/a8/a10/b/b2/b7/b9.py`. Branch `reconstruction-mie`
(diverged from `refactor-v2` at 3a14e3c). All on SK geom, 1050 MeV muon, MIE forced off for the
engine isolation, K=8 / MAXCELL=8 unless swept.

## The question
Rule out the forward simulation as the source of the recon "regression", so any remaining problem
is attributable to the loss/optimizer — not a silent forward-model drift.

## The two paths and their ONLY legitimate differences
| | TRUE (truth/data) | SIM (predictor) |
|---|---|---|
| iteration | `photon_iteration_sample` (hard MC) | `photon_iteration_update_factors` (expected/DiCE) |
| overlap | hard (temperature=None) | soft Gaussian (temperature 0.1) |
| QE | Bernoulli sample | multiplicative weight |
| time smear | per-photon TTS + per-sensor SK (toggleable) | off |

## Results (every stage)
- **A1/A2 step engine** — TRUE `sample` is the per-step hard realization of SIM `update_factors`'s
  expectation; agree to <0.3% (detect deposit) / ~1% (continuing) in expectation. No step-level mismatch.
- **A0 / A3 engine** — K=1 per-PMT charge is engine-independent (corr 1.0). The refactor-v2 STE→current
  DiCE rewrite changed multi-bounce charge ~4.6% total / 9.5% per-PMT L1 at K=8, but **toward truth**
  (DiCE total gap to sampled truth −1.1% vs STE +3.7%; STE mean-field over-counts multi-bounce survival).
- **A4 / A4b overlap + truth noise** — per-PMT L1(SIM,TRUE) is FLAT in overlap temperature (44.25%→43.75%
  for None→0.30) → not overlap. It falls as 1/√N_truth_keys (58%@8 → 12%@256) to a ~6% floor that is mostly
  the predictor's own sampling noise. **The predictor IS the correct mean of the truth.** Total ~1%, corr→0.996.
- **A6 QE** — Bernoulli (TRUE) == multiplicative weight (SIM) in expectation (corr 0.9999); qe_corrections identical.
- **A5 MAXCELL** — overlap truncation not converged at 32 (~2%/doubling, mc4 undercounts ~7%); SHARED by
  both paths → no TRUE-SIM mismatch, but absolute charge is MAXCELL-dependent (keep TRUE/SIM matched).
- **A8 SK smear** — mean-preserving (charge Δ0%, +0.31 ns time jitter); a variance-only knob SIM omits.
- **A10 wavelength** — λ physics applied identically TRUE/SIM (Δtot −1.1% on / −1.0% off). Scalar mode is
  ~8× the total charge (different normalization); recon uses λ-mode.
- **A7 timing** — well-lit PMTs (occ≥5) agree to a small known soft-min bias (median −1 to −2 ns, std ~11 ns
  per-event order-stat noise); low-occ dominated by few-photon order-stat noise; TTS = clean ~1 ns-earlier knob.
  CAVEAT: tested the 'aggregated' soft-min mode; RECON uses per-photon `first_arrival_nll` — a loss-level
  timing check is the proper deeper test (open).
- **B1–B4 emission** — SIREN vs PhotonSim: longitudinal s ~2%, Cherenkov cone cosθ ~0.7%, and `predict_t0(distance)`
  reproduces the emission-time-vs-distance trend to **0.02 ns RMSE** (only 0.12 ns jitter omitted). Only
  idealization: SIREN transverse r=0 (line source) vs PhotonSim 2.7 cm.
- **B7 coverage** — SIREN-mean == PhotonSim-mean at the detector: total +1.4%, per-PMT MC-noise-limited (corr 0.94).
- **B9 per-event floor** — PhotonSim per-event longitudinal charge-centroid spread = **16 cm** (SIREN 23 cm);
  per-PMT fractional spread 238% (PhotonSim) / 374% (SIREN).

## Conclusion
**No unexplained TRUE-vs-SIM forward mismatch.** Every residual is an intentional knob (overlap softness,
Bernoulli-vs-weight QE, TTS, SK smear) or irreducible per-event photon-counting noise. The predictor is the
correct mean of the truth; SIREN reproduces PhotonSim emission and coverage. **B9 ties the ~15 cm longitudinal
recon floor to per-event photon statistics (16 cm centroid spread)** — it is a statistics floor, not a model
error. Any "much better prior fit" was a noise-free-clock / near-truth-start artifact.

=> The lever for the recon regression is the **LOSS / OPTIMIZER**, not the forward simulation. Proceed to
interrogate the loss (gradient/Hessian quality, CRB, term structure) BEFORE touching the optimizer — see
`LOSS_PLAN.md`.

## Method notes / gotchas
- Monkeypatching a shared `jax.custom_vjp` mid-process collides with JAX's primal-jaxpr cache (gives a false
  byte-identical result). Patch the symbol `setup` reads (`simulator.photon_iteration_update_factors_safe`)
  in a SEPARATE PROCESS before any build.
- Per-PMT single-event charge/time are noise-dominated at ~0.5 PE/PMT (half-vs-half floor 70% @ 8 keys);
  compare totals, correlation, smoothed profiles, or high-key means — never raw per-PMT L1 at low key count.
- Bash cwd must be `LUCiD_recon` (local `lucid/` pkg + `config/`); session cwd defaults to `mie_hunter` → prefix `cd`.
