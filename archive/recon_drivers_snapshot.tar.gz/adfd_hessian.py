"""PHASE 4 — AD/FD gradient quality + HESSIAN quality (corrected loss + fixes). Thorough.
Config: SIREN pred (temp=0.1, K=8, MC=16, OVERLAP_RENORM), sample truth (temp=None), count-conditioned loss with
AMP_DETACH. Truth obs = NREAL-averaged (clean systematic). All gradients/Hessians averaged over NKEYS predictor
keys (CRN), with per-key spread reported.
 (1) AD vs FD gradient per param at an OFFSET center (nonzero grad): ratio, sign, kinkiness (multi-h profile slopes).
 (2) AD Hessian at truth: symmetry, eigenvalues, condition number, per-key spread, definiteness.
 (3) FD Hessian (central diff of AD grad) vs AD Hessian.
 (4) GN/Fisher charge Hessian J^T diag(1/mu) J vs AD Hessian (is GN a good model near the optimum?).
 (5) charge-only vs full (does AMP_DETACH improve conditioning vs the amplitude-coupled time term?).
Env: NPHOT NREAL NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python adfd_hessian.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ['MAXCELL']='16'; os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=170)
NPH=int(os.environ.get('NPHOT','500000')); NREAL=int(os.environ.get('NREAL','32')); NKEYS=int(os.environ.get('NKEYS','12'))
K=8; MC=16; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0)); POL,AZ=0.6,0.8
th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
SC=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
AMP=bool(int(os.environ.get('AMP','1')))
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# AD/FD+HESSIAN  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS} AMP={AMP} renorm={os.environ['OVERLAP_RENORM']}",flush=True)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); ND=H.num_detectors(pred)
truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=K,is_data=False,use_expected_value=False,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
trk=sc2(jnp.asarray(th9))
OC=np.zeros(ND); OTw=np.zeros(ND); OTn=np.zeros(ND)
for r in range(NREAL):
    c,t=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(9000+r))); c=np.asarray(c); t=np.asarray(t)
    OC+=c; m=c>0; OTw+=np.where(m,t,0.); OTn+=m
oc=jnp.asarray(OC/NREAL); ot=jnp.asarray(np.where(OTn>0,OTw/np.maximum(OTn,1),0.))
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def loss(t9,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jnp.exp(jnp.clip(lw,-60,20)); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8)
    wR=jax.lax.stop_gradient(ww) if AMP else ww; muS=jax.lax.stop_gradient(mu) if AMP else mu
    Rlo=jax.ops.segment_sum(wR*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(wR*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    time=jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
    return jnp.sum(mu-oc*jnp.log(mu))+time
gradf=jax.jit(jax.grad(loss))
# Hessian columns via HVP (forward-over-reverse): memory ~ a gradient, NOT the full 9x9 (which OOMs at 64M photons).
@jax.jit
def hvp(t9, v, key): return jax.jvp(lambda tt: gradf(tt, key), (t9,), (v,))[1]
def hess_key(t9, key): return jnp.stack([hvp(jnp.asarray(t9), jnp.asarray(np.eye(9)[j]), key) for j in range(9)], axis=1)
KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]

# ---- (1) AD vs FD gradient at an OFFSET center (per param) ----
print("# (1) GRADIENT AD vs FD (offset center 2*SC; per-key mean +/- std; FD = noise-avg central-diff over 3 h)",flush=True)
print(f"#  {'param':5s}  AD(mean/std over keys)     FD@h(1,2,4 *SC)              AD/FD   kinky?",flush=True)
for i in range(9):
    c0=th9+2.0*SC*np.eye(9)[i]
    gAD=np.array([float(gradf(jnp.asarray(c0),k)[i]) for k in KEYS])
    sl={}
    for hf in [1.,2.,4.]:
        h=hf*SC[i]
        lp=np.mean([float(loss(jnp.asarray(c0+h*np.eye(9)[i]),k)) for k in KEYS])
        lm=np.mean([float(loss(jnp.asarray(c0-h*np.eye(9)[i]),k)) for k in KEYS])
        sl[hf]=(lp-lm)/(2*h)
    kinky=(np.sign(sl[1.])!=np.sign(sl[2.]))or(np.sign(sl[2.])!=np.sign(sl[4.]))
    ratio=gAD.mean()/(sl[2.]+1e-30)
    print(f"#  {NM[i]:5s}  {gAD.mean():+9.1f}/{gAD.std():7.1f}  FD {sl[1.]:+9.1f}/{sl[2.]:+9.1f}/{sl[4.]:+9.1f}   {ratio:+.2f}  {'KINKY' if kinky else 'smooth'}",flush=True)

# ---- (2)(3) Hessian at truth ----
print("# (2) HESSIAN at truth (AD, averaged over keys)",flush=True)
Hs=np.array([np.asarray(hess_key(th9,k)) for k in KEYS])
Hm=Hs.mean(0); Hsym=0.5*(Hm+Hm.T)
asym=np.abs(Hm-Hm.T).max()/(np.abs(Hm).max()+1e-30)
ev=np.linalg.eigvalsh(Hsym)
print(f"#  symmetry: max|H-H^T|/max|H| = {asym:.2e}",flush=True)
print(f"#  eigenvalues: {ev}",flush=True)
print(f"#  cond(|ev|) = {np.abs(ev).max()/max(np.abs(ev).min(),1e-30):.2e}  n_negative_ev = {int((ev<0).sum())}  (PD if 0)",flush=True)
# per-key Hessian spread (diagonal)
dstd=Hs.diagonal(0,1,2).std(0); dmean=Hs.diagonal(0,1,2).mean(0)
print(f"#  per-key diag mean: {dmean}",flush=True)
print(f"#  per-key diag rel-std: {np.abs(dstd/(dmean+1e-30))}",flush=True)
# (3) FD Hessian (central diff of AD grad) vs AD
print("# (3) FD Hessian (central-diff of AD grad, key-avg) vs AD Hessian diagonal",flush=True)
HFD=np.zeros((9,9))
for j in range(9):
    h=0.5*SC[j]
    gp=np.mean([np.asarray(gradf(jnp.asarray(th9+h*np.eye(9)[j]),k)) for k in KEYS],0)
    gm=np.mean([np.asarray(gradf(jnp.asarray(th9-h*np.eye(9)[j]),k)) for k in KEYS],0)
    HFD[:,j]=(gp-gm)/(2*h)
HFD=0.5*(HFD+HFD.T)
print(f"#  diag AD : {np.diag(Hsym)}",flush=True)
print(f"#  diag FD : {np.diag(HFD)}",flush=True)
print(f"#  AD/FD diag ratio: {np.diag(Hsym)/(np.diag(HFD)+1e-30)}",flush=True)
np.save('/tmp/H_ad.npy',Hsym); np.save('/tmp/H_fd.npy',HFD)
print(f"# DONE adfd_hessian (AMP={AMP})",flush=True)
