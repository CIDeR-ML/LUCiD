# Plan — find the SOURCE of the residual mismatch

## Where we are
- Forward CHARGE aligned (predictor = truth mean, per-PMT diff is 1/√N photon noise).
- Loss form FIXED: count-conditioned Poisson first-arrival, NORMALIZED survival -> ENERGY-UNBIASED
  (charge -1.1 MeV, joint +37 vs the order-stat's +188). Adopt sin/cos angle rep (reliable sign).
- Angle-gradient magnitude: normal-detach costs only ~3-7% (emission dominates) -> NOT a big effect.
- RESIDUAL we still don't fully understand: a ~0.14-0.20 m POSITION bias in the time term
  (self-consistency: expected-engine-truth -0.137 m, sample-engine-truth -0.217 m). And the open
  end-to-end question: does the corrected loss actually reconstruct PhotonSim to target?

## Methodology (locked-in lessons)
NPH=500k (realistic; bugs hide at 50k noise); obs as JITTED ARGS (no per-event recompile, 0.14s/call);
per-event INTEGER-count obs for gradients (mean-obs S^n misleads); OFFSET-center profiles (not at the min);
>=20 events before any bias claim; engine toggles in SEPARATE processes (custom_vjp jaxpr cache).

## TIER 1 — the decisive split: is the residual the LOSS or the FORWARD?
T1  EXACT self-consistency. Generate the truth by SAMPLING the predictor's OWN first-arrival distribution
    (proper R-inversion / thinned-Poisson of the predicted rate), use it as obs, profile -> argmin AT theta_true?
    - bias ~ 0  => the loss form is EXACTLY unbiased; the -0.14 m is the FORWARD engine mismatch -> Tier 2.
    - bias != 0 => the loss/generative model still has a residual -> Tier 1b.
T1b If T1 != 0: which loss approximation? sweep the BIN width Delta, the conditioning (observed n vs a soft n),
    and sigma; isolate which knob's argmin sits at truth.

## TIER 2 — characterize the forward timing residual (EXPECTED vs SAMPLE engine)
Charge matches; the per-photon TIME distribution may not. R(t_obs) per-realization was 0.5-1.7 (should be 1).
T2a Per-PMT TIME-distribution match at theta_true: predictor weighted per-photon times vs truth detected-photon
    times (full distribution + early edge), bucketed by occupancy. Quantify the systematic offset.
T2b Decompose R(t_obs) by BOUNCE (direct vs reflected): is the residual the implicit-capture multi-bounce
    deposit timing (expected engine deposits every bounce) vs the sample's single first-detection?
T2c Engine-piece toggles (separate processes): (i) time from d_live vs the sampled free path, (ii) implicit-
    capture deposit vs first-detection, (iii) soft (0.1) vs hard overlap timing. Which toggle removes the residual?

## TIER 3 — TTS / sigma matching
T3  The loss sigma (TTS convolution) vs the truth's effective first-arrival WIDTH (TTS (+) the order-statistic
    narrowing). Bias grows with sigma (survival over-counts). Find the principled sigma and whether matching it
    zeroes the residual; check vs the truth's actual TTS_NS.

## TIER 4 — emission axis (PhotonSim truth)
T4  Bias test with PhotonSim truth (FIX recompilation: pad/truncate every event to a FIXED N). Compare to
    SIREN-truth to isolate the SIREN-vs-PhotonSim emission contribution to the residual.

## TIER 5 — end-to-end: does it matter?
T5  Run a clean optimizer (Adam, or the staged pipeline) with the corrected loss + sin/cos on >=20 PhotonSim
    events; measure vtx/dir/E/t0 vs targets. Is the -0.14 m residual inside the per-event photon-statistics
    floor (~16 cm, B9) -> harmless, or does it dominate -> must fix. THIS decides whether Tiers 2-4 matter.

## Order
T1 first (loss vs forward is the fork). Then, if forward: T2 (which engine piece) + T3 (sigma). T4 adds emission.
T5 can run in parallel early as a reality check (is the residual even relevant vs the 16 cm floor?).

## RESULTS — Tier 1 (DONE 2026-06-06)
T1  (loss_t1.py, diff-key, offset center, NREAL=24): argmin off-truth E -38 MeV, vtx 6-11 cm, t0 -0.08 ns.
T1b (loss_t1b.py, MATCHED-KEY vs diff-key control, truth-centered, NREAL=32) — THE CLEAN TEST:
    MATCHED-KEY (forward byte-identical at truth): E -2 MeV, x/y/z -0.9/-1.5/-1.3 cm, dir ~0, t0 +6 ps -> ~0.
    DIFF-KEY control: E -34 MeV, x/y/z -2.6/-3.7/-3.8 cm, t0 -44 ps  (reproduces T1's sign/scale).
  VERDICT: the count-conditioned Poisson first-arrival LOSS FORM is EXACTLY unbiased (matched-key argmin ~0,
  residual = finite-NREAL parabola noise). T1's apparent bias was FORWARD photon key-noise (diff-key control).
  => the real -0.14..-0.22 m residual is the FORWARD ENGINE (expected predictor vs SAMPLE engine) -> Tier 2.

## RESULTS — Tier 2a (DONE 2026-06-06, loss_t2a.py)
At theta_true, EXPECTED predictor (temp=0.1) vs SAMPLE engine (realistic, TTS=2.5), NREAL=40, NPH=500k:
  CHARGE aligned in every occupancy bucket (count/mu ~1.00).
  TIME mismatched: PIT mean 0.416 (<0.5 => sample EARLIER than model). dt(samp-model):
    occ 0.05-0.20 (6930 pmt): -3.87 ns ;  0.2-0.5: +0.50 ; 0.5-1: -1.11 ; 1-2: -1.29 ; 2+: -0.85.
  GLOBAL median dt -2.49 ns; resid(dt-glob) VARIES +/-3 ns across occupancy => NOT a global t0 =>
  position-correlated forward timing mismatch => biases vtx/E. SOURCE of the -0.14 m identified.
  Mechanism (hypothesis): expected/implicit-capture deposits weight at EVERY bounce incl late reflected
  photons => time-resolved rate LATE-biased; sample's hard absorption kills late photons => earlier first
  arrival, worst at low occupancy. Next: T2b isolate soft-overlap(temp=0.1) vs implicit-capture late weight.

## RESULTS — Tier 2b (DONE 2026-06-06, loss_t2b.py)
SOFT(temp=0.1) vs HARD(temp=None) expected predictor, model first-arrival vs SAMPLE, per occupancy:
  dt_soft and dt_hard are NEARLY IDENTICAL (low-occ +3.87 vs +4.26; matched pattern all buckets).
  => soft overlap (gradient smoothing) is NOT the cause. Residual = expected-value/implicit-capture vs
  quantum sampling, i.e. implicit capture deposits weight at EVERY bounce (incl late) while a sampled
  photon is consumed at first detection => model time-rate late-biased. Mechanism predicts dt grows with K.

## RESULTS — Tier 2c (DONE 2026-06-06, loss_t2c.py)
K-sweep of dt(model-sample) low-occupancy bucket: K=6 +3.98, K=8 +4.14, K=12 +4.08 ns (global +2.44/+2.54/+2.55).
FLAT in K (charge converged mu pred==samp all K). => the late time-bias is NOT bounce accumulation; it is
SATURATED by K=6. Refines T2b: the expected/implicit-capture engine's first-arrival time-rate is intrinsically
LATER than quantum sampling at DIM (low-occ) PMTs (multi-deposit vs single first-detection), K-saturated,
temperature-independent. THIS position-correlated time bias is the source of the ~0.14 m vtx/E residual.

## SYNTHESIS (Tiers 1-2 complete)
- LOSS form (count-conditioned Poisson first-arrival): EXACTLY unbiased (T1b matched-key argmin ~0).
- FORWARD charge: aligned (count==mu all occupancy).
- FORWARD time: expected engine first-arrival ~+4ns LATE at low-occ / ~+1ns mid, occupancy(=position)-correlated,
  K-saturated, temp-independent => biases vtx/E by ~0.14 m. ROOT = expected-value implicit-capture timing != sampling.
FORK for next: (A) accept + Tier 5 end-to-end (is 0.14m inside ~16cm photon floor => harmless?);
  (B) fix forward timing (first-passage/survival-weight the late deposits so the time-rate matches first-detection);
  (C) down-weight low-occupancy PMTs in the time term (they carry the bias).

## RESULTS — Tier 2d/2e + Tier 3 (DONE 2026-06-06) — REVISES the mechanism + REFRAMES the bias
T2d (loss_t2d.py, MODEL-FREE propagator rate, EXP vs SAMP both via per_photon):
  per-BOUNCE weight AND mean-time are IDENTICAL (3088/3097..., 88.2/88.2...) => NOT late-bounce accumulation.
  Yet per-PMT rate-mean-time dt(EXP-SAMP) = +3.86ns low-occ (matches the T2a first-arrival +3.87 => first-arrival
  model adds nothing; the diff is already in the raw deposit times).
  FIX TESTED: PSTEP_DBG=detect_hard (deposit only on hard-reached surfaces, no scatter-Rao-Blackwell) => NO change
  (dt +4.55). => scatter-RB is NOT the mechanism.
T2e (loss_t2e.py, weight-threshold sweep on EXP rate): sub-1e-5 tail is only 0.2% of weight; dt unchanged until
  the threshold cuts REAL weight (T=1e-4 wrong elsewhere). => low-weight late tail is NOT the mechanism.
  => THREE implicit-capture stories REFUTED by fix-and-see (late-bounce / scatter-RB / threshold tail).
T3 (loss_t3.py, count-cond loss, REAL sample-engine truth, 1D profiles) — REFRAMES the bias:
  argmin off-truth: E -24MeV, x/y/z +4.8/+2.9/+5.9 cm, dir ~0, t0 -0.55ns. The DOMINANT bias is t0 (-0.55ns),
  NOT position. -0.55ns x 0.225 m/ns (water v_g) = 0.12m == the old "-0.14m". So the forward mismatch is mostly a
  GLOBAL ~0.5ns time offset, DEGENERATE with vertex-along-track: free t0 absorbs it (vtx ~few cm); fixed t0 -> ~0.12m.
  T1b self-consistent t0 was +6ps => the -0.55ns IS the forward (expected-vs-sample) mismatch. detect_hard: no change.
T3joint (loss_t3joint.py): joint Adam fit, all 9 params, sample truth -> does t0 absorb, leaving small vtx? [running]

## RESULTS — Tier 3 joint (DONE 2026-06-06, loss_t3joint.py) — BOTTOM LINE
Joint Adam fit, all 9 params, REAL sample-engine truth, count-cond loss (NREAL=12 NKEYS=2, grad OOM caps these):
  BASELINE  -> t0 absorbs -0.71ns; FINAL |vtx|=6.4cm, E=+14MeV.
  detect_hard-> t0 -0.84ns; |vtx|=14cm (noisy last step along the flat t0-z valley; ~6cm at step 250). No sys help.
CONCLUSION: the forward implicit-capture time mismatch is DOMINANTLY a global ~0.5-0.7ns t0 offset (degenerate
with vertex-along-track). With a FREE t0 (real recon), t0 absorbs it and the orthogonal vertex residual ~6cm is
WITHIN the ~16cm per-event photon floor => BENIGN. Only a FIXED/external t0 turns the 0.5ns into ~0.12m (the old
"-0.14m"). ANSWER to "why would implicit capture cause this if done correctly": it largely does NOT cause a
harmful recon bias; the recon-relevant projection is a global time offset the t0 fit removes, and the residual is
below the photon floor. The +4ns dim-PMT rate difference is the mean-field(expected)-vs-quantum(sample) gap, not a
fixable bug (detect_hard/threshold/late-bounce all refuted). photon_step.py gained a default-OFF PSTEP_DBG=detect_hard
diagnostic toggle (inert without the flag; byte-identical default).

## RESULTS — Tier 5 (DONE 2026-06-06, loss_t5.py) — CLOSES the investigation
20 independent single-realization events, sample-engine truth, count-cond loss + sin/cos + FREE t0, fit from truth:
  VERTEX |vtx| RMS = 13.6 cm (about truth); per-component bias (-2.4,-3.7,-0.8)cm = ~4.5cm vector (sub-dominant).
  ENERGY bias +1.1 MeV (+0.11%), RMS 17.7 MeV (1.7%).   DIRECTION mean 0.45deg, RMS 0.54deg.
  t0 mean -0.594 ns (RMS 0.16 ns) -- the forward implicit-capture offset lands CONSISTENTLY in t0.
CONCLUSION: realized vertex 13.6cm RMS == the ~14-16cm per-event PHOTON FLOOR (CRB ~14.5cm). The corrected loss
REACHES the floor; the forward implicit-capture time mismatch is BENIGN -- it sits in t0 (-0.59ns, very stable) and
the orthogonal vertex systematic (~4.5cm) is well inside the statistical scatter. Energy unbiased, direction ~0.5deg.
=> The recon "regression" was the LOSS (old order-stat first_arrival_nll, +188MeV/-0.58m) + FIXED-t0 framing, NOT the
forward. Recipe: count-conditioned Poisson first-arrival (binned survival, OBSERVED n, normalized) + sin/cos angles +
free t0. Open: vary vertex/direction across events (config-dependence) + PhotonSim truth (Tier 4, fixed-N pad).

## CORRECTION (2026-06-06) — TTS=0/SIREN is NOT perfectly reconstructable (user was right)
TTS sweep of the T3 argmin (loss_t3_tts.py): t0 offset is ~LINEAR in TTS (-0.075 -0.19*TTS), nearly vanishes at
TTS=0 => the t0 part is the TTS first-arrival ORDER-STATISTIC (min-pull) bias, NOT the implicit-capture gap.
BUT at TTS=0 the recon is still NOT perfect, and it's a CHARGE problem (charge term has no t0/TTS):
  CHARGE-ONLY argmin (loss_chargeonly.py, NREAL=96 NKEYS=24, degeneracy-free): E +12MeV, vtx ~5-6cm (z dominant),
  total charge ratio pred/sample 0.991, occupancy-shaped (dim 0.988 < bright 0.991) -- STRUCTURAL (persists at hi stats).
  Isolation (loss_chargeonly2/3, meanfield_k): the gap is NOT the readout (make_hits_data vs _likelihood) and NOT a
  bounce-covariance (K-sweep total ratio flat 1.001). TWO real causes:
  (1) SOFT OVERLAP: temperature=0.1 (Gaussian acceptance, needed for the position gradient) integrates ~1% LESS charge
      than the hard top-hat (temperature=None) the truth uses. Pred temp=None (loss_chargeonly3 PRED_TEMP=none):
      total 0.992->1.0005, energy +11->+3.5 MeV. FIXABLE by renormalizing the soft overlap to the hard area.
  (2) LONGITUDINAL ~6cm: a charge-SHAPE diff in the multi-bounce light (meanfield_k dim ratio 1.024@K1 -> 0.998@K8
      while total stays ~1.001) that PERSISTS at temp=None (z=-6cm stable, not noise). The genuine mean-field-predictor
      vs sampled-truth shape gap; longitudinal because charge-shape sets the longitudinal observable.
CONCLUSION: at TTS=0/SIREN, NOT perfect: (a) fixable ~1% soft-overlap energy bias; (b) structural ~6cm longitudinal
charge-shape bias from the expected-vs-sample engine. Both TTS-independent. This corrects the earlier "benign/reaches
floor" reading -- the ~13.6cm Tier-5 had these baked in. NEXT: renormalize soft overlap (fixes energy); quantify how
much of the ~6cm is irreducible diff-engine finite-sample vs a fixable shape.

## FIX IMPLEMENTED + VALIDATED (2026-06-06) — soft-overlap renormalization (cause #1)
lucid/overlap.py: added env-gated OVERLAP_RENORM (default 1.0 = OFF, byte-identical) multiplying the SOFT
overlap_prob (interp + cubic branches). Mechanism: soft overlap f(d)=Gaussian-mass-in-disk LOSES the fraction
of each photon's spread that lands in inter-sensor GAPS (SK ~40% coverage) => ~1% total under-count, worse in
sparse/dim regions. A GLOBAL C=hard_total/soft_total restores the total without changing the gradient direction.
Calibrated C=1.009 for SK (=temp=None_total / temp=0.1_total).
VALIDATED (loss_chargeonly3 PRED_TEMP=0.1 OVERLAP_RENORM=1.009, gradprobe.py):
  total charge ratio 0.992 -> 1.0005 ; energy argmin +12 -> +3.5 MeV ; dLoss/dz +303.6 -> +304.7 (gradient PRESERVED).
  => cause #1 (soft-overlap total under-count -> energy) FIXED, differentiability intact (temp=None would kill the grad).
RESIDUAL: vertex z -5.9cm UNCHANGED + energy +3.5 + occupancy shape (dim 0.990/mid 1.008) = cause #2, the genuine
expected(mean-field)-vs-sample(quantum) charge-SHAPE gap. NOT fixed by a global scale; needs a shape-aware fix
(per-photon overlap normalization, or matching the predictor's multi-bounce light shape to the sample). OPEN.
NOTE: C=1.009 is per-DETECTOR (SK geometry); recalibrate for HK/WCTE. Default OVERLAP_RENORM=1.0 keeps prod byte-identical.

## COMPONENT ISOLATION (2026-06-06, loss_components.py + COMPONENTS.md) — cause #2 = READOUT, not the engine
Full enumeration in COMPONENTS.md (22 parts). 2x2 {STEP: expected/sample} x {READOUT: per_photon/realistic}, temp=None,
longitudinal charge-centroid (artifact-free):
  FULL cause#2  EXP_pp vs SMP_rl : centroid Δ -2.02cm
  STEP effect   EXP_pp vs SMP_pp : centroid Δ +0.17cm  (occupancy ratios all ~1.00) => STEP INNOCENT
  READOUT effect SMP_pp vs SMP_rl: centroid Δ -2.19cm  => READOUT is the ENTIRE source of cause #2
Localized to the BACKWARD longitudinal end (PMTs behind vertex, reflected/back-scattered light): long-bin ratio
[-22.7,-17.1]m = 1.027 (make_hits_likelihood over-counts ~2.7% there), all other bins ~1.00.
=> cause #2 is make_hits_data(truth) vs make_hits_likelihood(predictor), NOT the propagator. Drill: (a) Bernoulli vs
continuous QE [same mean], (b) threshold (data: none-on-charge; likelihood: qe_w>1e-10), (c) make_hits_likelihood
masks CHARGE by (flat_times>0 & finite) while make_hits_data does NOT -> leading suspect (early/near-vertex slots).

## DRILL into cause #2 (2026-06-06) — STEP innocent, READOUT structural (small charge shape, amplified)
High-NDRAW (240) components: centroid Δ EXP_pp-vs-SMP_rl -2.0->-0.49cm, STEP(EXP_pp-SMP_pp) +0.06, READOUT(SMP_pp-SMP_rl) -0.56.
=> big NOISE part averages out; STRUCTURAL floor ~-0.5cm centroid, ALL in the READOUT (step innocent).
Seed test (charge-only renorm, two independent truth-seed batches NREAL=48): z=-5.9 and -6.4cm (spread 0.5) => the
-6cm argmin is SEED-STABLE/STRUCTURAL, NOT shot noise. Reconciliation: a small ~0.5cm structural readout charge-shape,
amplified ~12x by the weakly-constrained longitudinal direction -> -6cm vertex argmin.
Readout sub-hypotheses TESTED + REFUTED (toggles, no effect): (a) make_hits_likelihood charge masked by flat_times>0
(LIK_CHG_NOTIME); (b) make_hits_data nonzero_mask gating charge on valid timing (DATA_CHG_NOTIME).
NEXT (definitive): feed the SAME propagator flat arrays to BOTH make_hits_data and make_hits_likelihood (my SMP_pp/SMP_rl
used same propagator but different per-draw keys) -> the PURE readout charge difference, find the exact sub-knob.

## RESOLUTION (2026-06-06) — "cause #2" was a MEASUREMENT ARTIFACT, not a forward bias
ARGMIN-metric component isolation (loss_comp_argmin.py): ALL 4 truth combos give z-argmin ~ -6.1cm INCLUDING
EXP_pp (predictor vs its OWN engine, self-consistent) -- and it does NOT shrink NKEYS 16->40. Stat- and
combo-independent => a MEASUREMENT artifact, not a forward/readout/step effect.
MATCHED-KEY self-consistency (loss_selfmatch.py, Gibbs => argmin must be 0): truth=pred(theta_true,k0), predictor
same k0. GRID-MIN z = +0.0cm at EVERY window (±0.2/0.4/0.8m). PARABOLA-vertex drifts -0.2/-1.0/-4.2cm with window.
=> the -6cm was (a) ~4cm PARABOLA-FIT ARTIFACT (vertex() lstsq over a wide window on the ASYMMETRIC charge-only
z-profile) + (b) ~4cm forward KEY-NOISE (diff-key grid-min -4cm, averages to 0). NOT Jensen (key-avg vs mu-avg
grid-min both 0). NO structural cause #2: the charge forward is SELF-CONSISTENT (Gibbs grid-min at truth).
LESSON: use the GRID-MIN (or a LOCAL parabola near the min), NOT a global parabola over a wide asymmetric window.
Tier-5 (Adam optimizer, no parabola) = the real ~13.6cm photon floor, uncontaminated.

## FINAL SYNTHESIS (TTS=0/SIREN reconstructability)
- LOSS form (count-cond first-arrival): exactly unbiased (T1b grid-truth).
- FORWARD charge: SELF-CONSISTENT (Gibbs). The ONLY real structural forward bias was CAUSE #1 = soft-overlap ~1%
  total under-count (gap-loss between sensors) -> energy; FIXED via OVERLAP_RENORM (gradient preserved).
- "CAUSE #2" (~6cm longitudinal): did NOT exist -- parabola-fit artifact + finite-sample key-noise.
- t0 offset: TTS first-arrival order-statistic (min-pull), ~linear in TTS, ->0 as TTS->0; absorbed by free t0.
=> at TTS->0 with SIREN, recon IS essentially perfect in expectation after the overlap renorm; residual = irreducible
per-event photon shot noise (the ~14cm floor), NOT a forward inconsistency. User's intuition was correct.

## CORRECTION 2 (2026-06-06) — same-key test was CIRCULAR; the PROPER diff-engine grid-min test
User: "same key analysis is wrong, that is comparing the same event to itself." Correct -- matched-key self
(pred reconstructs its own realization) is exactly 0 by Gibbs, tells us NOTHING about the real mismatch.
PROPER test (loss_gridmin.py): predictor = EXP charge averaged over NK INDEPENDENT keys; truths = EXP (control,
same engine diff keys) and SMP_rl (real sample truth) each averaged over NR INDEPENDENT keys (disjoint ranges);
GRID-MIN (fine grid + 3pt LOCAL parabola at the min, NOT wide global parabola). temp=None.
  z: control gridmin 0.00cm both stats. SMP(real) gridmin -1.33cm (NR=96) -> -0.36cm (NR=192); SMP-control excess
  -0.69 -> -0.30cm. Halves as stats double => 1/sqrt(N) NOISE, NOT a structural floor. energy consistent (0.06%).
=> NO structural expected-vs-sample ENGINE charge bias; the forward is consistent to <0.3cm (shrinking). The -6cm
was parabola-fit artifact (~4cm) + finite-sample noise (~1cm). The ONLY real structural forward bias remains cause #1
(soft overlap ~1%/energy, FIXED via OVERLAP_RENORM). No hidden charge bug. Per-event recon residual = shot-noise floor.

## TIER 5 PAIRED (2026-06-06, loss_t5.py TAG=off/on) — overlap renorm OFF vs ON, same 20 events
                         OFF(1.0)            ON(1.009)
  energy bias            -3.6MeV(-0.34%)     -12.9MeV(-1.23%)   RMS 14.7 / 15.6
  vertex systematic vec  3.3cm               1.4cm             (per-comp OFF(-2.2,-2.5,+0.2) ON(-1.3,+0.4,-0.4))
  |vtx| RMS              12.8cm              13.0cm   (= photon floor, unchanged)
  dir RMS                0.51deg             0.54deg ;  t0  -0.583 / -0.540 ns
FINDINGS: renorm HALVES the vertex SYSTEMATIC (3.3->1.4cm) = correct charge normalization; |vtx| RMS unchanged
(photon floor). BUT energy bias WORSENS -3.6->-12.9MeV (3.7sigma) -- the OFF ~0 was an ACCIDENTAL CANCELLATION:
soft-overlap charge UNDER-count biases E up (+~12 charge-only) while the count-conditioned TIME term biases E
DOWN ~-13MeV; they cancelled. Renorm removes the + side -> UNMASKS the time-term energy bias. => the real remaining
structural item is a ~-1.2% TIME-term energy bias (first-arrival likelihood), NOT charge/overlap. Next: diagnose the
count-conditioned time term's energy pull (sigma/Delta/normalization) -- it is the last real bias.

## TIME-TERM ENERGY BIAS — ROOT CAUSE (2026-06-06, loss_timeenergy2.py)
TIME-only energy argmin (grid-min, other params pinned, renorm ON): mu-FREE -190 to -200 MeV (sigma-scaled, Delta
irrelevant) vs mu-DETACHED (mu fixed at theta_true in S=1-R/mu) = +0.0cm EXACTLY at all sigma.
=> the time-term energy bias is ENTIRELY the survival NORMALIZATION S=1-R/mu carrying d mu/dE. The count-conditioned
factorization L = Poisson(n;mu)[charge] x order-stat(t|n,S)[time]: the TIME term should constrain timing/geometry,
not energy (charge's job), but mu in the denominator double-counts energy (wrong sign) -> the -1.2% pull that was
masked by the soft-overlap under-count.
FIX: detach mu in the survival -> S = 1 - R/stop_gradient(mu). R(t) keeps geometry/timing gradient; normalization
stops injecting the spurious energy pull. mu-DETACHED test confirms energy-neutral time term. NEXT: implement +
verify end-to-end (Tier-5 renorm + mu-detach -> energy bias -> ~0). Check vertex/dir/t0 timing constraint survives.

## TIME-TERM FIX VALIDATED (2026-06-06, loss_t5.py AMP_DETACH) — the payoff
Tier-5 paired (same 20 events), all with OVERLAP_RENORM=1.009:
                          energy            |vtx|RMS  dirRMS   t0
  OFF baseline           -3.6MeV(-0.34%)    12.8cm    0.51deg  -0.58
  renorm ON              -12.9MeV(-1.23%)   13.0cm    0.54deg  -0.54
  ON + MU_DETACH (BROKE) +214MeV(+20%)      24.7cm    0.84deg  -0.83   <- inconsistent (R live, mu detached)
  ON + AMP_DETACH (FIX)  +2.8MeV(+0.26%)    8.5cm     0.26deg  -0.61   <- energy unbiased + vtx 13->8.5 + dir 0.54->0.26
FIX = detach the whole AMPLITUDE (weights ww AND mu) in the survival S=1-R/mu, keep arrival times ft LIVE. The
first-arrival TIME term then constrains TIMES (geometry/direction/t0) ONLY, not photon counts (charge's job).
mu-detach ALONE broke it (R kept the amplitude gradient -> inconsistent -> +214MeV). AMP-detach is consistent.
RESULT: clean time<->charge factorization (charge->energy+longitudinal; time->transverse+dir+t0). vtx 8.5cm is
BELOW the ~14cm "floor" -- that floor was the amplitude-contaminated time term fighting charge, not irreducible.
TODO: port AMP_DETACH into the production recon loss (lucid/losses.py first_arrival / recon_harness make_loss);
re-confirm at higher event count + PhotonSim truth.

## PHOTONSIM (real GEANT4) VALIDATION (2026-06-06, loss_t4.py TAG=psbase/psfix, 10 events)
Paired, PhotonSim ROOT truth (muon_gun_1050MeV), fixed 400k buffer + mask, SVD-derived true track:
                              energy             |vtx|RMS  vbiasVec  dirRMS   t0
  BASELINE (no fixes)         +12.9MeV(+1.23%)   21.3cm    7.5cm     1.42deg  -0.275
  + OVERLAP_RENORM+AMP_DETACH -2.2MeV(-0.21%)    18.1cm    3.7cm     1.77deg  -0.161
FIXES TRANSFER to PhotonSim: energy bias +1.23%->-0.21% (was the SIREN-under-predicts-charge ~1.8% emission gap),
vertex systematic 7.5->3.7cm, |vtx|RMS 21->18cm, energy RMS 31->21. SANITY ev0: SIREN pred Q 5514 vs PhotonSim
5614 = 0.982 (residual SIREN-vs-GEANT EMISSION ~1.8%, NOT fixed by renorm=overlap-only).
CAVEATS: direction did NOT improve (1.42->1.77deg, 10-ev noise + near-vertical tracks) -- on SIREN-truth AMP_DETACH
halved dir (0.54->0.26); on PhotonSim dir is now SIREN-EMISSION-fidelity-limited, not loss-limited. Absolute vtx
18cm > SIREN-truth 8.5cm because PhotonSim adds the real per-event emission spread (~16cm centroid floor, B9). 10
events = noisy. => loss/forward fixes validated on real truth; remaining frontier = SIREN emitter vs GEANT4 (retrain).

## TTS=0 vs 2.5 with fixes (2026-06-07) — TTS dominates the realistic vertex floor
                       energy    vtx-sys  |vtx|RMS  dir     t0
  SIREN     TTS=2.5    +0.26%    2.4cm    8.5cm    0.26deg -0.605
  SIREN     TTS=0      +0.21%    1.7cm    7.0cm    0.52deg -0.089
  PhotonSim TTS=2.5    -0.21%    3.7cm    18.1cm   1.77deg -0.161
  PhotonSim TTS=0      +0.22%    1.7cm    7.4cm    0.81deg -0.015   (LOSS_SIGMA=0.15)
KEY: PhotonSim vertex 18.1->7.4cm at TTS=0 => the realistic ~18cm floor is DOMINATED by the 2.5ns TTS smearing,
NOT the SIREN-vs-GEANT emission gap (earlier attribution was wrong). At TTS=0 SIREN(7.0) ~ PhotonSim(7.4) => the
SIREN emitter is faithful for VERTEX once TTS is out; residual ~7cm = per-event CHARGE SHOT-NOISE (systematic only
1.7cm = ~unbiased). t0 offset collapses (-0.6/-0.16 -> -0.09/-0.02) => it was purely the TTS first-arrival order-stat.
Energy TTS-independent (+0.2%, charge-driven). dir: PhSim 1.77->0.81 (TTS helps); SIREN 0.26->0.52 (sharp-sigma
optimizer noise). => fixes validated at TTS=0 too; the dominant REALISTIC vertex-resolution limiter is detector TTS.

## TTS / K / MAXCELL sweeps (2026-06-07, loss_t5.py, SIREN truth, both fixes)
TTS sweep (truth=pred K8 MC16): SIREN vtx 7.0/7.8/8.5cm @ TTS 0/2.0/2.5; PhotonSim 7.4/15.5/18.1cm => realistic
PhotonSim vertex is TTS-DOMINATED, not emission.
K sweep (predictor K; truth K=10 MC=24; pred MC=16): E +1.82/+1.00/+1.06/+1.09% @ K 4/6/8/10; vtx/dir/t0 K-flat.
  => K=4 under-propagates (energy); K>=6 converged. The +1% floor = the MC mismatch (pred16 vs truth24).
MAXCELL sweep (predictor MC; truth K=10 MC=24; pred K=8): E +5.25/+2.87/+1.05/+0.04% @ MC 4/8/16/24; vtx/dir/t0 MC-flat.
  => MAXCELL is the dominant CHARGE-completeness->ENERGY knob; matched MC=24 -> +0.04% (unbiased); halving MC ~doubles bias.
CONCLUSION: K and MAXCELL both affect ENERGY only (charge completeness); vertex/dir/t0 robust. predictor needs K>=6
and MAXCELL matched (or near) the truth to avoid an energy bias.
RECOMPILATION CHECK (loss_timing.py): one ~35s compile then byte-stable per-call (376ms K8MC16 / 701ms K10MC24);
a NEW event (new oc/ot) does NOT recompile (obs passed as jitted ARGS). Higher K/MC = pure compute scaling, not recompile.
Cost = STEPS*NKEYS = 720 gradone/event. GPU NOTE: parallelize ALL (config x event) work across all 5 GPUs (was using 4).
