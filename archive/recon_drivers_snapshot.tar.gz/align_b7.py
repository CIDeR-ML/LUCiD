"""ALIGNMENT B7 — detector COVERAGE: PhotonSim vs SIREN through the SAME hard truth pipeline.

Isolates EMISSION at the detector level: feed PhotonSim photons (is_data=True) and SIREN photons
(is_data=False sample engine) through the identical hard truth pipeline (temperature=None, realistic
Bernoulli QE, K=8, MAXCELL=8, MIE off) on the SAME target track. Compare per-PMT charge MEANS
(PhotonSim avg over NEV events x keys ; SIREN avg over NKT keys) — the residual map: does the SIREN
mean reproduce the PhotonSim mean detector response?
Env: NEV NKT NPHOT MAXCELL.  Usage: CUDA_VISIBLE_DEVICES=g python align_b7.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NEV = int(os.environ.get('NEV', '20')); NKT = int(os.environ.get('NKT', '40'))
NPH = int(os.environ.get('NPHOT', '100000')); MAXCELL = int(os.environ.get('MAXCELL', '8')); K = 8
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
TGT_POL, TGT_AZ = 0.6, 0.8; ts = np.array([1050.0, 0, 0, 0, TGT_POL, TGT_AZ, 0.0])
track = H.theta_to_track(jnp.array(ts)); dummy = track

def _rod(v, ax, an):
    ax = ax / (np.linalg.norm(ax) + 1e-12)
    return v * np.cos(an) + np.cross(ax, v) * np.sin(an) + ax * (ax @ v) * (1 - np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.asarray(raw['photon_origins']) / 100.0; _, _, vt = np.linalg.svd(P - P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0) + ((P - P.mean(0)) @ d0).min() * d0
    dt = np.array([np.sin(TGT_POL) * np.cos(TGT_AZ), np.sin(TGT_POL) * np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0 @ dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax / (np.linalg.norm(ax) + 1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

NUM_SENSORS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
DP = np.asarray(generate_detector(H.GEOM).all_points)
dp = load_detector_params(H.PHYS, num_sensors=NUM_SENSORS)
dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# B7 coverage  NEV={NEV} NKT={NKT} NPH={NPH} MAXCELL={MAXCELL} K={K} MIE off  NUM_SENSORS={NUM_SENSORS}", flush=True)

data_sim = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MAXCELL, physics_config=H.PHYS, default_detector_params=dp_off, particle='muon',
    wavelength_mode=True, apply_smearing=False)
siren_sim = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MAXCELL, physics_config=H.PHYS, default_detector_params=dp_off,
    particle='muon', wavelength_mode=True, apply_smearing=False)

# PhotonSim mean coverage (NEV events x 2 keys each)
qp = np.zeros(NUM_SENSORS); npe = 0
for ev in range(NEV):
    pd = photon_data_for(ev)
    for j in range(2):
        qp += np.asarray(jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7 * ev + j), pd))[0]); npe += 1
qp /= npe
# SIREN mean coverage (NKT keys)
qs = np.mean([np.asarray(jax.lax.stop_gradient(siren_sim(track, jax.random.PRNGKey(s)))[0]) for s in range(NKT)], 0)

lit = (qp > 1e-6) | (qs > 1e-6)
L1 = np.abs(qp - qs).sum() / (qp.sum() + 1e-9); cc = np.corrcoef(qp[lit], qs[lit])[0, 1]
print(f"# PhotonSim mean tot {qp.sum():.1f} (over {npe} ev-keys) | SIREN mean tot {qs.sum():.1f} (over {NKT} keys)", flush=True)
print(f"# Δtot {100*(qs.sum()-qp.sum())/qp.sum():+.1f}%   per-PMT L1 {L1:.2%}   corr {cc:.4f}   litPMT {int(lit.sum())}", flush=True)

# ring profile: charge vs angle of PMT direction (from detector center) to the track axis
dtv = np.array([np.sin(TGT_POL) * np.cos(TGT_AZ), np.sin(TGT_POL) * np.sin(TGT_AZ), np.cos(TGT_POL)])
ang = np.degrees(np.arccos(np.clip((DP / (np.linalg.norm(DP, axis=1, keepdims=True) + 1e-9)) @ dtv, -1, 1)))
bins = np.linspace(0, 180, 61); cen = 0.5 * (bins[:-1] + bins[1:]); idx = np.digitize(ang, bins) - 1
prof_p = np.array([qp[idx == i].sum() for i in range(len(cen))]); prof_s = np.array([qs[idx == i].sum() for i in range(len(cen))])

fig, ax = plt.subplots(1, 2, figsize=(13, 5))
mm = lit & (qp > 1e-3) & (qs > 1e-3)
ax[0].scatter(qp[mm], qs[mm], s=3, alpha=0.2); lim = max(qp[mm].max(), qs[mm].max())
ax[0].plot([0, lim], [0, lim], 'k--', lw=1); ax[0].set_xlabel('PhotonSim per-PMT charge'); ax[0].set_ylabel('SIREN per-PMT charge')
ax[0].set_title(f'per-PMT charge (corr {cc:.3f}, L1 {L1:.1%})'); ax[0].set_xlim(0, lim); ax[0].set_ylim(0, lim)
ax[1].plot(cen, prof_p, 'C0-o', ms=3, label='PhotonSim'); ax[1].plot(cen, prof_s, 'C1-s', ms=3, label='SIREN')
ax[1].axvline(np.degrees(np.arccos(1 / 1.34)), color='k', ls='--', lw=1, label='θc')
ax[1].set_xlabel('PMT angle to track axis [deg]'); ax[1].set_ylabel('summed charge'); ax[1].set_title('Cherenkov ring profile'); ax[1].legend()
plt.tight_layout(); plt.savefig('_alignB7_coverage.png', dpi=90); print("# saved _alignB7_coverage.png", flush=True)
