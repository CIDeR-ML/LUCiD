# Simulation alignment test plan

**Goal.** Rule out the possibility that the recon "mismatch" comes from the *forward
simulation* (truth vs predictor) rather than the loss/optimizer. We do this by walking
the pipeline **stage by stage** and checking that the TRUE path and the SIM path agree
once the *known, intentional* differences between them are accounted for. Separately we
compare the two photon **emission** models (PhotonSim GEANT4 vs SIREN surrogate).

No experiment is run until the plan below is agreed. Every run, once executed, is logged
per the protocol in §4 (full param block + delta from previous run).

---

## 0. The two paths and their *known* differences

| Aspect | TRUE path (truth / "data") | SIM path (predictor / "expected") |
|---|---|---|
| photon iteration | `photon_iteration_sample` (hard MC) | `photon_iteration_update_factors` (expected/DiCE) |
| routing | `is_data=True` **or** `use_expected_value=False` | `use_expected_value=True` |
| overlap | `temperature=None` (hard: 1 photon → 1 PMT) | `temperature=0.1` (soft Gaussian acceptance) |
| QE | Bernoulli sample (`make_hits_data`) | multiplicative weight (`make_hits_likelihood`) |
| time smear | per-photon TTS (`TTS_NS`) + per-sensor SK (`apply_smearing`) — **on, toggleable** | **off** |
| first-arrival time | hard `segment_min` | per-photon times → soft order-stat NLL |
| output | per-PMT charge + per-PMT first-arrival time | per-photon `log_w`, times, idx + per-PMT total charge |

These are the ONLY differences that are *allowed*. Everything else (source photons,
propagation, geometry, optical params, K, MAXCELL, wavelength physics) must be **identical**.
The tests below each isolate one stage, hold everything else fixed, neutralize the allowed
differences (e.g. average the Bernoulli/MC over many keys; drive `temperature → 0`), and
check the two paths agree. Any residual disagreement = an *unintended* forward-model
mismatch to fix.

### 0.1 Canonical sim-param block (record ALL of these every run — §4)
```
SOURCE   : photonsim{root_file, event_index, rot_axis, rot_angle, translation}  OR
           siren{model_dir, table, energy, Nphot, num_seeds_(a,b,c)}
TRACK θ  : energy[MeV], pos(x,y,z)[m], polar[rad], azim[rad], t0[ns]
ENGINE   : use_expected_value, is_data                 -> update_factors | sample
HIT_MODE : realistic | per_photon | aggregated | waveform | waveform_expected
TEMP     : None | float                                 (overlap softness)
K        : int                                          (scatter/bounce iterations)
MAXCELL  : max_sensors_per_cell (env MAXCELL)
N_PHOT   : n_photons
WLMODE   : wavelength_mode (bool)
SMEAR    : apply_smearing (per-sensor SK gain+time)
TTS_NS   : env per-photon time-smear sigma (0 = off)
PHYS     : physics_config path
OPTICS   : scatter_length, mie_scatter_length, g, wall_refl, sensor_refl,
           absorption_length, qe, qe_corrections(summary)
GRAD     : pos_grad_threshold, n_grad_iters            (forward-irrelevant; record anyway)
RNG      : key seed(s); N_avg (keys averaged for sample/Bernoulli paths)
DBG      : PSTEP_DBG flags (default empty)
c_med    : SPEED_OF_LIGHT_MATERIAL
```

---

## PART A — Forward-pipeline alignment (source held fixed)

Default fixtures unless a test says otherwise: SK geom + `SK_physics_config.json`,
1050 MeV muon, target track vertex (0,0,0) / polar 0.6 / azim 0.8 / t0 0, Mie off
(`mie_scatter_length=1e9`, `g=0`), `wavelength_mode=True`.

### A-prep. Test infrastructure
- **A-prep.1** Build a **PhotonSim → expected-engine** harness: feed PhotonSim photons
  (the same rotated/translated rays used by the truth) as the initial rays of the
  `update_factors` scan body, so the SAME photons can run through BOTH engines. (Needed
  for a true PhotonSim apples-to-apples; without it, PhotonSim only routes through `sample`.)
- **A-prep.2** Per-stage taps: dump `propagate_fn` outputs (sensor_weights, indices,
  times, positions, normals, inside_sensor) and the per-step 7-tuple, so each stage can be
  compared in isolation rather than only end-to-end.

### A0. Propagation determinism (sanity floor)
Same source photons, same positions/directions → `propagate_fn` output **bit-identical**
across two independent builds and across engine choice. (Propagation is shared; this must
be exact. If not, nothing downstream is trustworthy.)

### A1. Step engine — detection deposit, single step (K=1)
Feed an identical batch of per-photon step inputs `(position, direction, surface_distance,
normal, optical params, hit_sensor)` to **both** `photon_iteration_sample` (average over
N_avg keys) and `photon_iteration_update_factors`. Compare **E[detect deposit]**
(`detect_prob · reflection_attenuation`) per photon and summed.
- Expectation: **identical** in expectation (Mie off). detect_prob uses no RNG; the
  refactor showed `sample` and `update_factors` deposit `exp(-Dd/L)(1-r)exp(-Dd/abs)`.
- Criterion: mean |Δ| / charge < MC noise floor (∝ 1/√N_avg).

### A2. Step engine — continuing / survival factor, single step
Same inputs; compare `continuing_factor` (the inter-step survival multiplier):
`sample` (hard per-photon) averaged vs `update_factors`.
- **Known divergence**: `update_factors` survival is the *analytic mean-field* sum
  `reach·r·atten + scatter·atten_scat`, whereas `sample`/DiCE is a hard per-photon draw.
  Quantify the bias E[hard] − meanfield; confirm it → 0 in expectation per step and locate
  where the K≥2 trajectory divergence enters.

### A3. Step engine — full forward charge vs refactor-v2 (the regression check)
SIREN source (so both engines exist). Three predictors on the **same track + same key**,
Mie off:
1. `build_predictor` (current DiCE `update_factors`),
2. monkeypatched **refactor-v2 STE** `update_factors` (reconstructed body) in the same
   pipeline,
3. `build_truth_sim` (`sample`) averaged over N_avg keys.
Compare per-PMT charge for K ∈ {1, 2, 4, 8}.
- Expectation: **K=1 byte-identical** (1 vs 2); **K≥2 diverges** (mean-field vs hard).
- Deliverable: a number for "how much did the forward charge model change from
  refactor-v2 at the recon config K=8" — the core question of this whole exercise.

### A4. Overlap — soft vs hard
SIM predictor charge at `temperature ∈ {0.30, 0.10, 0.05, 0.02, 0.01}` vs TRUE hard
(`temperature=None`) per-PMT charge (sample averaged). Same source + key.
- Expectation: soft → hard as `temperature → 0`; quantify the residual at 0.1 (the value
  recon uses) and whether it is a per-PMT bias (ring blur) or just variance.

### A5. Overlap truncation — MAXCELL
Per-PMT charge + total charge vs `max_sensors_per_cell ∈ {4, 8, 16, 32}`, both paths.
- Known: 4 under-counts charge ~10% and damages the track Hessian (memory
  `recon-track-hessian-breakers`). Confirm convergence and pick the floor MAXCELL where
  TRUE and SIM agree.

### A6. Sensor response — charge (QE)
Identical flat `(weights, indices, times)` arrays → `make_hits_data` (Bernoulli QE,
averaged over N_avg keys) vs `make_hits_likelihood` (multiplicative QE weight). Compare
per-PMT total charge.
- Expectation: E[Bernoulli] = qe·weight → match to MC floor. Also check the per-sensor QE
  correction `qe_corrections` is applied identically in both.

### A7. Sensor response — first-arrival time
Identical flat arrays → hard `segment_min` (`make_hits_data`) vs soft-min
(`make_hits_simulation`, `temperature → 0`) vs per-photon order-stat used by
`first_arrival_nll`. Compare per-PMT first-arrival time on lit sensors.
- Expectation: soft-min → hard-min as `temperature → 0`; quantify the soft-min early-bias
  at the temperature used.

### A8. Smearing (TRUE only) — isolate the toggle
TRUE per-PMT charge + time with: (i) `TTS_NS=0`, `apply_smearing=False` (off);
(ii) `TTS_NS=2.5`, `apply_smearing=False` (per-photon time only);
(iii) `TTS_NS=0`, `apply_smearing=True` (per-sensor SK gain+time).
- Deliverable: the size and shape of each smearing's effect on charge and first-arrival
  time, so its absence in the SIM path is a *quantified, intentional* gap (not a surprise).

### A9. Full TRUE vs SIM, SIREN source — the alignment ladder
Start fully matched, then enable ONE known difference per rung, re-checking per-PMT charge
and first-arrival time each time (TRUE averaged over N_avg keys):
1. both engines, `temperature` matched (drive both to hard/`→0`), QE as weight, no smear, K
   matched, MAXCELL matched  → expect tight match (only engine mean-field vs hard).
2. + overlap: TRUE hard vs SIM soft 0.1.
3. + QE: TRUE Bernoulli vs SIM weight.
4. + smear: TRUE TTS 2.5 + SK on.
- Deliverable: a table attributing the total TRUE↔SIM charge/time difference to each
  individual knob. This is the master alignment result.

### A10. Wavelength mode
Per-PMT charge + time, both paths, `wavelength_mode ∈ {True, False}`.
- Confirm the per-photon λ physics (n(λ), scatter/abs(λ), QE(λ)) is applied identically in
  TRUE and SIM, and quantify scalar-vs-λ charge difference.

---

## PART B — Emission comparison: PhotonSim vs SIREN (pipeline held fixed)

Compare the raw emitted photons and the resulting detector coverage. SIREN returns
`(ray_vectors, ray_origins, photon_weights)` from
`photonsim_differentiable_get_rays(track_origin, track_direction, energy, Nphot, ...)`;
PhotonSim returns origins/directions/times/(wavelengths) from
`read_photon_data_from_photonsim(root, event)`. Match energy/track between the two.

### B1. Photon yield vs energy
N emitted (and detected) photons, PhotonSim per-event vs SIREN, across energies. Check the
SIREN `num_seeds` power-law (a,b,c) reproduces the mean PhotonSim yield and its energy
scaling.

### B2. Origins — longitudinal & transverse profile
dN/d(distance along track) and transverse spread from the vertex. PhotonSim (per-event and
averaged) vs SIREN. This is the longitudinal-shape info that drives the vertex fit.

### B3. Directions — Cherenkov cone
Distribution of cos(angle to track direction); azimuthal uniformity around the axis.
PhotonSim vs SIREN. Check the cone angle and angular width.

### B4. Emission times
dN/dt emission profile, and the (longitudinal-position, time) correlation (the wavefront).
PhotonSim vs SIREN (`predict_t0` baseline + geometric).

### B5. Wavelengths / spectrum
dN/dλ. PhotonSim (`PhotonWavelength` branch) vs SIREN's sampled spectrum. Confirms the λ
fed to the medium/QE is distributed the same.

### B6. Joint (distance, angle) table
The 2D `(distance-along-track, angle)` emission density the SIREN is trained on, vs the
PhotonSim 2D histogram. This is the object SIREN actually approximates — the most direct
fidelity check.

### B7. Detector coverage — per-PMT charge ring
Run PhotonSim photons and SIREN photons through the **same** pipeline (TRUE pipeline for an
apples-to-apples, or A-prep.1 expected harness) at the same track. Compare:
per-PMT charge map, total charge, lit-PMT set (IoU / overlap), occupancy distribution, ring
radius/width. **This is the residual map** that decides whether SIREN-mean ≈ PhotonSim-event.

### B8. Detector coverage — per-PMT first-arrival time
Same as B7 for the per-PMT first-arrival time pattern.

### B9. Per-event stochasticity
PhotonSim event-to-event spread of (B7/B8) vs SIREN (mean-field, deterministic given track
+ key). Quantifies the *irreducible* stochastic floor the user flagged: how much does a
single PhotonSim event deviate from the SIREN mean, per PMT and in the vertex-relevant
projections.

---

## 4. Logging protocol (apply after EVERY run)

After each test executes, append one record to `RUN_LOG.md`:

```
### <TEST-ID> — <one-line purpose>            [date]
PARAMS:  <full canonical block from §0.1, every field filled>
DELTA:   <only the fields that changed vs the previous logged run, old -> new>
SOURCE:  <photonsim event(s) / siren; N_avg keys; key seeds>
RESULT:  <the numbers: per-PMT |Δ| mean/max, totals, scatter, etc.>
VERDICT: <aligns within floor | divergence of size X, attributed to Y>
NEXT:    <what this implies for the next run>
```

Rules:
- **Never** report a number without its full PARAMS block — a charge/time value is
  meaningless without K, MAXCELL, temperature, N_phot, N_avg, smear, source.
- **DELTA is mandatory**: state exactly what changed from the previous run so every result
  is attributable to a single controlled change.
- One controlled change per run wherever possible (the ladder discipline of A9).
- Average sample/Bernoulli paths over N_avg keys and report N_avg; a single-key result is
  never quoted as the resolution/alignment.
- ≥20 PhotonSim events before any per-event claim (no single-event conclusions).
```
```
