# LUCiD Track Reconstruction — Complete Pipeline Documentation

**Scope:** single-particle (1050 MeV muon) reconstruction in a Super-Kamiokande-like
water-Cherenkov detector, using the JAX differentiable forward model + a Gauss-Newton
optimizer. Units: **meters / nanoseconds / MeV** throughout. Main script:
`gn_fisher_recon.py`. Truth = PhotonSim/GEANT4 photon tables; TTS = 2.5 ns.

> **One-line summary:** A consistent PSD Fisher–Gauss-Newton optimizer, run in
> SCALE9-preconditioned coordinates, on a *plain Poisson charge + first-arrival
> order-statistic time* loss with a single total-charge calibration. Resolution floor
> **E ~0±24 MeV (2.3%), vertex ~13 cm, direction ~1.8°, t0 ~0.4 ns**, capturing from the
> whole fiducial volume. The floor is **bias-limited by the SIREN emitter (cone too wide)**,
> not by the optimizer, the loss, information, or compute.

---

## 1. The forward model (what we invert)

`lucid/simulation/simulator.py::setup_event_simulator` assembles a JIT-compiled forward
map `(ParticleParams, DetectorParams) -> per-PMT (charge, time)`. Two instances are built:

| | DATA (`data_sim`) | PREDICTOR (`pred`) |
|--|-------------------|--------------------|
| emission | GEANT4 photon table (PhotonSim) | **SIREN** surrogate (`photonsim_differentiable_get_rays`) |
| engine | `temperature=None` → **HARD** (Bernoulli sample) | `temperature=0.1` → **SOFT** (expected value, `use_expected_value=True`) |
| hit mode | `realistic` (`make_hits_data`, hard `segment_min` first-arrival + per-photon TTS) | `per_photon` (returns raw per-photon `lw,ft,fi` + per-PMT `tot`) |
| K (scatter iters) | **8** | **8** |
| detector params | `default_detector_params=True` | `default_detector_params=True` (SAME) |
| n_photons | 400k | 500k |

**Pipeline (both differentiable, under `lax.scan`/`vmap`/`jit`):**
emission → propagation (`K=8` Rayleigh+Mie scatter / wall reflect / absorb) → sensor
response (charge sum + first-arrival time, soft overlap at `temperature`).

**Geometry:** SK from `config/SK_geom_config.json` → `config/sk_geometry.npz` (11096 PMTs:
7752 barrel R≈16.96 m, 1672 top + 1672 bottom at |z|=18.19 m). Tank R=16.96 m, half-height
18.19 m.

### ⚠️ FUNDAMENTAL CAVEAT — the predictor is a MEAN-FIELD engine
`use_expected_value=True` makes the predictor exact for **linear/mean** observables and
*incapable* of order statistics:
- **Charge = Σ(weights)** is a *mean* → `E[Σ]=Σ E[·]` → predictor exact → charge aligns
  with the GEANT4 mean.
- **First-arrival time = min** is a nonlinear *order statistic* → `E[min] ≠ min E[·]`.
  The mean-field forward gives every PMT a continuous arrival-time distribution with a
  spurious early tail (direct light reaching off-ring PMTs); for a dim PMT that early tail
  has no real photon behind it. **Trust the engine's means (charge), not its order
  statistics.** (This is *not* fixed by retraining SIREN — it is structural.)

  We handle first-arrival **correctly anyway** by NOT taking a model `min`: the likelihood
  is built from `R(t) = Σ wᵢΦ((t−fᵢ)/σ)` = *expected cumulative count before t* (a mean,
  hence mean-field-exact) plus the *analytic* order statistic `S(t)ⁿ`. Verified: the
  order-statistic predicted first-arrival matches the data at dim PMTs (median residual
  ~0 ns), whereas a naive hard-min diagnostic is biased +40–50 ns (misleading — do not use
  hard-min to judge the time term).

---

## 2. Parameters & truth

**9 fitted parameters (`ParticleParams`):**
`θ = [E, x, y, z, sinθ, cosθ, sinφ, cosφ, t0]` — direction carried as sin/cos of
polar+azimuth (avoids wrap-around and kinky `atan2` gradients).
`SCALE9 = [50, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2]` = natural per-parameter scales
(≈ 50 MeV, 0.2 m, 0.02 cos-units, 0.2 ns). **Energy is fixed at the gun value (1050 MeV)**;
the data has one truth energy.

**`RANDOMIZE=1`** (`rand_tf`): per-event isotropic direction (Rodrigues rotation by an
isotropic polar angle) + uniform fiducial vertex shift (radius ≤ 12 m, |z| ≤ 12 m). This is
what prevents tunnel-visioning on one favorable geometry.

**`NPHOT_EV`** cycles the 100 base PhotonSim events (`ev % NPHOT_EV` for the read, full `ev`
for the RANDOMIZE/start/detection seeds) → 1000 distinct (geometry, start, detection) fits
from 100 base showers (shower set repeats every 100 — geometry/start/detection do not).

---

## 3. The loss (finalized)

`lossf = chargeloss(μ, n) + time_term(tnll)`  (+ optional t0 prior, OFF by default).

### 3.1 Charge — Poisson NLL
`Σ (μ − n·log μ)`, μ = predicted per-PMT charge, n = observed. Assumes per-PMT Poisson
(variance=mean) and PMT independence. Carries **energy** (total light) and the
**longitudinal vertex + transverse position** through the spatial shape of μ.
- `CLOSS` knob: `poisson` (default) | `sqmse` | `anscombe` | `mse`. **√-MSE was tested and
  is WORSE** for single-event recon (−437 MeV on one event — it overfits the noisy dim/zero
  PMTs; the calibration √-MSE win pools 10⁴ PMTs and does not transfer). **Keep Poisson.**

### 3.2 Time — first-arrival ORDER-STATISTIC likelihood (NOT a soft-min)
Per lit PMT, observed first-arrival `tobs`, observed count `n`:
`R(t)=Σ wᵢ·½(1+erf((t−fᵢ)/(σ√2)))`, `S(t)=(μ−R(t))/μ`,
`tnll = −log(S(tlo)ⁿ − S(thi)ⁿ)` over a Δ-window `[tobs±Δ/2]`.
σ = `LOSS_SIGMA = 2.5 ns` (= TTS), Δ = `DELTA = 1.0 ns`. Carries **direction, t0, transverse
vertex**. Conditioned on the observed count n (count-conditioned = exactly unbiased in form).
- **This is already the right mean-field construction** (uses `R(t)`, a mean; analytic order
  statistic) — it is NOT the legacy soft-min (`make_hits_simulation`'s log-sum-exp min, used
  by the old `loss_t4` path). Do not confuse them.

### 3.3 `AMP_DETACH` (on by default, hardcoded)
In the time survival, the photon **weights `ww` AND the per-PMT total `muS`** are
`stop_gradient`'d, so the time term's gradient flows ONLY through the predicted times `ft` —
not the amplitude. This enforces **charge owns counts/energy, time owns geometry**; without
it the two terms fight (energy blows up +214 MeV). **You must detach both ww and muS** —
detaching only one explodes.

### 3.4 `TOT_N_SCALE = 0.982` — the energy fix (single calibration constant)
Scales the predicted per-PMT charge (`mu = tot*TOT_N_SCALE`) ≡ scaling SIREN's
`tot_n_photons` (propagation is linear). **SIREN over-emits photon count by +1.9%
(position-independent normalization)**; scaling to the energy-zero removes the coherent
energy bias (−27 → ~0 MeV) and tightens energy RMS 35→24 MeV.
- ⚠️ **Must keep the TIME term scale-invariant:** `muS` (time-survival denominator) stays
  **UNSCALED** = `stop_gradient(max(tot,1e-8))` because `R(t)` is built from unscaled `ww`.
  Scaling `muS` too corrupts the survival → **far-capture collapses (10 m basin 100%→0%)**
  while the near-truth floor is robust to it. This bug cost a basin; it is fixed.
- The +3 MeV residual energy bias at 0.982 is real but tiny (0.3%); **0.983 would zero it.**
- Proper home: scale `tot_n_photons` a,c by ~0.982 in the muon/water photonsim config.

### 3.5 What was tried on the loss and REJECTED
- **OVERLAP_RENORM (separate overlap term): NOT needed.** It is a *pure global scalar*
  (`overlap.py`: "it is a pure scale"), exactly redundant with `TOT_N_SCALE`. Set
  `OVERLAP_RENORM=1.0` and fold into the one total calibration. (It's also temperature-
  dependent, which a fixed 1.009 can't track.)
- **EDETACH (separate overall charge from Poisson): NOT needed.** With the total calibrated,
  plain Poisson == EDETACH (energy reads off the calibrated total). A clean 1-eval
  factorization (Poisson = total(E) × multinomial-shape(geom)) exists (`stop_gradient`
  renorm so amplitude cancels) but adds nothing.
- **Temperature: irrelevant to resolution** (0.02–0.1 identical) → keep 0.1 (stable/fast
  gradients).
- **Time-loss variations all fail** (the residual is charge-driven, see §6): σ (2.5 optimal,
  widening destroys good events), robust clip/Huber/trim (no effect — bias is coherent not
  outlier), occupancy gate either direction (dim PMTs hold transverse info — excluding them
  blows up transverse; including only dim is worse), charge-consistency gate, global time
  weight (down-weighting makes wanderers WORSE → time *resists* the drift). **The time loss
  is correct and exhausted; nothing improves it.**

---

## 4. The optimizer — Fisher–Gauss-Newton (`gn_fisher_recon.py::fit`)

Gauss-Newton, because the autodiff **Hessian of the track loss is broken** (indefinite, neg
diagonal, cond ~1e10). We build a PSD Fisher metric and step against it.

**Metric** `F = F_charge + F_time` (consistent — g and F on the same fixed `KEYS`):
- `F_charge = Jμᵀ diag(1/μ) Jμ` (exact Poisson Fisher, PSD).
- `F_time = Jlᵀ Jl` (time-NLL **score-covariance** / empirical Fisher — the time FD Hessian
  is indefinite but the score-cov is PSD; Phase-1 gate verified across track angles).
- Both Jacobians via **finite differences** (`jacfwd`/`jacrev` BLOCKED by the DiCE
  `custom_vjp` — autodiff can't push through the engine's custom gradient). `FDH = 0.4·SCALE9`.

**Step:** `dθ = SCALE9 ⊙ [ −LR·(Fs + λ·diag(Fs) + RIDGE_I·median(diagFs)·I + 1e-9·I)⁻¹·(SCALE9⊙g) ]`,
with `Fs = SCALE9[:,None]·F·SCALE9[None,:]` (preconditioned), then min‖g‖ readout.

**Finalized knobs (all proven):**

| knob | value | why |
|------|-------|-----|
| `PRECOND` | **1 (mandatory)** | Raw F is position-dominated (`F_xx~1e5` vs `F_EE~1`) → energy step ~1e4× too small → **energy FREEZES**. Solve in SCALE9-scaled coords. Was *the* session bug; the prior "NO SCALE9" advice was wrong, and all pre-fix energy numbers were the freeze. |
| `NOCLIP` | 1 | The old step-clip was never the far-descent bottleneck (GN *under*-shoots far out). |
| `LR` | 8 | Step multiplier — amplifies the consistent GN under-shoot; reaches the floor from 10 m in ~150 iters (vs FAIL at NITERS=1000 with the clip). min‖g‖ catches overshoot. |
| `RIDGE_I` | 0.3 | Additive **Levenberg** floor = the clip's real job: bounds the FLAT (t0↔longitudinal) eigenvalue that `λ·diagF` (Marquardt) cannot. **`RIDGE_I=0` destabilizes even at truth** (t0 runs to 52 ns) → the degeneracy is fundamental. 0.1–0.3 both stable. |
| `REFRESH` | 8 | Cache the FD Fisher 8 steps = consistency sweet spot. REFRESH=1/2 reinjects FD key-noise → flat dir stalls; higher (12–200) degrades longitudinal (frozen-far-point curvature wrong near truth). Also 2× faster than refresh=1. |
| `NKEYS` | 4 | MC keys averaged in g and F. |
| `READOUT` | `ming` (min‖g‖) | NOT min-loss, NOT final. Robust to LR=8 overshoot + the changing metric; final under-reports energy at low NITERS. |
| `NITERS` | 250 (1σ) / 300–350 (far) | Energy under-converges at low NITERS (80 was too few). |
| `LAM` | 0.01 | Marquardt damping (numerical safety; ridge-robust 0.003–0.05). |

**Capture (validated):** 100% from the whole fiducial volume — vertex to 10 m (75% at the
15 m tank edge), energy ±900 MeV (effectively unbounded — total-light monotonic), t0
~20–40 ns. **Direction (~25–30°) is the only narrow basin** (the ~42° Cherenkov ring stops
overlapping the data ring past ~45°). So **from-scratch needs only a coarse direction seed
(<~25°)** — a charge-ring centroid gives far better than that; vertex/E/t0 then capture from
anywhere realistic. (This SUPERSEDES the old "track-vertex seeding is fiTQun-hard".)

---

## 5. Phase-0 fixed hyperparameters (proof-gated)
- `DELTA=1.0 ns` (insensitive 0.5–2; 4 degrades).
- `MAXCELL=4` (the 3.6% grid-charge loss CANCELS for matched truth=pred; 4=8=16 in noise).
- `K=8` (truth & forward MUST match; K=1 is unphysically half-dark).
- `temperature=0.1` (charge gradient AD==FD: cosine 0.96–0.999, magnitude 0.76–0.85;
  forward occupancy preserved).
- `SIGMA=2.5` (= TTS; scanned, optimal — widening destroys good events).

---

## 6. Key physics findings

1. **The floor is BIAS-limited, not info/optimizer/compute-limited.** CRB says vertex info
   ~3 cm, energy ~1.3 MeV; realized ~13 cm / 24 MeV. **More photons HURT** (sharpen the
   biased argmin). The gap is the **SIREN emitter mean-shape mismatch**.
2. **Root cause = SIREN's mean Cherenkov cone is TOO WIDE** (measured at the *generation*
   level, no propagation, via `gen_compare.py`): width **12.5° vs GEANT4 11.1°** (+13%),
   under-fills the ring peak (brightest-200 PMTs S/G=0.76, −24%), over-fills the dim halo
   (+8%); **total light conserved**. Plus the +1.9% count over-emission (fixed by
   TOT_N_SCALE). This one defect drives the ~13 cm longitudinal floor, the ~1.8° direction
   floor, AND (via charge-shape) the energy bias and the wanderers.
3. **The energy bias is charge-driven, not time/normalization.** E-sweeps: charge E-argmin at
   the *truth geometry* is UNBIASED (+4±7 MeV); the full-fit −35 MeV arises because the
   wide-cone charge mismatch pushes vertex+direction off-truth, and energy is dragged via
   charge coupling (LOSSCHK: −6 MeV @truth-geom → −38 @fit-geom). The count fix removes the
   coherent part. **NO E↔vtx degeneracy** (corr −0.04).
4. **The ~6% "wanderers"** drift along the **t0↔longitudinal degeneracy** (vertex-along-track
   + t0 move together to ~30–45 cm; energy/direction stay fine). **They are CHARGE-driven**
   (down-weighting time makes them WORSE → time resists). Only two things break it: a t0
   prior (rejected — needs an unphysically tight σ~0.1 ns) or the emitter fix. The optimizer
   cannot (genuinely flat valley; RIDGE_I=0.6 fails). They are intrinsic to ~6% of
   geometries, flat vs start offset (NOT a far-start failure).
5. **SIREN emission TIMES match GEANT4** (predict_t0 0.02 ns RMSE; longitudinal profile
   matches, no tail past the 4.7 m muon range). So the time mismatch is NOT emission — and
   the time *likelihood* is correct (§1 caveat). The residual is all the cone (charge).

---

## 7. Diagnostic modes & scripts (all env-gated in `gn_fisher_recon.py`)
| mode | purpose |
|------|---------|
| `ESWEEP` / `ZESWEEP` | sweep E (and 2D z,E) loss/grad → E-bias source |
| `LOSSCHK` | loss(truth) vs loss(fit) + E-argmin @truth-geom vs @fit-geom → real-min vs optimizer |
| `GRADCHK` | at-truth gradient charge vs time per param; per-PMT charge residual by hit-time |
| `SELFDATA` | SIREN-mean as data → isolates loss/optimizer bias from GEANT4-vs-mean |
| `CMP` | direct SIREN-mean vs GEANT4-mean per-PMT charge (over showers) |
| `HIST` | save full per-iteration trajectory (`hist_<TAG>_<ev>.npz`) |
| `TRACE` | per-iter |g|/dvtx/E-grad printout |
| capture offsets | `START_OFF`(+`START_PIDX`), `E_OFF`, `DIR_OFF`, `T0_OFF`, `JIT_ALL`, **`BJIT`** (basin jitter: all params further, within basin: `BJIT_V/E/D/T`) |
| `TOT_N_SCALE`, `CLOSS`, `EDETACH`, `TW`, `TROBUST`/`TCAP`, `OCC_GATE`/`OCC_MIN`, `CGATE`, `T0_PRIOR`, `DATA_NKEY` | loss-form experiments (mostly rejected, see §3.5) |

Standalone: `gen_compare.py` (generation count+cone, no propagation), `gen_time_compare.py`
(emission times), `mgpu.py` (auto-detect free GPUs, split events/cases), `plot_*.py`,
`hitdump.py` (event-display charge maps).

---

## 8. Studies run
- **1σ-jitter resolution study** (1000 events; ~770 completed): start ~19 cm vtx / ~25 MeV /
  ~0.8° / ~0.1 ns. Floor: **E +3±24 (2.3%), vtx med 13.1 (lon 12.5/tra 9.2), dir 1.77°,
  t0 0.39 ns**, 6.2% wanderers; resolution flat vs start offset. Trajectories in
  `study1k_trajectories/`.
- **Basin/capture maps:** vertex 2.5/5/10/15 m, direction 20/45/90°, t0 20/60 ns, energy
  400/900 MeV → §4 capture radii.
- **Further-from-truth (BJIT) study** (1000 events, RUNNING, ~9.7 h): vtx ≤5 m, E ±400 MeV,
  dir ≤12°, t0 ±15 ns (each within its basin). Trajectories in `bjstudy_trajectories/`.

---

## 9. ⚠️ CAVEATS & CONSIDERATIONS (read before extending)
1. **Mean-field forward** (§1): charge is exact in the mean; first-arrival is an order
   statistic the engine can't represent — we handle it analytically via `R(t)`. Do NOT judge
   the time term by a hard-min of predictor rays (misleading +50 ns); use the order-stat
   median (matches data ~0 ns).
2. **Bias-limited floor:** the emitter (cone width), not the optimizer/loss/info/compute,
   sets the floor. More photons or more iterations will NOT improve ~13 cm / ~1.8°.
3. **`PRECOND` is mandatory** — without it energy freezes. Never drop the SCALE9
   preconditioning.
4. **`TOT_N_SCALE` must NOT scale the time survival `muS`** — scale only the charge `mu`,
   keep `muS` unscaled, or far-capture dies.
5. **`RIDGE_I=0` is forbidden** (t0↔lon runaway); use 0.1–0.3.
6. **AMP_DETACH must detach BOTH `ww` and `muS`** — one alone explodes energy.
7. **√-MSE charge loss is worse than Poisson** for single-event recon (overfits dim-PMT
   noise) — do not adopt the calibration √-MSE result here.
8. **The data is a single GEANT4 SAMPLE; SIREN is the MEAN.** Any comparison/visualization
   must be like-with-like — e.g. Poisson-SAMPLE the sim before an event display, or average
   the data. (A sample-vs-mean event display looks broken when it isn't.)
9. **Event-display indexing:** the charge array is indexed by the *detector's internal sensor
   ID*; `sk_geometry.npz['positions_mm']` is a DIFFERENT permutation. Plot at
   `detector.all_points` with `detector.ID_to_case` (0=barrel,1=top,2=bottom) — NOT the npz
   arrays — or every PMT lands at the wrong place and the ring dissolves.
10. **FD Jacobians are forced** by the DiCE `custom_vjp` (autodiff blocked) — keep NKEYS≥4 to
    control FD/key noise; the FD step is `0.4·SCALE9`.
11. **Direction is the only seeding requirement** (~25–30° basin); everything else captures
    from the whole fiducial volume. A coarse charge-ring direction estimate suffices.
12. **6% wanderers (t0↔longitudinal)** are charge-driven and intrinsic; not fixable in the
    loss/optimizer. min‖g‖ readout often catches a good earlier iterate even when the last
    iterate drifts — judge by the *readout*, not the last iterate.
13. **Energy is fixed truth (1050 MeV)** in these studies; energy *resolution* is honest only
    when the start E is offset (the start-at-truth E was historically the frozen-energy
    artifact). The current count fix leaves a small +3 MeV residual (0.983 zeroes it).
14. **GPU memory:** ~8.5 GB/job on the 11 GB cards → one job per GPU (no co-tenancy; OOM
    otherwise). `mgpu.py` auto-detects free GPUs; env vars (not cmdline) carry `EVENT_START`
    so find jobs via `/proc/<pid>/environ`.
15. **mgpu parent can die after a wave** (foreground `sleep` is harness-blocked; launch
    without sleeps) — but per-event `hist_*.npz` + log lines are written incrementally, so
    aggregate from those, not the end-of-job `gf_*.txt`.
16. **Calibration vs recon engines:** the implicit/expected calibration engine is ~√12
    quieter than real Poisson; recon uses the *sample* `data_sim` as data, so quote honest
    (sampled) numbers, not the toy-MC.

---

## 10. Open frontiers
- **Only real lever left = the SIREN emitter cone** (sharpen the ~42° ring; `gen_compare.py`
  measures the per-angle kernel). A fixed output-correction kernel (like the count fix) would
  be SIREN-agnostic and close vertex+direction+energy together. We have **accepted the floor**
  for now.
- Per-angle/occupancy time-bias *calibration* if a first-arrival-only readout is kept and the
  cone is not fixed.
- Multi-particle / ring-counting, real-data path (ROOT events), production integration.

---

## 11. Finalized run command (reference)
```
RANDOMIZE=1 JIT_ALL=1            # truth varied + 1σ start (or BJIT=1 for further)
NOCLIP=1 LR=8 REFRESH=8 RIDGE_I=0.3 PRECOND=1 NITERS=250 NKEYS=4   # optimizer
PRED_TEMP=0.1 OVERLAP_RENORM=1.0 TOT_N_SCALE=0.982 EDETACH=0 CLOSS=poisson   # finalized loss
python gn_fisher_recon.py     # via mgpu.py for multi-GPU
```
