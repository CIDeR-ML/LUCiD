#!/usr/bin/env python3
"""Auto-detect free GPUs and run a recon script over many events (and/or multiple cases), SPLITTING the work
across all GPUs so we wait less. Each job = one GPU process over an event slice. Pools jobs (queues extras when
jobs > GPUs), then AGGREGATES the per-event results across all chunks and prints the all-parameter resolution.

Works with any script that reads EVENT_START / EVENT_COUNT / TAG / CUDA_VISIBLE_DEVICES and prints lines like
'#  ev... E<resid> |vtx|<cm>cm (lon.. tra..) dir<deg> t0<ns>' (gn_fisher_recon.py, loss_t4.py).

Usage:
  # one config, split 96 events across ALL free GPUs:
  python mgpu.py gn_fisher_recon.py 0:96 floor "ADAPT=0 LAM=0.01 RANDOMIZE=1 READOUT=final NITERS=300"
  # several CASES (each split across GPUs); case syntax name:ENV=val,ENV2=val2 :
  python mgpu.py gn_fisher_recon.py 0:32 sweep "RANDOMIZE=1 NITERS=300" --cases lam003:LAM=0.003 lam05:LAM=0.05
Env: MAXFREE (MB, GPU counts as free if used<MAXFREE; default 1500).
"""
import os,sys,subprocess,time,math,re,glob
import numpy as np

def free_gpus(max_used=None):
    max_used=int(os.environ.get('MAXFREE','1500')) if max_used is None else max_used
    out=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits']).decode()
    g=[int(l.split(',')[0]) for l in out.strip().splitlines() if int(l.split(',')[1].strip())<max_used]
    sel=os.environ.get('GPUS','')                       # restrict to a comma-list, e.g. GPUS=0,1,2,3,4
    if sel: allow=set(int(x) for x in sel.split(',')); g=[x for x in g if x in allow]
    return g

def parse_env(s): return dict(x.split('=',1) for x in s.replace(',',' ').split()) if s else {}

def aggregate(prefixes):
    E=[];V=[];D=[];T=[];LON=[];TRA=[]
    for f in sum([glob.glob(f'/tmp/mg_{p}*.log') for p in prefixes],[]):
        for l in open(f):
            m=re.search(r'E\s*([+-][0-9.]+)\s+\|vtx\|\s*([0-9.]+)cm \(lon\s*([0-9.]+) tra\s*([0-9.]+)\).*dir\s*([0-9.]+).*t0\s*([+-][0-9.]+)',l)
            if m: E.append(float(m.group(1)));V.append(float(m.group(2)));LON.append(float(m.group(3)));TRA.append(float(m.group(4)));D.append(float(m.group(5)));T.append(float(m.group(6)))
    if not V: print("  (no results parsed)"); return
    E,V,D,T,LON,TRA=map(np.array,(E,V,D,T,LON,TRA)); ok=V<60; n=ok.sum()
    print(f"  N={n} | E bias={E[ok].mean():+.1f} RMS={np.sqrt((E[ok]**2).mean()):.1f} | vtx med={np.median(V[ok]):.1f} RMS={np.sqrt((V[ok]**2).mean()):.1f}(lon{np.sqrt((LON[ok]**2).mean()):.1f}/tra{np.sqrt((TRA[ok]**2).mean()):.1f}) | dir med={np.median(D[ok]):.2f} | t0 RMS={np.sqrt((T[ok]**2).mean()):.2f}",flush=True)

def main():
    if len(sys.argv)<4: print(__doc__); return
    script=sys.argv[1]; e0,e1=[int(x) for x in sys.argv[2].split(':')]; ec=e1-e0; tag=sys.argv[3]
    base=sys.argv[4] if len(sys.argv)>4 and not sys.argv[4].startswith('--') else ""
    cases=[]
    if '--cases' in sys.argv: cases=sys.argv[sys.argv.index('--cases')+1:]
    base_env=parse_env(base)
    gpus=free_gpus()
    if not gpus: print("NO FREE GPUS (raise MAXFREE if a job we own is idle)"); return
    nG=len(gpus); chunk=math.ceil(ec/nG)
    caselist=cases if cases else [f"{tag}:"]
    jobs=[]   # (name, env)
    for c in caselist:
        cname,cenv=(c.split(':',1)+[''])[:2]; cenv_d=parse_env(cenv)
        for k in range(nG):
            s=e0+k*chunk; cc=min(chunk,e0+ec-s)
            if cc<=0: break
            nm=f"{cname}_{s}"
            jobs.append((nm,{**base_env,**cenv_d,'EVENT_START':str(s),'EVENT_COUNT':str(cc),'TAG':nm}))
    print(f"# mgpu: {nG} free GPUs {gpus} | {len(jobs)} jobs ({len(caselist)} case(s) x {math.ceil(ec/chunk)} chunks of ~{chunk} ev) | script {script}",flush=True)
    queue=list(jobs); running={}; freeg=list(gpus); t0=time.time()
    while queue or running:
        while queue and freeg:
            g=freeg.pop(0); name,env=queue.pop(0)
            e=dict(os.environ); e.update(env); e['CUDA_VISIBLE_DEVICES']=str(g)
            lf=open(f'/tmp/mg_{name}.log','w'); p=subprocess.Popen([sys.executable,script],env=e,stdout=lf,stderr=subprocess.STDOUT)
            running[g]=(p,name,lf); print(f"[{time.strftime('%H:%M:%S')}] GPU{g} <- {name} (ev {env['EVENT_START']}+{env['EVENT_COUNT']})",flush=True)
        time.sleep(5)
        for g,(p,name,lf) in list(running.items()):
            if p.poll() is not None:
                lf.close(); print(f"[{time.strftime('%H:%M:%S')}] GPU{g} done {name} rc={p.returncode}",flush=True); del running[g]; freeg.append(g)
    print(f"# all {len(jobs)} jobs done in {(time.time()-t0)/60:.1f} min. AGGREGATE:",flush=True)
    for c in caselist:
        cname=c.split(':',1)[0]; print(f"  [{cname}]",end=''); aggregate([cname])

main()
