"""POISSON FA bias decomposition — where does the residual -0.22m come from?
Split the time NLL into -log_r (rate) and +R (survival), sweep sigma, per-event x argmin. K=8 MAXCELL=16.
Env: TTS_NS NPHOT NKEYS NEV.  Usage: CUDA_VISIBLE_DEVICES=g python loss_poisfa_decomp.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '16')); NEV = int(os.environ.get('NEV', '12'))
K = 8; PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
print(f"# POISSON FA decomp  TTS={os.environ['TTS_NS']} NPH={NPH} NKEYS={NKEYS} NEV={NEV} K={K} MC={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH, apply_smearing=False)
ND = H.num_detectors(pred); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def make(oc, ot, hit, sigma, mode):  # mode: 'full' | 'logr' | 'R'
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hit = jax.lax.stop_gradient(hit)
    LOGN_C = float(np.log(sigma * np.sqrt(2 * np.pi))); SQ = float(np.sqrt(2.0))
    def loss(theta, key):
        log_w, ft, fi, total_charge = pred(H.theta_to_track(theta), key)
        d = (ot - theta[6])[fi] - ft
        log_r = segment_logsumexp(log_w + (-0.5 * (d / sigma) ** 2 - LOGN_C), fi, ND)
        R = jax.ops.segment_sum(jnp.exp(log_w) * 0.5 * (1.0 + erf(d / (sigma * SQ))), fi, num_segments=ND)
        FL = -60.0; lr = jnp.maximum(log_r, FL); empty = log_r <= (FL + 1.0)
        term = (-lr + R) if mode == 'full' else ((-lr) if mode == 'logr' else R)
        usable = hit & (~empty)
        return jnp.sum(jnp.where(usable, term, 0.0))
    return loss

def argmin(lj, i=1, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts)
    c = np.array([np.mean([float(lj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

print("# --- term decomposition @ sigma=2.5 (per-event x bias) ---", flush=True)
for mode in ['full', 'logr', 'R']:
    b = []
    for ev in range(NEV):
        oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(5000 + ev))
        b.append(argmin(jax.jit(make(oc, ot, hit, 2.5, mode))))
    b = np.array(b); print(f"#  time-{mode:5s}  x bias {b.mean():+.3f} std {b.std():.3f} m", flush=True)
print("# --- sigma sweep (full time term, per-event x bias) ---", flush=True)
for sg in [1.5, 2.5, 4.0, 6.0, 10.0]:
    b = []
    for ev in range(NEV):
        oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(5000 + ev))
        b.append(argmin(jax.jit(make(oc, ot, hit, sg, 'full'))))
    b = np.array(b); print(f"#  sigma={sg:5.1f}  x bias {b.mean():+.3f} std {b.std():.3f} m", flush=True)
print("# READ: which term (rate/survival) carries the bias; does sigma~TTS or larger zero it (width-matching) or is it flat (forward residual).", flush=True)
