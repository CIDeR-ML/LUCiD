"""Validate "density x DiCE" inside the FULL simulator.

Monkeypatch lucid.sources.siren_rays.photonsim_differentiable_get_rays with a density x DiCE
version, BEFORE building the predictor (build_predictor imports the simulator which captures
the function reference at module-import / setup time). We patch BOTH the source module and the
already-imported binding inside lucid.simulation.simulator.

Checks:
  (a) total charge / occupancy at 1050 MeV ~ 5000  (forward magnitude preserved)
  (b) d(total charge)/d(energy):  E[AD] over NK keys  vs  central FD over NK keys  -> ratio ~1.0

Set MODE env var to "old" to run the unpatched scheme for comparison, "new" for density x DiCE.
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
from functools import partial
from jax import random

MODE = os.environ.get("MODE", "new")
MATCH_OCCUPANCY = os.environ.get("MATCH_OCCUPANCY", "0") == "1"
np.set_printoptions(precision=6, suppress=True)

# ---- import the original (for the shared boilerplate) and the SIREN model ----
import lucid.sources.siren_rays as SR
from lucid.sources.siren_rays import (
    normalize_inputs_jit, denormalize_log_predictions, generate_random_cone_vectors)
from lucid.siren.core import SIREN
from lucid.utils import normalize

sg = jax.lax.stop_gradient


@partial(jax.jit, static_argnums=(3,))
def dice_get_rays(track_origin, track_direction, energy, Nphot,
                  table_data, model_params, key,
                  num_seeds_a=0.035882, num_seeds_b=1.417106, num_seeds_c=2.75):
    """Density x DiCE replacement for photonsim_differentiable_get_rays.

    Sample bins ~ density (categorical, SELECTION DETACHED), gather the EXACT grid
    (angle,dist) of the sampled bin (no argsort), and set the per-photon weight to
        weight = density(bin, E) * dice_score,   dice_score = exp(logp - sg(logp)).
    Forward: dice_score == 1  => weight == density (the old self-normalized forward,
    occupancy preserved).  Gradient: d weight/dE = d density/dE + density * d logp/dE
    => carries BOTH the weight grad AND the emission-geometry score.
    """
    key, subkey = random.split(key)
    (n_bins, energy_min, energy_max, angle_min, angle_max, distance_min, distance_max,
     angle_bins, distance_bins, angle_dist_grid, angle_mesh, distance_mesh,
     log_min, log_max) = table_data

    # full grid density (log-space SIREN output)
    evaluation_grid = jnp.stack([
        jnp.full_like(angle_mesh, energy).ravel(),
        angle_mesh.ravel(),
        distance_mesh.ravel(),
    ], axis=1)
    normalized_grid = normalize_inputs_jit(evaluation_grid, energy_min, energy_max,
                                           angle_min, angle_max, distance_min, distance_max)
    model = SIREN(hidden_features=256, hidden_layers=3, out_features=1)
    logw_grid, _ = model.apply(model_params, normalized_grid)
    logw_grid = jnp.squeeze(logw_grid)                      # (n_grid,) normalized-log density

    # density in physical (denormalized) units -> the actual emission weight scale
    dens = denormalize_log_predictions(logw_grid, log_max, log_min)   # (n_grid,)
    dens = jnp.clip(dens, 1e-12, None)

    # categorical proposal proportional to density, SELECTION DETACHED
    p = dens / jnp.sum(dens)
    key, sampling_key = random.split(key)
    idx = random.choice(sampling_key, dens.shape[0], (Nphot,), p=sg(p))

    angle_dist_mesh = jnp.asarray(angle_dist_grid)
    sel = angle_dist_mesh[idx]
    sampled_angle = sel[:, 0]
    sampled_dist = sel[:, 1]

    # DiCE score on the (detached-sampled) bins, in the SAME denormalized density space
    logp = jnp.log(p[idx])
    score = jnp.exp(logp - sg(logp))                       # ==1 forward; carries d logp/dE
    weight = dens[idx] * score                             # density x dice  (no second eval)

    # --- OCCUPANCY MATCH (optional): rescale per-photon weight to the OLD scheme's scale.
    # The old scheme samples UNIFORMLY among the top num_seeds bins and weights by density,
    # so its expected per-photon weight = mean(top-k densities). Density-x-DiCE samples
    # ~density, so its expected per-photon weight = sum d^2 / sum d. Multiply by the DETACHED
    # ratio so the forward occupancy matches the old scheme; a stop_gradient constant does
    # NOT change the AD/FD gradient RATIO (it scales numerator and FD identically).
    if MATCH_OCCUPANCY:
        # Calibrate the scale at a FROZEN reference energy E_CAL so the constant does NOT
        # inject spurious dc/dE into the gradient. c is a fixed forward calibration constant.
        E_CAL = 1050.0
        cal_grid = jnp.stack([
            jnp.full_like(angle_mesh, E_CAL).ravel(), angle_mesh.ravel(), distance_mesh.ravel(),
        ], axis=1)
        cal_ng = normalize_inputs_jit(cal_grid, energy_min, energy_max,
                                      angle_min, angle_max, distance_min, distance_max)
        cal_lw, _ = model.apply(model_params, cal_ng)
        cal_dens = jnp.clip(denormalize_log_predictions(jnp.squeeze(cal_lw), log_max, log_min), 1e-12, None)
        num_seeds = jnp.int32(num_seeds_a * (E_CAL ** num_seeds_b) + num_seeds_c)
        ds_sorted = jnp.sort(cal_dens)[::-1]
        topk_mask = jnp.arange(cal_dens.shape[0]) < num_seeds
        mean_topk = jnp.sum(jnp.where(topk_mask, ds_sorted, 0.0)) / jnp.sum(topk_mask)
        e_dice = jnp.sum(cal_dens * cal_dens) / jnp.sum(cal_dens)
        c = sg(mean_topk / e_dice)                          # frozen constant, no dc/dE
        weight = weight * c

    # boundary mask (sampled bins are exactly on-grid, so this is all-True, kept for parity)
    weight = jnp.where(sampled_angle < angle_min, 0.0, weight)
    weight = jnp.where(sampled_angle > angle_max, 0.0, weight)
    weight = jnp.where(sampled_dist < distance_min, 0.0, weight)
    weight = jnp.where(sampled_dist > distance_max, 0.0, weight)

    # geometry: rays on the Cherenkov cone, origins along the track at the sampled range
    photon_thetas = sampled_angle
    subkey, subkey2 = random.split(subkey)
    ray_vectors = generate_random_cone_vectors(track_direction, photon_thetas, Nphot, subkey)
    ranges = sampled_dist / 1000.0
    ray_origins = (jnp.ones((Nphot, 3)) * track_origin[None, :]
                   + ranges[:, None] * normalize(track_direction[None, :]))

    # IMPORTANT: weight here is ALREADY the denormalized density (not the SIREN log output),
    # so unlike the original we do NOT call denormalize_log_predictions again.
    return ray_vectors, ray_origins, weight


# ---------------------------------------------------------------------------
# Monkeypatch BEFORE build_predictor (which imports the simulator)
# ---------------------------------------------------------------------------
if MODE == "new":
    SR.photonsim_differentiable_get_rays = dice_get_rays
    # simulator.py did `from lucid.sources.siren_rays import photonsim_differentiable_get_rays`
    import lucid.simulation.simulator as SIM
    SIM.photonsim_differentiable_get_rays = dice_get_rays
    print("[patched] using density x DiCE get_rays", flush=True)
else:
    print("[unpatched] using ORIGINAL argsort get_rays", flush=True)

import recon_harness as H

pred = H.build_predictor(temperature=None, K=7, n_photons=50_000)

NK = int(os.environ.get("NK", "32"))
E0 = 1050.0
base = jnp.array([E0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])   # energy,x,y,z,polar,azim,t0


def total_charge_at(theta, key):
    log_w, ftimes, fidx, total_charge = pred(H.theta_to_track(theta), key)
    return jnp.sum(total_charge)


tc_fn = jax.jit(total_charge_at)
# d total_charge / d energy  via AD (grad wrt theta[0])
grad_e_fn = jax.jit(lambda theta, key: jax.grad(lambda th: total_charge_at(th, key))(theta)[0])

keys = jax.random.split(jax.random.PRNGKey(0), NK)

# (a) occupancy
occ = np.array([float(tc_fn(base, k)) for k in keys])
print(f"\n(a) total charge / occupancy at {E0} MeV: mean={occ.mean():.1f}  std={occ.std():.1f}  "
      f"(target ~5000)", flush=True)

# (b) energy gradient: AD vs central FD, both averaged over the SAME keys
H_FD = float(os.environ.get("FD_H", "5.0"))   # MeV
theta_p = base.at[0].add(H_FD)
theta_m = base.at[0].add(-H_FD)
ad = np.array([float(grad_e_fn(base, k)) for k in keys])
fd = np.array([(float(tc_fn(theta_p, k)) - float(tc_fn(theta_m, k))) / (2 * H_FD) for k in keys])
print(f"\n(b) d(total charge)/d(energy), averaged over {NK} keys, FD h={H_FD} MeV:", flush=True)
print(f"     AD  mean={ad.mean():.4f}  std={ad.std():.4f}", flush=True)
print(f"     FD  mean={fd.mean():.4f}  std={fd.std():.4f}", flush=True)
print(f"     ratio AD/FD = {ad.mean()/ (fd.mean()+1e-30):.4f}   (target ~1.0)", flush=True)
