"""ALIGNMENT A6 — sensor-response QE unit test. make_hits_data (Bernoulli QE, averaged) vs
make_hits_likelihood (multiplicative QE weight) on IDENTICAL flat arrays. E[Bernoulli]=qe*w must
match the weight path per sensor. Also checks per-sensor qe_corrections applied identically.
Env: N ND M.  Usage: CUDA_VISIBLE_DEVICES=g python align_a6.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.sensor_response import make_hits_data, make_hits_likelihood
np.set_printoptions(precision=4, suppress=True, linewidth=160)
N = int(os.environ.get('N', '400000')); ND = int(os.environ.get('ND', '120')); M = int(os.environ.get('M', '64'))
QE = 0.226
k = jax.random.PRNGKey(0); k1, k2, k3 = jax.random.split(k, 3)
idx = jax.random.randint(k1, (N,), 0, ND)
w = jax.random.uniform(k2, (N,), minval=0.2, maxval=1.0)            # varied per-photon weights
t = jax.random.uniform(k3, (N,), minval=1.0, maxval=80.0)
qc = jnp.asarray(0.5 + np.random.RandomState(0).rand(ND))          # non-trivial per-sensor QE corrections

_, _, _, q_lik = make_hits_likelihood(w, idx, t, ND, qe=QE, qe_corrections=qc)
q_data = np.mean([np.asarray(make_hits_data(w, idx, t, ND, qe=QE, qe_corrections=qc,
                 rng_key=jax.random.PRNGKey(100 + s), apply_smearing=False)[0]) for s in range(M)], 0)
q_lik = np.asarray(q_lik)
lit = q_lik > 1e-6
rel = np.abs(q_data - q_lik)[lit] / (q_lik[lit] + 1e-9)
print(f"# A6 QE unit: N={N} ND={ND} M={M} qe={QE}", flush=True)
print(f"# total charge: Bernoulli-avg {q_data.sum():.2f}  vs  weight {q_lik.sum():.2f}  (Δtot {100*(q_data.sum()-q_lik.sum())/q_lik.sum():+.2f}%)", flush=True)
print(f"# per-sensor relErr: mean {rel.mean():.2%}  max {rel.max():.2%}  (MC floor ~ 1/sqrt(M*<n>) )", flush=True)
print(f"# corr {np.corrcoef(q_data[lit], q_lik[lit])[0,1]:.5f}", flush=True)
print(f"# VERDICT: Bernoulli QE (TRUE) == multiplicative QE weight (SIM) in expectation, qe_corrections identical.", flush=True)
