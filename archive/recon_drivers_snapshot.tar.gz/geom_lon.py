"""MODEL-INDEPENDENT geometric longitudinal estimator vs the SIREN Poisson fit. The Poisson longitudinal
is limited by the SIREN ring-SHAPE mismatch (~20cm, coherent, not fixable by robust losses). A purely
GEOMETRIC estimate uses only the Cherenkov angle: the OUTER edge of the charge ring sits at angle
theta_c = arccos(1/n) from the track axis, measured FROM THE VERTEX. For a candidate longitudinal lambda
the per-PMT angle alpha_i = angle(P_i - V(lambda), d); solve for lambda where the charge-weighted upper
edge of the alpha-distribution equals theta_c. No SIREN -> immune to the ring-shape mismatch (but exposed
to track-extent / scattering smearing of the edge). Head-to-head bias/scatter/RMS over N events.
Env: NPHOT NKT NEV NW.  Usage: CUDA_VISIBLE_DEVICES=g python geom_lon.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.geometry import generate_detector
np.set_printoptions(precision=3, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKT = int(os.environ.get('NKT', '4')); NEV = int(os.environ.get('NEV', '25'))
NW = float(os.environ.get('NW', '1.34')); K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '16'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
TGT_POL = 0.6; TGT_AZ = 0.8; ts = np.array([1050.0, 0, 0, 0, TGT_POL, TGT_AZ, 0.0])
THC = float(np.arccos(1.0/NW))                         # Cherenkov angle (rad)

def _rod(v, ax, an):
    ax = ax/(np.linalg.norm(ax)+1e-12); return v*np.cos(an)+np.cross(ax, v)*np.sin(an)+ax*(ax@v)*(1-np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins'])/100.0; _, _, vt = np.linalg.svd(P-P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0@dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax/(np.linalg.norm(ax)+1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

# only need the data sim (model-independent) + a pred for the Poisson baseline
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHOT)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(pred); det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(p, a): return np.array([np.sin(p)*np.cos(a), np.sin(p)*np.sin(a), np.cos(p)])
d_true = dvec(ts[4], ts[5]); dummy = H.theta_to_track(jnp.array(ts))
qof = jax.jit(lambda th, key: pred(H.theta_to_track(th), key)[3])
lam = np.unique(np.concatenate([np.arange(-1.5, 1.501, 0.04), np.arange(-0.1, 0.1001, 0.01)]))
MU = np.clip(np.stack([np.mean([np.array(qof(jnp.array(ts+np.array([0, d_true[0]*l, d_true[1]*l, d_true[2]*l, 0, 0, 0])), jax.random.PRNGKey(1000+13*k))) for k in range(3)], 0) for l in lam]), 1e-8, None)
print(f"# GEOM-LON NEV={NEV} theta_c={np.degrees(THC):.1f}deg  {len(lam)} lon pts", flush=True)

def alpha_edge(V, Q, hit, p):
    """charge-weighted p-quantile of the per-PMT angle alpha=angle(P-V, d) over hit PMTs (the ring's OUTER edge)."""
    vec = DP[hit] - V[None, :]; al = np.arccos(np.clip((vec@d_true)/(np.linalg.norm(vec, axis=1)+1e-9), -1, 1))
    o = np.argsort(al); w = Q[hit][o]; cw = np.cumsum(w)/w.sum(); return al[o][np.searchsorted(cw, p)]
def geom_lon(Q, hit, p):
    """solve for lambda where the alpha-edge = theta_c (root of edge(lambda)-theta_c, monotone in lambda)."""
    ev = np.array([alpha_edge(ts[1:4]+l*d_true, Q, hit, p) for l in lam]) - THC
    s = np.where(np.diff(np.sign(ev)))[0]
    if len(s) == 0: return lam[np.argmin(np.abs(ev))]*100
    i = s[0]; return (lam[i] + (lam[i+1]-lam[i])*(-ev[i]/(ev[i+1]-ev[i])))*100
def pois_lon(Q):
    c = np.array([np.sum(MU[i]-Q*np.log(MU[i])) for i in range(len(lam))]); j = int(np.argmin(c))
    lo = max(0, j-2); hi = min(len(lam), j+3); a, b, _ = np.polyfit(lam[lo:hi], c[lo:hi], 2)
    return (-b/(2*a) if a > 0 else lam[j])*100

PCT = [0.80, 0.90, 0.95]; res = {f'GEOM{int(p*100)}': [] for p in PCT}; res['POISSON'] = []
for ev in range(NEV):
    pd = photon_data_for(ev)
    Q = np.mean([np.array(jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev+j), pd))[0]) for j in range(NKT)], 0)
    hit = Q > 0
    res['POISSON'].append(pois_lon(Q))
    for p in PCT: res[f'GEOM{int(p*100)}'].append(geom_lon(Q, hit, p))
    print(f"#   ev{ev:2d}  POIS:{res['POISSON'][-1]:+6.1f}  " + "  ".join(f"G{int(p*100)}:{res[f'GEOM{int(p*100)}'][-1]:+6.1f}" for p in PCT), flush=True)

print(f"\n# longitudinal over {NEV} events: bias  scatter  RMS  [cm]  (GEOM = model-independent Cherenkov-ring edge)", flush=True)
for name in ['POISSON'] + [f'GEOM{int(p*100)}' for p in PCT]:
    a = np.array(res[name]); print(f"#   {name:9s} bias {a.mean():+6.1f}  scatter {a.std():5.1f}  RMS {np.sqrt(a.mean()**2+a.std()**2):5.1f}", flush=True)
# inverse-variance combine the best geom percentile with Poisson (if independent, beats either)
gp = min(PCT, key=lambda p: np.std(res[f'GEOM{int(p*100)}'])); g = np.array(res[f'GEOM{int(gp*100)}']); po = np.array(res['POISSON'])
cc = np.corrcoef(g, po)[0, 1]; wv = 1/g.var(); wp = 1/po.var(); comb = (wv*g+wp*po)/(wv+wp)
print(f"# corr(GEOM{int(gp*100)}, POISSON)={cc:+.2f}  inverse-var COMBINED bias {comb.mean():+5.1f} scatter {comb.std():4.1f} RMS {np.sqrt(comb.mean()**2+comb.std()**2):4.1f}", flush=True)
print(f"# if GEOM independent of POISSON (low corr) and comparable scatter -> combination beats the {po.std():.0f}cm charge floor.", flush=True)
