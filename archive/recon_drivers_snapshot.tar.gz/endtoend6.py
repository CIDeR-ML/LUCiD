"""END-TO-END v6: v1's good seed (transverse vtx + dir + E) + a 1D lCEN LINE-SEARCH along the track axis
for the longitudinal DOF (the ONE degenerate direction) + lCEN-augmented refiner. Rationale:
  - v1 radial point-fit (origin_time_loss) gives TRANSVERSE vertex (~20cm) + charge-axis direction (~2.5deg)
    + total-charge energy, but longitudinal is +7m (Cherenkov virtual source).
  - longitudinal is ONE unconstrained DOF -> a 1D LINE-SEARCH (not a volume grid) along d, scored by lCEN
    (model charge-centroid on axis; probe_lon: argmin EXACTLY at truth, unbiased ~10cm, wide). Adam can't
    traverse 7m in 80 steps; a direct line-search jumps to the minimum.
  - refiner = lE + WCEN*lCEN + WT*lT_gd polishes (lCEN holds longitudinal/stops drift; lT_gd does transverse+dir+t0).
Env: TRUTH TTS_NS NKG SPS WT WCEN TKS EVENT NW LSPAN LSN. Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 python endtoend6.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.grid_search import hierarchical_position_grid_search_4d, get_detector_bounds
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
WT = float(os.environ.get('WT', '1.0')); WCEN = float(os.environ.get('WCEN', '3.0'))
NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '16')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0'))
NW = float(os.environ.get('NW', '1.34')); LSPAN = float(os.environ.get('LSPAN', '12.0')); LSN = int(os.environ.get('LSN', '49'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi); C = 0.299792; G = float(np.sqrt(NW ** 2 - 1.0))
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points)); BOUNDS = get_detector_bounds(det)

def dvec(pol, az): return jnp.array([jnp.sin(pol) * jnp.cos(az), jnp.sin(pol) * jnp.sin(az), jnp.cos(pol)])

def lcen_only(theta, key, oc):       # model longitudinal charge-centroid mismatch (for the line search)
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    d = dvec(theta[4], theta[5]); cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / sumobs
    return ((cen_p - cen_o) @ d) ** 2
lcen_j = jax.jit(lcen_only)

def lt_only(theta, key, oc, ot, hi, sig):   # timing-only lT_gd, for the 1D t0 line-search (vertex fixed => well-posed)
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
lt_j = jax.jit(lt_only)

def geom_seed(oc, ot, hi):
    hm = np.array(hi); P = DP[jnp.array(hm)]; tobs = np.array(ot)[hm]; q = np.array(oc)[hm]; Pn = np.array(P)
    r = hierarchical_position_grid_search_4d(jnp.array(Pn), jnp.array(tobs), jnp.array(q),
        true_position=ts[1:4], true_t0=ts[6], t0_guess=0.0, detector_bounds=BOUNDS, n_div=5, t0_n_div=5,
        levels=6, fraction=1.0, t0_min=-15.0, t0_max=15.0, verbosity=0)
    Vrp = np.array(r['best_position']); t0 = float(r['best_t0'])             # transverse-good, long +7m
    dv = Pn - Vrp[None, :]; dv = dv / (np.linalg.norm(dv, axis=1, keepdims=True) + 1e-9)
    ax = (q[:, None] * dv).sum(0); ax = ax / (np.linalg.norm(ax) + 1e-9)
    pol = float(np.arccos(np.clip(ax[2], -1, 1))); az = float(np.arctan2(ax[1], ax[0]))
    E = float(estimate_muon_energy_from_photon_count(float(q.sum())))
    # 1D lCEN line-search for the longitudinal DOF along d
    lam = np.linspace(-LSPAN, LSPAN, LSN); vals = []
    for L in lam:
        th = np.array([E, Vrp[0] + L * ax[0], Vrp[1] + L * ax[1], Vrp[2] + L * ax[2], pol, az, t0])
        vals.append(float(lcen_j(jnp.array(th), jax.random.PRNGKey(11), jnp.array(oc))))
    Lbest = lam[int(np.argmin(vals))]; V = Vrp + Lbest * ax
    # RECOMPUTE t0 from the Cherenkov wavefront at the corrected vertex (the old t0 was tied to the +7m
    # point-fit vertex -> ~19ns off; without this the refiner drifts longitudinal back out via the t0 degeneracy)
    a = Pn - V[None, :]; apar = a @ ax; aperp = np.sqrt(np.maximum((a * a).sum(1) - apar ** 2, 1e-9))
    res = tobs - (apar + aperp * G) / C; o = np.argsort(res); cw = np.cumsum(q[o]) / (q.sum() + 1e-9)
    t0g = float(np.interp(0.08, cw, res[o]))                                 # early/direct-edge t0 (rough)
    # 1D lT_gd line-search for t0 (vertex now FIXED by lCEN -> degeneracy broken -> t0 well-posed via timing)
    t0s = t0g + np.linspace(-8.0, 8.0, 33); tv = []
    for tt in t0s:
        th = np.array([E, V[0], V[1], V[2], pol, az, tt])
        tv.append(float(lt_j(jnp.array(th), jax.random.PRNGKey(13), jnp.array(oc), jnp.array(np.array(ot)), jnp.array(hm), 4.0)))
    t0 = float(t0s[int(np.argmin(tv))])
    return np.array([E, V[0], V[1], V[2], pol, az, t0])

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    d = dvec(theta[4], theta[5]); cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / sumobs
    lCEN = ((cen_p - cen_o) @ d) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WCEN * lCEN + WT * lT
gfn = jax.jit(jax.grad(loss))

def refine(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g; mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t): return float(np.degrees(np.arccos(np.clip(np.array(dvec(t[4], t[5])) @ np.array(dvec(ts[4], ts[5])), -1, 1))))
def lon(t): return float(((np.array(t) - ts)[1:4] @ np.array(dvec(ts[4], ts[5]))) * 100)
def report(tag, th): return f"{tag}: vtx={vtx(th):6.1f}cm (lon={lon(th):+6.0f}) dir={degf(th):5.2f}deg t0_err={abs(th[6]-ts[6]):5.2f}ns E_err={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"

print(f"# ENDTOEND6 TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} NW={NW} WCEN={WCEN} LSPAN={LSPAN} LSN={LSN} (v1 seed + lCEN line-search + lCEN refiner)", flush=True)
print(f"#   truth theta = {ts}", flush=True)
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0 = geom_seed(oc, ot, hi); thf = refine(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    print(f"  key {tk}  {report('SEED ', th0)}", flush=True)
    print(f"  key {tk}  {report('FINAL', thf)}", flush=True)
SE = np.array([[vtx(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():6.1f}cm dir={SE[:,1].mean():5.2f}deg t0={SE[:,2].mean():5.2f}ns E={SE[:,3].mean():5.1f}%", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():6.1f}cm dir={FE[:,1].mean():5.2f}deg t0={FE[:,2].mean():5.2f}ns E={FE[:,3].mean():5.1f}%  TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
