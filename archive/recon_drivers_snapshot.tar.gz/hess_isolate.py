"""DECISIVE ISOLATION: is the broken autodiff Hessian a property of the OPTICAL path (smooth physics,
the mie_hunter calibration case the user says was EXACT) or the TRACK path (geometry: propagator
intersection + sensor selection + overlap + multi-bounce)?

Same pipeline, same clean charge-MSE probe L = sum((q-oc)^2) (no log/division -> no near-dark-sensor
blowup; curved in BOTH optical and track directions; at truth q~oc so H ~ 2 J^T J = Fisher curvature).
  - OPTICAL Hessian: d2L/d(optical)^2  (track fixed -> geometry constant -> overlap distances constant)
  - TRACK   Hessian: d2L/d(theta)^2    (geometry varies through every intersection/selection)
Run with the CONSISTENT C-inf erf overlap so the overlap is provably NOT a breaker; whatever残 remains
in the track block is then pure geometry. Sanitizer custom_vjp bypassed (needed for 2nd-order AD).
(erf overlap removes the forward/backward mismatch AND is C-inf, so it cannot break the Hessian.)
Usage: CUDA_VISIBLE_DEVICES=g OVERLAP_ANALYTIC=erf python hess_isolate.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
import recon_harness as H, recon_ps_setup as PS
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=140)

OV = os.environ.get('OVERLAP_ANALYTIC', '(none)')
NKEYS = int(os.environ.get('NKEYS', '24')); NPH = 40000; K = int(os.environ.get('KK', str(PS.K)))
MAXCELL = int(os.environ.get('MAXCELL', '4')); CYLEPS = os.environ.get('CYL_SQRT_EPS', '0')
SC = np.array(H.PARAM_SCALE)

# baked predictor -> grab its DetectorParams; open predictor -> takes (track, dp, key)
pred_baked = H.build_predictor(temperature=0.1, K=K, n_photons=NPH)
DP0 = pred_baked.default_detector_params
pred_open = setup_event_simulator(
    H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False, use_expected_value=True,
    hit_mode='per_photon', max_sensors_per_cell=MAXCELL, physics_config=H.PHYS,
    default_detector_params=False, particle='muon', wavelength_mode=True,
    pos_grad_threshold=K, n_grad_iters=K)

ts = np.array([1050.0, 0.0, 0.0, 0.0, 0.6, 0.8, 0.0])
trk = H.theta_to_track(jnp.asarray(ts))
oc = jax.lax.stop_gradient(pred_open(trk, DP0, jax.random.PRNGKey(999))[3])   # reference charge

OPT = ['scatter_length', 'wall_reflection_rate', 'sensor_reflection_rate', 'absorption_length', 'qe']
base = np.array([float(getattr(DP0, n)) for n in OPT])
def dp_from(mult):
    return DP0._replace(**{n: getattr(DP0, n) * mult[i] for i, n in enumerate(OPT)})

def L_opt(mult, key):
    q = pred_open(trk, dp_from(mult), key)[3]
    return jnp.sum((q - oc) ** 2)
def L_trk(theta, key):
    q = pred_open(H.theta_to_track(theta), DP0, key)[3]
    return jnp.sum((q - oc) ** 2)

ks = [jax.random.PRNGKey(60000 + i) for i in range(NKEYS)]
def ad_fd(L, x0, scl, n, h=0.3):
    g = jax.jit(jax.grad(L)); he = jax.jit(jax.hessian(L))
    gbar = lambda x: np.mean([np.array(g(jnp.asarray(x), k)) for k in ks], 0)
    Had = np.mean([np.array(he(jnp.asarray(x0), k)) for k in ks], 0) * np.outer(scl, scl)
    Hfd = np.zeros((n, n))
    for j in range(n):
        d = h * scl[j]
        Hfd[:, j] = (gbar(x0 + np.eye(n)[j] * d) - gbar(x0 - np.eye(n)[j] * d)) / (2 * h) * scl
    Hfd = 0.5 * (Hfd + Hfd.T)
    cos = float(Had.ravel() @ Hfd.ravel() / (np.linalg.norm(Had.ravel()) * np.linalg.norm(Hfd.ravel()) + 1e-12))
    rel = float(np.linalg.norm(Had - Hfd) / (np.linalg.norm(Hfd) + 1e-12))
    return Had, Hfd, cos, rel, bool(np.isfinite(Had).all())

print(f"=== overlap={OV}  NKEYS={NKEYS}  K={K}  max_per_cell={MAXCELL}  cyl_sqrt_eps={CYLEPS} ===", flush=True)
mult0 = np.ones(5)
Hao, Hfo, co, ro, fo = ad_fd(L_opt, mult0, base * 0.0 + 1.0, 5)   # optical: scale=1 (relative mult)
print(f"[OPTICAL block 5x5]  finite={fo}  cosine(AD,FD)={co:.3f}  rel_err={ro:.3f}", flush=True)
print("  AD diag:", np.diag(Hao), flush=True)
print("  FD diag:", np.diag(Hfo), flush=True)
Hat, Hft, ct, rt, ft = ad_fd(L_trk, ts, SC, 7)                    # track
pb = slice(1, 6)
ct_pos = float(Hat[pb, pb].ravel() @ Hft[pb, pb].ravel() /
               (np.linalg.norm(Hat[pb, pb].ravel()) * np.linalg.norm(Hft[pb, pb].ravel()) + 1e-12))
print(f"[TRACK block 7x7]    finite={ft}  cosine(AD,FD)={ct:.3f}  rel_err={rt:.3f}  pos-block cosine={ct_pos:.3f}", flush=True)
print("  AD diag:", np.diag(Hat), flush=True)
print("  FD diag:", np.diag(Hft), flush=True)
print(f"\nVERDICT: optical cos={co:.3f} vs track cos={ct:.3f} -> "
      f"{'GEOMETRY path is the breaker (optical clean, track broken)' if co > 0.9 and ct < 0.7 else 'inconclusive / both affected'}", flush=True)
