"""Reusable PhotonSim-truth setup for the recon analysis (loss surface / gradients / CRB / HP).
Truth = is_data simulator fed the event's REAL Cherenkov photons. The event track is SHIFTED+ROTATED
(via photon_data) to a clean, well-determined target track (central vertex, non-axial direction) so the
analysis isn't confounded by the near-axial degeneracy or edge effects.
Prediction = SIREN+DiCE expected per-photon simulator. make_loss = raw Poisson charge NLL + first_arrival.
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.losses import first_arrival_nll, segment_logsumexp

ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
K = int(os.environ.get('RECON_K', '8'))   # truth/predictor scatter iters; >=8 (user constraint)

def _rod(v, axis, ang):
    axis = axis / (np.linalg.norm(axis) + 1e-12)
    return v * np.cos(ang) + np.cross(axis, v) * np.sin(ang) + axis * (axis @ v) * (1 - np.cos(ang))

def setup(event=0, nphot=80_000, target_vtx=(0.0, 0.0, 0.0),
          target_polar=0.6, target_azim=0.8, truth_key=0, truth_source='photonsim',
          pred_temperature=0.1):
    """truth_source='photonsim' -> is_data sim fed the rotated/shifted real photons (model mismatch).
    truth_source='siren'        -> SIREN sampling sim at the SAME track (self-consistent control).
    pred_temperature: predictor overlap. None -> hard step (straight-through backward); a float t ->
    soft Gaussian-acceptance overlap weight with sigma=t*sensor_radius (consistent fwd/bwd, no sigmoid)."""
    raw = read_photon_data_from_photonsim(ROOT, event)
    n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins']) / 100.0                       # cm -> m
    C = P - P.mean(0); _, _, vt = np.linalg.svd(C, full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    proj = (P - P.mean(0)) @ d0; vtx0 = P.mean(0) + proj.min() * d0   # true vertex (m)
    dt = np.array([np.sin(target_polar) * np.cos(target_azim),
                   np.sin(target_polar) * np.sin(target_azim), np.cos(target_polar)])
    axis = np.cross(d0, dt)
    if np.linalg.norm(axis) < 1e-7:
        axis = np.array([1.0, 0.0, 0.0]); ang = 0.0
    else:
        ang = float(np.arccos(np.clip(d0 @ dt, -1.0, 1.0)))
    vtx_rot = _rod(vtx0, axis, ang)
    trans = np.array(target_vtx) - vtx_rot                            # meters
    photon_data = {
        'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
        'photon_times': raw['photon_times'], 'N': n,
        'apply_rotation': True, 'rotation_axis': jnp.array(axis / (np.linalg.norm(axis) + 1e-12)),
        'rotation_angle': jnp.array(ang), 'apply_translation': True,
        'translation_vector': jnp.array(trans)}
    if 'wavelengths' in raw: photon_data['wavelengths'] = raw['wavelengths']

    theta_star = np.array([float(raw['energy']), target_vtx[0], target_vtx[1], target_vtx[2],
                           target_polar, target_azim, 0.0])

    pred = H.build_predictor(temperature=pred_temperature, K=K, n_photons=nphot)
    ND = H.num_detectors(pred)
    dummy = H.theta_to_track(jnp.array(theta_star))
    _mc = int(os.environ.get('MAXCELL', '16'))                        # truth uses >=16 candidates/cell
    # PER-PHOTON time smearing (TTS) is applied INSIDE make_hits_data (smears each photon then takes the
    # first-arrival min -> correct early-bias), gated by env TTS_NS. NOT smeared per-sensor here.
    if truth_source == 'siren':                                       # self-consistent control
        siren_truth = H.build_truth_sim(K=K, n_photons=nphot)
        def regen(tk):
            oc_, ot_ = jax.lax.stop_gradient(siren_truth(dummy, jax.random.PRNGKey(int(tk))))
            h_ = oc_ > 0; return jax.lax.stop_gradient(oc_), jax.lax.stop_gradient(jnp.where(h_, ot_, 0.0)), jax.lax.stop_gradient(h_)
    else:                                                             # real PhotonSim photons
        data_sim = setup_event_simulator(H.GEOM, n_photons=nphot, temperature=None, K=K, is_data=True,
            hit_mode='realistic', max_sensors_per_cell=_mc, physics_config=H.PHYS,
            default_detector_params=True, particle='muon', wavelength_mode=True, apply_smearing=False)
        def regen(tk):
            oc_, ot_ = jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(int(tk)), photon_data))
            h_ = oc_ > 0; return jax.lax.stop_gradient(oc_), jax.lax.stop_gradient(jnp.where(h_, ot_, 0.0)), jax.lax.stop_gradient(h_)
    oc, ot, hit = regen(truth_key)
    return dict(theta_star=theta_star, pred=pred, ND=ND, regen=regen,
                oc=jax.lax.stop_gradient(oc), ot=jax.lax.stop_gradient(ot),
                hit=jax.lax.stop_gradient(hit), sumobs=float(jnp.sum(oc)), nhit=int(hit.sum()))

def make_loss(S, WT=0.03, TAU=4.0, THR=0.0):
    """THR = minimum OBSERVED charge for a sensor to contribute its first-arrival time. Low-occupancy
    sensors have noisy earliest-photon times; raising THR keeps only well-determined first arrivals
    (sharper longitudinal-vertex / t0 constraint), at the cost of fewer timing sensors."""
    pred, ocf, otf, hitf, ND, SUMOBS = S['pred'], S['oc'], S['ot'], S['hit'], S['ND'], S['sumobs']
    tmask = jax.lax.stop_gradient(hitf & (ocf >= THR))    # concrete (built outside any jit)
    def loss(theta, key):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key)
        c = jnp.sum(q - ocf * jnp.log(q + 1e-8)) / SUMOBS * 100.0
        t = jnp.sum(jnp.where(tmask, first_arrival_nll(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
        return c, t, c + WT * t
    return loss


def n_time_sensors(S, THR=0.0):
    """How many sensors contribute a first-arrival time at this charge threshold."""
    import numpy as _np
    return int(_np.sum((_np.array(S['hit'])) & (_np.array(S['oc']) >= THR)))


def first_arrival_shape(log_w, flat_times, flat_idx, t_obs_per_sensor, tau, ND):
    """Count-DECOUPLED first-arrival NLL: the order-statistic timing likelihood with the energy/count
    carriers removed -- the `-log_w_total` count-reward is dropped and the per-sensor count N_s is
    stop_gradient'd. The arrival-time density uses per-sensor NORMALIZED weights, so dL/dEnergy ~ 0; the
    gradient wrt vertex/dir/t0 still flows through the predicted times. (cf. lucid.losses.first_arrival_nll)
    """
    t_obs = t_obs_per_sensor[flat_idx]
    x = (t_obs - flat_times) / tau
    valid = log_w > -20.0
    safe_log_w = jnp.where(valid, log_w, -1e6)
    log_w_total = segment_logsumexp(safe_log_w, flat_idx, ND)
    log_w_norm = safe_log_w - log_w_total[flat_idx]                       # normalized -> scale invariant
    log_kernel = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    log_f = segment_logsumexp(log_w_norm + log_kernel, flat_idx, ND)
    log_1mF = segment_logsumexp(log_w_norm + jax.nn.log_sigmoid(-x), flat_idx, ND)
    LF = -60.0
    empty = log_w_total <= (LF + 1.0)
    log_f_s = jnp.maximum(log_f, LF); log_1mF_s = jnp.maximum(log_1mF, LF)
    N_s = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(log_w_total, LF), LF, 50.0)))  # count detached
    loss = -log_f_s - (N_s - 1.0) * log_1mF_s                              # no -log_w_total term
    return jnp.where(empty, 0.0, loss)


def make_loss_sep(S, wE=1.0, wS=1.0, wT=0.03, TAU=0.3, THR=4.0, eps=1e-8):
    """ENERGY-SEPARATED loss = wE*L_E + wS*L_S + wT*L_T, where energy appears in L_E ONLY:
      L_E (energy)      = ((sum q_hat - sum q_obs)/sum q_obs)^2 * 100   -- total charge (0th moment)
      L_S (vertex/dir)  = -sum_i q_obs_i * log(p_hat_i),  p_hat=q_hat/sum q_hat  -- scale-invariant shape
      L_T (vtx/dir/t0)  = count-decoupled first_arrival_shape over sensors with q_obs >= THR
    By construction dL_S/dE = dL_T/dE ~ 0, so the energy gradient comes from L_E alone.
    Returns loss(theta,key) -> (lE, lS, lT, total)."""
    pred, ocf, hitf, ND, SUMOBS = S['pred'], S['oc'], S['hit'], S['ND'], S['sumobs']
    otf = S['ot']
    tmask = jax.lax.stop_gradient(hitf & (ocf >= THR))
    def loss(theta, key):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key)
        sumq = jnp.sum(q)
        lE = ((sumq - SUMOBS) / SUMOBS) ** 2 * 100.0
        phat = q / (sumq + eps)
        lS = -jnp.sum(ocf * jnp.log(phat + eps)) / SUMOBS * 100.0         # scale-invariant (energy cancels)
        lT = jnp.sum(jnp.where(tmask, first_arrival_shape(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
        return lE, lS, lT, wE*lE + wS*lS + wT*lT
    return loss
