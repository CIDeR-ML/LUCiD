"""Isolate the gradient discrepancy: charge-only vs time-only, across overlap temperatures.
Large temperature => smooth overlap => CRN finite-difference is a RELIABLE ground truth, so a
cosine<1 there is a genuine implementation bug. temperature=None => hard overlap (jumps)."""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import poisson_nll, first_arrival_nll

K, NPHOT = 7, 30_000
theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 0.0])

def run(temp):
    pred = H.build_predictor(temperature=temp, K=K, n_photons=NPHOT)
    truth = H.build_truth_sim(K=K, n_photons=NPHOT)
    ND = H.num_detectors(pred)
    oc, ot, hit = H.gen_truth(truth, theta_star, jax.random.PRNGKey(7))
    key = jax.random.PRNGKey(123)

    def charge_loss(th):
        _, _, _, q = pred(H.theta_to_track(th), key)
        return jnp.sum(poisson_nll(oc, q))

    def time_loss(th):
        lw, ft, fi, _ = pred(H.theta_to_track(th), key)
        nll = first_arrival_nll(lw, ft, fi, ot, 1.5, ND)
        return jnp.sum(jnp.where(hit, nll, 0.0))

    theta0 = theta_star + 0.3 * H.PARAM_SCALE
    eye = np.eye(7)
    hstep = 0.01 * np.array(H.PARAM_SCALE)
    print(f"\n=== temperature={temp} ===", flush=True)
    for name, lf in [('charge', charge_loss), ('time', time_loss)]:
        gad = np.array(jax.jit(jax.grad(lf))(theta0))
        L = jax.jit(lf)
        gfd = np.array([(float(L(theta0 + hstep[i] * eye[i])) - float(L(theta0 - hstep[i] * eye[i]))) / (2 * hstep[i])
                        for i in range(7)])
        cos = float(np.dot(gad, gfd) / (np.linalg.norm(gad) * np.linalg.norm(gfd) + 1e-12))
        mag = np.linalg.norm(gad) / (np.linalg.norm(gfd) + 1e-12)
        print(f"  {name:6s}: cos={cos:+.3f}  |AD|/|FD|={mag:.3f}", flush=True)
        print(f"     AD = {np.array2string(gad, precision=1, suppress_small=True)}", flush=True)
        print(f"     FD = {np.array2string(gfd, precision=1, suppress_small=True)}", flush=True)

for temp in [1.0, 0.3, None]:
    run(temp)
