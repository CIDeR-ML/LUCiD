"""END-TO-END pipeline validation: geometric SEED -> differentiable REFINER. The basin study proved
gradient descent is a LOCAL refiner (~2-3deg/30cm, un-wideable by annealing) and charge GD is vtx-biased
(52cm). So the coarse seed must be model-independent geometry:
  vertex+t0 : hierarchical_position_grid_search_4d scored by origin_time_loss (geometric TOF point-fit)
  direction : charge-weighted ring-axis = sum_i q_i * unit(PMT_i - vtx_seed)  (cone axis; model-independent)
  energy    : estimate_muon_energy_from_photon_count(sum charge)
Then the lE+lT_gd sigma-annealed refiner polishes. Reports SEED error AND FINAL error vs targets
(vtx<15cm, dir<2deg, t0<1ns, E<20%). Answers: does the geometric seed land in the basin, does the
refiner reach the targets? Env: TRUTH TTS_NS NKG SPS WT TKS EVENT.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 python endtoend.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.grid_search import hierarchical_position_grid_search_4d, get_detector_bounds
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000'))
WT = float(os.environ.get('WT', '1.0')); THR = float(os.environ.get('THR', '4.0'))
NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '16')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = np.array(det.all_points); BOUNDS = get_detector_bounds(det)

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WT * lT
gfn = jax.jit(jax.grad(loss))

def refine(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g
            mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def geom_seed(oc, ot, hi):
    """Model-independent coarse seed -> 7-vector theta0."""
    hm = np.array(hi); pos = DP[hm]; tobs = np.array(ot)[hm]; q = np.array(oc)[hm]
    # vertex + t0: geometric TOF point-fit (hierarchical grid on origin_time_loss)
    r = hierarchical_position_grid_search_4d(jnp.array(pos), jnp.array(tobs), jnp.array(q),
        true_position=ts[1:4], true_t0=ts[6], t0_guess=0.0, detector_bounds=BOUNDS,
        n_div=5, t0_n_div=5, levels=6, fraction=1.0, t0_min=-15.0, t0_max=15.0, verbosity=0)
    vtx = np.array(r['best_position']); t0 = float(r['best_t0'])
    # direction: charge-weighted Cherenkov-cone axis = sum q_i * unit(PMT_i - vtx)
    dvec = pos - vtx[None, :]; dvec = dvec / (np.linalg.norm(dvec, axis=1, keepdims=True) + 1e-9)
    axis = np.sum(q[:, None] * dvec, 0); axis = axis / (np.linalg.norm(axis) + 1e-9)
    polar = float(np.arccos(np.clip(axis[2], -1, 1))); azim = float(np.arctan2(axis[1], axis[0]))
    # energy: empirical total-charge fit
    E = float(estimate_muon_energy_from_photon_count(float(q.sum())))
    return np.array([E, vtx[0], vtx[1], vtx[2], polar, azim, t0]), r

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
def report(tag, th):
    return f"{tag}: vtx={vtx(th):6.1f}cm dir={degf(th):5.2f}deg t0_err={abs(th[6]-ts[6]):5.2f}ns E_err={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"

print(f"# ENDTOEND TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} SIGSCHED={SIGSCHED} NKG={NKG} SPS={SPS} (geometric seed -> lE+lT_gd refiner)", flush=True)
print(f"#   truth theta = {ts}", flush=True)
dtruth = np.array([np.sin(ts[4])*np.cos(ts[5]), np.sin(ts[4])*np.sin(ts[5]), np.cos(ts[4])])
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0, r = geom_seed(oc, ot, hi)
    thf = refine(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    # downstream-bias check: how far along +track-direction is the seed vertex?
    dv = th0[1:4] - ts[1:4]; along = float(dv @ dtruth); perp = float(np.linalg.norm(dv - along*dtruth))
    print(f"  key {tk}  {report('SEED ', th0)}  [vtx_seed=({th0[1]:.2f},{th0[2]:.2f},{th0[3]:.2f}) along_dir={along*100:+.0f}cm perp={perp*100:.0f}cm]", flush=True)
    print(f"  key {tk}  {report('FINAL', thf)}", flush=True)
    # CONTROL: refine from TRUE vtx+t0 but GEOMETRIC dir+E -> is fixing only the vertex seed sufficient?
    thc0 = th0.copy(); thc0[1:4] = ts[1:4]; thc0[6] = ts[6]
    thc = refine(thc0, oc, ot, hi, tk)
    print(f"  key {tk}  {report('CTRL ', thc)}  (true vtx/t0 + geom dir/E seed)", flush=True)
SE = np.array([[vtx(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():6.1f}cm dir={SE[:,1].mean():5.2f}deg t0={SE[:,2].mean():5.2f}ns E={SE[:,3].mean():5.1f}%", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():6.1f}cm dir={FE[:,1].mean():5.2f}deg t0={FE[:,2].mean():5.2f}ns E={FE[:,3].mean():5.1f}%  TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
