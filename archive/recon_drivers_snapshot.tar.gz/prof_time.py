"""Profile where the time goes: closure-baked-obs (jit per event = RECOMPILE) vs obs-as-args (jit once)."""
import os, time
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.simulation.simulator import setup_event_simulator
NPH = int(os.environ.get('NPHOT', '500000')); K = 8; MC = 16; SIGMA = 2.5; SQ = float(np.sqrt(2.0))
tt = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.asarray(tt))
def T(): return time.time()
t = T(); pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); print(f"build_predictor      : {T()-t:5.1f}s", flush=True)
ND = H.num_detectors(pred)
t = T(); truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
print(f"build_truth          : {T()-t:5.1f}s", flush=True)
t = T(); oc, ot = [x.block_until_ready() for x in jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(0)))]; print(f"truth call (compile) : {T()-t:5.1f}s", flush=True)
t = T(); oc2, ot2 = [x.block_until_ready() for x in jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(1)))]; print(f"truth call (cached)  : {T()-t:5.2f}s", flush=True)
hit = oc > 0
def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
def core(th, key, oc, ot, hit):
    lw, ft, fi, tot = pred(H.theta_to_track(th), key); w = jnp.exp(jnp.clip(lw, -60, 20)); tob = (ot - th[6])[fi]; mu = jnp.maximum(tot, 1e-8)
    def Rof(x): return jax.ops.segment_sum(w * 0.5 * (1 + erf((x - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Slo = jnp.clip((mu - Rof(tob - 0.5)) / mu, 1e-12, 1.0); Shi = jnp.clip((mu - Rof(tob + 0.5)) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(Shi) - jnp.log(Slo)), -1e-9)
    tm = jnp.sum(jnp.where(hit & (oc > 0), -n * jnp.log(Slo) - log1mexp(a), 0.0)); return jnp.sum(mu - oc * jnp.log(mu)) + tm
# PATTERN A: obs baked into closure, jit per obs
def make(oc, ot, hit):
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hit = jax.lax.stop_gradient(hit)
    return lambda th, key: core(th, key, oc, ot, hit)
t = T(); ljA = jax.jit(make(oc, ot, hit)); ljA(jnp.asarray(tt), jax.random.PRNGKey(0)).block_until_ready(); print(f"A jit(make(obs1)) cmp: {T()-t:5.1f}s", flush=True)
t = T(); ljA(jnp.asarray(tt + 0.01), jax.random.PRNGKey(0)).block_until_ready(); print(f"A same lj, new theta : {T()-t:5.2f}s", flush=True)
t = T(); ljB = jax.jit(make(oc2, ot2, oc2 > 0)); ljB(jnp.asarray(tt), jax.random.PRNGKey(0)).block_until_ready(); print(f"A jit(make(NEW obs)) : {T()-t:5.1f}s  <-- RECOMPILE if ~compile time = the bug", flush=True)
# PATTERN B: obs as args, jit once
cj = jax.jit(core)
t = T(); cj(jnp.asarray(tt), jax.random.PRNGKey(0), oc, ot, hit).block_until_ready(); print(f"B jit(core) compile  : {T()-t:5.1f}s", flush=True)
t = T(); cj(jnp.asarray(tt + 0.01), jax.random.PRNGKey(0), oc, ot, hit).block_until_ready(); print(f"B new theta (cached) : {T()-t:5.2f}s", flush=True)
t = T(); cj(jnp.asarray(tt), jax.random.PRNGKey(0), oc2, ot2, oc2 > 0).block_until_ready(); print(f"B NEW obs (args)     : {T()-t:5.2f}s  <-- CACHED = the fix", flush=True)
