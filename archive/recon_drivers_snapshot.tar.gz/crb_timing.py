"""CRB with different first-arrival TIMING LIKELIHOODS (same observable = one smeared min/PMT; the SIM keeps
all predicted photons and models the min differently). Does the CONSTRUCTIVE likelihood (proper Poisson
first-arrival using the full predicted intensity) extract MORE info (lower vertex floor) than the current
normalized-logistic one? At truth, over M data keys, F = cov(g_E + g_T), CRB = sqrt(diag(F^-1)).
  lT_old : fa_shape (logistic kernel, per-sensor NORMALIZED weights -> count-decoupled, lossy on intensity)
  lT_tts : Poisson lam*exp(-Lam), Gaussian sigma=SIG, ABSOLUTE intensity (full info, couples energy)
  lT_gd  : Gaussian kernel but count-decoupled (normalized)
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 EVENT=0 SIG=2.5 python crb_timing.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True, linewidth=160)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '150000'))
M = int(os.environ.get('M', '64')); TAU = float(os.environ.get('TAU', '2.5')); SIG = float(os.environ.get('SIG', '2.5'))
THR = float(os.environ.get('THR', '4.0')); EVENT = int(os.environ.get('EVENT', '0'))
POLAR = float(os.environ.get('POLAR', '0.6')); AZIM = float(os.environ.get('AZIM', '0.8'))
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1, target_polar=POLAR, target_azim=AZIM)
ts = jnp.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def gE_(theta, key, oc, ot, hi):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    return ((sumq - sumobs) / sumobs) ** 2 * 100.0
def lT_old(theta, key, oc, ot, hi):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); tobs = (ot - theta[6])[fi]; x = (tobs - ft) / TAU
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(TAU)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
def lT_tts(theta, key, oc, ot, hi):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); w = jnp.exp(jnp.clip(lw, -50.0, 10.0)); valid = lw > -20.0
    x = ((ot - theta[6])[fi] - ft) / SIG
    lam = jnp.where(valid, w * jnp.exp(-0.5 * x ** 2) / (SQ2PI * SIG), 0.0)
    Lam = jnp.where(valid, w * 0.5 * (1.0 + jax.lax.erf(x / SQ2)), 0.0)
    lamS = jax.ops.segment_sum(lam, fi, ND); LamS = jax.ops.segment_sum(Lam, fi, ND)
    return jnp.sum(jnp.where(hi & (oc >= THR), -jnp.log(lamS + 1e-12) + LamS, 0.0))
def lT_gd(theta, key, oc, ot, hi):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); tobs = (ot - theta[6])[fi]; x = (tobs - ft) / SIG
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(SIG * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
gE = jax.jit(jax.grad(gE_)); gO = jax.jit(jax.grad(lT_old)); gT = jax.jit(jax.grad(lT_tts)); gD = jax.jit(jax.grad(lT_gd))
GE, GO, GT, GD = [], [], [], []
for m in range(M):
    oc, ot, hi = regen(5000 + m); pk = jax.random.PRNGKey(m)
    GE.append(np.array(gE(ts, pk, oc, ot, hi)) * SC); GO.append(np.array(gO(ts, pk, oc, ot, hi)) * SC)
    GT.append(np.array(gT(ts, pk, oc, ot, hi)) * SC); GD.append(np.array(gD(ts, pk, oc, ot, hi)) * SC)
GE, GO, GT, GD = map(np.array, (GE, GO, GT, GD))
def crb(name, Gt):
    F = ((GE + Gt).T @ (GE + Gt)) / M; F = F + 1e-7 * np.trace(F) * np.eye(7)
    c = np.sqrt(np.clip(np.diag(np.linalg.inv(F)), 0, None))
    vtx = np.sqrt(sum((c[i] * SC[i]) ** 2 for i in [1, 2, 3])) * 100; dr = np.sqrt(sum((c[i] * SC[i]) ** 2 for i in [4, 5])) * deg
    print(f"  lE+{name:8s}: E={c[0]*SC[0]/float(ts[0])*100:5.1f}%  vtx={vtx:6.1f}cm  dir={dr:5.2f}deg  t0={c[6]*SC[6]:5.2f}ns", flush=True)
print(f"# CRB-by-TIMING-LIKELIHOOD TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} EVENT={EVENT} M={M} SIG={SIG}", flush=True)
crb('lT_old', GO); crb('lT_tts', GT); crb('lT_gd', GD)
