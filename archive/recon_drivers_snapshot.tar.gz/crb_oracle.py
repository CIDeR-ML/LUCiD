"""CRB floor oracle for the 7 reconstruction params (energy,x,y,z,polar,azim,t0).
Fisher from FINITE-DIFFERENCE Jacobians of the EXPECTED observables (data-like sim averaged
over keys) -> captures the TRUE energy->geometry dependence (sidesteps the SIREN AD detachment).
Gaussian/Poisson Fisher per sensor:  F = sum_s [ dq_s dq_s^T / var(q_s) + dt_s dt_s^T / var(t_s) ].
Reports charge-only vs charge+time CRB per param, the parameter CORRELATION (coupling), and
photon scaling. Usage: CUDA_VISIBLE_DEVICES=g python crb_oracle.py [NPHOT]
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

K = 7
NPHOT = int(float(sys.argv[1])) if len(sys.argv) > 1 else 50_000
NK = int(os.environ.get('NK', '48'))
# truth track: off-axis, t0=5ns; vertex offset so the geometry is non-degenerate
theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 5.0])
FD = 0.08 * np.array(H.PARAM_SCALE)   # FD step per param

truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(truth)
keys = jax.random.split(jax.random.PRNGKey(0), NK)

@jax.jit
def one(theta, key):
    return truth(H.theta_to_track(theta), key)

def observables(theta):
    Q = np.zeros((NK, ND)); T = np.zeros((NK, ND))
    for j, k in enumerate(keys):
        qc, qt = one(theta, k)
        Q[j] = np.array(qc); T[j] = np.array(qt)
    return Q, T

print(f"NPHOT={NPHOT}  NK={NK}", flush=True)
Q0, T0 = observables(theta_star)
q_mean = Q0.mean(0)
hit_frac = (T0 > 0).mean(0)
# CHARGE Fisher: every sensor with meaningful expected charge (incl. low-occupancy).
lit_c = q_mean > 0.02
# TIME Fisher: sensors hit often enough for a stable first-arrival estimate.
lit_t = hit_frac > 0.30
nc, nt = int(lit_c.sum()), int(lit_t.sum())
q_var = np.maximum(Q0[:, lit_c].var(0), np.maximum(q_mean[lit_c], 0.05))   # >= Poisson floor
Tm = np.where(T0[:, lit_t] > 0, T0[:, lit_t], np.nan)
t_var = np.maximum(np.nanvar(Tm, 0), 0.25)    # ns^2 floor (TTS ~ 0.5 ns)
print(f"charge sensors={nc} (total charge={q_mean[lit_c].sum():.0f})  time sensors={nt}", flush=True)

eye = np.eye(7)
dQ = np.zeros((7, nc)); dT = np.zeros((7, nt))
for i in range(7):
    Qp, Tp = observables(theta_star + jnp.array(FD[i] * eye[i]))
    Qm, Tm_ = observables(theta_star - jnp.array(FD[i] * eye[i]))
    dQ[i] = (Qp.mean(0) - Qm.mean(0))[lit_c] / (2 * FD[i])
    Tp_m = np.where(Tp[:, lit_t] > 0, Tp[:, lit_t], np.nan)
    Tm_m = np.where(Tm_[:, lit_t] > 0, Tm_[:, lit_t], np.nan)
    dT[i] = np.nan_to_num((np.nanmean(Tp_m, 0) - np.nanmean(Tm_m, 0)) / (2 * FD[i]))
    print(f"  Jacobian col {H.PARAM_NAMES[i]:6s} done", flush=True)

Fc = np.einsum('is,js->ij', dQ / q_var, dQ)              # charge Fisher
Ft = np.einsum('is,js->ij', dT / t_var, dT)              # time Fisher

def crb(F):
    Finv = np.linalg.inv(F + 1e-9 * np.eye(7) * np.trace(F))
    return np.sqrt(np.diag(Finv)), Finv

UNITS = ['MeV', 'm', 'm', 'm', 'rad', 'rad', 'ns']
sig_c, _ = crb(Fc)
sig_ct, Finv_ct = crb(Fc + Ft)
print("\n== CRB floor (1-sigma) per param ==", flush=True)
print(f"{'param':>7} {'unit':>4} {'charge-only':>13} {'charge+time':>13} {'time gain':>10}", flush=True)
for i, nm in enumerate(H.PARAM_NAMES):
    gain = sig_c[i] / (sig_ct[i] + 1e-30)
    print(f"{nm:>7} {UNITS[i]:>4} {sig_c[i]:>13.4g} {sig_ct[i]:>13.4g} {gain:>9.2f}x", flush=True)

# Parameter coupling (correlation matrix of the charge+time CRB)
D = np.sqrt(np.diag(Finv_ct))
corr = Finv_ct / np.outer(D, D)
print("\n== parameter correlation (charge+time CRB) — |rho|>0.7 are strongly coupled ==", flush=True)
print("        " + " ".join(f"{n:>6}" for n in H.PARAM_NAMES), flush=True)
for i, nm in enumerate(H.PARAM_NAMES):
    print(f"{nm:>7} " + " ".join(f"{corr[i,j]:>6.2f}" for j in range(7)), flush=True)
print(f"\nNote: CRB ~ 1/sqrt(N_photons). Run at multiple NPHOT to confirm scaling.", flush=True)
