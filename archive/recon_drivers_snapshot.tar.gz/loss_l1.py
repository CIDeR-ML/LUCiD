"""LOSS L1 — AD vs FD GRADIENT quality of the recon loss, with FD-step validation.

loss(theta,key) = charge Poisson-NLL + first-arrival time NLL (recon_harness.make_loss). Stochastic in
key -> COMMON RANDOM NUMBERS (same key for +/-h and the AD eval), averaged over NKEYS. Evaluated at
theta0 = theta_true + delta (a modest displacement so the gradient is non-trivial). Truth = SIREN self-
consistent (numerical differentiability is a property of the predictor map, not the truth physics).

Reports: (L1.0) FD h-plateau sweep [cosine(AD,FD), ||AD||/||FD||] to find where FD is trustworthy;
(L1.1) at the plateau h, per-parameter AD vs FD with relErr, split SCALAR(energy,t0) vs GEOMETRY(x,y,z,polar,azim);
per-key cosine spread (heavy-tail diagnostic).
Env: NPHOT NKEYS RECON_K MAXCELL TEMP.  Usage: CUDA_VISIBLE_DEVICES=g python loss_l1.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '24'))
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '8')); TEMP = float(os.environ.get('TEMP', '0.1'))
PN = H.PARAM_NAMES; PS = np.asarray(H.PARAM_SCALE)
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
delta = np.array([50.0, 0.10, 0.0, 0.0, 0.0175, 0.0, 0.5])         # E+50, x+10cm, polar+1deg, t0+0.5ns
theta0 = jnp.asarray(theta_true + delta)
print(f"# L1 grad AD-vs-FD  NPH={NPH} NKEYS={NKEYS} K={K} MAXCELL={MC} TEMP={TEMP}", flush=True)
print(f"# theta0 = theta_true + [E+50, x+0.10, polar+0.0175, t0+0.5]  (non-trivial gradient)", flush=True)

pred = H.build_predictor(temperature=TEMP, K=K, n_photons=NPH)
tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(777))
loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=1.0)
lossj = jax.jit(loss); gradj = jax.jit(jax.grad(loss))
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

# AD gradient per key + mean
gAD_k = np.stack([np.asarray(gradj(theta0, k)) for k in keys])      # (NKEYS,7)
gAD = gAD_k.mean(0)
def unit(v): return v / (np.linalg.norm(v) + 1e-30)
# per-key AD cosine spread vs the mean AD (heavy-tail diagnostic)
adcos = np.array([float(unit(gAD_k[i]) @ unit(gAD)) for i in range(NKEYS)])
print(f"# AD per-key cosine vs mean-AD: median {np.median(adcos):.3f}  min {adcos.min():.3f}  (low/heavy-tail => need more keys)", flush=True)

def fd_grad(frac):
    h = frac * PS; g = np.zeros((NKEYS, 7))
    for i in range(7):
        e = np.zeros(7); e[i] = h[i]
        tp = jnp.asarray(np.asarray(theta0) + e); tm = jnp.asarray(np.asarray(theta0) - e)
        for j, k in enumerate(keys):
            g[j, i] = (float(lossj(tp, k)) - float(lossj(tm, k))) / (2 * h[i])
    return g.mean(0), g

sc = [0, 6]; ge = [1, 2, 3, 4, 5]
print(f"# L1.0 FD h-plateau (frac of PARAM_SCALE):  cos_all  cos_SCALAR  cos_GEOM  ||AD||/||FD||", flush=True)
best = None
for frac in [1e-3, 3e-3, 1e-2, 3e-2, 1e-1]:
    gFD, _ = fd_grad(frac)
    cos = float(unit(gAD) @ unit(gFD)); mr = np.linalg.norm(gAD) / (np.linalg.norm(gFD) + 1e-30)
    cs = float(unit(gAD[sc]) @ unit(gFD[sc])); cg = float(unit(gAD[ge]) @ unit(gFD[ge]))
    print(f"#   frac {frac:.0e}:  {cos:+.4f}   {cs:+.4f}     {cg:+.4f}    {mr:.4f}", flush=True)
    if best is None or cg > best[2]: best = (frac, gFD, cg)
fracp, gFDp = best[0], best[1]
print(f"# (plateau frac chosen by best GEOMETRY cosine = {fracp:.0e}, cos_geom {best[2]:+.4f})", flush=True)
print(f"# L1.1 per-parameter AD vs FD at frac={fracp:.0e}  (group: S=scalar E/t0, G=geometry):", flush=True)
print(f"#   {'param':6s} {'grp':3s} {'AD':>11s} {'FD':>11s} {'relErr':>8s}", flush=True)
for i, nm in enumerate(PN):
    grp = 'S' if nm in ('energy', 't0') else 'G'
    re = abs(gAD[i] - gFDp[i]) / (abs(gFDp[i]) + 1e-30)
    print(f"#   {nm:6s} {grp:3s} {gAD[i]:+11.4f} {gFDp[i]:+11.4f} {re:8.2%}", flush=True)
print(f"#   SCALAR  cos {float(unit(gAD[sc])@unit(gFDp[sc])):+.4f}  | GEOMETRY cos {float(unit(gAD[ge])@unit(gFDp[ge])):+.4f}", flush=True)
print(f"# VERDICT: where AD==FD (cos~1, mag~1, low per-key spread) the gradient is trustworthy; flag the params/knobs where it is not.", flush=True)
