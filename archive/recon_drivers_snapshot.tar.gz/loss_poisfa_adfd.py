"""AD=FD on the POISSON FIRST-ARRIVAL joint loss — run AFTER confirming the loss is sensible/unbiased.
Compares AD gradient to the clean noise-averaged profile slope per param at theta0 (multi-scale -> smooth?).
Same Poisson first-arrival + raw Poisson charge as loss_poisson_fa.py. K=8, MAXCELL=16.
Env: TTS_NS NPHOT NKEYS SIGMA THR WT.  Usage: CUDA_VISIBLE_DEVICES=g python loss_poisfa_adfd.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '64'))
SIGMA = float(os.environ.get('SIGMA', '2.5')); THR = float(os.environ.get('THR', '0.0')); WT = float(os.environ.get('WT', '1.0'))
K = 8; PS = np.asarray(H.PARAM_SCALE); PN = H.PARAM_NAMES
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0, 0, 0.0175, 0, 0.5]); theta0 = theta_true + delta
LOGN_C = float(np.log(SIGMA * np.sqrt(2 * np.pi))); SQRT2 = float(np.sqrt(2.0))
print(f"# AD=FD on POISSON FIRST-ARRIVAL joint  TTS={os.environ['TTS_NS']} SIGMA={SIGMA} THR={THR} WT={WT} NKEYS={NKEYS} K={K} MC={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH, apply_smearing=False)
ND = H.num_detectors(pred)
# truth MEAN for a stable target
cs, ts = [], []
for s in range(24):
    c, t = jax.lax.stop_gradient(tsim(H.theta_to_track(jnp.asarray(theta_true)), jax.random.PRNGKey(10000 + s)))
    cs.append(np.asarray(c)); ts.append(np.where(np.asarray(c) > 0, np.asarray(t), np.nan))
oc = jax.lax.stop_gradient(jnp.asarray(np.mean(cs, 0))); hit = jax.lax.stop_gradient(jnp.asarray(np.mean(cs, 0) > 1e-6))
ot = jax.lax.stop_gradient(jnp.asarray(np.nan_to_num(np.nanmean(ts, 0))))
def loss(theta, key):
    log_w, ft, fi, total_charge = pred(H.theta_to_track(theta), key)
    d = (ot - theta[6])[fi] - ft
    log_r = segment_logsumexp(log_w + (-0.5 * (d / SIGMA) ** 2 - LOGN_C), fi, ND)
    R = jax.ops.segment_sum(jnp.exp(log_w) * 0.5 * (1.0 + erf(d / (SIGMA * SQRT2))), fi, num_segments=ND)
    FL = -60.0; lr = jnp.maximum(log_r, FL); empty = log_r <= (FL + 1.0)
    usable = hit & (oc > THR) & (~empty)
    time = jnp.sum(jnp.where(usable, -lr + R, 0.0))
    mu = jnp.maximum(total_charge, 1e-8)
    return jnp.sum(mu - oc * jnp.log(mu)) + WT * time
lossj = jax.jit(loss); gradj = jax.jit(jax.grad(loss)); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
gAD = np.stack([np.asarray(gradj(jnp.asarray(theta0), k)) for k in keys]).mean(0)
print(f"#  param  grp     AD         profile slopes w1/2/4 (->s=0)        AD/coarse  smooth?", flush=True)
for i, nm in enumerate(PN):
    grp = 'S' if nm in ('energy', 't0') else 'G'
    sv = np.linspace(-6 * PS[i], 6 * PS[i], 25); j0 = 12; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(lossj(jnp.asarray(theta0 + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    sl = {w: (prof[j0 + w] - prof[j0 - w]) / (2 * w * dg) for w in [1, 2, 4]}
    kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
    tag = 'KINKY' if kinky else f'AD/coarse {gAD[i]/(sl[4]+1e-30):+.2f}'
    print(f"#  {nm:6s} {grp}  {gAD[i]:+11.2f}   {sl[1]:+10.1f} {sl[2]:+10.1f} {sl[4]:+10.1f}   {tag}", flush=True)
print(f"# READ: with the PRINCIPLED time term, do the angle profiles smooth out + AD match? (vs order-stat's kinky angles)", flush=True)
