"""OPTIMIZER LAB (MAXCELL=4). Compare optimizers for (1) MINIMUM reached (floor) and (2) BASIN width. Runs to
COMPLETE optimization (long, with a plateau check). Loss = count-conditioned + AMP_DETACH + OVERLAP_RENORM, sin/cos.
OPT: adam | gd | gn | gnrec | newton | lm
Reports loss + residual trajectory and FINAL (vtx,dir,E,t0,loss,iters_used). Saves /tmp/opt_{TAG}_{TRUTHKEY}.txt:
  TRUTHKEY vtx dir E t0 finalloss iters startoff
Env: OPT TRUTHKEY START_PIDX START_OFF NITERS NKEYS LR RIDGE_EPS CLIP_FRAC DAMP TR RECOMP SIGMA NPHOT TAG.
Usage: CUDA_VISIBLE_DEVICES=g OPT=gn START_OFF=8 TRUTHKEY=5000 python opt_lab.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ['MAXCELL']='4'; os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np, optax
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=170)
NPH=int(os.environ.get('NPHOT','500000')); NKEYS=int(os.environ.get('NKEYS','6')); NITERS=int(os.environ.get('NITERS','400'))
OPT=os.environ.get('OPT','adam'); LR=float(os.environ.get('LR','3e-2')); RIDGE_EPS=float(os.environ.get('RIDGE_EPS','0.6'))
CLIP_FRAC=float(os.environ.get('CLIP_FRAC','0.05')); DAMP=float(os.environ.get('DAMP','0.7')); TR=float(os.environ.get('TR','0.3'))
RECOMP=int(os.environ.get('RECOMP','10')); START_OFF=float(os.environ.get('START_OFF','0')); START_PIDX=int(os.environ.get('START_PIDX','3'))
TRUTHKEY=int(os.environ.get('TRUTHKEY','5000')); SIGMA=float(os.environ.get('SIGMA','2.5')); CW=float(os.environ.get('CW','1.0')); K=8; MC=4; DELTA=1.0; SQ=float(np.sqrt(2.0)); POL=float(os.environ.get('POL','0.6')); AZ=float(os.environ.get('AZ','0.8'))
th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
SC=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def th9dir(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=np.hypot(st,ct); npp=np.hypot(sp,cp); st,ct,sp,cp=st/nt,ct/nt,sp/npp,cp/npp
    return np.array([st*cp,st*sp,ct])
print(f"# OPT_LAB OPT={OPT} MC=4 startoff={START_OFF}({NM[START_PIDX]}) NITERS={NITERS} NKEYS={NKEYS} LR={LR} eps={RIDGE_EPS} clip={CLIP_FRAC} damp={DAMP} TR={TR} sigma={SIGMA} key={TRUTHKEY}",flush=True)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); ND=H.num_detectors(pred)
truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=K,is_data=False,use_expected_value=False,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
NREAL=int(os.environ.get('NREAL','1'))   # NREAL>1 = noise-averaged truth (clean minimum at truth, for optimizer comparison)
trk=sc2(jnp.asarray(th9)); dtrue=th9dir(th9)
if NREAL==1:
    c,t=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(TRUTHKEY))); oc=jnp.asarray(np.asarray(c)); ot=jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
else:
    OC=np.zeros(ND); OTw=np.zeros(ND); OTn=np.zeros(ND)
    for r in range(NREAL):
        cc,tt=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(TRUTHKEY+r))); cc=np.asarray(cc); tt=np.asarray(tt)
        OC+=cc; m=cc>0; OTw+=np.where(m,tt,0.); OTn+=m
    oc=jnp.asarray(OC/NREAL); ot=jnp.asarray(np.where(OTn>0,OTw/np.maximum(OTn,1),0.))
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
_LMODE=os.environ.get('LOSS_MODE','full'); _CHGW=1.0 if _LMODE in ('full','charge') else 0.0; _TIMW=1.0 if _LMODE in ('full','time') else 0.0
@jax.jit
def loss(t9,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8); muS=jax.lax.stop_gradient(mu)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return _CHGW*CW*jnp.sum(mu-oc*jnp.log(mu))+_TIMW*jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))  # LOSS_MODE: full/charge/time
gradf=jax.jit(jax.grad(loss)); SCj=jnp.asarray(SC); T0=jnp.asarray(th9); KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
def G(th): return np.mean([np.asarray(gradf(jnp.asarray(th),k)) for k in KEYS],0)
def AL(th): return float(np.mean([float(loss(jnp.asarray(th),k)) for k in KEYS]))
def errs(th):
    d=th-th9; return np.sqrt(d[1]**2+d[2]**2+d[3]**2), np.degrees(np.arccos(np.clip(np.dot(th9dir(th),dtrue),-1,1))), d[0], d[8]
def fd_hess(th):
    Hf=np.zeros((9,9))
    for j in range(9):
        h=0.4*SC[j]; gp=G(th+h*np.eye(9)[j]); gm=G(th-h*np.eye(9)[j]); Hf[:,j]=(gp-gm)/(2*h)
    return 0.5*(Hf+Hf.T)
def solve_step(Hz,gz,clip,ridge):
    if clip:
        ev,V=np.linalg.eigh(Hz); ev=np.clip(ev,CLIP_FRAC*max(np.abs(ev).max(),1e-9),None); Hz=V@np.diag(ev)@V.T
    lam=ridge*(np.median(np.diag(Hz)) if ridge>0 else 0.0)
    return -np.linalg.solve(Hz+ (lam if ridge>0 else 0.0)*np.eye(9), gz)

if os.environ.get('START_COMBO'):  # realistic seed: E + all 3 position axes + direction ALL wrong at once
    off=np.zeros(9); off[0]=6.; off[1]=off[2]=off[3]=6.; off[6]=10.; off[7]=-10.  # +300MeV, ~2.08m vtx, ~8deg dir
    start=th9+off*SC; print(f"# START_COMBO: E+{off[0]*SC[0]:.0f}MeV vtx{np.sqrt(3)*off[1]*SC[1]:.2f}m dir-rot",flush=True)
else:
    start=th9+START_OFF*SC*np.eye(9)[START_PIDX]
th=start.copy()
M=fd_hess(start) if OPT in('gn','newton') else None   # fixed Hessian for gn/newton
opt=optax.adam(LR); z=(jnp.asarray(start)-T0)/SCj; ostate=opt.init(z)
lam_lm=float(os.environ.get('LM_LAM0','1.0')); prevloss=AL(start); loss0=prevloss
print(f"#  it | loss     | vtxcm dir E t0    | gnorm",flush=True)
used=NITERS
for it in range(NITERS):
    g=G(th); gz=g*SC
    if OPT=='adam':
        thh=T0+z*SCj; gg=jnp.zeros(9)
        for s in range(NKEYS): gg=gg+gradf(thh,KEYS[s])
        u,ostate=opt.update((gg/NKEYS)*SCj,ostate); z=optax.apply_updates(z,u); th=np.asarray(T0+z*SCj)
    elif OPT=='gd':
        z=z-LR*jnp.asarray(np.clip(gz,-TR,TR)); th=np.asarray(T0+z*SCj)
    elif OPT in('gn','newton'):
        Hz=M*np.outer(SC,SC); dz=solve_step(0.5*(Hz+Hz.T),gz,True,(RIDGE_EPS if OPT=='gn' else 0.0))
        th=th+DAMP*np.clip(dz,-TR,TR)*SC
    elif OPT=='gnrec':
        if it%RECOMP==0: M=fd_hess(th)
        Hz=M*np.outer(SC,SC); dz=solve_step(0.5*(Hz+Hz.T),gz,True,RIDGE_EPS); th=th+DAMP*np.clip(dz,-TR,TR)*SC
    elif OPT=='lm':
        if it%RECOMP==0 or it==0: M=fd_hess(th)
        Hz=M*np.outer(SC,SC); dz=solve_step(0.5*(Hz+Hz.T),gz,True,lam_lm); thn=th+np.clip(dz,-TR,TR)*SC
        nl=AL(thn)
        if nl<prevloss: th=thn; lam_lm=max(lam_lm*0.5,1e-3); prevloss=nl
        else: lam_lm=min(lam_lm*2.0,1e3)
    if it%max(1,NITERS//12)==0 or it==NITERS-1:
        v,a,e,t0=errs(th); cl=AL(th); print(f"#  {it:3d} | {cl:8.1f} | {v*100:5.1f} {a:4.1f} {e:+6.0f} {t0:+.2f} | {np.linalg.norm(gz):.1f}",flush=True)
        if it>NITERS//4 and abs(cl-prevloss)/max(abs(prevloss),1)<1e-5 and OPT in('adam','gd'): used=it; break
        if OPT in('adam','gd'): prevloss=cl
fl=AL(th); v,a,e,t0=errs(th)
print(f"#  {OPT} FINAL: vtx {v*100:.1f}cm dir {a:.2f}deg E {e:+.1f}MeV t0 {t0:+.3f}ns  loss {fl:.1f} (start {loss0:.1f}) iters {used}",flush=True)
with open(f"/tmp/opt_{os.environ.get('TAG',OPT)}_{TRUTHKEY}.txt","w") as f:
    f.write(f"{TRUTHKEY} {v*100:.3f} {a:.3f} {e:.2f} {t0:.4f} {fl:.2f} {used} {START_OFF:.1f}\n")
print(f"# DONE opt {OPT} key={TRUTHKEY} off={START_OFF}",flush=True)
