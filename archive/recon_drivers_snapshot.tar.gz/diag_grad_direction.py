"""Does E[-grad] point toward the truth, per parameter? And is it the CHARGE or the TIME
channel that carries each parameter? Diagnoses whether poor convergence is a gradient problem
(e.g. hard-overlap kills the charge->position gradient) or an optimizer problem."""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import poisson_nll, first_arrival_nll
np.set_printoptions(precision=3, suppress=True)

K, NPHOT, NK = 7, 30_000, 24
SCALE = np.array(H.PARAM_SCALE)
theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 5.0])
pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(truth, theta_star, jax.random.PRNGKey(7))

def charge_loss(th, key):
    _, _, _, q = pred(H.theta_to_track(th), key)
    return jnp.sum(poisson_nll(oc, q))
def time_loss(th, key):
    lw, ft, fi, _ = pred(H.theta_to_track(th), key)
    return jnp.sum(jnp.where(hit, first_arrival_nll(lw, ft, fi, ot - th[6], 1.5, ND), 0.0))
def full_loss(th, key):
    return charge_loss(th, key) + time_loss(th, key)

gC = jax.jit(jax.grad(charge_loss)); gT = jax.jit(jax.grad(time_loss)); gF = jax.jit(jax.grad(full_loss))
rng = np.random.default_rng(0)
theta = jnp.array(np.array(theta_star) + rng.uniform(-1, 1, 7) * 1.0 * SCALE)
toward = (np.array(theta_star) - np.array(theta)) / SCALE          # normalized direction to truth
keys = jax.random.split(jax.random.PRNGKey(3), NK)

print(f"loss(truth)={np.mean([float(full_loss(theta_star,k)) for k in keys]):.1f}  "
      f"loss(offset)={np.mean([float(full_loss(theta,k)) for k in keys]):.1f}\n", flush=True)
for name, gf in [('charge', gC), ('time', gT), ('full', gF)]:
    G = np.mean([np.array(gf(theta, k)) for k in keys], 0) * SCALE   # normalized grad
    nd = -G                                                          # descent direction
    aligned = np.sign(nd) == np.sign(toward)                        # per-param: points toward truth?
    cos = np.dot(nd, toward) / (np.linalg.norm(nd) * np.linalg.norm(toward) + 1e-12)
    print(f"[{name}] cos(-grad, toward_truth)={cos:+.3f}", flush=True)
    print(f"   per-param -grad   = {nd}", flush=True)
    print(f"   toward truth      = {toward}", flush=True)
    print(f"   aligned (sign ok) = {aligned.astype(int)}  ({H.PARAM_NAMES})", flush=True)
