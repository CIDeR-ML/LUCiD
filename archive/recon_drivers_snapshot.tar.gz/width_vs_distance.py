"""Pin the CAUSE of SIREN's too-narrow angular spread: measure the emission-angle width as a function of
distance-along-track for (A) the real PhotonSim event photons and (B) the SIREN emission density itself.
Multiple scattering broadens the angle with distance (~sqrt(d)). If SIREN's width is ~constant ≈ chromatic
(1.8 deg) vs distance while PhotonSim's grows, MS is absent from the table (frame/averaging removed it),
not merely under-sampled. Usage: CUDA_VISIBLE_DEVICES=g python width_vs_distance.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.siren.core import create_photonsim_siren_grid
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import SIREN
from lucid.sources.siren_rays import normalize_inputs_jit, denormalize_log_predictions
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=3, suppress=True)

# ---- (A) PhotonSim event: angle-to-initial-direction vs distance-along-track ----
raw = PS.read_photon_data_from_photonsim(PS.ROOT, 0)
P = np.array(raw['photon_origins'])/100.0; D = np.array(raw['photon_directions'])
C = P-P.mean(0); _,_,vt=np.linalg.svd(C,full_matrices=False); d0=vt[0]
if d0[2]<0: d0=-d0
vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
s_ps = (P - vtx0) @ d0                                   # m along track from vertex
ang_ps = np.degrees(np.arccos(np.clip(D @ d0, -1, 1)))   # angle to INITIAL track dir (incl. MS)
print("=== (A) PhotonSim photons: emission-angle width vs distance ===")
print(f"  {'s_bin(m)':>10} {'n':>7} {'mean_ang':>9} {'std_ang':>9}")
for lo in range(0,5):
    m=(s_ps>=lo)&(s_ps<lo+1)
    if m.sum()>50: print(f"  {f'{lo}-{lo+1}':>10} {int(m.sum()):>7} {ang_ps[m].mean():>9.2f} {ang_ps[m].std():>9.2f}")

# ---- (B) SIREN emission density: angular width vs distance, at E=1050 ----
dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4)
pp=unpack_photonsim_params('muon', dg.medium.material)
predr=SIRENPredictor(pp['siren_model_path']); grid=create_photonsim_siren_grid(predr)
(n_bins,emin,emax,amin,amax,dmin,dmax,abins,dbins,adgrid,amesh,dmesh,logmin,logmax)=grid
E=1050.0
eg=jnp.stack([jnp.full_like(amesh,E).ravel(), amesh.ravel(), dmesh.ravel()],1)
ng=normalize_inputs_jit(eg,emin,emax,amin,amax,dmin,dmax)
model=SIREN(hidden_features=256,hidden_layers=3,out_features=1)
lp,_=model.apply(predr.params, ng)
dens=np.array(jnp.clip(denormalize_log_predictions(jnp.squeeze(lp),logmax,logmin),1e-12,None))
amesh=np.array(amesh); dmesh=np.array(dmesh)              # shape (n_angle, n_distance) or flattened-mesh
ang_deg=np.degrees(amesh); dist_m=dmesh/1000.0           # angle rad->deg, distance mm->m
print(f"\n=== (B) SIREN density: emission-angle width vs distance (E={E:.0f}) ===")
print(f"  grid: angle {np.degrees(amin):.1f}-{np.degrees(amax):.1f} deg, distance {dmin/1000:.2f}-{dmax/1000:.2f} m, shape {amesh.shape}")
print(f"  {'d_bin(m)':>10} {'mean_ang':>9} {'std_ang':>9} {'dens_frac':>9}")
flat_a=ang_deg.ravel(); flat_d=dist_m.ravel(); flat_w=dens.ravel()
for lo in range(0,10,1):
    m=(flat_d>=lo)&(flat_d<lo+1); w=flat_w[m]
    if w.sum()<=0: continue
    mu=(w*flat_a[m]).sum()/w.sum(); sd=np.sqrt((w*(flat_a[m]-mu)**2).sum()/w.sum())
    print(f"  {f'{lo}-{lo+1}':>10} {mu:>9.2f} {sd:>9.2f} {w.sum()/flat_w.sum():>9.3f}")
