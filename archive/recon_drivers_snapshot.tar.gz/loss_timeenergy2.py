"""TIME-term energy bias diag (jitted, stable). Isolate TIME-only energy argmin (grid-min) vs mu-free and
mu-DETACHED (mu fixed at theta_true in S=1-R/mu), across sigma. If mu-detached ->0 the S-normalization energy
coupling is the cause; if it persists it's the R(t)-shape/sigma. Other params pinned at truth (t0=0).
Env: NPHOT NREAL NKEYS OVERLAP_RENORM.  Usage: CUDA_VISIBLE_DEVICES=g OVERLAP_RENORM=1.009 python loss_timeenergy2.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH=int(os.environ.get('NPHOT','500000')); NREAL=int(os.environ.get('NREAL','64')); NKEYS=int(os.environ.get('NKEYS','6'))
K=8; MC=16; SQ=float(np.sqrt(2.0)); POL,AZ=0.6,0.8
th9=np.array([1050.0,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.0])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# TIME-ENERGY2 NPH={NPH} NREAL={NREAL} NKEYS={NKEYS} RENORM={os.environ.get('OVERLAP_RENORM','1.0')}",flush=True)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); ND=H.num_detectors(pred)
truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=K,is_data=False,use_expected_value=False,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
trk=sc(jnp.asarray(th9))
OC=np.zeros(ND); OTw=np.zeros(ND); OTn=np.zeros(ND)
for r in range(NREAL):
    c,t=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(9000+r))); c=np.asarray(c); t=np.asarray(t)
    OC+=c; m=c>0; OTw+=np.where(m,t,0.0); OTn+=m
oc=jnp.asarray(OC/NREAL); ot=jnp.asarray(np.where(OTn>0,OTw/np.maximum(OTn,1),0.0))
PK=jnp.stack([jax.random.PRNGKey(s) for s in range(NKEYS)])
mu_true=jnp.maximum(jnp.mean(jax.lax.map(lambda k: pred(trk,k)[3], PK),0),1e-8)
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))

def tloss_1key(t9, key, SIGMA, DELTA, muS):
    lw,ft,fi,tot=pred(sc(t9),key); w=jnp.exp(jnp.clip(lw,-60,20)); tobs=(ot)[fi]
    Rlo=jax.ops.segment_sum(w*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(w*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.0); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.0)
    n=jnp.maximum(oc,0.0); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.0))
@jax.jit
def tloss(t9, SIGMA, DELTA, detach):
    def one(key):
        lw,ft,fi,tot=pred(sc(t9),key); muS=jnp.where(detach, mu_true, jnp.maximum(tot,1e-8))
        return tloss_1key(t9,key,SIGMA,DELTA,muS)
    return jnp.mean(jax.lax.map(one, PK))
def egrid(SIGMA,DELTA,detach,half=200.0,n=41):
    sv=np.linspace(-half,half,n); prof=np.array([float(tloss(jnp.asarray(th9+s*np.eye(9)[0]),SIGMA,DELTA,detach)) for s in sv])
    j=int(np.argmin(prof))
    if 0<j<n-1:
        y0,y1,y2=prof[j-1],prof[j],prof[j+1]; d=(y0-2*y1+y2); sref=sv[j]+(0.5*(y0-y2)/d*(sv[1]-sv[0]) if abs(d)>1e-12 else 0)
    else: sref=sv[j]
    return sv[j],sref
for SIG in [1.0,1.5,2.5]:
    g,l=egrid(SIG,1.0,False); gd,ld=egrid(SIG,1.0,True)
    print(f"#  sigma={SIG} Delta=1: TIME-only E argmin  mu-FREE grid {g:+6.1f} local {l:+6.1f} | mu-DETACHED grid {gd:+6.1f} local {ld:+6.1f} MeV",flush=True)
print(f"# READ: mu-FREE strongly negative + mu-DETACHED ~0 => S=1-R/mu energy coupling is the bias; both negative => R-shape/sigma.",flush=True)
