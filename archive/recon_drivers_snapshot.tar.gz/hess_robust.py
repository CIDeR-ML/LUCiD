"""Track-Hessian AD-vs-FD with BOTH mean-over-keys and MEDIAN-over-keys estimators (median is robust to
the heavy-tailed per-key spikes from residual kinks). Tests: (a) smallest max_sensors_per_cell that
works, (b) whether the magnitude inflation (rel_err) is a real bounce bias or just mean-estimator noise.
Track block only (optical is always 1.000). cubic overlap, sanitizer bypassed.
Usage: CUDA_VISIBLE_DEVICES=g MAXCELL=6 KK=4 OVERLAP_ANALYTIC=cubic NKEYS=48 python hess_robust.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
import recon_harness as H, recon_ps_setup as PS
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=2, suppress=True, linewidth=140)
OV = os.environ.get('OVERLAP_ANALYTIC', '(none)')
NKEYS = int(os.environ.get('NKEYS', '48')); NPH = 40000
K = int(os.environ.get('KK', str(PS.K))); MAXCELL = int(os.environ.get('MAXCELL', '16'))
FDH = float(os.environ.get('FDH', '0.3'))     # FD step as fraction of PARAM_SCALE (test FD resolution)
SC = np.array(H.PARAM_SCALE)
pred_baked = H.build_predictor(temperature=0.1, K=K, n_photons=NPH)
DP0 = pred_baked.default_detector_params
pred_open = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False,
    use_expected_value=True, hit_mode='per_photon', max_sensors_per_cell=MAXCELL, physics_config=H.PHYS,
    default_detector_params=False, particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
ts = np.array([1050., 0., 0., 0., 0.6, 0.8, 0.]); trk = H.theta_to_track(jnp.asarray(ts))
oc = jax.lax.stop_gradient(pred_open(trk, DP0, jax.random.PRNGKey(999))[3])
def L_trk(theta, key):
    q = pred_open(H.theta_to_track(theta), DP0, key)[3]
    return jnp.sum((q - oc) ** 2)
ks = [jax.random.PRNGKey(60000 + i) for i in range(NKEYS)]
g = jax.jit(jax.grad(L_trk)); he = jax.jit(jax.hessian(L_trk))
gbar = lambda x: np.mean([np.array(g(jnp.asarray(x), k)) for k in ks], 0)
Hstk = np.stack([np.array(he(jnp.asarray(ts), k)) for k in ks], 0) * np.outer(SC, SC)
Hmean = Hstk.mean(0); Hmed = np.median(Hstk, 0)
n = 7; Hfd = np.zeros((n, n))
for j in range(n):
    d = FDH * SC[j]
    Hfd[:, j] = (gbar(ts + np.eye(n)[j] * d) - gbar(ts - np.eye(n)[j] * d)) / (2 * FDH) * SC
Hfd = 0.5 * (Hfd + Hfd.T)
def met(Hh):
    c = float(Hh.ravel() @ Hfd.ravel() / (np.linalg.norm(Hh.ravel()) * np.linalg.norm(Hfd.ravel()) + 1e-12))
    r = float(np.linalg.norm(Hh - Hfd) / (np.linalg.norm(Hfd) + 1e-12))
    pb = slice(1, 4)
    cp = float(Hh[pb, pb].ravel() @ Hfd[pb, pb].ravel() /
               (np.linalg.norm(Hh[pb, pb].ravel()) * np.linalg.norm(Hfd[pb, pb].ravel()) + 1e-12))
    return c, r, cp
cm, rm, cpm = met(Hmean); cmed, rmed, cpmed = met(Hmed)
print(f"K={K} maxcell={MAXCELL} overlap={OV} NK={NKEYS} FDH={FDH}: "
      f"MEAN cos={cm:.3f} rel={rm:.2f} posC={cpm:.3f} | MEDIAN cos={cmed:.3f} rel={rmed:.2f} posC={cpmed:.3f}", flush=True)
print(f"  FD diag       : {np.diag(Hfd)}")
print(f"  AD mean   diag: {np.diag(Hmean)}")
print(f"  AD median diag: {np.diag(Hmed)}", flush=True)
