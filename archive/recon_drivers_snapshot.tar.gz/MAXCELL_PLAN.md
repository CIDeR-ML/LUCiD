# 8h investigation (start 2026-06-07 04:08 PDT, end ~12:08)
PHASES (user order):
 1. temp=0.05: re-run MC-sweep / charge diagnostics at temp=0.05 (vs 0.1, None).
 2. MAXCELL bug hunt: WHY does low MAXCELL under-count charge? propagation (cell assignment) + temperature
    (soft overlap spreads to neighbors) + floating-point accuracy. Look for a real bug.
 3. BASIN check (thorough) with the corrected loss + fixes.
 4. AD/FD quality + HESSIAN quality (extensive — most important).
 5. Gauss-Newton optimizer: ridge (mean & median), clip-all-to-positive; robust optimization;
    COMPARE to prior best-fit + basin results.
RUN ON ALL 5 GPUs. Check date as needed.

## PHASE 1+2 FINDINGS (2026-06-07 ~05:00)
temp=0.05: charge-loss-vs-MAXCELL is IDENTICAL to temp 0.1/0.2/none (MC16 Q/Q64 = 0.9641 all temps).
=> the MAXCELL issue is TEMPERATURE-INDEPENDENT (NOT the soft overlap). Refutes the temperature hypothesis.
NOT OVERFLOW: grid_occupancy.py shows SK cells NEVER exceed the cap (max geom-assign/cell: 9@MC16, 25@MC64,
36@MC96; 0% cells>cap; 0% dropped at EVERY MC). So create_inverted_sensor_map is NOT dropping sensors.
=> The loss is GRID-RESOLUTION (cell-boundary lookup): finer grid (lower MC) loses MORE charge (3.6% @MC16),
converges slowly (0.964/0.975/0.982/0.992/1.000 @ MC 16/24/32/48/64, still climbing). Uniform across occupancy.
Geometrically the assignment SHOULD be exact for hard overlap (a sensor a photon overlaps is within sensor_radius
of the photon, so assigned to the photon's cell) => the 3.6% loss is an IMPLEMENTATION BUG at cell boundaries
(ray wall-hit cell-map vs sensor assign-to-cell inconsistency / float edges), NOT geometry. [brute-force test pending]
KEY PRACTICAL POINT: the loss CANCELS when truth & predictor use the SAME MAXCELL (both lose the same charge)
=> it does NOT bias matched-MC sim-vs-sim recon (Tier-5 used matched MC, energy fine). It only matters as an
ABSOLUTE charge deficit vs real data (handled like the overlap renorm, a global C). So "need high MC" is for
absolute charge accuracy, not for the recon when matched. Grid grows COARSER with MC (scale=sqrt(MC/4)).

## PHASE 2 RESOLVED — we do NOT need high MAXCELL for the recon
brute_force_charge.py (synthetic rays aimed inside sensors, hard overlap): grid catches 100% at MC=4/16/64,
0 missed even at the disk EDGE (0.97rs). => the per-photon sensor lookup is GEOMETRICALLY EXACT; NO cell-boundary
bug. The 3.6% MC-growth in the full multi-bounce sim is a subtler effect (reflection hit_sensor / cap grid / edge),
small, temp-independent.
MATCHED-MC recon (loss_t5, truth=pred MAXCELL, both K=8, fixes): MC=4 -> E -0.06% vtx 7.0cm dir 0.21deg (== MC=16!).
=> the grid charge loss CANCELS when truth & predictor share MAXCELL. The earlier "+5% energy @ MC4" was the
truth(24)-vs-pred(MC) MISMATCH in the sweep, NOT a low-MC problem. CONCLUSION: recon runs fine at MC=4 (6-8x cheaper).
High MAXCELL only matters for ABSOLUTE charge vs real data (handled by a charge renorm). NOT a bug that breaks recon.

## PHASE 4 — AD/FD + HESSIAN (2026-06-07 ~05:00, adfd_hessian.py)
GRADIENT (offset center, key-avg): ALL SMOOTH (no kinks) with sin/cos + AMP_DETACH. AD/FD ratio <1 (AD ~0.55-0.85x FD
= soft-overlap straight-through underestimate). AMP_DETACH DRAMATICALLY lowers gradient per-key VARIANCE (angles
s_p std 15077->1945, 8x) and removes sign-flips => the fix improves gradient quality too.
HESSIAN (AD via hvp, key-avg, at truth): BROKEN for geometry. 3 NEGATIVE eigenvalues (incl -1.7e8), indefinite,
cond 1.5e10. DIAGONAL NEGATIVE for x,y,z,s_t,c_t where FD diag is POSITIVE (AD/FD -88..-365). Per-key diag rel-std
~80 for x,y. => jax.hessian UNUSABLE for GN (straight-through 2nd-deriv broken; AMP_DETACH does NOT fix it).
FD Hessian diag is CORRECT (all positive: [0.006,1210,2129,3024,3.3e5,1.4e5,3.5e4,2.0e5,223]).
=> GN MUST use the FISHER/GN approximation J_mu^T diag(1/mu) J_mu (PSD by construction), NOT the AD Hessian.
The user's "clip all to positive helps" = exactly fixing the indefinite Hessian. Rebuild GN around Fisher.

## PHASE 5 — GAUSS-NEWTON (2026-06-07 ~05:55, gn_recon.py)
The AD Hessian is broken (Phase 4) and jacfwd-Fisher is blocked by custom_vjp (forward-mode). Solution:
GN metric = FD Hessian of the FULL loss (reverse-mode grad + central diff), z-scaled, POSITIVE-eigenvalue-CLIPPED,
+ ridge (median of diag). FD Hessian z-scaled is well-conditioned (cond 180 vs AD 1.5e10; 3 small neg evs -> clip).
Best config: HESS=fdfixed (FD Hessian computed ONCE at start, reused) RIDGE=median CLIP_POS=1 eps=0.6 damp=0.7 TR=0.3.
ridge mean~median (8.1 vs 9.5cm single-ev); clip~noclip at convergence BUT clip needed for the indefinite directions.
RESULT (10 ev, start z+0.4m): GN vtxRMS 9.8cm/dir0.28 ~ ADAM 8.8cm/0.20 (COMPARABLE at the floor).
BASIN WIDTH (the win): GN converges from z+1.2m (vtx 13.2cm) where ADAM FAILS (36.6cm); z+0.8m both OK; z+1.6m both
struggle (GN 38 vs Adam 69). => GN's SPATIAL/vertex basin is ~3-4x wider than Adam (and vs the prior ~0.3m memory).
Energy basin wide for both (E+200MeV both ~converge). Direction GN not better (13.8 Adam vs 18.9 GN @ dir+9deg).
=> USE GN (FD-Hessian, median ridge, positive clip) for ROBUST capture (vertex), Adam-equal at the floor.

## GN BASIN WIN — CONFIRMED (z+1.2m, 5 events)
GN vtx [12.4,7.3,4.5,13.2,7.5] -> 5/5 CONVERGED (to floor). ADAM vtx [36.6,40.7,42.7,41.6,36.3] -> 0/5 (stuck ~40cm).
=> GN (FD-Hessian + median ridge + positive clip) ROBUSTLY captures the vertex from 1.2m where Adam ALWAYS fails.
~4x the prior ~0.3m spatial basin. This is THE robustness deliverable. Recipe locked: gn_recon.py HESS=fdfixed
RIDGE=median CLIP_POS=1 RIDGE_EPS=0.6 DAMP=0.7 TR=0.3.

## SESSION SUMMARY (8h, 2026-06-07)
1. temp: MAXCELL issue is TEMPERATURE-INDEPENDENT (temp=0.05/0.1/0.2/none identical). NOT the soft overlap.
2. MAXCELL: NOT overflow (cells under cap), per-photon lookup EXACT (brute-force 0 missed). The 3.6% MC charge loss
   CANCELS for matched truth=pred MC -> recon FINE at MC=4 (matched, E unbiased, vtx 7cm). High MC NOT needed for recon.
3. AD/FD: gradient SMOOTH (no kinks), AD~0.6-0.8x FD; AMP_DETACH halves gradient variance. AD HESSIAN BROKEN for
   geometry (indefinite, neg diag, cond 1e10). FD Hessian GOOD (cond 180, pos diag). jacfwd-Fisher blocked by custom_vjp.
4. GN: FD-Hessian + median ridge + positive eigen-clip. Floor-equal to Adam; 3-4x WIDER vertex basin (1.2m vs Adam fail).

## RIDGE mean/median + CLIP at basin edge (z+1.2m)
median+clip 5/5 (vtx 4.5-13cm) ; mean+clip 3/3 (5.5-13cm) ; median+NOCLIP 1/2 (one DIVERGED to 112cm).
=> POSITIVE CLIP is ESSENTIAL (no-clip diverges on the indefinite Hessian directions = user's "clip to positive helps").
ridge mean ~= median (both fine with clip); median slightly preferred. RECIPE: FD-Hessian + median-ridge + pos-clip.

## OPTIMIZER CAMPAIGN (2026-06-07, MAXCELL=4, opt_lab.py) — minimum vs basin
Single-event truth, count-cond+AMP+renorm, fixes. FD-Hessian (AD broken). Metrics: vtx residual (floor) + capture.
MULTI-EVENT BASIN @ z+2.0m (5ev): gn 5/5 (RMS 7.8cm), LM 5/5 (RMS 4.9cm BEST floor), gnrec 5/5 (6.9cm). Adam FAILS ~0.8m.
BASIN EDGE: gn captures from z+5.2m (3/4, RMS 14.5cm) and 3.6m (2/2); LM fails beyond ~3.6m (adaptive ridge over-damps
far out); LM floor(0.4m) 1.8-13.7cm. => TRADEOFF: gn=WIDEST basin (>=5.2m), LM=TIGHTEST floor (~2-5cm), gnrec=middle.
LANDSCAPE: the longitudinal-t0 valley is the loose direction (charge-shape-limited ~15cm CRB). On AVERAGED truth gn
SLIDES along it to 17-30cm (no shot-noise to pin it); CW(charge weight)=10 reduces slide (30->17cm) + fixes energy
(+1.0MeV) but can't fully pin the longitudinal (fundamental charge-shape floor). Single-event shot noise pins it -> gn
works (5/5 @2.0m). [testing gn@6/8m edge + gnrec basin/floor]
RECIPE so far: GN = FD-Hessian(fixed) + median ridge(eps0.6) + POSITIVE eigen-clip(0.05) + TR0.3 damp0.7. Pos-clip ESSENTIAL.

## OPTIMIZER WINNER — gnrec (Gauss-Newton + periodic Hessian recompute) [2026-06-07 ~09:00]
Aggregated multi-event, MAXCELL=4, single-event truth (shot noise pins the longitudinal valley):
| opt   | start | conv  | vtxRMS | dirRMS | Ebias | note |
|-------|-------|-------|--------|--------|-------|------|
| gnrec | 5.2m  | 2/2   | 7.6cm  | 0.11   | +6    | CLEAN far-capture, best dir |
| gnrec | 2.8m  | 1/1   | 8.3cm  | 0.16   | +9    | |
| gnrec | floor | 2/2   | 10.5cm | 0.18   | +8    | |
| gnrec | 2.0m  | 5/5   | 7.3cm  | 0.21   | +5    | (Mgnr) clean energy |
| gn    | 6.0m  | 3/3   | 8.5cm  | 0.50   | -12   | captures but dir/E degrade |
| gn    | 8.0m  | 0/3   | FAIL   | -      | -     | basin edge < 8m (vtx 74-137cm) |
| gn    | 2.0m  | 5/5   | 7.8cm  | 0.28   | +6    | |
| lm    | 5.2m  | 0/3*  | ~35cm  | -      | -65   | stuck (barely<40); narrow basin |
| lm    | 2.0m  | 5/5   | 5.5cm  | 0.29   | -25   | tight floor BUT energy bias |
| Adam  | 0.8m  | fails | -      | -      | -     | |
WINNER = **gnrec**: periodic FD-Hessian recompute (RECOMP=10) gives BOTH the wide basin (clean 5.2m capture,
7.6cm/0.11deg) AND tight floor (7-10cm) AND clean energy (+5..+9, no LM-style bias) — all WITHOUT schedules,
one knob (RECOMP). gn (fixed Hessian) captures ~6m but its dir/energy degrade far out (stale curvature);
lm tightest floor but narrow basin + energy bias. Recompute is the lever: refreshing curvature as the step
moves keeps the metric valid across the long descent. [testing gnrec edge @8m(R40)/10m(R50) to pin its basin]

## gnrec BASIN SWEEP — captures from ANYWHERE in the tank [2026-06-07 09:33]
gnrec (GN + FD-Hessian recompute every RECOMP=10), single-event truth, MAXCELL=4, count-cond+AMP+renorm loss.
START_OFF in z (the LOOSE longitudinal direction, hardest), NITERS 350-400 (far=more):
  floor 0.4m  6/6  vtxRMS 9.0cm
  2.0m        5/5  7.3cm  dir0.21 E+5
  5.2m        4/4  6.0cm  dir0.11 E+6
  8.0m        2/2  7.1-9.7cm  dir0.12-0.31 E+3..+9
 10.0m        2/2  8.3-8.9cm  dir0.07-0.16 E+5..+9
 12.4m        1/1  10.3cm  dir0.19 E+12
 15.0m        1/1  10.0cm  dir0.07 E-25 (vertex/dir nail it; energy carries ~2% at the extreme edge)
NO failure point found within the tank (SK radius ~17m). Compare gn (FIXED Hessian): DIES at 8m (0/4, 114cm).
=> gnrec basin >= 15m ~ whole tank; vertex 7-10cm + dir <0.2deg from anywhere. The Hessian RECOMPUTE is the lever:
   gn's one-shot start-Hessian goes stale over a 10m descent (8m=0/4); gnrec refreshes curvature -> stays valid.
FINAL DELIVERABLE (both user aspects, no schedules, one knob RECOMP):
  (1) MINIMUM/floor: vtx ~7-9cm, dir ~0.1-0.2deg, E clean (+5..+9) -- == Adam floor.
  (2) BASIN: >=15m (whole tank), vs Adam ~0.8m, vs fixed-H gn ~6-7m. ~20x Adam.

## gnrec FINAL multi-event aggregate + COMBO (realistic) start [2026-06-07 09:50]
gnrec converges 11/11 across all far/combo starts (single-ev truth, MAXCELL=4):
  8m    3/3  vtxRMS 8.1cm  dir0.22 E+3
 10m    3/3         7.3cm  dir0.16 E+1
 12.4m  2/2         9.3cm  dir0.16 E+8
 15m    2/2        14.8cm  dir0.11 E-30  (extreme edge: vtx/E soften, one ev 18cm; DIR still 0.11deg)
 COMBO  1/1        10.3cm  dir0.12 E+11  (E+300MeV + vtx 2.08m + dir ~8deg ALL wrong simultaneously -- realistic seed)
=> The basin is the whole tank AND robust to the realistic multi-param wrong-seed (not just single-axis z). Only the
   extreme 15m edge softens vtx/E (dir stays). For practical seeding (<=12m, any direction) gnrec lands vtx 7-9cm/dir<0.2deg/E clean.
CAMPAIGN COMPLETE. Deliverable = gnrec (FD-Hessian recompute/10 + median-ridge + pos-clip): best floor (~7-9cm) AND
whole-tank basin, no schedules, one knob. Recorded in RECIPE.md + memory recon-maxcell-hessian-gn.

## PHOTONSIM FLOOR INVESTIGATION — "floor too high" RESOLVED [2026-06-07 23:13]
Observed: fresh loss_t4 PhotonSim floor 22-30cm (events 0-2), higher than the recorded 18.1cm. Investigated
(loss_t4_scan.py = scan loss along z/x/E/t0 around derive_truth for PhotonSim(PS) vs SIREN-self-consistency(SN)):
1. MEASUREMENT BUG (mine): loss_t4 ENV-GATES AMP_DETACH+OVERLAP_RENORM; opt_lab HARDCODES both. My re-runs left
   them OFF -> floor inflated. With fixes: ev0 22.6->13.9, ev1 30.0->24.3, ev2 13.2->10.6 (mean ~22->~16cm ==
   the recorded 18.1). The transverse/t0 contamination collapsed (x -0.18->+0.03). => loss_t4 now DEFAULTS both ON.
2. GEOMETRY hypothesis REFUTED by control (SIREN-matched floor, start@truth, gnrec): VERTICAL pol~3deg vtx 7.9/4.3cm
   ~= SLANTED pol~34deg 11.5/7.0cm. Near-vertical tracks do NOT inflate the floor; the flat z-valley is shot-noise-
   pinned when truth=SIREN. So the PhotonSim inflation is NOT geometry.
3. SCAN localized the genuine ~16cm PhotonSim floor (vs ~7cm SIREN) to TWO emitter/observable limits, NOT recon bugs:
   (a) EMISSION mismatch: PS CHARGE argmin offset z -0.40m / x +0.3-0.6m / E -50 (SIREN charge SHAPE != GEANT4);
       SN charge argmin is CLEAN (z 0.00, E 0.00) -> loss + derive_truth charge reference are SOUND.
   (b) first-arrival TIME bias ~+0.2m z / -0.5ns t0, present EVEN in SIREN self-consistency (SN time argmin z+0.20
       t0-0.50) -> intrinsic soft-min/order-stat bias; explains every fit's t0~-0.7ns.
CONCLUSION: nothing broken. PhotonSim floor = ~16cm with the proper loss; gap to 7cm SIREN-ideal = emission fidelity
+ time bias. To push lower: better emitter (SIREN vs GEANT4) and/or full-waveform/de-biased time (not first-arrival).
