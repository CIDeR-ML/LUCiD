"""TAU hyperparameter scan on the TIME-driven params (z, t0, y) vs PhotonSim truth.
For each TAU, scans the param offset and reports the time-channel and full-loss (WT=0.03) argmin, to see
whether the soft-first-arrival bias (t0 +2.6ns etc.) can be reduced by the time-softness TAU.
Usage: CUDA_VISIBLE_DEVICES=g python tau_scan.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

WT = float(os.environ.get('WT', '0.03'))
NKEYS = int(os.environ.get('NKEYS', '8'))
TAUS = [1.5, 2.0, 4.0, 8.0, 16.0]
PARAMS = {3: ('z', 1.0), 6: ('t0', 4.0), 2: ('y', 1.0)}    # idx -> (name, half-range)
NPTS = 25

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim')
theta_star = jnp.array(S['theta_star'])
keys = [jax.random.PRNGKey(3000 + k) for k in range(NKEYS)]
print(f"setup done nhit={S['nhit']} sumobs={S['sumobs']:.0f}", flush=True)

def amin(offs, y):
    j = int(np.argmin(y))
    if 0 < j < len(y)-1:
        a, b, c = y[j-1], y[j], y[j+1]; den = a-2*b+c
        return offs[j] + (0.5*(a-c)/den if abs(den) > 1e-12 else 0.0)*(offs[1]-offs[0])
    return offs[j]

for tau in TAUS:
    loss_j = jax.jit(PS.make_loss(S, WT=WT, TAU=tau))
    for p, (nm, half) in PARAMS.items():
        offs = np.linspace(-half, half, NPTS)
        T = np.zeros(NPTS); Fm = np.zeros(NPTS)
        for i, o in enumerate(offs):
            th = theta_star.at[p].add(float(o))
            ts = []; fs = []
            for k in keys:
                c, t, f = loss_j(th, k); ts.append(float(t)); fs.append(float(f))
            T[i] = np.mean(ts); Fm[i] = np.mean(fs)
        print(f"TAU={tau:5.1f}  {nm:3s}: time_argmin={amin(offs,T):+.4g}  full_argmin={amin(offs,Fm):+.4g}", flush=True)
