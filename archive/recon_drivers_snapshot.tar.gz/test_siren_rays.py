"""Directly test the SIREN ray-generation gradients vs FD (fixed key => deterministic =>
clean AD-vs-FD for origin/direction; energy goes through argsort selection so its geometry
gradient is expected to be sampled/detached, only the weights carry it)."""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
from lucid.sources.siren_rays import photonsim_differentiable_get_rays
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=4, suppress=True)

pp = unpack_photonsim_params('muon', 'water')
predictor = SIRENPredictor(pp['siren_model_path'])
grid = create_photonsim_siren_grid(predictor)
mparams = predictor.params
na, nb, nc = pp['num_seeds']
Nphot = 20000
key = jax.random.PRNGKey(0)

def rays(origin, direction, energy):
    return photonsim_differentiable_get_rays(origin, direction, energy, Nphot, grid, mparams, key, na, nb, nc)

O0 = jnp.array([0.5, -0.3, 0.4]); D0 = jnp.array([0.2, 0.1, 0.97]); E0 = jnp.array(1050.0)

def fd(f, x0, i, h):
    xp = x0.at[i].add(h) if x0.ndim else x0 + h
    xm = x0.at[i].add(-h) if x0.ndim else x0 - h
    return (float(f(xp)) - float(f(xm))) / (2 * h)

print(f"Nphot={Nphot}", flush=True)

# --- d(sum origins)/d(track_origin): expect identity diagonal = Nphot ---
def sum_orig_O(o): return jnp.sum(rays(o, D0, E0)[1])
g = np.array(jax.grad(sum_orig_O)(O0))
gfd = np.array([fd(sum_orig_O, O0, i, 1e-4) for i in range(3)])
print(f"\nd(sum ray_origins)/d(track_origin):  AD={g}  FD={gfd}  (expect ~[{Nphot},{Nphot},{Nphot}])", flush=True)

# --- d(sum origins)/d(track_direction) ---
def sum_orig_D(d): return jnp.sum(rays(O0, d, E0)[1])
g = np.array(jax.grad(sum_orig_D)(D0)); gfd = np.array([fd(sum_orig_D, D0, i, 1e-4) for i in range(3)])
print(f"d(sum ray_origins)/d(track_direction): AD={g}  FD={gfd}", flush=True)

# --- d(sum ray_vectors)/d(track_direction) ---
def sum_dirs_D(d): return jnp.sum(rays(O0, d, E0)[0])
g = np.array(jax.grad(sum_dirs_D)(D0)); gfd = np.array([fd(sum_dirs_D, D0, i, 1e-4) for i in range(3)])
print(f"d(sum ray_vectors)/d(track_direction): AD={g}  FD={gfd}", flush=True)

# --- d(sum weights)/d(energy): smooth via SIREN (but argsort selection may add jumps) ---
def sum_w_E(e): return jnp.sum(rays(O0, D0, e)[2])
g = float(jax.grad(sum_w_E)(E0))
print(f"\nd(sum photon_weights)/d(energy): AD={g:.4f}", flush=True)
for h in [10.0, 3.0, 1.0, 0.3]:
    print(f"   FD(h={h}) = {fd(sum_w_E, E0, None, h):.4f}", flush=True)

# --- d(sum origins)/d(energy): expect ~0 (ranges are sampled, detached from energy) ---
def sum_orig_E(e): return jnp.sum(rays(O0, D0, e)[1])
g = float(jax.grad(sum_orig_E)(E0))
print(f"\nd(sum ray_origins)/d(energy): AD={g:.4f}  (expect 0 -> energy does NOT move the ray geometry)", flush=True)
# and the geometric spread of origins along the track (the emission profile) vs energy:
def mean_range_E(e):
    o = rays(O0, D0, e)[1]
    return jnp.mean(jnp.linalg.norm(o - O0[None, :], axis=1))
print(f"   mean photon range at E0    = {float(mean_range_E(E0)):.4f} m", flush=True)
print(f"   mean photon range at E0+200= {float(mean_range_E(E0+200)):.4f} m  (does the profile move with energy?)", flush=True)
print(f"   d(mean range)/d(energy) AD = {float(jax.grad(mean_range_E)(E0)):.6f}", flush=True)
