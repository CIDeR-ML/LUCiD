"""BINNED Poisson first-arrival loss vs PhotonSim TRUTH (is_data=True) — the realistic case.

TRUTH = real PhotonSim GEANT4 photons (rotated/translated onto the target track) through the SAMPLE engine
(is_data=True, hard overlap, Bernoulli QE, hard first-arrival, TTS). SIM = SIREN expected predictor.
Loss = binned Poisson first-arrival (R-only) + raw Poisson charge. Per-event argmin x, energy (charge / joint).
Also reports the self-consistency control (EXPECTED-engine SIREN truth, the 'should-be-perfect' case) at the
same stats for direct comparison. K=8 MAXCELL=16 TTS=2.5.
Env: NPHOT NKEYS NEV SIGMA DELTA.  Usage: CUDA_VISIBLE_DEVICES=g python loss_ps_binned.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '16')); NEV = int(os.environ.get('NEV', '20'))
SIGMA = float(os.environ.get('SIGMA', '2.5')); DELTA = float(os.environ.get('DELTA', '1.0')); K = 8
PS = np.asarray(H.PARAM_SCALE); TGT_POL, TGT_AZ = 0.6, 0.8; theta_true = np.array([1050.0, 0, 0, 0, TGT_POL, TGT_AZ, 0.0])
track = H.theta_to_track(jnp.asarray(theta_true)); SQ = float(np.sqrt(2.0))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
print(f"# BINNED loss vs PhotonSim TRUTH  NPH={NPH} NKEYS={NKEYS} NEV={NEV} SIGMA={SIGMA} DELTA={DELTA} K={K} MC={os.environ['MAXCELL']}", flush=True)

def _rod(v, ax, an):
    ax = ax / (np.linalg.norm(ax) + 1e-12); return v * np.cos(an) + np.cross(ax, v) * np.sin(an) + ax * (ax @ v) * (1 - np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.asarray(raw['photon_origins']) / 100.0; _, _, vt = np.linalg.svd(P - P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0) + ((P - P.mean(0)) @ d0).min() * d0
    dt = np.array([np.sin(TGT_POL) * np.cos(TGT_AZ), np.sin(TGT_POL) * np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0 @ dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax / (np.linalg.norm(ax) + 1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH)
ND = H.num_detectors(pred)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=int(os.environ['MAXCELL']), physics_config=H.PHYS, default_detector_params=True,
    particle='muon', wavelength_mode=True, apply_smearing=False)
exp_truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False, use_expected_value=True,
    hit_mode='realistic', max_sensors_per_cell=int(os.environ['MAXCELL']), physics_config=H.PHYS,
    default_detector_params=True, particle='muon', wavelength_mode=True)
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def log1mexp(a):
    a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
def make(oc, ot, hit, wt):
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hit = jax.lax.stop_gradient(hit)
    def loss(theta, key):
        log_w, ft, fi, tot = pred(H.theta_to_track(theta), key)
        w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - theta[6])[fi]
        def Rof(tt): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf((tt - ft) / (SIGMA * SQ))), fi, num_segments=ND)
        R_lo = Rof(tobs - DELTA / 2); dR = jnp.maximum(Rof(tobs + DELTA / 2) - R_lo, 1e-12)
        nll = R_lo - log1mexp(-dR)
        time = jnp.sum(jnp.where(hit & (dR > 1e-9), nll, 0.0)); mu = jnp.maximum(tot, 1e-8)
        return jnp.sum(mu - oc * jnp.log(mu)) + wt * time
    return loss
def argmin(lj, i, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts)
    c = np.array([np.mean([float(lj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

for srcname in ['PHOTONSIM', 'EXPECTED-selfconsist']:
    acc = {('charge', 'x'): [], ('charge', 'e'): [], ('joint', 'x'): [], ('joint', 'e'): []}
    for ev in range(NEV):
        if srcname == 'PHOTONSIM':
            pd = photon_data_for(ev); oc, ot = jax.lax.stop_gradient(data_sim(track, jax.random.PRNGKey(7 * ev), pd))
            hit = oc > 0; ot = jnp.where(hit, ot, 0.0)
        else:
            oc, ot, hit = H.gen_truth(exp_truth, jnp.asarray(theta_true), jax.random.PRNGKey(7 * ev))
        for tag, wt in [('charge', 0.0), ('joint', 1.0)]:
            lj = jax.jit(make(oc, ot, hit, wt)); acc[(tag, 'x')].append(argmin(lj, 1)); acc[(tag, 'e')].append(argmin(lj, 0))
    print(f"# --- {srcname} truth (NEV={NEV}) ---", flush=True)
    for tag in ['charge', 'joint']:
        x = np.array(acc[(tag, 'x')]); e = np.array(acc[(tag, 'e')])
        print(f"#   {tag:6s}  x bias {x.mean():+.3f} +/- {x.std()/np.sqrt(NEV):.3f} (std {x.std():.3f}) m | "
              f"energy {e.mean():+6.1f} +/- {e.std()/np.sqrt(NEV):.1f} (std {e.std():.1f}) MeV", flush=True)
print(f"# READ: EXPECTED-selfconsist should be ~0 if the loss is perfect; PHOTONSIM adds emission + engine residual.", flush=True)
