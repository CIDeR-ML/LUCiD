"""Enhanced Hessian comparison: configurable K (env K), per-parameter diag(H_ad) vs diag(H_fd),
and an is_scat/trajectory softening toggle (env SOFT_SCAT). Bypasses the NaN-sanitizer custom_vjp.
Usage: LOSS=sumq NKEYS=24 K=7 SOFT_SCAT=0 CUDA_VISIBLE_DEVICES=g XLA_PYTHON_CLIENT_PREALLOCATE=false python hess_compare2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW              # bypass sanitizer
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NKEYS = int(os.environ.get('NKEYS', '16'))
DSTEP = float(os.environ.get('DSTEP', '0.3'))
K     = int(os.environ.get('K', '7'))
NPHOT = int(os.environ.get('NPHOT', '30000'))
LOSS  = os.environ.get('LOSS', 'sumq')
PNAMES = H.PARAM_NAMES

# Build predictor with configurable K (recon_ps_setup.setup hardcodes K=7, so build pred ourselves).
PS.K = K                                              # so setup uses our K for the truth sim too
S = PS.setup(event=0, nphot=NPHOT, truth_source='siren', pred_temperature=0.1, truth_key=0)
ts = np.array(S['theta_star']); oc = np.array(S['oc']); SC = np.array(H.PARAM_SCALE)

# Override the predictor with our K (setup built it at PS.K already, but be explicit)
_PGT = os.environ.get('PGT'); _NGI = os.environ.get('NGI')
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHOT,
                         pos_grad_threshold=(int(_PGT) if _PGT is not None else None),
                         n_grad_iters=(int(_NGI) if _NGI is not None else None))

def lc(th, k):
    _, _, _, q = pred(H.theta_to_track(th), k)
    if LOSS == 'sumq': return jnp.sum(q)
    if LOSS == 'quad': return 0.5 * jnp.sum((q - oc) ** 2)
    return jnp.sum(q - oc * jnp.log(q + 1e-8))

print(f"LOSS={LOSS}  K={K}  NPHOT={NPHOT}  NKEYS={NKEYS}  DSTEP={DSTEP}  SOFT_SCAT={os.environ.get('SOFT_SCAT','0')}")
hess = jax.jit(jax.hessian(lc)); gfn = jax.jit(jax.grad(lc))
ks = [jax.random.PRNGKey(40000 + i) for i in range(NKEYS)]

Had = np.mean([np.array(hess(jnp.asarray(ts), k)) for k in ks], 0) * np.outer(SC, SC)
def gbar(th): return np.mean([np.array(gfn(jnp.asarray(th), k)) for k in ks], 0)
Hfd = np.zeros((7, 7))
for j in range(7):
    d = DSTEP * SC[j]
    Hfd[:, j] = (gbar(ts + np.eye(7)[j] * d) - gbar(ts - np.eye(7)[j] * d)) / (2 * DSTEP) * SC
Hfd = 0.5 * (Hfd + Hfd.T)

print("autodiff Hessian finite:", bool(np.isfinite(Had).all()))
dad, dfd = np.diag(Had), np.diag(Hfd)
print(f"{'param':>8}  {'diag_ad':>12}  {'diag_fd':>12}  {'ratio':>8}")
for i, nm in enumerate(PNAMES):
    r = dad[i] / dfd[i] if abs(dfd[i]) > 1e-9 else float('nan')
    print(f"{nm:>8}  {dad[i]:12.4f}  {dfd[i]:12.4f}  {r:8.3f}")
num = np.linalg.norm(Had - Hfd); den = np.linalg.norm(Hfd)
cos = float((Had.ravel() @ Hfd.ravel()) / (np.linalg.norm(Had.ravel()) * np.linalg.norm(Hfd.ravel()) + 1e-12))
print(f"relative ||H_ad-H_fd||/||H_fd|| = {num/den:.4f}    cosine = {cos:.4f}")

# Per-block cosine: energy(0), pos(1-3), dir(4-5), t0(6)
blocks = {'energy': [0], 'pos': [1,2,3], 'dir': [4,5], 't0': [6]}
for bn, idx in blocks.items():
    A = Had[np.ix_(idx, idx)].ravel(); B = Hfd[np.ix_(idx, idx)].ravel()
    c = float((A @ B) / (np.linalg.norm(A) * np.linalg.norm(B) + 1e-12))
    rel = np.linalg.norm(A - B) / (np.linalg.norm(B) + 1e-12)
    print(f"  block {bn:>7}: cosine={c:7.4f}  rel={rel:7.4f}")
