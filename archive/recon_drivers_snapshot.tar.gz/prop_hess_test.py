"""Propagator-level 2nd-order AD-vs-FD test.

Isolates lucid/propagation/cylinder.py (via DetectorGeometry.from_config +
det_geom.propagator). Photons' origins/directions are a smooth (pathwise)
function of a 6-vector track p=[origin(3), direction(3)]. We build a scalar
from the propagator outputs (surface_distance, positions, normals) and compare
jax.hessian to a central-FD Hessian of the gradient.

Env toggles (each replaces ONE suspect op in lucid/propagation/cylinder.py at
import time via monkeypatch; default = no patch = baseline):
  PROP_VARIANT = base       (default, unmodified)
                 safe_cap    (safe 1/ray_dir[2] in cap intersection)
                 safe_wall   (safe 1/(2a) in wall intersection)
                 safe_div    (both safe divisions)
                 soft_min    (soft-min over wall/top/bottom t instead of hard min/argmin)
                 soft_normal (softmax-weighted normal instead of where-select)
                 all         (safe_div + soft_min + soft_normal)
  SCALAR  = sd       sum of surface_distance (default)
            pos      sum of hit_positions
            normal   sum of normals
            all      sum of sd+pos+normal
  NPHOT   number of photons (default 24000)
  FD_STEP base FD step (default 1e-3, in meters / dir-units)
"""
import os
os.environ.setdefault('JAX_PLATFORM_NAME', 'gpu')
os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE', 'false')

import numpy as np
import jax
import jax.numpy as jnp
from functools import partial

jax.config.update('jax_enable_x64', False)

VARIANT = os.environ.get('PROP_VARIANT', 'base')
SCALAR = os.environ.get('SCALAR', 'sd')
NPHOT = int(os.environ.get('NPHOT', '24000'))
FD_STEP = float(os.environ.get('FD_STEP', '1e-3'))

# ───────────────────────── monkeypatch suspect ops ─────────────────────────
import lucid.propagation.cylinder as CYL
from jax import lax

LARGE = 1e10


def _safe_cap_intersect(ray_origin, ray_direction, r, z):
    """Cap intersection with a SAFE 1/ray_direction[2] (no 1/0 at grazing)."""
    dz = ray_direction[2]
    safe_dz = jnp.where(jnp.abs(dz) < 1e-9, 1e-9, dz)
    t_plane = (z - ray_origin[2]) / safe_dz
    ipt = ray_origin + t_plane * ray_direction
    within_circle = (ipt[0]**2 + ipt[1]**2) <= r**2
    parallel = jnp.abs(dz) < 1e-9
    intersects_ = (t_plane > 0) & within_circle & (~parallel)
    tval_ = jnp.where(intersects_, t_plane, LARGE)
    return (intersects_, tval_)


def _safe_wall_intersect(ray_origin, ray_direction, r, h):
    """Wall intersection with a SAFE 1/(2a) (no 1/0 at axis-parallel)."""
    a = ray_direction[0]**2 + ray_direction[1]**2
    b = 2.0 * (ray_origin[0]*ray_direction[0] + ray_origin[1]*ray_direction[1])
    c = ray_origin[0]**2 + ray_origin[1]**2 - r**2
    discriminant = b**2 - 4*a*c
    epsilon = 1e-6
    sqrt_disc = jnp.sqrt(jnp.maximum(discriminant, 1e-6))
    safe_2a = jnp.where(jnp.abs(a) < 1e-9, 1e-9, 2*a)
    t1 = (-b - sqrt_disc) / safe_2a
    t2 = (-b + sqrt_disc) / safe_2a
    t1, t2 = jnp.minimum(t1, t2), jnp.maximum(t1, t2)
    valid_t = (t1 > 0) | (t2 > 0)
    t_candidate = jnp.where(t1 > 0, t1, t2)
    ipt = ray_origin + t_candidate * ray_direction
    within_height = jnp.abs(ipt[2]) <= (h / 2)
    parallel = jnp.abs(a) < 1e-9
    intersects_ = (discriminant >= -epsilon) & valid_t & within_height & (~parallel)
    tval_ = jnp.where(intersects_, t_candidate, LARGE)
    return (intersects_, tval_)


def _make_softmin_intersect_cylinder(beta):
    """intersect_cylinder with a SOFT (smooth) min/select over the 3 surfaces.

    Returns (any_intersects, soft_min_t, soft_part_onehot) but keeps the same
    3-tuple signature; part index returned as a soft argmin (float) is not used
    downstream for gradients (it feeds grid indexing which is stop_gradient'd),
    so we still return the hard argmin int for indexing but the SOFT t for the
    differentiated distance.
    """
    wall_fn = CYL.intersect_cylinder_wall
    cap_fn = CYL.intersect_cylinder_cap

    def intersect_cylinder_soft(ray_origin, ray_direction, r, h):
        wi, wt = wall_fn(ray_origin, ray_direction, r, h)
        ti, tt = cap_fn(ray_origin, ray_direction, r, h / 2)
        bi, bt = cap_fn(ray_origin, ray_direction, r, -h / 2)
        ts = jnp.stack([wt, tt, bt], axis=0)
        intersects = jnp.stack([wi, ti, bi], axis=0)
        # soft-min weights (smooth selection of the nearest surface)
        w = jax.nn.softmax(-beta * ts)
        soft_t = jnp.sum(w * ts)
        hard_idx = jnp.argmin(ts)   # int, only used for stop_gradient grid lookup
        any_intersects = jnp.any(intersects)
        return any_intersects, soft_t, hard_idx
    return intersect_cylinder_soft


def _make_soft_normal(beta):
    """calculate_cylinder_normals with softmax blend instead of where-select.

    is_wall/is_top_cap are bool; we keep them but additionally smooth the
    geometry switch. Since the hard which-surface here is itself a discrete
    function of the (continuous) intersection geometry, we blend using the
    *signed distance to each surface region*. Simpler: keep the original
    where but this variant is only meaningful if surface flags are themselves
    smooth — they are not here (they come from argmin). So instead we blend
    wall vs caps by a smooth function of |z| relative to h/2 boundary.
    """
    orig = CYL.calculate_cylinder_normals

    def soft_normals(intersection_point, is_wall, is_top_cap):
        xy = intersection_point[:, :2]
        wall_n = xy / (jnp.linalg.norm(xy, axis=1, keepdims=True) + 1e-10)
        wall_n = jnp.concatenate([wall_n, jnp.zeros_like(intersection_point[:, :1])], axis=1)
        top_n = jnp.array([0., 0., 1.])
        bot_n = jnp.array([0., 0., -1.])
        cap_n = jnp.where((intersection_point[:, 2:3] >= 0), top_n, bot_n)
        # keep hard where (these flags are not differentiable anyway); this
        # variant is a no-op structurally but provided for completeness.
        return jnp.where(is_wall[:, None], wall_n,
                         jnp.where(is_top_cap[:, None], top_n, bot_n))
    return soft_normals


_patches = []


def _apply_variant(v):
    if v in ('safe_cap', 'safe_div', 'all'):
        # Replace the cap intersection's normal branch with a safe-division version.
        # We override intersect_cylinder_cap entirely (keeping parallel handling
        # folded into the safe form so no lax.cond 1/0 survives).
        orig_cap = CYL.intersect_cylinder_cap
        CYL.intersect_cylinder_cap = jax.jit(_safe_cap_intersect)
        _patches.append(('intersect_cylinder_cap', orig_cap))
    if v in ('safe_wall', 'safe_div', 'all'):
        orig_wall = CYL.intersect_cylinder_wall
        CYL.intersect_cylinder_wall = jax.jit(_safe_wall_intersect)
        _patches.append(('intersect_cylinder_wall', orig_wall))
    if v in ('soft_min', 'all'):
        beta = float(os.environ.get('SOFT_BETA', '50.0'))
        orig_ic = CYL.intersect_cylinder
        CYL.intersect_cylinder = jax.jit(_make_softmin_intersect_cylinder(beta))
        _patches.append(('intersect_cylinder', orig_ic))
    if v in ('soft_normal', 'all'):
        beta = float(os.environ.get('SOFT_BETA', '50.0'))
        orig_n = CYL.calculate_cylinder_normals
        CYL.calculate_cylinder_normals = _make_soft_normal(beta)
        _patches.append(('calculate_cylinder_normals', orig_n))


_apply_variant(VARIANT)

# IMPORTANT: intersect_cylinder is called inside intersect_cylinder_with_grid,
# which is module-level @jax.jit and captured CYL.intersect_cylinder at def time.
# Re-bind the grid function to pick up the patched intersect_cylinder / cap / wall.
# We rebuild intersect_cylinder_with_grid's closure by re-exec is overkill; instead
# patch by re-defining it to call the (now-patched) module functions.

import importlib
# Rebuild the grid intersector so it references the patched functions.
_src_ic = CYL.intersect_cylinder
_src_wall = CYL.intersect_cylinder_wall
_src_cap = CYL.intersect_cylinder_cap


@partial(jax.jit, static_argnums=(2, 3, 4, 5, 6))
def _grid_intersect(ray_origin, ray_direction, r, h, n_cap, n_angular, n_height):
    intersects, t, part = _src_ic(ray_origin, ray_direction, r, h)
    intersection_point = ray_origin + t * ray_direction
    angle = jnp.arctan2(intersection_point[1], intersection_point[0]) % (2 * jnp.pi)
    angular_idx = jnp.floor(angle / (2 * jnp.pi) * n_angular).astype(jnp.int32)
    angular_idx = angular_idx % n_angular
    height_idx = jnp.floor((intersection_point[2] + h / 2) / h * n_height).astype(jnp.int32)
    height_idx = jnp.clip(height_idx, 0, n_height - 1)
    cap_x = (intersection_point[0] + r) / (2 * r)
    cap_y = (intersection_point[1] + r) / (2 * r)
    cap_x_idx = jnp.clip(jnp.floor(cap_x * n_cap).astype(jnp.int32), 0, n_cap - 1)
    cap_y_idx = jnp.clip(jnp.floor(cap_y * n_cap).astype(jnp.int32), 0, n_cap - 1)
    wall_indices = jnp.array([angular_idx, height_idx])
    cap_indices = jnp.array([cap_x_idx, cap_y_idx])
    is_wall = part == 0
    is_top_cap = part == 1
    return intersects, t, is_wall, is_top_cap, wall_indices, cap_indices, intersection_point


CYL.batch_intersect_cylinder_with_grid = jax.vmap(
    _grid_intersect, in_axes=(0, 0, None, None, None, None, None))

# ───────────────────────── build the propagator ─────────────────────────
from lucid.geometry.detector_geometry import DetectorGeometry

CFG = 'config/SK_geom_config.json'
det_geom = DetectorGeometry.from_config(CFG, temperature=0.1, max_sensors_per_cell=4)
propagate_fn = det_geom.propagator

det = det_geom.detector
R = float(det.r); Hc = float(det.H)
print(f"[setup] variant={VARIANT} scalar={SCALAR} nphot={NPHOT} R={R:.2f} H={Hc:.2f} "
      f"nsensors={det_geom.num_sensors}")

# ───────────────────────── pathwise photon factory ─────────────────────────
# Fixed (parameter-independent) per-photon design: arc-lengths t_i along the
# track, and a fixed set of cone offset directions. Origins and directions are
# SMOOTH functions of p, so position/direction enter purely pathwise.
rng = np.random.default_rng(0)
# arc-length samples along the track (meters), keep photons inside the tank
t_arc = jnp.asarray(rng.uniform(-3.0, 3.0, size=NPHOT).astype(np.float32))
# build a fixed orthonormal-ish set of cone perturbation vectors (param-free)
cone_a = jnp.asarray(rng.normal(size=(NPHOT, 3)).astype(np.float32))
cone_b = jnp.asarray(rng.normal(size=(NPHOT, 3)).astype(np.float32))
cone_amp = 0.6  # how wide the emission cone is


def make_rays(p):
    o = p[:3]
    d = p[3:]
    dn = d / (jnp.linalg.norm(d) + 1e-12)
    # two perpendicular basis vectors to dn (Gram-Schmidt of the fixed cone_a/b)
    a_perp = cone_a - (cone_a @ dn)[:, None] * dn[None, :]
    b_perp = cone_b - (cone_b @ dn)[:, None] * dn[None, :]
    # directions: cone around dn (smooth in d)
    dirs = dn[None, :] + cone_amp * a_perp + cone_amp * b_perp
    dirs = dirs / (jnp.linalg.norm(dirs, axis=1, keepdims=True) + 1e-12)
    # origins: along the track (smooth in o and d)
    origins = o[None, :] + t_arc[:, None] * dn[None, :]
    return origins, dirs


def scalar_from_results(p):
    origins, dirs = make_rays(p)
    res = propagate_fn(origins, dirs)
    hit_positions = res['positions']         # (N,3)
    normals = res['normals']                 # (N,3)
    surface_distances = jnp.sqrt(
        jnp.sum((hit_positions - origins)**2, axis=1) + 1e-12) - 1e-6
    s_sd = jnp.sum(surface_distances)
    s_pos = jnp.sum(hit_positions)
    s_norm = jnp.sum(normals)
    if SCALAR == 'sd':
        return s_sd
    if SCALAR == 'pos':
        return s_pos
    if SCALAR == 'normal':
        return s_norm
    return s_sd + s_pos + s_norm


# ───────────────────────── parameter point ─────────────────────────
# A track centered in the tank, pointing diagonally (generic, not axis-aligned,
# so we don't sit on a degenerate 1/0). Direction unnormalized on purpose.
p0 = jnp.asarray(np.array([0.3, -0.5, 0.2,   0.4, 0.3, 0.85], dtype=np.float32))

val = float(scalar_from_results(p0))
g0 = jax.grad(scalar_from_results)(p0)
print(f"[value] scalar(p0)={val:.6f}  finite={np.isfinite(val)}")
print(f"[grad ] {np.array(g0)}  finite={bool(np.isfinite(np.array(g0)).all())}")

# ───────────────────────── AD Hessian ─────────────────────────
H_ad = np.array(jax.hessian(scalar_from_results)(p0))
print(f"[H_ad ] finite={bool(np.isfinite(H_ad).all())}")

# ───────────────────────── central-FD Hessian of the gradient ─────────────────
gfn = jax.jit(jax.grad(scalar_from_results))
n = 6
H_fd = np.zeros((n, n))
eye = np.eye(n, dtype=np.float32)
for j in range(n):
    dj = FD_STEP
    gp = np.array(gfn(p0 + jnp.asarray(eye[j] * dj)))
    gm = np.array(gfn(p0 - jnp.asarray(eye[j] * dj)))
    H_fd[:, j] = (gp - gm) / (2 * dj)
H_fd = 0.5 * (H_fd + H_fd.T)

# symmetrize AD too for fair comparison
H_ad_s = 0.5 * (H_ad + H_ad.T)

num = np.linalg.norm(H_ad_s - H_fd)
den = np.linalg.norm(H_fd)
cos = float((H_ad_s.ravel() @ H_fd.ravel()) /
            (np.linalg.norm(H_ad_s.ravel()) * np.linalg.norm(H_fd.ravel()) + 1e-30))

np.set_printoptions(precision=4, suppress=True, linewidth=160)
print("\n[diag H_ad]", np.diag(H_ad_s))
print("[diag H_fd]", np.diag(H_fd))
print(f"\n==> relative ||H_ad - H_fd|| / ||H_fd|| = {num/den:.4f}")
print(f"==> cosine(flatten)                     = {cos:.4f}")
print(f"==> ||H_ad||={np.linalg.norm(H_ad_s):.3e}  ||H_fd||={np.linalg.norm(H_fd):.3e}")
