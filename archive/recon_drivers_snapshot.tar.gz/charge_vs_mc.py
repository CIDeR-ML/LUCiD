"""WHY so many MAXCELL? Total + per-occupancy charge vs max_sensors_per_cell, for a given overlap temperature.
Each photon only sees the <=MC sensors in its grid cell; if a cell holds >MC sensors the rest are dropped ->
missed charge. Is the MC requirement the GRID (hard overlap loses too) or the soft-overlap SPREAD (soft loses more)?
Reference = this temp at MC=64. Run one temp per process (PRED_TEMP), loops MC internally.
Env: PRED_TEMP NPHOT NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g PRED_TEMP=0.1 python charge_vs_mc.py   (PRED_TEMP=none for hard)
"""
import os
os.environ.setdefault('TTS_NS','2.5')
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH=int(os.environ.get('NPHOT','500000')); NKEYS=int(os.environ.get('NKEYS','4')); K=8
TEMP=os.environ.get('PRED_TEMP','0.1'); temp=None if TEMP=='none' else float(TEMP)
POL,AZ=0.6,0.8; th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
trk=sc(jnp.asarray(th9))
print(f"# CHARGE vs MAXCELL  temp={TEMP}  NPH={NPH} NKEYS={NKEYS}",flush=True)
MCS=[4,8,16,24,32,48,64]
tot={}; perpmt={}
for mc in MCS:
    os.environ['MAXCELL']=str(mc)
    sim=setup_event_simulator(H.GEOM, n_photons=NPH, temperature=temp, K=K, is_data=False, use_expected_value=True,
        hit_mode='per_photon', max_sensors_per_cell=mc, physics_config=H.PHYS, default_detector_params=True,
        particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
    ND=H.num_detectors(sim)
    q=np.mean([np.asarray(jax.lax.stop_gradient(sim(trk,jax.random.PRNGKey(s)))[3]) for s in range(NKEYS)],0)
    tot[mc]=q.sum(); perpmt[mc]=q
ref=tot[64]
print(f"#  MC | total Q | Q/Q(MC64) | charge LOST vs MC64",flush=True)
for mc in MCS:
    print(f"#  {mc:2d} | {tot[mc]:8.1f} | {tot[mc]/ref:.4f} | {tot[mc]-ref:+7.1f}",flush=True)
# per-occupancy at MC=16 vs MC=64 (where is the loss?)
q16,q64=perpmt[16],perpmt[64]
print(f"#  per-occupancy ratio MC16/MC64 (occupancy by q64):",flush=True)
for lo,hi in [(0.01,0.1),(0.1,0.3),(0.3,1.0),(1.0,3.0),(3.0,100)]:
    sel=np.where((q64>lo)&(q64<=hi))[0]
    if sel.size: print(f"#    occ {lo:.2f}-{hi:<5.1f} N{sel.size:5d}  q16/q64 {q16[sel].sum()/max(q64[sel].sum(),1e-9):.4f}",flush=True)
print(f"# READ: hard(temp=none) MC-flat + soft MC-sensitive => soft-overlap SPREAD; both lose => GRID (cells hold >MC sensors).",flush=True)
