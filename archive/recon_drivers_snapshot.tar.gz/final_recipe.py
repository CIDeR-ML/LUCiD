"""Final recipe following the explicit evidence: energy is the blocker (per-sensor charge NLL -> +15.7%
from the SIREN ring-shape mismatch); given correct E the vertex (~12cm, full loss) and direction (~0.1deg,
time) are recoverable. So decouple energy from the corrupted per-sensor shape:
  ALTERNATE  [E from TOTAL charge (shape-robust), pos fixed]  <->  [full-loss pos/dir/t0, E fixed],
  then a TIME-only direction/t0 polish.  PhotonSim. Reports convergence + final.
Diagnostic: total-charge E at the TRUE vertex (should be ~ the +2-4% calibration offset, not +15.7%).
Usage: CUDA_VISIBLE_DEVICES=g python final_recipe.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
THR = 4.0; SC = np.array(H.PARAM_SCALE); SCHED = [2, 1, 0.5, 0.3, 0.2]
S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; SUMOBS = S['sumobs']
def gchan(WT_, TAU_, chan):
    f = PS.make_loss(S, WT=WT_, TAU=TAU_, THR=THR); return jax.jit(jax.grad(lambda th,k: f(th,k)[chan]))
gchrg = gchan(0.0, 0.3, 0)
gfull = {tau: gchan(0.05, tau, 2) for tau in SCHED}
gtime = {tau: gchan(1.0, tau, 1) for tau in SCHED}
def etot_loss(theta, key):
    _,_,_,q = pred(H.theta_to_track(theta), key); return ((jnp.sum(q)-SUMOBS)/SUMOBS)**2 * 1e4
getot = jax.jit(jax.grad(etot_loss))
def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr=np.zeros(7)
    if freeze:
        for i in freeze: fr[i]=1.0
    T=[]
    for s in range(steps):
        ks=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in ks]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st*(1-fr))
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t): return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t): return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
def anneal(th, gd, freeze, t0, steps=50):
    for j,tau in enumerate(SCHED): th=gnlm(th, gd[tau], steps, freeze=freeze, tag=t0+j)
    return th

# diagnostic: total-charge E at the TRUE vertex/dir
thd = gnlm(jnp.array(ts.copy()), getot, 80, freeze=[1,2,3,4,5,6], tag=950)
print(f"FINAL seed={SEED}  [diag] total-charge E @ true vertex = {Ep(thd):+.1f}%  (vs per-sensor +15.7%)", flush=True)

rng=np.random.default_rng(SEED)
th=jnp.array(ts + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
th=gnlm(th, gchrg, 90, tag=1)
print(f"  rough charge: vtx={vtx(th):.0f}cm E={Ep(th):+.0f}%", flush=True)
for it in range(4):
    th=gnlm(th, getot, 60, freeze=[1,2,3,4,5,6], tag=500+it)    # E from total charge (pos fixed)
    th=anneal(th, gfull, [0], 600+it*10)                         # vertex from full loss (E fixed)
    print(f"  round {it}: vtx={vtx(th):5.1f}cm  E={Ep(th):+.1f}%  dir={deg(th):.2f}", flush=True)
th=anneal(th, gtime, [0], 800)                                   # final TIME-only direction/t0/long-vtx polish
print(f"  + time polish: vtx={vtx(th):5.1f}cm  E={Ep(th):+.1f}%  dir={deg(th):.2f}  t0={float(th[6]-ts[6]):+.2f}ns", flush=True)
