"""Two distinct taus, tested properly:
  tau_SMOOTH = SPATIAL Gaussian smoothing of the per-PMT CHARGE (dist_weights @ charge, like WC_smooth_loss)
  tau_TIME   = first-arrival timing-kernel softness.
The ring-width SIREN-vs-PhotonSim mismatch is HIGH spatial frequency; smoothing both pred & obs charge with
tau_SMOOTH >~ the ring width should suppress it while preserving the total (energy) and ring location (vertex).

(1) DECISIVE 1D: at the true vertex, scan ENERGY -> argmin of the tau_SMOOTH-smoothed charge loss, for several
    tau_SMOOTH. Raw per-sensor gave +15.7%; does smoothing pull it to the ~+1.8% total-charge value?
    Also scan z (a vertex axis) at true energy -> is the smoothed-charge vertex argmin at truth?
Usage: CUDA_VISIBLE_DEVICES=g python smooth_test.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=3, suppress=True)
NK = int(os.environ.get('NKEYS', '8'))
TAUS_SMOOTH = [0.0, 1.0, 2.0, 4.0]            # metres; 0 = raw per-sensor

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; oc = jnp.asarray(S['oc']); SUMOBS = S['sumobs']
dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
sp = jnp.asarray(np.array(dg.sensor_points))                 # (ND,3) m
a = jnp.sum(sp**2, axis=1)
G = sp @ sp.T
d2 = jnp.clip(a[:, None] + a[None, :] - 2*G, 0.0, None)       # pairwise squared distance (ND,ND)

def smoother(tau):
    if tau <= 0: return None
    W = jnp.exp(-d2 / (2*tau**2))
    return W / (jnp.sum(W, axis=0, keepdims=True) + 1e-8)     # column-normalized -> conserves total

def charge_loss(q, W):
    if W is None:
        qs, os_ = q, oc
    else:
        qs, os_ = W @ q, W @ oc
    return jnp.sum(qs - os_ * jnp.log(qs + 1e-8))

keys = [jax.random.PRNGKey(9000+k) for k in range(NK)]
def qpred(theta):
    qs = [jax.jit(pred)(H.theta_to_track(jnp.asarray(theta)), k)[3] for k in keys]
    return qs
def loss_at(theta, W):
    return float(np.mean([float(charge_loss(q, W)) for q in qpred(theta)]))

print(f"=== smoothed-charge tests (NK={NK}); raw per-sensor energy bias was +15.7% ===", flush=True)
Ws = {t: smoother(t) for t in TAUS_SMOOTH}

# (1a) ENERGY scan at the true vertex
dEs = np.array([-200, -150, -100, -50, 0, 50, 100, 150, 200, 250, 300])     # MeV offsets
print("\n[ENERGY argmin @ true vertex] (parabola-interpolated, MeV and %):", flush=True)
for t in TAUS_SMOOTH:
    ys = np.array([loss_at(ts + np.array([dE,0,0,0,0,0,0]), Ws[t]) for dE in dEs])
    j = int(np.argmin(ys))
    if 0 < j < len(ys)-1:
        A,B,C = ys[j-1],ys[j],ys[j+1]; den=A-2*B+C
        am = dEs[j] + (0.5*(A-C)/den if abs(den)>1e-9 else 0)*(dEs[1]-dEs[0])
    else: am = dEs[j]
    print(f"  tau_smooth={t:>4}m : E argmin = {am:+.0f} MeV ({am/ts[0]*100:+.1f}%)", flush=True)

# (1b) z-vertex scan at the true energy
dZs = np.linspace(-1.0, 1.0, 11)
print("\n[z-vertex argmin @ true energy] (m):", flush=True)
for t in TAUS_SMOOTH:
    ys = np.array([loss_at(ts + np.array([0,0,0,dz,0,0,0]), Ws[t]) for dz in dZs])
    j = int(np.argmin(ys))
    if 0 < j < len(ys)-1:
        A,B,C = ys[j-1],ys[j],ys[j+1]; den=A-2*B+C
        am = dZs[j] + (0.5*(A-C)/den if abs(den)>1e-9 else 0)*(dZs[1]-dZs[0])
    else: am = dZs[j]
    print(f"  tau_smooth={t:>4}m : z argmin = {am:+.3f} m", flush=True)
