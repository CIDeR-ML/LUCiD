#!/usr/bin/env python3
"""Direct SIREN-mean vs GEANT4-mean per-PMT charge comparison (same gun, averaged over many showers).
Reads /tmp/cmp_cmpm_*.npz (muG=GEANT4 per-event expected, muS=SIREN expected, tt=hit time, th9=truth)."""
import glob,numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
F=sorted(glob.glob('/tmp/cmp_cmpm_*.npz'))
D=[np.load(f) for f in F]
TH=np.array([d['th9'] for d in D])
print(f'{len(D)} events. Same-gun check (std over events): E={TH[:,0].std():.1f}MeV vtx={np.linalg.norm(TH[:,1:4].std(0))*100:.1f}cm')
# all same frame (gun fixed) -> average per-PMT over events = GEANT4 mean
muG=np.mean([d['muG'] for d in D],0)   # GEANT4 mean (showers averaged)
muS=np.mean([d['muS'] for d in D],0)   # SIREN mean
tt=D[0]['tt']
print(f'TOTAL charge: GEANT4 {muG.sum():.0f}  SIREN {muS.sum():.0f}  ratio S/G = {muS.sum()/muG.sum():.4f}')
sel=(muG>0.02)|(muS>0.02)
print(f'lit PMTs (muG>0.5): {int((muG>0.5).sum())}  corr={np.corrcoef(muG[sel],muS[sel])[0,1]:.4f}')

fig,ax=plt.subplots(2,2,figsize=(13,10))
# (a) per-PMT scatter SIREN vs GEANT4
ax[0,0].scatter(muG[sel],muS[sel],s=6,alpha=0.3)
m=max(muG[sel].max(),muS[sel].max()); ax[0,0].plot([0,m],[0,m],'k--',label='y=x'); ax[0,0].plot([0,m],[0,1.03*m],'r:',label='+3%')
ax[0,0].set_xlabel('GEANT4 mean charge / PMT'); ax[0,0].set_ylabel('SIREN mean charge / PMT'); ax[0,0].set_title('Per-PMT: SIREN vs GEANT4 mean'); ax[0,0].legend(); ax[0,0].grid(alpha=0.3)
# (b) charge vs hit time profile
hit=(muG>0.05)|(muS>0.05); th=tt[hit]; o=np.argsort(th)
bins=np.linspace(np.percentile(th,1),np.percentile(th,99),25); ic=np.digitize(th,bins)
gG=[muG[hit][ic==i].sum() for i in range(1,len(bins))]; gS=[muS[hit][ic==i].sum() for i in range(1,len(bins))]
bc=0.5*(bins[1:]+bins[:-1])
ax[0,1].plot(bc,gG,'o-',label='GEANT4',color='C0'); ax[0,1].plot(bc,gS,'s-',label='SIREN',color='C3')
ax[0,1].set_xlabel('hit time - t0 (ns)  [early=forward]'); ax[0,1].set_ylabel('summed charge in bin'); ax[0,1].set_title('Charge vs hit-time profile'); ax[0,1].legend(); ax[0,1].grid(alpha=0.3)
# (c) residual (SIREN-GEANT4) vs hit time
rr=[(muS[hit]-muG[hit])[ic==i].sum() for i in range(1,len(bins))]
ax[1,0].bar(bc,rr,width=(bc[1]-bc[0])*0.9,color=['C3' if r>0 else 'C0' for r in rr]); ax[1,0].axhline(0,color='k',lw=0.6)
ax[1,0].set_xlabel('hit time - t0 (ns)'); ax[1,0].set_ylabel('SIREN - GEANT4 charge'); ax[1,0].set_title('Residual vs hit-time (red=SIREN over)'); ax[1,0].grid(alpha=0.3)
# (d) charge distribution (per-PMT histogram, lit)
b=np.linspace(0,np.percentile(muG[muG>0.5],99),30)
ax[1,1].hist(muG[muG>0.05],bins=b,alpha=0.5,label=f'GEANT4 (tot {muG.sum():.0f})',color='C0')
ax[1,1].hist(muS[muS>0.05],bins=b,alpha=0.5,label=f'SIREN (tot {muS.sum():.0f})',color='C3')
ax[1,1].set_xlabel('charge / PMT'); ax[1,1].set_ylabel('# PMTs'); ax[1,1].set_title('Per-PMT charge distribution'); ax[1,1].legend(); ax[1,1].grid(alpha=0.3); ax[1,1].set_yscale('log')
fig.suptitle(f'SIREN mean vs GEANT4 mean ({len(D)} showers, same gun): total ratio S/G = {muS.sum()/muG.sum():.3f}',fontsize=13)
fig.tight_layout(rect=[0,0,1,0.97]); fig.savefig('recon_plots/siren_vs_geant.png',dpi=110); print('wrote siren_vs_geant.png')
