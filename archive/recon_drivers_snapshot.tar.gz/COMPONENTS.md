# Every part of the simulation (TRUTH = sample engine vs PREDICTOR = expected engine)

Pipeline: source -> per-photon optics -> geometry/overlap -> K-step propagation -> readout.
S = SHARED (identical code, only photon-key realization differs). D = DIFFERS truth vs predictor.

## Source & emission  (both is_data=False -> same SIREN path _simulation_without_data_impl)
1. S  SIREN ray gen: photon origins, directions, weights  (photonsim_differentiable_get_rays)
2. S  photon-number norm: tot_n_photons_normalization(E) * weights / Nphot  -> photon_intensities
3. S  emission times: predict_t0(distance_to_vertex, E)  (stop_gradient)

## Per-photon optics  (_get_optical_arrays)
4. S  wavelength sampling (Cherenkov spectrum)
5. S  scatter_length, mie_scatter_length, absorption_length  (medium coeffs at lambda)
6. S  qe_per_photon = qe_fn(lambda) * detector.qe

## Geometry / overlap  (propagate_photons = det_geom.propagator; same for both at fixed temperature)
7. S  surface-distance + sensor-cell intersection (which sensors, distance-to-center)
8. D  OVERLAP weight overlap_prob(distance)  -- HARD top-hat (temp=None) vs SOFT Gaussian (temp=0.1).
      [== CAUSE #1, the ~1% total under-count; FIXED via OVERLAP_RENORM]
9. S  inside_detector bounds check; survival accumulation; K-iteration lax.scan; max_sensors_per_cell

## Propagation STEP  (D: photon_step_sample [hard binary] vs photon_step [expected/Rao-Blackwell]) -- sub-pieces:
10. D  reach/scatter decision (reach_surface_prob = exp(-Dd*mu_tot))      hard u1<reach   vs  hard d<Dd
11. D  scatter direction (Rayleigh/Mie mixture)                            sampled         vs  sampled (detached score)
12. D  reflection (specular sensor / diffuse wall)                         hard branch     vs  hard branch
13. D  ABSORPTION                                                          Bernoulli {0,1} vs  continuous atten=exp(-d/abs)
14. D  DETECTION deposit                                                   detects {0,1}   vs  reach*(1-refl)*atten_surf (continuous, RB)
15. D  continuing_factor / survival update                                where(detects,0,atten) vs where(is_scat,atten,refl*atten)
16. D  DiCE score increment                                                0 (truth)       vs  lf+la (fwd value=1)
17. S  time update  (dist/c)

## Readout make_hits  (D: make_hits_data [truth] vs make_hits_likelihood [predictor])
18. D  QE application            Bernoulli coin (u<qe) on binary weights   vs  continuous weight*qe
19. D  threshold                 1e-5 on flat_weights                      vs  1e-10 on qe_weights
20. D  charge aggregation        segment_sum                               vs  segment_sum  (same op)
21. D  time: first-arrival       segment_min over QE-passed slots (+TTS)   vs  per-photon log_w/times for the loss
22. D  TTS smearing              per-photon Gaussian (data only)           vs  modeled in the loss (sigma)

## Where the two CONFIRMED causes live
- CAUSE #1 (total/energy ~1%): part 8 (soft overlap) -- FIXED.
- CAUSE #2 (longitudinal ~6cm charge SHAPE, persists at temp=None): MUST be in parts 10-16 (STEP) and/or 18-20
  (CHARGE readout). To isolate: 2x2 = {STEP: sample/expected} x {readout: data/likelihood}, all temp=None,
  high stats, compare per-PMT charge + longitudinal profile.  -> loss_components.py
