"""ALIGNMENT A8 — smearing toggle (TRUE only). Per-PMT charge + first-arrival time of the hard truth
with apply_smearing False vs True (per-sensor SK gain+time smear). Quantifies the per-sensor smear knob
that the SIM path omits. Same SIREN source, track, K=8, hard overlap, MIE off, TTS_NS=0.
Env: NPHOT NKT.  Usage: CUDA_VISIBLE_DEVICES=g python align_a8.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '100000')); NKT = int(os.environ.get('NKT', '24')); K = 8
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NS); dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A8 smearing (per-sensor SK) toggle  NPH={NPH} NKT={NKT} K={K} TTS_NS=0 MIE off", flush=True)
def truth(sm):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
        hit_mode='realistic', max_sensors_per_cell=8, physics_config=H.PHYS, default_detector_params=dp_off,
        particle='muon', wavelength_mode=True, apply_smearing=sm)
def run(sm):
    qs, ts_ = [], []
    for s in range(NKT):
        c, t = [np.asarray(x) for x in jax.lax.stop_gradient(truth(sm)(track, jax.random.PRNGKey(s)))]
        qs.append(c); ts_.append(np.where(c > 1e-6, t, np.nan))
    return np.mean(qs, 0), np.nanmean(ts_, 0)
q0, t0 = run(False); q1, t1 = run(True)
lit = (q0 > 1e-6) & (q1 > 1e-6)
print(f"# total charge: no-smear {q0.sum():.1f}  smear {q1.sum():.1f}  (Δtot {100*(q1.sum()-q0.sum())/q0.sum():+.1f}%)", flush=True)
print(f"# per-PMT charge corr {np.corrcoef(q0[lit],q1[lit])[0,1]:.4f} ; mean|Δq|/q {np.abs(q0-q1)[lit].sum()/q0.sum():.2%}", flush=True)
tl = lit & np.isfinite(t0) & np.isfinite(t1)
print(f"# per-PMT first-arrival time Δ(smear-nosmear): median {np.median(t1[tl]-t0[tl]):+.3f} ns  std {(t1[tl]-t0[tl]).std():.3f} ns", flush=True)
print(f"# VERDICT: per-sensor SK smear effect on charge (gain) and time — quantified knob the SIM path omits.", flush=True)
