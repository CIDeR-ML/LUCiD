"""Phase-2 resolution campaign. Config locked: K=8, maxcell=16, cubic overlap, SIREN_IMPORTANCE.
Factored loss (energy DECOUPLED): lE=total-charge^2, lS=scale-invariant multinomial shape (energy
cancels), lT=count-decoupled first-arrival shape (THR-gated). oc/ot/hit passed as ARGS -> grad compiled
ONCE, reused across truth realizations. Resolution = scatter of MLEs over truth keys; bias = mean offset.
Optimizer = empirical-Fisher GN-LM (final_recipe.gnlm) with energy<->geometry alternation.
Env: TRUTH(photonsim/siren) NPHOT NK TKS(csv) WE WS WT TAU THR STRAT(alt/unified) LR LM
Set on cmdline: RECON_K=8 MAXCELL=16 OVERLAP_ANALYTIC=cubic SIREN_IMPORTANCE=1
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim python recon2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import first_arrival_nll, segment_logsumexp
np.set_printoptions(precision=3, suppress=True)

TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '100000'))
WE = float(os.environ.get('WE', '1.0')); WS = float(os.environ.get('WS', '1.0')); WT = float(os.environ.get('WT', '0.05'))
TAU = float(os.environ.get('TAU', '0.3')); THR = float(os.environ.get('THR', '4.0'))
NK = int(os.environ.get('NK', '6')); STRAT = os.environ.get('STRAT', 'alt')
LR = float(os.environ.get('LR', '0.4')); LM = float(os.environ.get('LM', '0.05'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3,4,5,6,7').split(',')]
SC = np.array(H.PARAM_SCALE); SCHED = [2.0, 1.0, 0.5, 0.3, 0.2]

POLAR = float(os.environ.get('POLAR', '0.6')); AZIM = float(os.environ.get('AZIM', '0.8'))
VX = float(os.environ.get('VX', '0.0')); VY = float(os.environ.get('VY', '0.0')); VZ = float(os.environ.get('VZ', '0.0'))
EVENT = int(os.environ.get('EVENT', '0'))   # which GEANT4 muon (vary the underlying event, not just QE key)
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1,
             target_vtx=(VX, VY, VZ), target_polar=POLAR, target_azim=AZIM)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def fa_shape(lw, ft, fi, tobs, tau, ND):
    t_obs = tobs[fi]; x = (t_obs - ft) / tau
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0)
    lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    loss = -lf - (Ns - 1.0) * l1mf
    return jnp.where(empty, 0.0, loss)

def terms(theta, key, ocf, otf, hitf):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    sumq = jnp.sum(q); sumobs = jnp.sum(ocf) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    phat = q / (sumq + 1e-8)
    lS = -jnp.sum(ocf * jnp.log(phat + 1e-8)) / sumobs * 100.0
    tmask = hitf & (ocf >= THR)
    lT = jnp.sum(jnp.where(tmask, fa_shape(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
    return lE, lS, lT

def lossfn(theta, key, ocf, otf, hitf, we, ws, wt):
    lE, lS, lT = terms(theta, key, ocf, otf, hitf)
    return we * lE + ws * lS + wt * lT
# channel grads (compiled once; weights baked per channel-combo via closures)
gE = jax.jit(jax.grad(lambda th, k, oc, ot, hi: terms(th, k, oc, ot, hi)[0]))
gpos = jax.jit(jax.grad(lambda th, k, oc, ot, hi: WS * terms(th, k, oc, ot, hi)[1] + WT * terms(th, k, oc, ot, hi)[2]))
gtime = jax.jit(jax.grad(lambda th, k, oc, ot, hi: terms(th, k, oc, ot, hi)[2]))
gall = jax.jit(jax.grad(lambda th, k, oc, ot, hi: lossfn(th, k, oc, ot, hi, WE, WS, WT)))
WTS = float(os.environ.get('WTS', '1.0'))   # strong time weight for staged stage-2 direction fit
gstrong = jax.jit(jax.grad(lambda th, k, oc, ot, hi: WS * terms(th, k, oc, ot, hi)[1] + WTS * terms(th, k, oc, ot, hi)[2]))

def gnlm(theta, gfn, oc, ot, hi, steps, freeze=None, tag=0, tail=30):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T = []
    for s in range(steps):
        ks = jax.random.split(jax.random.PRNGKey(101 + 7919 * tag + s), NK)
        G = np.stack([np.array(gfn(theta, k, oc, ot, hi)) * SC for k in ks]); g = G.mean(0); F = (G.T @ G) / NK
        dd = np.clip(np.diag(F), 1e-12, None)
        ev, V = np.linalg.eigh(F + LM * np.diag(dd) + 1e-9 * np.eye(7) * (dd.max() + 1e-12))
        ev = np.clip(ev, 2e-2 * ev.max(), None)
        st = np.clip(V @ np.diag(1 / ev) @ V.T @ g, -0.35, 0.35) * SC
        theta = theta - LR * jnp.array(st * (1 - fr))
        if s >= steps - tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def Ep(t): return float((t[0] - ts[0]) / ts[0] * 100)
def deg(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
def t0e(t): return float(t[6] - ts[6])

lval = jax.jit(lambda th, k, oc, ot, hi: WS * terms(th, k, oc, ot, hi)[1] + 0.05 * terms(th, k, oc, ot, hi)[2])
lTval = jax.jit(lambda th, k, oc, ot, hi: terms(th, k, oc, ot, hi)[2])    # time-only value (dir sphere search)
lCval = jax.jit(lambda th, k, oc, ot, hi: terms(th, k, oc, ot, hi)[1])    # charge-shape value (vtx grid)
from lucid.geometry.detector_geometry import DetectorGeometry as _DG
_dgo = _DG.from_config(H.GEOM, temperature=None, max_sensors_per_cell=MAXCELL)
SPOS = np.array(_dgo.sensor_points)   # (ND,3) sensor positions, same ordering as oc

def _sphere_dir(th, k, oc, ot, hi):
    """direction (polar,azim) from a TIME-loss sphere search at the current vertex (data-driven)."""
    bl = np.inf; bp, ba = th[4], th[5]
    for p in np.linspace(0.15, np.pi - 0.15, 12):
        for a in np.linspace(0, 2 * np.pi, 24, endpoint=False):
            t = th.copy(); t[4] = p; t[5] = a
            l = float(lTval(jnp.asarray(t), k, oc, ot, hi))
            if np.isfinite(l) and l < bl: bl = l; bp, ba = p, a
    th = th.copy(); th[4] = bp; th[5] = ba; return th

def _vtx_grid(th, k, oc, ot, hi, cen):
    """vertex from a CHARGE-shape grid search (centroid neighbourhood + detector-wide), then a tight refine."""
    best = th[1:4].copy(); bl = np.inf
    for ctr, span, n in [(cen, 6.0, 4), (np.zeros(3), 14.0, 4)]:
        for dx in np.linspace(-span, span, n):
            for dy in np.linspace(-span, span, n):
                for dz in np.linspace(-span, span, n):
                    v = ctr + np.array([dx, dy, dz])
                    if v[0]**2 + v[1]**2 > 16.5**2 or abs(v[2]) > 18.0: continue
                    t = th.copy(); t[1:4] = v
                    l = float(lCval(jnp.asarray(t), k, oc, ot, hi))
                    if np.isfinite(l) and l < bl: bl = l; best = v.copy()
    bl = np.inf; bv = best.copy()
    for dx in np.linspace(-3, 3, 5):
        for dy in np.linspace(-3, 3, 5):
            for dz in np.linspace(-3, 3, 5):
                t = th.copy(); t[1:4] = best + np.array([dx, dy, dz])
                l = float(lCval(jnp.asarray(t), k, oc, ot, hi))
                if np.isfinite(l) and l < bl: bl = l; bv = best + np.array([dx, dy, dz])
    th = th.copy(); th[1:4] = bv; return th

def data_init(oc, ot, hi, seed):
    """DATA-DRIVEN init, NO truth: neutral start -> dir sphere-search at the illumination centroid ->
    vertex charge-grid at that dir -> refine dir at the found vertex. Energy starts at a generic 800 MeV
    (lE refines it from total charge). t0 starts 0."""
    k = jax.random.PRNGKey(53 + seed); q = np.array(oc)
    cen = (q[:, None] * SPOS).sum(0) / (q.sum() + 1e-9)
    th = np.array(ts).copy(); th[0] = 800.0; th[4] = np.pi / 2; th[5] = 0.0; th[6] = 0.0  # neutral (no truth)
    th[1:4] = cen
    th = _sphere_dir(th, k, oc, ot, hi)          # rough direction (data)
    th = _vtx_grid(th, k, oc, ot, hi, cen)       # vertex at rough direction (data)
    th = _sphere_dir(th, k, oc, ot, hi)          # refine direction at found vertex (data)
    return jnp.asarray(th)

_GSPAN = float(os.environ.get('GSPAN', '0.45')); _GN = int(os.environ.get('GN', '5'))
def grid_vertex(th0, oc, ot, hi, seed):
    """Coarse 3D vertex grid-search on the charge-shape(+light-time) loss to escape local minima /
    wide starts before the gradient fit. Returns th0 with the best vertex (x,y,z)."""
    k = jax.random.PRNGKey(31 + seed)
    offs = np.linspace(-_GSPAN, _GSPAN, _GN)
    base = np.array(th0); best_l = np.inf; best_v = base[1:4].copy()
    for dx in offs:
        for dy in offs:
            for dz in offs:
                th = base.copy(); th[1] += dx; th[2] += dy; th[3] += dz
                l = float(lval(jnp.asarray(th), k, oc, ot, hi))
                if np.isfinite(l) and l < best_l: best_l = l; best_v = th[1:4]
    base[1:4] = best_v; return jnp.asarray(base)

def full_alt(th0, poschan, oc, ot, hi, seed, tag0):
    """rough pos/dir -> [E from total charge | pos/dir from poschan] x3. poschan = gpos (charge-heavy)
    or gstrong (time-heavy). Returns converged theta."""
    th = gnlm(th0, poschan, oc, ot, hi, 60, freeze=[0], tag=tag0 + seed)
    for it in range(3):
        th = gnlm(th, gE, oc, ot, hi, 35, freeze=[1, 2, 3, 4, 5, 6], tag=tag0 + 500 + it + 10 * seed)
        th = gnlm(th, poschan, oc, ot, hi, 55, freeze=[0], tag=tag0 + 600 + it + 10 * seed)
    return th

STARTW = float(os.environ.get('STARTW', '1.0'))   # init-offset scale (robustness: 1=default, >1 wider)
# REALISTIC absolute start widths (NOT tied to PARAM_SCALE; angle scale 0.02rad was too small a start).
EW = float(os.environ.get('EW', '200')); VW = float(os.environ.get('VW', '0.5'))
DW = float(os.environ.get('DW', '0.15')); TW0 = float(os.environ.get('TW0', '3.0'))  # MeV, m, rad(~8.6deg), ns
START_ABS = np.array([EW, VW, VW, VW, DW, DW, TW0])
def recon_one(oc, ot, hi, seed):
    rng = np.random.default_rng(1000 + seed)
    th0 = jnp.array(ts + rng.uniform(-1, 1, 7) * START_ABS * STARTW)
    if STRAT == 'pipeline':
        # DATA-DRIVEN init (no truth) -> charge refine (vtx/E) and time refine (dir/t0) from that init
        thi = data_init(oc, ot, hi, seed)
        if os.environ.get('DBGINIT', '0') == '1':
            print(f"    [init seed={seed}] vtx={vtx(thi):.1f}cm dir={deg(thi):.2f}deg", flush=True)
        thA = full_alt(thi, gpos, oc, ot, hi, seed, 0)               # charge -> vtx + E
        thB = gnlm(thi, gstrong, oc, ot, hi, 200, freeze=[0], tag=3000 + seed)  # time -> dir + t0 (from data init)
        return thA, thB
    if STRAT == 'unified':
        th = gnlm(th0, gall, oc, ot, hi, 160, tag=seed); return th, th
    if STRAT == 'twofit':
        thg = grid_vertex(th0, oc, ot, hi, seed) if os.environ.get('GRID', '1') == '1' else th0
        thA = full_alt(thg, gpos, oc, ot, hi, seed, 0)        # CHARGE-heavy: vtx + E (grid-anchored)
        thB = full_alt(th0, gstrong, oc, ot, hi, seed, 3000)  # TIME-heavy (from scratch): dir + t0
        return thA, thB
    # 'alt'/'staged': single charge-heavy alternation
    th = full_alt(th0, gpos, oc, ot, hi, seed, 0)
    if STRAT == 'staged':
        th_dir = gnlm(th, gstrong, oc, ot, hi, 130, freeze=[0], tag=800 + seed)
        return th, th_dir
    th = gnlm(th, gtime, oc, ot, hi, 70, freeze=[0, 1, 2, 3], tag=800 + seed)
    return th, th

rowsA = []; rowsB = []
print(f"# TRUTH={TRUTH} NPHOT={NPHOT} W=({WE},{WS},{WT}) TAU={TAU} THR={THR} STRAT={STRAT} K={PS.K} "
      f"start(E{EW},V{VW},D{DW}rad,t{TW0})xSTARTW={STARTW} EVENT={EVENT} POLAR={POLAR} AZIM={AZIM}", flush=True)
for tk in TKS:
    oc, ot, hi = regen(tk)
    thA, thB = recon_one(oc, ot, hi, tk)
    # FULL theta of EACH fit (consistent within a fit). A=charge fit, B=time fit. No chimera.
    rowsA.append((Ep(thA), vtx(thA), deg(thA), t0e(thA)))
    rowsB.append((Ep(thB), vtx(thB), deg(thB), t0e(thB)))
    print(f"  tk={tk}: fitA[E{Ep(thA):+5.1f}% v{vtx(thA):5.1f} d{deg(thA):4.2f} t{t0e(thA):+5.2f}] "
          f"fitB[E{Ep(thB):+5.1f}% v{vtx(thB):5.1f} d{deg(thB):4.2f} t{t0e(thB):+5.2f}]", flush=True)
def summ(A, lbl):
    A = np.array(A)
    return (f"{lbl}: E bias={A[:,0].mean():+.1f}% res={A[:,0].std():.1f}% | vtx {A[:,1].mean():.1f}+-{A[:,1].std():.1f}cm | "
            f"dir {A[:,2].mean():.2f}+-{A[:,2].std():.2f}deg | t0 bias={A[:,3].mean():+.2f} res={A[:,3].std():.2f}ns")
print(f"RESULT TRUTH={TRUTH} STRAT={STRAT} TAU={TAU} WTS={WTS} | CONSISTENT single-theta per fit:", flush=True)
print(f"  {summ(rowsA, 'fitA(charge->vtx/E)')}", flush=True)
print(f"  {summ(rowsB, 'fitB(time->dir/t0) ')}", flush=True)
