import os, time; os.environ['MAXCELL']='16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
N=int(os.environ.get('N','500000'))
tt=jnp.asarray(np.array([1050.,0,0,0,0.6,0.8,0.])); track=H.theta_to_track(tt)
t0=time.time(); pred=H.build_predictor(temperature=0.1,K=8,n_photons=N); 
out=pred(track, jax.random.PRNGKey(0)); out[3].block_until_ready(); t1=time.time()
out=pred(track, jax.random.PRNGKey(1)); out[3].block_until_ready(); t2=time.time()
print(f"N={N}: build+compile {t1-t0:.1f}s, second call {t2-t1:.2f}s, total_charge {float(out[3].sum()):.0f}, nphotons_out {out[1].shape[0]}")
