"""ALIGNMENT B9 — per-event stochasticity floor. PhotonSim event-to-event spread of the per-PMT charge
vs the SIREN key-to-key spread, both through the hard truth pipeline. Quantifies the irreducible
single-event noise (the recon floor) and whether PhotonSim carries EXTRA fluctuation beyond SIREN+Poisson
(GEANT4 shower/hadronic fluctuation a mean-field surrogate omits).
Env: NEV NKT NPHOT.  Usage: CUDA_VISIBLE_DEVICES=g python align_b9.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NEV = int(os.environ.get('NEV', '30')); NKT = int(os.environ.get('NKT', '30')); NPH = int(os.environ.get('NPHOT', '100000')); K = 8
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
TGT_POL, TGT_AZ = 0.6, 0.8; ts = np.array([1050.0, 0, 0, 0, TGT_POL, TGT_AZ, 0.0])
track = H.theta_to_track(jnp.array(ts)); dummy = track
def _rod(v, ax, an):
    ax = ax / (np.linalg.norm(ax) + 1e-12); return v*np.cos(an)+np.cross(ax, v)*np.sin(an)+ax*(ax@v)*(1-np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.asarray(raw['photon_origins'])/100.0; _, _, vt = np.linalg.svd(P-P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0@dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax/(np.linalg.norm(ax)+1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd
NS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NS); dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# B9 per-event stochasticity  NEV={NEV} NKT={NKT} NPH={NPH} K={K} MIE off", flush=True)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=8, physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True, apply_smearing=False)
siren = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=8, physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True, apply_smearing=False)
QP = np.array([np.asarray(jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev), photon_data_for(ev)))[0]) for ev in range(NEV)])
QS = np.array([np.asarray(jax.lax.stop_gradient(siren(track, jax.random.PRNGKey(s)))[0]) for s in range(NKT)])
def frac_spread(Q):
    mean = Q.mean(0); lit = mean > 0.05; rel = Q[:, lit].std(0) / mean[lit]; return mean.sum(), Q.sum(1).std()/Q.sum(1).mean(), np.median(rel)
tp, totp, medp = frac_spread(QP); tsr, tots, meds = frac_spread(QS)
print(f"# PhotonSim: total-charge event-to-event fluct {totp:.2%} ; median per-PMT fractional spread {medp:.2%}", flush=True)
print(f"# SIREN    : total-charge key-to-key   fluct {tots:.2%} ; median per-PMT fractional spread {meds:.2%}", flush=True)
# vertex-relevant projection: charge-weighted longitudinal centroid per event (spread => stochastic vtx floor proxy)
DP = np.asarray(generate_detector(H.GEOM).all_points)
dtv = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
proj = DP @ dtv
cp = (QP @ proj) / (QP.sum(1) + 1e-9); cs = (QS @ proj) / (QS.sum(1) + 1e-9)
print(f"# longitudinal charge-centroid (proj onto track axis) [m]: PhotonSim std {cp.std():.3f} (over {NEV} ev) ; SIREN std {cs.std():.3f} (over {NKT} keys)", flush=True)
print(f"# VERDICT: single-event per-PMT noise quantified = the irreducible recon floor. PhotonSim vs SIREN spread", flush=True)
print(f"#   comparison shows any EXTRA GEANT4 fluctuation beyond SIREN-mean+Poisson (mean-field surrogate limit).", flush=True)
