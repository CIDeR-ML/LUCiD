"""Q1 PROBE: robustness when CLOSE. Seed at truth + a random JOINT offset (ALL params perturbed together,
the realistic case -- one-at-a-time basins are optimistic) of scaled magnitude RHO, K random directions per
RHO. Refine with lE+lT_gd. Report convergence FRACTION (vtx<15 & dir<2 & t0<1 & E<20) and mean quality vs RHO.
Answers "within radius RHO, what do we robustly guarantee?". Offset unit = PARAM_SCALE (MeV,m,m,m,rad,rad,ns).
Env: TRUTH TTS_NS NKG SPS WT RHOS K TKS EVENT.
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
WT = float(os.environ.get('WT', '1.0')); NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '16')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0')); K = int(os.environ.get('K', '6'))
RHOS = [float(x) for x in os.environ.get('RHOS', '0.5,1.0,1.5,2.0,3.0').split(',')]
TKS = [int(x) for x in os.environ.get('TKS', '0,1').split(',')]
SC = np.array(H.PARAM_SCALE); deg = 180 / np.pi; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi)
# per-axis offset scale (one "rho unit"): direction/vertex/t0/energy in their natural target scales
USCALE = np.array([100.0, 0.15, 0.15, 0.15, 0.035, 0.035, 1.5])   # MeV, m, rad(~2deg), ns
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WT * lT
gfn = jax.jit(jax.grad(loss))

def refine(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g
            mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t):
    dv = lambda p: np.array([np.sin(p[4]) * np.cos(p[5]), np.sin(p[4]) * np.sin(p[5]), np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t)) @ dv(ts), -1, 1))))
def ok(t): return vtx(t) < 15 and degf(t) < 2 and abs(t[6]-ts[6]) < 1 and abs(t[0]-ts[0])/ts[0]*100 < 20

print(f"# JOINTBASIN TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} K={K} dirs/rho  USCALE={USCALE}  (joint offset = rho * USCALE * unit_vec)", flush=True)
print(f"#   rho     conv_frac   <vtx>   <dir>   <t0>   <E%>   (over converged) | worst", flush=True)
rng = np.random.RandomState(0)
for rho in RHOS:
    res = []
    for tk in TKS:
        oc, ot, hi = regen(tk)
        for kk in range(K):
            u = rng.randn(7); u = u / np.linalg.norm(u)
            th0 = ts + rho * USCALE * u
            thf = refine(th0, oc, ot, hi, tk * 100 + kk)
            res.append((ok(thf), vtx(thf), degf(thf), abs(thf[6]-ts[6]), abs(thf[0]-ts[0])/ts[0]*100))
    R = np.array([r[1:] for r in res]); frac = np.mean([r[0] for r in res])
    cw = np.array([r[1:] for r in res if r[0]])  # converged-only quality
    qual = cw.mean(0) if len(cw) else np.array([np.nan]*4)
    print(f"  {rho:5.2f}   {frac:6.2f}    {qual[0]:6.1f}  {qual[1]:5.2f}  {qual[2]:5.2f}  {qual[3]:5.1f}  | worst vtx={R[:,0].max():.0f}cm dir={R[:,1].max():.1f}", flush=True)
