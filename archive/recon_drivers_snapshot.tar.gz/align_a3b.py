"""ALIGNMENT A0+A3 (process-isolated) — per-PMT forward CHARGE: DiCE vs refactor-v2 STE vs sample truth.

Monkeypatching a shared custom_vjp mid-process collides with JAX's primal-jaxpr cache, so we
run each engine in its OWN process (fresh cache). ENGINE=ste patches the simulator's
`photon_iteration_update_factors_safe` to the refactor-v2 STE body BEFORE any build.

  ENGINE=dice : current DiCE engine; writes _a3_dice_K{K}.npy (+ _a3_samp_K{K}.npy truth)
  ENGINE=ste  : refactor-v2 STE engine; writes _a3_ste_K{K}.npy; then loads all three and compares.

Same SIREN source + same key + same baked optics (MIE OFF, L_M=1e9), K in {1,8}.
Env: ENGINE NPHOT NKG NKT MAXCELL.  Usage: CUDA_VISIBLE_DEVICES=g ENGINE=dice python align_a3b.py
"""
import os, jax, jax.numpy as jnp, numpy as np
ENGINE = os.environ.get('ENGINE', 'dice')
NPH = int(os.environ.get('NPHOT', '100000')); NKG = int(os.environ.get('NKG', '4'))
NKT = int(os.environ.get('NKT', '16')); MAXCELL = int(os.environ.get('MAXCELL', '8'))
KS = [1, 8]

from lucid.simulation.optics import (normalize, compute_reflection_direction,
    sample_cosine_hemisphere, sample_scatter_distance, compute_scatter_direction)
def OLD_update_factors(position, direction, time, surface_distance,
        normal, scatter_length, mie_scatter_length, g, wall_reflection_rate, sensor_reflection_rate,
        absorption_length, hit_sensor, rng_key, speed_of_light):
    """refactor-v2 photon_iteration_update_factors (STE mean-field), 14-arg/7-tuple, ignores Mie."""
    k1, k2, k3 = jax.random.split(rng_key, 3)
    reflection_rate = jnp.where(hit_sensor, sensor_reflection_rate, wall_reflection_rate)
    scatter_distance = sample_scatter_distance(surface_distance, scatter_length, k2)
    ratio = surface_distance / scatter_length
    reach_surface_prob = jnp.exp(-ratio); scatter_prob = -jnp.expm1(-ratio)
    reflect_prob = reach_surface_prob * reflection_rate
    detect_prob = reach_surface_prob * (1 - reflection_rate)
    reflection_attenuation = jnp.exp(-surface_distance / absorption_length)
    scatter_attenuation = jnp.exp(-scatter_distance / absorption_length)
    probs = jnp.array([reach_surface_prob, scatter_prob])
    probs_normalized = probs / (jnp.sum(probs) + 1e-10)
    u = jax.random.uniform(k1)
    hard_choice = (u < probs_normalized[0]).astype(jnp.float32)
    hard_weights = jnp.array([hard_choice, 1.0 - hard_choice])
    action_weights = hard_weights - jax.lax.stop_gradient(probs_normalized) + probs_normalized
    surface_weight = action_weights[0]; scatter_weight = action_weights[1]
    epsilon = 1e-4
    normal_refl = jax.lax.stop_gradient(normal); inward_normal = -normal_refl
    surface_pos = position + surface_distance * normalize(direction) + epsilon * normalize(inward_normal)
    scatter_pos = position + scatter_distance * normalize(direction)
    specular_dir = compute_reflection_direction(direction, normal_refl)
    diffuse_dir = sample_cosine_hemisphere(inward_normal, k3)
    reflection_dir = jnp.where(hit_sensor, specular_dir, diffuse_dir)
    scatter_dir = compute_scatter_direction(direction, k3)
    new_pos = surface_weight * surface_pos + scatter_weight * scatter_pos
    new_dir = normalize(surface_weight * reflection_dir + scatter_weight * scatter_dir)
    continuing_factor = reflect_prob * reflection_attenuation + scatter_prob * scatter_attenuation
    distance_traveled = surface_weight * surface_distance + scatter_weight * scatter_distance
    new_time = time + distance_traveled / speed_of_light
    return new_pos, new_dir, new_time, detect_prob, reflection_attenuation, continuing_factor, jnp.zeros_like(new_time)

# ---- PATCH BEFORE ANY BUILD (fresh process => no cache collision) ----
if ENGINE == 'ste':
    import lucid.simulation.simulator as SIM
    SIM.photon_iteration_update_factors_safe = OLD_update_factors
    print("# PATCHED simulator.photon_iteration_update_factors_safe = refactor-v2 STE", flush=True)

from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NUM_SENSORS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NUM_SENSORS)
dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A3b ENGINE={ENGINE} NPH={NPH} NKG={NKG} NKT={NKT} MAXCELL={MAXCELL} NUM_SENSORS={NUM_SENSORS} MIE OFF", flush=True)

def build_exp(K):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False,
        use_expected_value=True, hit_mode='per_photon', max_sensors_per_cell=MAXCELL,
        physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
        pos_grad_threshold=K, n_grad_iters=K)
def build_samp(K):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
        use_expected_value=False, hit_mode='realistic', max_sensors_per_cell=MAXCELL,
        physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
        apply_smearing=False)
def avg_charge(fn, nkeys, idx):
    return np.mean([np.asarray(jax.lax.stop_gradient(fn(track, jax.random.PRNGKey(s)))[idx]) for s in range(nkeys)], 0)

for K in KS:
    q = avg_charge(build_exp(K), NKG, 3)
    np.save(f"_a3_{ENGINE}_K{K}.npy", q)
    print(f"# {ENGINE} K={K}: total charge {q.sum():.2f}  litPMT {(q>1e-6).sum()}", flush=True)
    if ENGINE == 'dice':
        qt = avg_charge(build_samp(K), NKT, 0)
        np.save(f"_a3_samp_K{K}.npy", qt)
        print(f"# samp K={K}: total charge {qt.sum():.2f}  litPMT {(qt>1e-6).sum()}", flush=True)

if ENGINE == 'ste':
    def cmp(a, b, name):
        d = np.abs(a - b); lit = (a > 1e-6) | (b > 1e-6)
        cc = np.corrcoef(a[lit], b[lit])[0, 1] if lit.sum() > 2 else float('nan')
        print(f"#   {name:16s} tot {a.sum():9.2f} vs {b.sum():9.2f} (Δtot {100*(a.sum()-b.sum())/(b.sum()+1e-9):+5.1f}%)  "
              f"sum|Δ|/tot {d.sum()/(b.sum()+1e-9):6.2%}  max|Δ| {d.max():.4f}  corr {cc:.5f}", flush=True)
    print("\n# ===== A3 ENGINE COMPARISON (per-PMT charge) =====", flush=True)
    for K in KS:
        qd = np.load(f"_a3_dice_K{K}.npy"); qs = np.load(f"_a3_ste_K{K}.npy"); qt = np.load(f"_a3_samp_K{K}.npy")
        print(f"# --- K={K} ---", flush=True)
        cmp(qd, qs, 'DiCE vs STE')     # K=1 ~identical (A0); K=8 = the engine forward-charge change
        cmp(qd, qt, 'DiCE vs SAMPLE')  # current predictor vs truth
        cmp(qs, qt, 'STE  vs SAMPLE')  # refactor-v2 predictor vs truth
    print("# DiCE vs STE @K=8 = how much the forward charge model changed from refactor-v2 (engine only).", flush=True)
