"""Compare temperature=None (hard-step + sigmoid straight-through overlap) vs temperature=0.1 (jnp.interp
soft overlap), for BOTH the 1st-order gradient and the 2nd-order Hessian (autodiff vs FD), self-consistent
SIREN truth, LOSS=sum(q). Bypasses the step's NaN-sanitizer custom_vjp (needed for autodiff Hessians).
Usage: CUDA_VISIBLE_DEVICES=g python temp_test.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=140)
NKEYS=16; NPH=40000; SC=np.array(H.PARAM_SCALE)

def run(temp):
    S=PS.setup(event=0,nphot=NPH,truth_source='siren',pred_temperature=temp,truth_key=0)
    ts=np.array(S['theta_star']); pred=S['pred']
    lc=jax.jit(lambda th,k: jnp.sum(pred(H.theta_to_track(th),k)[3]))
    gfn=jax.jit(jax.grad(lambda th,k: jnp.sum(pred(H.theta_to_track(th),k)[3])))
    hess=jax.jit(jax.hessian(lambda th,k: jnp.sum(pred(H.theta_to_track(th),k)[3])))
    ks=[jax.random.PRNGKey(50000+i) for i in range(NKEYS)]
    gbar=lambda th: np.mean([np.array(gfn(jnp.asarray(th),k)) for k in ks],0)
    lbar=lambda th: np.mean([float(lc(jnp.asarray(th),k)) for k in ks])
    # GRADIENT AD vs FD at a +0.3*scale x-offset (well-resolved), normalized
    thg=ts.copy(); thg[1]+=0.3*SC[1]
    gad=gbar(thg)*SC
    gfd=np.array([(lbar(thg+np.eye(7)[j]*0.4*SC[j])-lbar(thg-np.eye(7)[j]*0.4*SC[j]))/(2*0.4)*SC[j] for j in range(7)])
    gcos=float(gad@gfd/(np.linalg.norm(gad)*np.linalg.norm(gfd)+1e-12)); gmag=np.linalg.norm(gad)/(np.linalg.norm(gfd)+1e-12)
    # HESSIAN AD vs FD at truth, normalized
    Had=np.mean([np.array(hess(jnp.asarray(ts),k)) for k in ks],0)*np.outer(SC,SC)
    Hfd=np.zeros((7,7))
    for j in range(7):
        Hfd[:,j]=(gbar(ts+np.eye(7)[j]*0.3*SC[j])-gbar(ts-np.eye(7)[j]*0.3*SC[j]))/(2*0.3)*SC
    Hfd=0.5*(Hfd+Hfd.T)
    hcos=float(Had.ravel()@Hfd.ravel()/(np.linalg.norm(Had.ravel())*np.linalg.norm(Hfd.ravel())+1e-12))
    hrel=float(np.linalg.norm(Had-Hfd)/(np.linalg.norm(Hfd)+1e-12))
    pb=slice(1,6)
    hcos_pos=float(Had[pb,pb].ravel()@Hfd[pb,pb].ravel()/(np.linalg.norm(Had[pb,pb].ravel())*np.linalg.norm(Hfd[pb,pb].ravel())+1e-12))
    return gcos,gmag,hcos,hrel,hcos_pos,bool(np.isfinite(Had).all())

for temp,lbl in [(None,'temperature=None (sigmoid straight-through)'),(0.1,'temperature=0.1 (jnp.interp soft)')]:
    gcos,gmag,hcos,hrel,hcos_pos,fin=run(temp)
    print(f"[{lbl}]", flush=True)
    print(f"   GRADIENT  cosine(AD,FD)={gcos:.3f}  |AD|/|FD|={gmag:.3f}", flush=True)
    print(f"   HESSIAN   finite={fin}  cosine(AD,FD)={hcos:.3f}  rel_err={hrel:.2f}  pos-block cosine={hcos_pos:.3f}", flush=True)
