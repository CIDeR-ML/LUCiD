"""BRUTE-FORCE vs GRID charge: is the MAXCELL loss a real BUG? Aim N rays at sensor centers (jittered INSIDE the
disk), hard overlap (temp=None => weight=1 if inside). BRUTE: for each ray's wall-hit point, the true answer is 1
if it lands inside some sensor (KDTree). GRID: the propagator's summed sensor_weights. A ray that is geometrically
INSIDE a sensor but gets grid weight ~0 = the sensor was MISSED from its cell list = the bug. Localize the misses.
Env: MC NRAY.  Usage: CUDA_VISIBLE_DEVICES=g python brute_force_charge.py
"""
import os
os.environ.setdefault('TTS_NS','2.5')
import numpy as np, jax, jax.numpy as jnp
from lucid.geometry import generate_detector
from lucid.propagation.cylinder import create_photon_propagator
from scipy.spatial import cKDTree
MC=int(os.environ.get('MC','16')); NRAY=int(os.environ.get('NRAY','40000'))
det=generate_detector('config/SK_geom_config.json')
P=np.asarray(det.raw_positions); rs=float(det.S_radius); R=float(det.r); Hh=float(det.H)
det.configure_grid(max_sensors_per_cell=MC); na,nh,nc=det._n_angular,det._n_height,det._n_cap
print(f"# BRUTE vs GRID  MC={MC} NRAY={NRAY}  n_ang={na} n_h={nh} n_cap={nc}  R={R:.2f} H={Hh:.2f} rs={rs:.3f}",flush=True)
prop=create_photon_propagator(jnp.asarray(P), rs, R, Hh, nc, na, nh, temperature=None, max_sensors_per_cell=MC)
rng=np.random.default_rng(0)
# pick random sensors, jitter target inside disk (radius 0.7*rs), ray from center through it
sidx=rng.integers(0,P.shape[0],NRAY); cen=P[sidx]
# random tangential jitter (perp to radial) within 0.7 rs
rad=cen/np.linalg.norm(cen,axis=1,keepdims=True)
t1=np.cross(rad,np.array([0,0,1.0])); t1/=np.linalg.norm(t1,axis=1,keepdims=True)+1e-9
t2=np.cross(rad,t1)
jr=float(os.environ.get("JF","0.7"))*rs*np.sqrt(rng.random(NRAY)); jth=2*np.pi*rng.random(NRAY)
target=cen+(jr*np.cos(jth))[:,None]*t1+(jr*np.sin(jth))[:,None]*t2
origins=np.zeros((NRAY,3)); dirs=target/np.linalg.norm(target,axis=1,keepdims=True)
res=prop(jnp.asarray(origins),jnp.asarray(dirs))
W=np.asarray(res['sensor_weights'])                                    # (MC, NRAY)
grid_q=W.sum(0)                                                        # per-ray grid charge
ip,_,_,_=det.intersect_ray(jnp.asarray(origins),jnp.asarray(dirs)); HP=np.asarray(ip)  # (NRAY,3) clean wall hit
# brute: nearest sensor to hit point; inside if dist<rs
tree=cKDTree(P); d,nn=tree.query(HP, k=1); brute_inside=(d<rs).astype(float)
miss=(brute_inside>0.5)&(grid_q<0.5)   # inside a sensor but grid missed it
print(f"#  rays inside a sensor (brute): {int(brute_inside.sum())}/{NRAY}  grid total {grid_q.sum():.0f}  brute total {brute_inside.sum():.0f}  grid/brute {grid_q.sum()/max(brute_inside.sum(),1):.4f}",flush=True)
print(f"#  MISSED (inside-but-grid-0): {int(miss.sum())} = {100*miss.sum()/max(brute_inside.sum(),1):.2f}% of inside-rays",flush=True)
if miss.sum()>0:
    mhp=HP[miss]; mr=np.sqrt(mhp[:,0]**2+mhp[:,1]**2); mz=mhp[:,2]
    onwall=np.abs(mr-R)<=2*rs
    print(f"#  of missed: {100*onwall.mean():.0f}% on WALL, {100*(1-onwall.mean()):.0f}% on CAPS;  miss z-range [{mz.min():.1f},{mz.max():.1f}] (H/2={Hh/2:.1f})",flush=True)
    # are misses near cell boundaries? fractional angular position of the missed hit
    ang=np.arctan2(mhp[:,1],mhp[:,0])%(2*np.pi); afrac=(ang/(2*np.pi)*na)%1
    print(f"#  missed angular-frac: mean {afrac.mean():.2f} (0/1=boundary, 0.5=center) frac<0.15or>0.85 = {100*((afrac<0.15)|(afrac>0.85)).mean():.0f}%",flush=True)
print(f"# READ: misses ~0% => grid is exact (loss is elsewhere); misses>0 & near boundaries => cell-assignment boundary BUG.",flush=True)
