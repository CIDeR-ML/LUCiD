"""Micro-probe: isolate whether the AD-vs-FD 2nd-deriv mismatch in the K=1 charge is the
overlap_prob (jnp.interp) curvature or the norm/normalize geometry. Mirrors the exact deposit
distance chain from lucid/propagation/base.py and sums overlap over a batch of rays vs a sensor.
"""
import os, numpy as np, jax, jax.numpy as jnp
from lucid.overlap import create_overlap_prob

r_sensor = 0.2542  # SK PMT radius (m) approx; value cancels in the comparison logic
sigma = 0.1 * r_sensor
mode = os.environ.get('OVL', 'interp')   # interp | erf | logistic
if mode == 'interp':
    os.environ.pop('OVERLAP_ANALYTIC', None)
else:
    os.environ['OVERLAP_ANALYTIC'] = mode
ov = create_overlap_prob(sigma, r_sensor)   # uses temperature*sensor_radius -> sigma here

rng = np.random.default_rng(0)
N = 4000
# random sensor centers + per-ray direction jitter BAKED as constants (deterministic across traces)
centers = jnp.asarray(rng.normal(0, 3.0, size=(N, 3)))
DIR_JIT = jnp.asarray(rng.normal(0, 0.3, size=(N, 3)))
def charge(theta):
    # theta = [x,y,z, dx,dy,dz] a single shared track-vertex shift + dir; rays fan out
    o = theta[:3]
    base_dir = theta[3:6]
    origins = o[None, :]
    dirs = base_dir[None, :] + DIR_JIT
    rd = dirs / (jnp.linalg.norm(dirs, axis=1, keepdims=True) + 1e-10)
    oc = origins - centers
    t_closest = -jnp.sum(oc * rd, axis=1, keepdims=True)
    closest = origins + t_closest * rd
    to_sensor = closest - centers
    soft = float(os.environ.get('SOFTNORM', '0'))   # eps^2 added inside sqrt to regularize 2nd deriv
    if soft > 0:
        distance = jnp.sqrt(jnp.sum(to_sensor**2, axis=1) + soft**2)
    else:
        distance = jnp.linalg.norm(to_sensor, axis=1)
    w = ov(distance)
    return jnp.sum(w)

th = jnp.array([0.1, -0.2, 0.3, 0.5, 0.2, 0.8])
g = jax.jit(jax.grad(charge)); Hf = jax.jit(jax.hessian(charge))
Had = np.array(Hf(th))
# FD hessian
def gv(t): return np.array(g(jnp.asarray(t)))
eps = float(os.environ.get('FDEPS', '1e-3'))
Hfd = np.zeros((6, 6))
for j in range(6):
    e = np.zeros(6); e[j] = eps
    Hfd[:, j] = (gv(th + e) - gv(th - e)) / (2 * eps)
Hfd = 0.5 * (Hfd + Hfd.T)
np.set_printoptions(precision=4, suppress=True, linewidth=140)
print(f"OVL={mode}")
print("diag Had:", np.diag(Had))
print("diag Hfd:", np.diag(Hfd))
num = np.linalg.norm(Had - Hfd); den = np.linalg.norm(Hfd) + 1e-12
cos = float(Had.ravel() @ Hfd.ravel() / (np.linalg.norm(Had.ravel()) * np.linalg.norm(Hfd.ravel()) + 1e-12))
print(f"rel={num/den:.4f}  cosine={cos:.4f}")
