"""SEEDER (charge-coarse grid) + Fisher-GN pipeline — the "from far" solution. No local optimizer crosses a random
~10m, so seed first: grid-search (vertex x direction) scored by CHARGE NLL only (charge is time-independent -> t0
irrelevant for the seed), pick min-NLL -> seed within the local basin -> Fisher-GN(min||g||) polish. Reports
seed-to-truth distance AND final resolution, over varied (isotropic dir + fiducial shift) PhotonSim events.
Env: EVENT_* NVTXR NVTXZ NDIR NPHOT_PRED. Usage: CUDA_VISIBLE_DEVICES=0 EVENT_START=0 EVENT_COUNT=8 python seeder_grid.py
"""
import os,time
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=3, suppress=True, linewidth=170)
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NBUF=400_000
MC=int(os.environ['MAXCELL']); K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0)); NPHP=int(os.environ.get('NPHOT_PRED','500000'))
E0=int(os.environ.get('EVENT_START','0')); EC=int(os.environ.get('EVENT_COUNT','8')); FIDR=12.; FIDZ=12.
NVTXR=int(os.environ.get('NVTXR','3')); NVTXZ=int(os.environ.get('NVTXZ','5')); NDIR=int(os.environ.get('NDIR','24')); NITERS=int(os.environ.get('NITERS','100')); LAM=float(os.environ.get('LAM','0.01'))
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); FDH=0.4*SCALE9
TANKR=float(os.environ.get('TANKR','14')); TANKZ=float(os.environ.get('TANKZ','14'))
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def dir2sc(d): pol=np.arccos(np.clip(d[2],-1,1)); az=np.arctan2(d[1],d[0]); return np.sin(pol),np.cos(pol),np.sin(az),np.cos(az)
def th9dir(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=np.hypot(st,ct); npp=np.hypot(sp,cp); return np.array([st/nt*sp/npp*0+st/nt*cp/npp, st/nt*sp/npp, ct/nt])
def _rotax(u,deg):
    a=np.radians(deg); ca,sa=np.cos(a),np.sin(a); u=u/np.linalg.norm(u)
    ux=np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]]); return np.eye(3)*ca+sa*ux+(1-ca)*np.outer(u,u)
def rand_tf(raw,ev):
    rng=np.random.default_rng(100003+ev); beta=np.degrees(np.arccos(rng.uniform(-1,1))); al=rng.uniform(0,2*np.pi)
    axis=np.array([-np.sin(al),np.cos(al),0.]); rr=FIDR*np.sqrt(rng.uniform()); ph=rng.uniform(0,2*np.pi)
    sh=np.array([rr*np.cos(ph),rr*np.sin(ph),rng.uniform(-FIDZ,FIDZ)])*100.0
    raw=dict(raw); O=np.asarray(raw['photon_origins']).astype(float); D=np.asarray(raw['photon_directions']).astype(float); R=_rotax(axis,beta); c=O.mean(0)
    raw['photon_origins']=(O-c)@R.T+c+sh; raw['photon_directions']=D@R.T; return raw
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); C=P-P.mean(0)
    _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d
    vtx=P.mean(0)+proj.min()*d; sc=dir2sc(d)
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],sc[0],sc[1],sc[2],sc[3],0.]),d
def fib_sphere(n):
    i=np.arange(n)+0.5; ph=np.arccos(1-2*i/n); th=np.pi*(1+5**0.5)*i
    return np.stack([np.sin(ph)*np.cos(th),np.sin(ph)*np.sin(th),np.cos(ph)],1)
print(f"# SEEDER+FisherGN  vtxgrid r{NVTXR}xz{NVTXZ}xphi4 dir{NDIR}  events[{E0}:{E0+EC}]",flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
@jax.jit
def mu_of(t9,key): return jnp.maximum(pred(sc2(t9),key)[3],1e-8)
@jax.jit
def perpmt(t9,oc,ot,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8); muS=jax.lax.stop_gradient(mu)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND); Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.); n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return mu, jnp.where(oc>0,-n*jnp.log(Slo)-jnp.where(a>-0.6931,jnp.log(-jnp.expm1(jnp.minimum(a,-1e-7))),jnp.log1p(-jnp.exp(jnp.minimum(a,-1e-7)))),0.)
@jax.jit
def loss_full(t9,oc,ot,key): mu,tn=perpmt(t9,oc,ot,key); return jnp.sum(mu-oc*jnp.log(mu))+jnp.sum(tn)
gradf=jax.jit(jax.grad(loss_full)); KEYS=[jax.random.PRNGKey(s) for s in range(4)]
DIRS=fib_sphere(NDIR)
# vertex grid (cylinder)
rs=np.linspace(0,TANKR,NVTXR+1)[1:] if NVTXR>1 else [0.]; rs=np.concatenate([[0.],rs[:-1]]) if NVTXR>1 else [0.]
VG=[]
for z in np.linspace(-TANKZ,TANKZ,NVTXZ):
    for r in (np.linspace(0,TANKR,NVTXR)):
        for ph in (np.linspace(0,2*np.pi,4,endpoint=False) if r>0.1 else [0.]):
            VG.append([r*np.cos(ph),r*np.sin(ph),z])
VG=np.array(VG)
def seed(oc):
    key=KEYS[0]; best=(1e30,None)
    for v in VG:
        for d in DIRS:
            sc=dir2sc(d); th=np.array([1050.,v[0],v[1],v[2],sc[0],sc[1],sc[2],sc[3],0.])
            mu=np.asarray(mu_of(jnp.asarray(th),key)); nll=float(np.sum(mu-oc*np.log(np.maximum(mu,1e-8))))
            if nll<best[0]: best=(nll,th)
    return best[1]
def fitgn(oc,ot,th0):
    th=th0.copy(); bestg=(1e18,th.copy())
    for it in range(NITERS):
        g=np.mean([np.asarray(gradf(jnp.asarray(th),oc,ot,k)) for k in KEYS],0)
        mu0=np.maximum(np.mean([np.asarray(perpmt(jnp.asarray(th),oc,ot,k)[0]) for k in KEYS],0),1e-8)
        Jm=np.zeros((ND,9)); Jl=np.zeros((ND,9))
        for j in range(9):
            h=FDH[j]; ej=np.eye(9)[j]
            mp,lp=[np.mean([np.asarray(x) for x in xs],0) for xs in zip(*[perpmt(jnp.asarray(th+h*ej),oc,ot,k) for k in KEYS])]
            mm,lm=[np.mean([np.asarray(x) for x in xs],0) for xs in zip(*[perpmt(jnp.asarray(th-h*ej),oc,ot,k) for k in KEYS])]
            Jm[:,j]=(mp-mm)/(2*h); Jl[:,j]=(lp-lm)/(2*h)
        F=(Jm/np.sqrt(mu0)[:,None]).T@(Jm/np.sqrt(mu0)[:,None])+Jl.T@Jl
        dth=np.clip(-np.linalg.solve(F+LAM*np.diag(np.clip(np.diag(F),1e-12,None))+1e-9*np.eye(9),g),-0.5*SCALE9,0.5*SCALE9); th=th+dth
        gn=float(np.linalg.norm(g*SCALE9))
        if gn<bestg[0]: bestg=(gn,th.copy())
    return bestg[1]
rows=[]
for ev in range(E0,E0+EC):
    t0=time.time(); raw=rand_tf(read_photon_data_from_photonsim(ROOT,ev),ev); th9,d=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
    c,t=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev),pd)); oc=np.asarray(c); ot=jnp.asarray(np.where(oc>0,np.asarray(t),0.)); ocj=jnp.asarray(oc)
    s=seed(oc); sd=np.sqrt(((s-th9)[1:4]**2).sum())*100   # seed vertex error (cm)
    th=fitgn(ocj,ot,s); dlt=th-th9; dvtx=float(np.sqrt((dlt[1:4]**2).sum()))*100
    pol=float(np.degrees(np.arccos(np.clip(d[2],-1,1)))); el=time.time()-t0
    rows.append([ev,sd,dvtx,dlt[0],pol]); print(f"#  ev{ev:3d} pol{pol:4.0f} seed_vtx={sd:6.1f}cm -> final_vtx={dvtx:5.1f}cm E{dlt[0]:+.0f} [{el:.0f}s]",flush=True)
np.savetxt(f"/tmp/seed_{os.environ.get('TAG','x')}_{E0}.txt",np.array(rows),fmt="%.4f"); print("# DONE",flush=True)
