"""ALIGNMENT A5 — MAXCELL (max_sensors_per_cell) overlap-truncation convergence.
Total + per-PMT charge of the SIM predictor (and TRUE truth at the recon values) vs
max_sensors_per_cell in {4,8,16,32}. Memory: 4 under-counts ~10%. Find where charge converges.
Same SIREN source, track, K=8, temp 0.1, MIE off. Env: NPHOT NKG.  Usage: CUDA_VISIBLE_DEVICES=g python align_a5.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '100000')); NKG = int(os.environ.get('NKG', '4')); K = 8
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NS); dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A5 MAXCELL convergence  NPH={NPH} NKG={NKG} K={K} MIE off", flush=True)
def pred(mc):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False, use_expected_value=True,
        hit_mode='per_photon', max_sensors_per_cell=mc, physics_config=H.PHYS, default_detector_params=dp_off,
        particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
prev = None
print(f"#  MAXCELL   total_charge   Δvs_prev   litPMT", flush=True)
for mc in [4, 8, 16, 32]:
    q = np.mean([np.asarray(jax.lax.stop_gradient(pred(mc)(track, jax.random.PRNGKey(s)))[3]) for s in range(NKG)], 0)
    dv = '' if prev is None else f'{100*(q.sum()-prev)/prev:+5.1f}%'
    print(f"#  {mc:5d}   {q.sum():11.2f}   {dv:>8s}   {(q>1e-6).sum()}", flush=True)
    prev = q.sum()
print(f"# VERDICT: charge converges with MAXCELL; the under-count at 4 vs 16+ is the recon-relevant truncation bias.", flush=True)
