"""Clean GRADIENT probe for the three overlap modes. The earlier cnll probe (sum(q - oc*log(q+1e-8)))
is dominated by near-dark sensors (oc/(q+1e-8) blows up) -> pure noise, cosine ~0 for ALL modes.
Replace with charge MSE L = sum((q-oc)^2): position-sensitive (per-sensor charge pattern shifts with the
track) AND numerically clean (no log/division). Reports the FULL 7-grad and the POSITION block (the
quantity charge-based vertex recon actually uses) AD-vs-FD cosine + magnitude, at a +0.3*scale x-offset.
Modes (env): PRED_TEMP='' -> temp=None straight-through (fwd!=bwd); 0.1 -> consistent. OVERLAP=erf -> C-inf.
Usage: CUDA_VISIBLE_DEVICES=g PRED_TEMP=0.1 OVERLAP=erf python grad_clean.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
OV = os.environ.get('OVERLAP', '')
if OV: os.environ['OVERLAP_ANALYTIC'] = OV
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=140)
PT = os.environ.get('PRED_TEMP', ''); temp = None if PT in ('', 'none', 'None') else float(PT)
NKEYS = int(os.environ.get('NKEYS', '24')); NPH = 40000; SC = np.array(H.PARAM_SCALE)
S = PS.setup(event=0, nphot=NPH, truth_source='siren', pred_temperature=temp, truth_key=0)
ts = np.array(S['theta_star']); pred = S['pred']; oc = S['oc']

def mse(th, k):
    q = pred(H.theta_to_track(th), k)[3]
    return jnp.sum((q - oc) ** 2)
g = jax.jit(jax.grad(mse)); l = jax.jit(mse)
ks = [jax.random.PRNGKey(60000 + i) for i in range(NKEYS)]
gbar = lambda th: np.mean([np.array(g(jnp.asarray(th), k)) for k in ks], 0)
lbar = lambda th: np.mean([float(l(jnp.asarray(th), k)) for k in ks])

thg = ts.copy(); thg[1] += 0.3 * SC[1]                       # +0.3 m in x: well-resolved displacement
gad = gbar(thg) * SC
gfd = np.array([(lbar(thg + np.eye(7)[j] * 0.4 * SC[j]) - lbar(thg - np.eye(7)[j] * 0.4 * SC[j])) /
                (2 * 0.4) * SC[j] for j in range(7)])
def cm(a, b):
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12)), \
           float(np.linalg.norm(a) / (np.linalg.norm(b) + 1e-12))
fcos, fmag = cm(gad, gfd)
pb = slice(1, 4)                                             # position block (x,y,z)
pcos, pmag = cm(gad[pb], gfd[pb])
print(f"MODE temp={PT or 'None'} overlap={OV or 'default'} NK={NKEYS}: "
      f"FULL cos={fcos:.3f} mag={fmag:.3f} | POS cos={pcos:.3f} mag={pmag:.3f}", flush=True)
print("  AD pos grad:", gad[pb], " FD pos grad:", gfd[pb], flush=True)
