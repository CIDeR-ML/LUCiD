"""CRB re-analysis across loss terms + hyperparameters. At the true track, the empirical Fisher
F = Cov_keys(g) (gradient covariance over predictor keys, mean removed -> the score covariance ~ Fisher)
gives the achievable per-parameter resolution CRB_i = sqrt(diag(F^-1)) for the FULL loss, plus the
per-channel information diag(F) for charge-only and time-only (which params each channel constrains).
Scans nphot N, time TAU, overlap TEMP, loss weighting WT; multiple data seeds (truth realizations).
Usage: CUDA_VISIBLE_DEVICES=g [NPHOT=80000 TAU=1.0 TEMP=0.1 WT=0.05 THR=4 SRC=siren NKEYS=48 SEEDS=0,1,2]
        python crb_scan.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=140)
N=int(float(os.environ.get('NPHOT','80000'))); TAU=float(os.environ.get('TAU','1.0'))
TEMP=float(os.environ.get('TEMP','0.1')); WT=float(os.environ.get('WT','0.05')); THR=float(os.environ.get('THR','4'))
SRC=os.environ.get('SRC','siren'); NKEYS=int(os.environ.get('NKEYS','48'))
SEEDS=[int(x) for x in os.environ.get('SEEDS','0,1,2').split(',')]
SC=np.array(H.PARAM_SCALE); names=H.PARAM_NAMES; U=['MeV','m','m','m','rad','rad','ns']
tag=f"N={N} TAU={TAU} TEMP={TEMP} WT={WT} THR={THR} SRC={SRC} NKEYS={NKEYS}"

def marg(G):                                            # marginal CRB per param: 1/sqrt(Fisher_ii) (others known)
    F=np.cov(G.T); return np.sqrt(1.0/np.clip(np.diag(F),1e-30,None))*SC
def crb_for_seed(seed):
    S=PS.setup(event=0,nphot=N,truth_source=SRC,pred_temperature=TEMP,truth_key=seed)
    ts=jnp.array(S['theta_star'])
    mk=PS.make_loss(S,WT=WT,TAU=TAU,THR=THR)
    gf=jax.jit(jax.grad(lambda th,k: mk(th,k)[2]))
    gc=jax.jit(jax.grad(lambda th,k: mk(th,k)[0]))
    gt=jax.jit(jax.grad(lambda th,k: mk(th,k)[1]))
    ks=[jax.random.PRNGKey(20000+seed*1000+i) for i in range(NKEYS)]
    Gf=np.stack([np.array(gf(ts,k))*SC for k in ks])
    Gc=np.stack([np.array(gc(ts,k))*SC for k in ks])
    Gt=np.stack([np.array(gt(ts,k))*SC for k in ks])
    F=np.cov(Gf.T)
    Finv=np.linalg.pinv(F + 1e-6*np.eye(7)*np.trace(F)/7)
    crb_joint=np.sqrt(np.clip(np.diag(Finv),0,None))*SC
    ev=np.linalg.eigvalsh(F); cond=ev[-1]/max(ev[0],1e-12)
    return crb_joint, cond, marg(Gc), marg(Gt), marg(Gf)

print(f"=== CRB {tag} ===",flush=True)
J=[];MC=[];MT=[];MF=[]
for sd in SEEDS:
    cj,cond,mc,mt,mf=crb_for_seed(sd); J.append(cj);MC.append(mc);MT.append(mt);MF.append(mf)
    print(f"[seed {sd}] cond(F_full)={cond:.1e}",flush=True)
J=np.array(J);MC=np.array(MC);MT=np.array(MT);MF=np.array(MF)
def line(lbl,A): print(f"  {lbl:16}"+"  ".join(f"{names[i][:3]}={A[:,i].mean():.3g}{U[i]}" for i in range(7)),flush=True)
print(f"--- MARGINAL CRB (1/sqrt Fisher_ii; resolution if other params known) mean/{len(SEEDS)} seeds ---")
line("charge-only:",MC); line("time-only:",MT); line("full:",MF)
print(f"--- JOINT CRB (full loss, sqrt diag F^-1; with the parameter degeneracy) ---")
line("full-joint:",J)
print(f"  [joint seed-spread t0={J[:,6].std():.2g}ns z={J[:,3].std():.2g}m -> if large, more keys]",flush=True)
