"""Is the NaN in the SIREN source itself? grad of sum(rays)+sum(origins)+sum(weights) wrt the track
(origin, direction, energy), at nphot=80000. Usage: CUDA_VISIBLE_DEVICES=g python src_grad.py"""
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.siren.core import create_photonsim_siren_grid
from lucid.siren.training.inference import SIRENPredictor
from lucid.sources.siren_rays import photonsim_differentiable_get_rays
from lucid.utils import unpack_photonsim_params
dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4)
pp=unpack_photonsim_params('muon',dg.medium.material); pr=SIRENPredictor(pp['siren_model_path']); grid=create_photonsim_siren_grid(pr)
na,nb,nc=pp['num_seeds']; mp=pr.params; k=jax.random.PRNGKey(0)
def fin(x): return bool(np.isfinite(np.array(x)).all())
def src(origin, dvec, E):
    rv,ro,w=photonsim_differentiable_get_rays(origin, dvec, E, 80000, grid, mp, k, na,nb,nc)
    return jnp.sum(rv)+jnp.sum(ro)+jnp.sum(w)
o0=jnp.zeros(3); d0=jnp.array([np.sin(0.6)*np.cos(0.8),np.sin(0.6)*np.sin(0.8),np.cos(0.6)]); E0=1050.0
print("grad wrt origin   finite:", fin(jax.grad(src,0)(o0,d0,E0)))
print("grad wrt direction finite:", fin(jax.grad(src,1)(o0,d0,E0)))
print("grad wrt energy   finite:", fin(jax.grad(src,2)(o0,d0,E0)))
