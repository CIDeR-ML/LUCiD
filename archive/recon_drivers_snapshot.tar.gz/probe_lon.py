"""Q2 PROBE: which observable has a WIDE, smooth gradient along the LONGITUDINAL vertex DOF (the only
degenerate direction)? Sweep vertex = truth_vtx + lambda*d_truth over lambda in [-LMAX, LMAX], ALL other
params at truth, and report 3 losses + their d/dlambda:
  lE   = total-charge term                  (energy carrier; ~flat longitudinally?)
  lCEN = |centroid_pred - centroid_obs|^2 projected on track axis  (GLOBAL charge moment; wide gradient?)
  lT   = lT_gd Gaussian first-arrival       (timing; should be FLAT longitudinally = the degeneracy)
Shows where each minimum sits (bias) and how wide/monotonic the gradient is from far. Env: TRUTH TTS_NS LMAX NL TKS.
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
np.set_printoptions(precision=4, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
LMAX = float(os.environ.get('LMAX', '5.0')); NL = int(os.environ.get('NL', '21')); SIG = float(os.environ.get('SIG', '2.5'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1').split(',')]
SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi); NW = float(os.environ.get('NW', '1.34'))
COT = 1.0 / float(np.sqrt(NW ** 2 - 1.0)); TSM = float(os.environ.get('TSM', '0.5'))  # cot(theta_c); softmin temp (m)
S = PS.setup(event=int(os.environ.get('EVENT','0')), nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points))
dtruth = jnp.array([np.sin(ts[4])*np.cos(ts[5]), np.sin(ts[4])*np.sin(ts[5]), np.cos(ts[4])])

def edge_loss(theta, oc, hi):
    """MODEL-FREE differentiable longitudinal term: charge-weighted soft-min of the Cherenkov emission
    coordinate s* = a_par - a_perp*cot(theta_c). Vertex at track start => softmin(s*)=0. (softmin)^2 pulls it."""
    V = theta[1:4]; d = jnp.array([jnp.sin(theta[4])*jnp.cos(theta[5]), jnp.sin(theta[4])*jnp.sin(theta[5]), jnp.cos(theta[4])])
    a = DP - V[None, :]; apar = a @ d; aperp = jnp.sqrt(jnp.maximum(jnp.sum(a*a,1)-apar**2, 1e-9))
    s = apar - aperp * COT
    w = jnp.where(hi & (oc >= THR), oc, 0.0); w = w / (jnp.sum(w) + 1e-9)
    softmin = -TSM * jax.scipy.special.logsumexp(-s / TSM, b=w)      # charge-weighted soft-min of s*
    return softmin ** 2 * 100.0

def losses(theta, key, oc, ot, hi):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / (sumobs)
    lCEN = jnp.sum(((cen_p - cen_o) @ dtruth) ** 2) * 100.0          # longitudinal centroid mismatch (m^2*100)
    lEDGE = edge_loss(theta, oc, hi)
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / SIG
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(SIG * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE, lCEN, lT, lEDGE
lfn = jax.jit(losses)

def theta_at(lam): th = ts.copy(); th[1:4] = ts[1:4] + lam * np.array(dtruth); return jnp.array(th)
lams = np.linspace(-LMAX, LMAX, NL)
print(f"# PROBE_LON TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} sweep longitudinal lambda in [{-LMAX},{LMAX}] (all else truth); SIG={SIG} TSM={TSM}", flush=True)
print(f"#   lE=total-charge  lCEN=model charge-centroid(long)  lT=lT_gd timing(expect FLAT)  lEDGE=MODEL-FREE soft emission-edge", flush=True)
print(f"#  lambda(m)   lE        lCEN       lT         lEDGE", flush=True)
acc = np.zeros((NL, 4))
for tk in TKS:
    oc, ot, hi = regen(tk)
    for i, lam in enumerate(lams):
        e, c, t, ed = lfn(theta_at(lam), jax.random.PRNGKey(7 + tk), oc, ot, hi)
        acc[i] += np.array([float(e), float(c), float(t), float(ed)])
acc /= len(TKS)
for i, lam in enumerate(lams):
    mark = "  <- truth" if abs(lam) < 1e-6 else ""
    print(f"  {lam:+7.2f}  {acc[i,0]:9.3f}  {acc[i,1]:9.4f}  {acc[i,2]:9.2f}  {acc[i,3]:9.4f}{mark}", flush=True)
# argmins (bias) and gradient width
for j, nm in enumerate(['lE', 'lCEN', 'lT', 'lEDGE']):
    col = acc[:, j]; amin = lams[np.argmin(col)]
    rng = col.max() - col.min(); print(f"# {nm}: argmin lambda={amin:+.2f}m  range={rng:.3g}  (flat if range~0; want argmin~0 + wide range)", flush=True)
