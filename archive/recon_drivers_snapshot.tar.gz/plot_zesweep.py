#!/usr/bin/env python3
"""2D charge-loss landscape over (longitudinal vtx, E). Tests the vtx<->E coupling: if the valley floor E*(z)
tilts, a longitudinal vtx bias DRAGS energy. Induced E-bias ~ (dE*/dz) * (z-bias)."""
import glob,os,numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'recon_plots'); os.makedirs(OUT,exist_ok=True)
F=sorted(glob.glob('/tmp/zesw_zes_*.npz'))
if not F: print('no zesw files'); raise SystemExit
D=[np.load(f) for f in F]
slopes=[]; zarg=[]; Earg=[]; EatTruthZ=[]
for d in D:
    E=d['E']; Z=d['Z']; L=d['L']        # L[iz,ie]
    Estar=np.array([E[np.argmin(L[iz])] for iz in range(len(Z))])   # valley floor E*(z)
    m=np.abs(Z)<=20                                                  # slope near truth (+/-20cm)
    s=np.polyfit(Z[m],Estar[m],1)[0]; slopes.append(s)              # MeV per cm
    iz,ie=np.unravel_index(np.argmin(L),L.shape); zarg.append(Z[iz]); Earg.append(E[ie])
    EatTruthZ.append(E[np.argmin(L[len(Z)//2])])
slopes,zarg,Earg,EatTruthZ=map(np.array,(slopes,zarg,Earg,EatTruthZ))
print(f'N={len(D)} events')
print(f'  charge 2D argmin: dz={zarg.mean():+.0f}+/-{zarg.std():.0f}cm  dE={Earg.mean():+.0f}+/-{Earg.std():.0f}MeV')
print(f'  E*(truth z)                 = {EatTruthZ.mean():+.0f}+/-{EatTruthZ.std():.0f} MeV  (charge E-bias at truth vertex)')
print(f'  valley slope dE*/dz         = {slopes.mean():+.2f}+/-{slopes.std():.2f} MeV/cm')
print(f'  => induced E-bias at +14cm longitudinal vtx-bias = {slopes.mean()*14:+.0f} MeV  (vs full-fit -40)')

# plot: 4 example landscapes + slope histogram
fig,axs=plt.subplots(2,3,figsize=(15,9)); axs=axs.ravel()
for k in range(min(5,len(D))):
    d=D[k]; E=d['E']; Z=d['Z']; L=d['L']; ax=axs[k]
    cs=ax.contourf(E,Z,L-L.min(),levels=25,cmap='viridis'); plt.colorbar(cs,ax=ax,shrink=0.8)
    Estar=np.array([E[np.argmin(L[iz])] for iz in range(len(Z))])
    ax.plot(Estar,Z,'w.-',lw=1,ms=4,label='valley E*(z)')
    iz,ie=np.unravel_index(np.argmin(L),L.shape)
    ax.plot(0,0,'r*',ms=14,label='truth'); ax.plot(E[ie],Z[iz],'mo',ms=8,label='2D argmin')
    ax.set_xlabel('E - E_true (MeV)'); ax.set_ylabel('longitudinal dz (cm)'); ax.set_title(f'event {k}'); ax.legend(fontsize=7)
axs[5].hist(slopes,bins=10,color='C0',edgecolor='k'); axs[5].axvline(slopes.mean(),color='r',label=f'mean {slopes.mean():+.2f} MeV/cm')
axs[5].set_xlabel('valley slope dE*/dz (MeV/cm)'); axs[5].set_ylabel('events'); axs[5].set_title('vtx->E coupling slope'); axs[5].legend(); axs[5].grid(alpha=0.3)
fig.suptitle('Charge-loss 2D landscape (longitudinal vtx vs E): valley tilt = vtx->E coupling that drags the energy bias',fontsize=12)
fig.tight_layout(rect=[0,0,1,0.97]); fig.savefig(os.path.join(OUT,'zesweep_coupling.png'),dpi=105); print('wrote zesweep_coupling.png')
