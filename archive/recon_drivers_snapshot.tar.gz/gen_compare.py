#!/usr/bin/env python3
"""FACTORIZE: compare PHOTON GENERATION (SIREN emission vs GEANT4 photon table) directly, NO propagation -> fast.
Generation count (position-indep power law) + angular cone shape (track frame). The position-dependent detected
over-light must come from the angular generation diff convolved with absorption (propagation)."""
import os,sys,glob
os.environ.setdefault('JAX_PLATFORM_NAME','gpu')
import numpy as np, jax, jax.numpy as jnp
from lucid.utils import unpack_photonsim_params
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
import importlib
photonsim_differentiable_get_rays=importlib.import_module(os.environ.get('SAMPLER_MODULE','lucid.sources.siren_rays')).photonsim_differentiable_get_rays
from lucid.sources.event_io import read_photon_data_from_photonsim

ROOT=os.environ.get('ROOT', sorted(glob.glob('data/*.root')+glob.glob('data/**/*.root',recursive=True))[0])
NPHOT=int(os.environ.get('NPHOT','200000')); NEV=int(os.environ.get('NEV','10'))
pp=unpack_photonsim_params('muon','water')
predr=SIRENPredictor(pp['siren_model_path']); grid=create_photonsim_siren_grid(predr); mp=predr.params
A,B,C=pp['tot_n_photons_normalization']; sa,sb,sc=pp['num_seeds']
getrays=jax.jit(lambda to,td,E,key: photonsim_differentiable_get_rays(to,td,E,NPHOT,grid,mp,key,sa,sb,sc))
def norm(v): return v/np.linalg.norm(v,axis=-1,keepdims=True)
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); Cc=P-P.mean(0)
    _,_,vt=np.linalg.svd(Cc,full_matrices=False); d=vt[0]; proj=Cc@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d; proj=-proj
    vtx=P.mean(0)+proj.min()*d; return vtx,d,float(raw['energy'])

ANGB=np.linspace(0,np.pi,60); GA=np.zeros(len(ANGB)-1); SA=np.zeros(len(ANGB)-1); rows=[]
for ev in range(NEV):
    raw=read_photon_data_from_photonsim(ROOT,ev); vtx,d,E=derive_truth(raw)
    dirG=norm(np.asarray(raw['photon_directions']).astype(float)); NG=len(dirG)
    angG=np.arccos(np.clip(dirG@d,-1,1))
    rv,ro,w=getrays(jnp.asarray(vtx),jnp.asarray(d),jnp.asarray(E),jax.random.PRNGKey(13+ev))
    rv=np.asarray(rv); w=np.asarray(w); angS=np.arccos(np.clip(norm(rv)@d,-1,1))
    totS=(A*E**B+C)*w.sum()/NPHOT                              # SIREN expected total photons
    wS=w/ w.sum()                                              # angular weights
    GA+=np.histogram(angG,ANGB)[0]/NG; SA+=np.histogram(angS,ANGB,weights=wS)[0]
    # Cherenkov peak angle + cone width (weighted std around peak)
    mG=np.degrees(np.average(angG)); mS=np.degrees(np.average(angS,weights=wS))
    sdG=np.degrees(np.sqrt(np.average((angG-np.radians(mG))**2))); sdS=np.degrees(np.sqrt(np.average((angS-np.radians(mS))**2,weights=wS)))
    rows.append((ev,E,NG,totS,totS/NG,mG,mS,sdG,sdS))
    print(f"ev{ev} E{E:.0f} | GEN count G={NG} S={totS:.0f} S/G={totS/NG:.4f} | cone-mean G={mG:.1f} S={mS:.1f}deg | cone-width G={sdG:.1f} S={sdS:.1f}deg",flush=True)
R=np.array([r[4] for r in rows])
print(f"\nGENERATION count ratio S/G = {R.mean():.4f} +/- {R.std()/max(len(R)**.5,1):.4f} (position-INDEPENDENT)")
print(f"cone mean G={np.mean([r[5] for r in rows]):.2f} S={np.mean([r[6] for r in rows]):.2f} deg ; width G={np.mean([r[7] for r in rows]):.2f} S={np.mean([r[8] for r in rows]):.2f} deg")
np.savez('/tmp/gencmp.npz',ANGB=ANGB,GA=GA/NEV,SA=SA/NEV,rows=np.array(rows))
print('saved /tmp/gencmp.npz')
