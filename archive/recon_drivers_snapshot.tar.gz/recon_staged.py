"""Two-stage GN-LM reconstruction (removes the energy bias):
  Stage 1: charge-dominated (WT~0) GN-LM on all 7 params -> ENERGY (unbiased from charge) + rough pos/dir.
  Stage 2: full loss (WT,TAU best) GN-LM with ENERGY FROZEN at the stage-1 value -> refine pos/dir/t0
           without the time count-pull re-biasing energy.
Usage: CUDA_VISIBLE_DEVICES=g python recon_staged.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import first_arrival_nll
np.set_printoptions(precision=4, suppress=True)

K = 7
NPHOT = int(float(os.environ.get('NPHOT', '50000')))
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
NK = 6; SCALE = np.array(H.PARAM_SCALE)
theta_star = np.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 5.0])
pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(truth, jnp.array(theta_star), jax.random.PRNGKey(SEED))
ocf = jax.lax.stop_gradient(oc); otf = jax.lax.stop_gradient(ot); hitf = jax.lax.stop_gradient(hit)
SUMOBS = float(jnp.sum(oc))

def make_loss(WT, TAU):
    def loss(theta, key):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key)
        c = jnp.sum(q - ocf * jnp.log(q + 1e-8)) / SUMOBS * 100.0
        t = jnp.sum(jnp.where(hitf, first_arrival_nll(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
        return c + WT * t
    return jax.jit(jax.grad(loss))

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=45):
    frozen = np.zeros(7);
    if freeze is not None:
        for i in freeze: frozen[i] = 1.0
    T = []
    for s in range(steps):
        keys = jax.random.split(jax.random.PRNGKey(31 * SEED + 9999 * (freeze is not None) + s), NK)
        G = np.stack([np.array(gfn(theta, k)) * SCALE for k in keys])
        g = G.mean(0); F = (G.T @ G) / NK
        d = np.clip(np.diag(F), 1e-12, None)
        ev, V = np.linalg.eigh(F + LM * np.diag(d) + 1e-9 * np.eye(7) * (d.max() + 1e-12))
        ev = np.clip(ev, 2e-2 * ev.max(), None)
        step = np.clip(V @ np.diag(1.0 / ev) @ V.T @ g, -0.35, 0.35) * SCALE
        step = step * (1.0 - frozen)                                  # freeze selected params
        theta = theta - LR * jnp.array(step)
        if s >= steps - tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))

rng = np.random.default_rng(SEED)
theta = jnp.array(theta_star + rng.uniform(-1, 1, 7) * 0.6 * SCALE)
# Stage 1: charge-dominated -> energy
theta1 = gnlm(theta, make_loss(WT=0.0, TAU=4.0), steps=90)
# Stage 2: full loss, freeze energy
theta2 = gnlm(theta1, make_loss(WT=0.03, TAU=4.0), steps=110, freeze=[0])
pa = np.array(theta2); err = pa - theta_star
U = ['MeV', 'm', 'm', 'm', 'rad', 'rad', 'ns']
print(f"STAGED {SEED} E1={float(theta1[0]):.0f} -> " + " ".join(f"{pa[i]:.4f}" for i in range(7))
      + " | err " + " ".join(f"{err[i]:+.3g}{U[i]}" for i in range(7)), flush=True)
