"""WHY kinky? Split the corrected-loss profile into CHARGE-only vs TIME-only per param, single integer-count
event @500k. Multi-scale slopes (w=1,2,4,8) -> sign-flip = kinky. If charge smooth but time kinky in x/y ->
the TIME term causes it; then probe the mechanism. Also: does more key-averaging smooth it (noise vs real)?
Env: NPHOT NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_kink.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NKEYS = int(os.environ.get('NKEYS', '8')); K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
PS = np.asarray(H.PARAM_SCALE); tt = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
# MEAN obs (smooth forward profile) — kinkiness is a property of the forward loss, not per-event noise
cs, ts = [], []
for s in range(12):
    cc, tt2 = jax.lax.stop_gradient(truth(H.theta_to_track(jnp.asarray(tt)), jax.random.PRNGKey(900 + s)))
    cs.append(np.asarray(cc)); ts.append(np.where(np.asarray(cc) > 0, np.asarray(tt2), np.nan))
oc = jnp.asarray(np.mean(cs, 0)); hit = jnp.asarray(np.mean(cs, 0) > 1e-6); ot = jnp.asarray(np.nan_to_num(np.nanmean(ts, 0)))
def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def core(theta, key, wc, wt):
    log_w, ft, fi, tot = pred(H.theta_to_track(theta), key)
    w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - theta[6])[fi]; mu = jnp.maximum(tot, 1e-8)
    def Rof(x): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf((x - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rof(tobs - DELTA / 2)) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rof(tobs + DELTA / 2)) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(hit & (oc > 0), -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    charge = jnp.sum(mu - oc * jnp.log(mu))
    return wc * charge + wt * time
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def slopes(i, wc, wt):
    # center the scan at an OFFSET in param i (theta_true + 3*PS[i]) -> non-trivial gradient, away from the min
    c0 = tt + 3.0 * PS[i] * np.eye(7)[i]
    sv = np.linspace(-6 * PS[i], 6 * PS[i], 33); j0 = 16; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(core(jnp.asarray(c0 + s * np.eye(7)[i]), k, jnp.asarray(wc), jnp.asarray(wt))) for k in keys]) for s in sv])
    return {wv: (prof[j0 + wv] - prof[j0 - wv]) / (2 * wv * dg) for wv in [1, 2, 4, 8]}
print(f"# WHY KINKY  NPH={NPH} NKEYS={NKEYS} MEAN-obs, centered at theta_true + 3*scale per param (offset, non-trivial grad)", flush=True)
for nm, i in [('x', 1), ('y', 2), ('z', 3), ('polar', 4), ('azim', 5)]:
    for tag, wc, wt in [('charge', 1.0, 0.0), ('time', 0.0, 1.0)]:
        sl = slopes(i, wc, wt); kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
        print(f"#  {nm:6s} {tag:6s} slopes w1/2/4/8 {sl[1]:+9.1f} {sl[2]:+9.1f} {sl[4]:+9.1f} {sl[8]:+9.1f}  {'KINKY' if kinky else 'smooth'}", flush=True)
print(f"# READ: which TERM is kinky in x/y/azim -> if time-only kinky & charge-only smooth -> the S^n time term is the source.", flush=True)
