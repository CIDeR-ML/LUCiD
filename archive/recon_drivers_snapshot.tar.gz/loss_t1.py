"""TIER 1 — EXACT self-consistency. Generate truth by sampling the PREDICTOR's OWN
count-conditioned first-arrival model (the exact generative model the loss assumes):
  per PMT: n ~ Poisson(mu=sum_j w_j); draw n photons, photon j w.p. w_j/mu, time = ft_j + sigma*eps;
  observe oc=n, ot=min(times).  This realizes survival S(t)=1-R(t)/mu, F_first=1-S^n EXACTLY.
Then profile the SAME loss core() over each param at an offset center, averaged over many
realizations -> is the argmin AT theta_true?
  bias ~ 0   => loss form EXACTLY unbiased; the -0.14 m residual is the FORWARD engine -> Tier 2.
  bias != 0  => loss/generative model has a residual -> Tier 1b.
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t1.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '24'))
K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
ASC = 0.02
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, ASC, ASC, ASC, ASC, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    theta = jnp.arctan2(st, ct); phi = jnp.arctan2(sp, cp)
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=theta, phi=phi, t0=th9[8])
print(f"# T1 SELF-CONSISTENCY  NPH={NPH} NREAL={NREAL}  (truth = predictor's OWN count-cond model)", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)

# ---- generate truth realizations from the predictor's own generative model ----
log_w, ft, fi, tot = [np.asarray(a) for a in jax.lax.stop_gradient(pred(sc2track(jnp.asarray(th9_true)), jax.random.PRNGKey(0)))]
w = np.exp(np.clip(log_w, -60, 20)); mu = np.asarray(tot)
# group photon indices by PMT once
order = np.argsort(fi); fi_s = fi[order]; w_s = w[order]; ft_s = ft[order]
bounds = np.searchsorted(fi_s, np.arange(ND + 1))            # photons for PMT p: [bounds[p],bounds[p+1])
lit = np.where(mu > 1e-6)[0]
print(f"#  lit PMTs={lit.size}  mean mu(lit)={mu[lit].mean():.2f}  total mu={mu.sum():.0f}", flush=True)
rng = np.random.default_rng(12345)
realizations = []                                            # list of (oc, ot)
for r in range(NREAL):
    oc = np.zeros(ND); ot = np.zeros(ND)
    ns = rng.poisson(mu[lit])
    for p, n in zip(lit, ns):
        if n == 0: continue
        a, b = bounds[p], bounds[p + 1]
        wj = w_s[a:b]; tj = ft_s[a:b]
        comp = rng.choice(b - a, size=int(n), p=wj / wj.sum())
        times = tj[comp] + SIGMA * rng.standard_normal(int(n))
        oc[p] = n; ot[p] = times.min()
    realizations.append((oc, ot))
print(f"#  realized: mean lit-per-event={np.mean([(o>0).sum() for o,_ in realizations]):.0f}", flush=True)

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def core(th9, oc, ot, key):
    log_w, ftt, fii, tott = pred(sc2track(th9), key)
    ww = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - th9[8])[fii]; muu = jnp.maximum(tott, 1e-8)
    def Rof(x): return jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((x - ftt) / (SIGMA * SQ))), fii, num_segments=ND)
    S_lo = jnp.clip((muu - Rof(tobs - DELTA / 2)) / muu, 1e-12, 1.0); S_hi = jnp.clip((muu - Rof(tobs + DELTA / 2)) / muu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    hit = oc > 0
    time = jnp.sum(jnp.where(hit, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(muu - oc * jnp.log(muu)) + time

key = jax.random.PRNGKey(7)
OCs = [jnp.asarray(o) for o, _ in realizations]; OTs = [jnp.asarray(t) for _, t in realizations]
for i, nm in enumerate(NAMES):
    c0 = th9_true + 3.0 * SCALE9[i] * np.eye(9)[i]            # offset center (non-trivial grad)
    sv = np.linspace(-6 * SCALE9[i], 6 * SCALE9[i], 33); j0 = 16; dg = sv[1] - sv[0]
    # profile averaged over realizations (each realization its OWN integer obs)
    prof = np.zeros(sv.size)
    for oc, ot in zip(OCs, OTs):
        prof += np.array([float(core(jnp.asarray(c0 + s * np.eye(9)[i]), oc, ot, key)) for s in sv])
    prof /= len(OCs)
    # argmin of a local quadratic fit around j0, mapped back to offset-from-truth (in param units)
    jmin = int(np.argmin(prof)); s_at_min = sv[jmin]
    # refine: parabola through 3 points around jmin
    if 0 < jmin < sv.size - 1:
        y0, y1, y2 = prof[jmin - 1], prof[jmin], prof[jmin + 1]
        denom = (y0 - 2 * y1 + y2)
        s_ref = sv[jmin] + (0.5 * (y0 - y2) / denom * dg if abs(denom) > 1e-12 else 0.0)
    else:
        s_ref = s_at_min
    bias_units = s_ref                                        # offset from truth in param units (s=0 is truth)
    sl1 = (prof[j0 + 1] - prof[j0 - 1]) / (2 * dg)
    print(f"#  {nm:6s} argmin@truth_offset {bias_units:+9.4f} ({bias_units/SCALE9[i]:+5.2f} scale)  slope@center {sl1:+10.1f}", flush=True)
print(f"# READ: argmin should be ~0 (truth) for EVERY param if the loss is exactly self-consistent.", flush=True)
print(f"#       position (x,y,z) argmin ~0 => loss unbiased, -0.14m is FORWARD (Tier 2). !=0 => loss residual (Tier 1b).", flush=True)
