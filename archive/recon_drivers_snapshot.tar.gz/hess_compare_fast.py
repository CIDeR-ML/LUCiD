"""PROOF: with the NaN op fixed, the autodiff Hessian is finite AND matches the FD Hessian.
Bypasses the step's NaN-sanitizer custom_vjp (no longer needed at 2nd order) and compares
jax.hessian vs central finite-difference of the gradient, for the raw Poisson charge NLL.
Usage: CUDA_VISIBLE_DEVICES=g python hess_compare.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW              # bypass sanitizer
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=140)
NKEYS=int(os.environ.get('NKEYS','6')); DSTEP=0.3
NPHOT=int(os.environ.get('NPHOT','40000'))
S=PS.setup(event=0,nphot=NPHOT,truth_source='siren',pred_temperature=0.1,truth_key=0)
ts=np.array(S['theta_star']); pred=S['pred']; oc=S['oc']; SC=np.array(H.PARAM_SCALE)
LOSS=os.environ.get('LOSS','sumq')
def lc(th,k):
    _,_,_,q=pred(H.theta_to_track(th),k)
    if LOSS=='sumq':   return jnp.sum(q)                       # smooth, no log
    if LOSS=='quad':   return 0.5*jnp.sum((q-oc)**2)           # smooth quadratic
    return jnp.sum(q-oc*jnp.log(q+1e-8))                       # Poisson NLL (sharp log curvature)
print("LOSS =", LOSS)
hess=jax.jit(jax.hessian(lc)); gfn=jax.jit(jax.grad(lc))
ks=[jax.random.PRNGKey(40000+i) for i in range(NKEYS)]

# autodiff Hessian (normalized units), key-averaged
Had=np.mean([np.array(hess(jnp.asarray(ts),k)) for k in ks],0)*np.outer(SC,SC)
# FD Hessian of key-averaged gradient
def gbar(th): return np.mean([np.array(gfn(jnp.asarray(th),k)) for k in ks],0)
Hfd=np.zeros((7,7))
for j in range(7):
    d=DSTEP*SC[j]
    Hfd[:,j]=(gbar(ts+np.eye(7)[j]*d)-gbar(ts-np.eye(7)[j]*d))/(2*DSTEP)*SC
Hfd=0.5*(Hfd+Hfd.T)
print("autodiff Hessian finite:", bool(np.isfinite(Had).all()))
print("diag(H_autodiff):", np.diag(Had))
print("diag(H_FD)      :", np.diag(Hfd))
num=np.linalg.norm(Had-Hfd); den=np.linalg.norm(Hfd)
print(f"relative ||H_ad - H_fd|| / ||H_fd|| = {num/den:.4f}")
print(f"cosine(flatten) = {float((Had.ravel()@Hfd.ravel())/(np.linalg.norm(Had.ravel())*np.linalg.norm(Hfd.ravel())+1e-12)):.4f}")
# energy is theta[0] -> ROW 0. report it specifically (the suspect).
erad,erfd=Had[0],Hfd[0]
print("energy-row autodiff:", erad)
print("energy-row FD      :", erfd)
ercos=float(erad@erfd/(np.linalg.norm(erad)*np.linalg.norm(erfd)+1e-12))
print(f"ENERGY-ROW rel={np.linalg.norm(erad-erfd)/(np.linalg.norm(erfd)+1e-9):.4f} cos={ercos:.4f}")
print(f"PATHWISE (pos+ang+t0, idx1:7) rel={np.linalg.norm(Had[1:,1:]-Hfd[1:,1:])/(np.linalg.norm(Hfd[1:,1:])+1e-9):.4f}")
