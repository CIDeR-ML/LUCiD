"""SYSTEMATIC per-TERM CRB vs HYPERPARAMETERS. Characterize each likelihood term in ISOLATION before
combining. Analytic (no optimizer): Poisson charge Fisher from the predictor's per-PMT mean charge mu_i
and its CRN-finite-difference Jacobian; timing Fisher from the analytic wavefront tau_i.
  F_charge[a,b] = sum_i (mask_i/mu_i) d_a mu_i d_b mu_i          (charge: lon + E + dir; weak transverse; NO t0)
  F_time[a,b]   = sum_i (mask_i/sig^2) d_a tau_i d_b tau_i        (time: transverse + dir + t0; lon<->t0 NULL)
Reports marginalized CRB on lon / transverse vertex / dir / t0 / E for each hyperparameter setting.

SCANS: (A) charge CRB vs charge THR (mu-threshold);  (B) charge CRB vs predictor temperature (rebuilds);
(C) timing CRB vs (sigma, THR);  (D) the combination at chosen settings.
Env: NPHOT NKG STEP EVENT NW.  Usage: CUDA_VISIBLE_DEVICES=g python term_crb.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.geometry import generate_detector
np.set_printoptions(precision=4, suppress=True, linewidth=170)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKG = int(os.environ.get('NKG', '4'))
STEP = float(os.environ.get('STEP', '0.25')); EVENT = int(os.environ.get('EVENT', '0')); NW = float(os.environ.get('NW', '1.34'))
K = int(os.environ.get('RECON_K', '8')); C = 0.299792; G = float(np.sqrt(NW**2-1.0))
ts = np.array([1050.0, 0.0, 0.0, 0.0, 0.6, 0.8, 0.0]); h = np.array(H.PARAM_SCALE) * STEP
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points)); DPn = np.array(DP)
def dvec(pol, az): return jnp.array([jnp.sin(pol)*jnp.cos(az), jnp.sin(pol)*jnp.sin(az), jnp.cos(pol)])
d_true = np.array(dvec(ts[4], ts[5]))

def wavefront(theta):
    V = theta[1:4]; d = dvec(theta[4], theta[5]); t0 = theta[6]
    a = DP - V[None, :]; apar = a @ d; aperp = jnp.sqrt(jnp.maximum((a*a).sum(1)-apar**2, 1e-12))
    return t0 + (apar + aperp*G)/C
Jtau = np.array(jax.jacfwd(wavefront)(jnp.array(ts)))                       # (ND,7), analytic

def charge_jac(temperature, Kp, nphot):
    """build predictor at (temperature,K), return mu (avg over keys) and d mu/d theta via CRN central FD."""
    pred = H.build_predictor(temperature=temperature, K=Kp, n_photons=nphot)
    qof = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key)[3])
    mus = []; Jqs = []
    for k in range(NKG):
        key = jax.random.PRNGKey(1000+13*k); mus.append(np.array(qof(jnp.array(ts), key)))
        Jk = np.zeros((len(DPn), 7))
        for a in range(7):
            e = np.zeros(7); e[a] = h[a]
            Jk[:, a] = (np.array(qof(jnp.array(ts+e), key)) - np.array(qof(jnp.array(ts-e), key)))/(2*h[a])
        Jqs.append(Jk)
    return np.mean(mus, 0), np.mean(Jqs, 0)

def crb(F, idx):
    """marginalized CRB over params `idx`; returns dict lon/trans/dir/t0/E (cm,cm,deg,ns,%) or None if degenerate."""
    Fb = F[np.ix_(idx, idx)]; ev = np.linalg.eigvalsh(Fb)
    if ev[0] <= 1e-9*ev[-1]:
        return f"DEGEN({int((ev>1e-9*ev[-1]).sum())}/{len(idx)})"
    Cov = np.linalg.inv(Fb); pos = {p: j for j, p in enumerate(idx)}; o = {}
    if all(p in pos for p in (1, 2, 3)):
        Cx = Cov[np.ix_([pos[1], pos[2], pos[3]], [pos[1], pos[2], pos[3]])]
        o['lon'] = float(np.sqrt(max(d_true@Cx@d_true, 0)))*100
        o['trans'] = float(np.sqrt(max(np.trace(Cx)-d_true@Cx@d_true, 0)))*100
    o['dir'] = float(np.degrees(np.sqrt(max(Cov[pos[4], pos[4]]+np.sin(ts[4])**2*Cov[pos[5], pos[5]], 0)))) if 4 in pos and 5 in pos else None
    o['t0'] = float(np.sqrt(max(Cov[pos[6], pos[6]], 0))) if 6 in pos else None
    o['E'] = float(np.sqrt(max(Cov[pos[0], pos[0]], 0)))/ts[0]*100 if 0 in pos else None
    return o

def fmt(o):
    if isinstance(o, str): return f"{o:>28s}"
    s = f"lon={o.get('lon', float('nan')):6.1f} trans={o.get('trans', float('nan')):6.1f}"
    s += f" dir={o['dir']:5.2f}" if o.get('dir') is not None else " dir=  -  "
    s += f" t0={o['t0']:5.2f}" if o.get('t0') is not None else " t0=  -  "
    s += f" E={o['E']:4.1f}%" if o.get('E') is not None else ""
    return s

NOT0 = [0, 1, 2, 3, 4, 5]; ALL = [0, 1, 2, 3, 4, 5, 6]
mu, Jq = charge_jac(0.1, K, NPHOT)
print(f"# TERM-CRB EVENT={EVENT} NPHOT={NPHOT} NKG={NKG} K={K}  ND={len(DPn)} sum(mu)={mu.sum():.0f} max(mu)={mu.max():.1f}", flush=True)

def F_charge(thr, mu_, Jq_):
    m = mu_ > thr; mc = np.clip(mu_, max(thr, 1e-3), None); return Jq_.T @ ((m/mc)[:, None]*Jq_)
def F_time(thr, sig, mu_):
    m = mu_ > thr; w = m.astype(float)/sig**2; return Jtau.T @ (w[:, None]*Jtau)   # w_i=1 per hit PMT (first-arrival)

print(f"\n# (A) CHARGE term CRB vs THR (mu-threshold); marginalize E,dir; t0 ABSENT (charge has none) [cm,deg,%]", flush=True)
for thr in [0.0, 0.5, 1.0, 2.0, 5.0]:
    print(f"#   THR={thr:4.1f} (PMTs {int((mu>thr).sum()):5d})  {fmt(crb(F_charge(thr, mu, Jq), NOT0))}", flush=True)

print(f"\n# (C) TIMING term CRB vs (sigma, THR); t0 free; lon<->t0 degenerate so report with charge-pinned (see D) [cm,deg,ns]", flush=True)
for sig in [1.5, 2.5, 5.0]:
    for thr in [0.0, 2.0, 5.0]:
        print(f"#   sig={sig:3.1f} THR={thr:4.1f} (PMTs {int((mu>thr).sum()):5d})  {fmt(crb(F_time(thr, sig, mu), ALL))}", flush=True)

print(f"\n# (D) COMBINATION CRB = F_charge(THR_c) + F_time(THR_t,sig); all 7 params incl t0 [cm,deg,ns,%]", flush=True)
for (thrc, thrt, sig) in [(0.0, 0.0, 2.5), (0.0, 2.0, 2.5), (0.5, 2.0, 2.5), (0.0, 0.0, 1.5)]:
    o = crb(F_charge(thrc, mu, Jq) + F_time(thrt, sig, mu), ALL)
    print(f"#   charge THR={thrc:3.1f} + time THR={thrt:3.1f} sig={sig:3.1f}   {fmt(o)}", flush=True)

print(f"\n# (B) CHARGE term CRB vs predictor TEMPERATURE (rebuilds pred); charge-only, marginalize E,dir [cm,deg,%]", flush=True)
for temp in [0.05, 0.1, 0.2]:
    mut, Jqt = charge_jac(temp, K, NPHOT)
    print(f"#   temp={temp:4.2f}  sum(mu)={mut.sum():5.0f}  {fmt(crb(F_charge(0.0, mut, Jqt), NOT0))}", flush=True)
print(f"\n# NOTE timing F uses w_i=1 (one first-arrival/PMT) at resolution sigma -> CONSERVATIVE; sum over hit PMTs.", flush=True)
