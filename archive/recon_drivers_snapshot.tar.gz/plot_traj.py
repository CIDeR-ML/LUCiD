#!/usr/bin/env python3
"""Plot full per-iteration parameter-history trajectories from /tmp/hist_<case>_*.npz.
Grid: rows = parameters (E, longitudinal vtx, transverse vtx, direction, t0, |g|), cols = cases (JIT_ALL).
Each panel overlays every event's residual-from-truth trajectory -> shows WHERE the joint fit fails."""
import glob,os,numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'recon_plots'); os.makedirs(OUT,exist_ok=True)
CASES=[('JIT=1','jit1'),('JIT=2','jit2'),('JIT=3','jit3'),('JIT=4','jit4'),('JIT=6','jit6')]
def dirvec(p):   # p[...,4:8]=sinT,cosT,sinP,cosP -> unit xyz
    st,ct,sp,cp=p[...,4],p[...,5],p[...,6],p[...,7]
    nt=np.hypot(st,ct); npp=np.hypot(sp,cp); st,ct,sp,cp=st/nt,ct/nt,sp/npp,cp/npp
    return np.stack([st*cp,st*sp,ct],-1)
def resids(d):
    tr=d['traj']; tru=d['truth']; td=d['tdir']
    E=tr[:,0]-tru[0]
    dv=tr[:,1:4]-tru[1:4]; lon=dv@td; tra=np.sqrt(np.maximum((dv**2).sum(1)-lon**2,0))
    dd=dirvec(tr); ang=np.degrees(np.arccos(np.clip(dd@(td/np.linalg.norm(td)),-1,1)))
    t0=tr[:,8]-tru[8]
    return E,lon*100,tra*100,ang,t0
ROWS=[('E residual (MeV)',0,200),('longitudinal vtx (cm)',1,150),('transverse vtx (cm)',2,150),
      ('direction (deg)',3,15),('t0 residual (ns)',4,3)]
nC=len(CASES); nR=len(ROWS)+1
fig,axes=plt.subplots(nR,nC,figsize=(3.4*nC,2.4*nR),sharex=True)
for cj,(clab,cpre) in enumerate(CASES):
    files=sorted(glob.glob(f'/tmp/hist_{cpre}_*.npz'))
    axes[0,cj].set_title(f'{clab}  ({len(files)} ev)',fontsize=11)
    for f in files:
        d=np.load(f); R=resids(d); gn=d['gn']; it=np.arange(len(d['traj']))
        for ri,(lab,idx,ylim) in enumerate(ROWS):
            axes[ri,cj].plot(it,R[idx],lw=0.9,alpha=0.8)
        axes[nR-1,cj].plot(np.arange(len(gn)),gn,lw=0.9,alpha=0.8)
    for ri,(lab,idx,ylim) in enumerate(ROWS):
        ax=axes[ri,cj]; ax.axhline(0,color='k',lw=0.5,ls=':'); ax.grid(alpha=0.25); ax.set_ylim(-ylim,ylim)
        if cj==0: ax.set_ylabel(lab,fontsize=9)
    axes[nR-1,cj].set_yscale('log'); axes[nR-1,cj].grid(alpha=0.25)
    if cj==0: axes[nR-1,cj].set_ylabel('|grad| (scaled)',fontsize=9)
    axes[nR-1,cj].set_xlabel('iteration')
fig.suptitle('Joint all-parameter convergence trajectories vs start-offset magnitude (PRECOND fix; each line = one event)',fontsize=12)
fig.tight_layout(rect=[0,0,1,0.985])
fig.savefig(os.path.join(OUT,'joint_trajectories.png'),dpi=105); print('wrote joint_trajectories.png')

# ---- before/after ENERGY contrast: frozen (p0 backup) vs fixed (precond) ----
fig2,axes2=plt.subplots(1,len(CASES),figsize=(3.2*len(CASES),3.2),sharey=True)
for cj,(clab,cpre) in enumerate(CASES):
    ax=axes2[cj]
    for f in sorted(glob.glob(f'/tmp/hist_p0/hist_{cpre}_*.npz')):
        d=np.load(f); ax.plot(np.arange(len(d['traj'])),d['traj'][:,0]-d['truth'][0],color='C3',lw=0.9,alpha=0.7)
    for f in sorted(glob.glob(f'/tmp/hist_{cpre}_*.npz')):
        d=np.load(f); ax.plot(np.arange(len(d['traj'])),d['traj'][:,0]-d['truth'][0],color='C0',lw=0.9,alpha=0.7)
    ax.axhline(0,color='k',lw=0.5,ls=':'); ax.set_title(clab,fontsize=11); ax.set_xlabel('iteration'); ax.grid(alpha=0.25); ax.set_ylim(-330,330)
    if cj==0: ax.set_ylabel('E residual (MeV)')
axes2[0].plot([],[],color='C3',label='PRECOND=0 (frozen)'); axes2[0].plot([],[],color='C0',label='PRECOND=1 (fixed)'); axes2[0].legend(fontsize=8,loc='upper right')
fig2.suptitle('Energy convergence: missing SCALE9 preconditioning FROZE energy (red); fix lets it converge (blue)',fontsize=11)
fig2.tight_layout(rect=[0,0,1,0.94]); fig2.savefig(os.path.join(OUT,'energy_freeze_fix.png'),dpi=110); print('wrote energy_freeze_fix.png')

# capture summary: final |vtx|, |E|, dir per case
print(f"{'case':>6} {'N':>2} | final-iterate residuals (median): E  |vtx|(lon/tra)  dir  t0")
for clab,cpre in CASES:
    files=sorted(glob.glob(f'/tmp/hist_{cpre}_*.npz'))
    fin=[]
    for f in files:
        d=np.load(f); E,lon,tra,ang,t0=[r[-1] for r in resids(d)]; fin.append([abs(E),np.hypot(lon,tra),lon,tra,ang,abs(t0)])
    if not fin: continue
    a=np.array(fin); m=np.median(a,0)
    print(f"{cpre:>6} {len(files):>2} | E {m[0]:6.1f}  |vtx| {m[1]:5.1f}(lon{m[2]:+5.1f}/tra{m[3]:4.1f})  dir {m[4]:4.2f}  t0 {m[5]:.2f}")
