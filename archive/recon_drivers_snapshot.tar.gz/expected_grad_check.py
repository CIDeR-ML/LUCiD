"""Correct gradient validation: E_key[AD]  vs  grad of E_key[loss].
The per-key loss has step discontinuities (grid/overlap sensor reassignment) so per-key
CRN-FD is invalid; but E[loss] is smooth (jumps average out). Compare the key-AVERAGED
pathwise gradient E[AD] to the finite-difference of the EXPECTED loss (independent keys).
If they agree -> AD is an unbiased descent direction. Args: sys.argv[1]=temperature
('none' or float), sys.argv[2]=max_sensors_per_cell."""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import poisson_nll, first_arrival_nll
from lucid.simulation.simulator import setup_event_simulator

TEMP = None if sys.argv[1].lower() == 'none' else float(sys.argv[1])
MSPC = int(sys.argv[2]) if len(sys.argv) > 2 else 8
K, NPHOT, NK = 7, 20_000, 64
theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 0.0])

def build(temp):
    return setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=temp, K=K,
        is_data=False, use_expected_value=True, hit_mode='per_photon',
        max_sensors_per_cell=MSPC, physics_config=H.PHYS, default_detector_params=True,
        particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)

pred = build(TEMP)
truth = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=False,
    use_expected_value=False, hit_mode='realistic', max_sensors_per_cell=MSPC,
    physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(truth, theta_star, jax.random.PRNGKey(7))

def loss(th, key):
    lw, ft, fi, q = pred(H.theta_to_track(th), key)
    charge = jnp.sum(poisson_nll(oc, q))
    time = jnp.sum(jnp.where(hit, first_arrival_nll(lw, ft, fi, ot, 1.5, ND), 0.0))
    return charge + time

gfn = jax.jit(jax.grad(loss))
lfn = jax.jit(loss)
theta0 = theta_star + 0.3 * H.PARAM_SCALE
keys = jax.random.split(jax.random.PRNGKey(0), NK)

# E[AD]
G = np.stack([np.array(gfn(theta0, k)) for k in keys])
E_ad = G.mean(0); sem_ad = G.std(0) / np.sqrt(NK)

# grad of E[loss] via independent-key FD (moderate h; jumps average out in E[loss])
eye = np.eye(7)
print(f"temperature={TEMP}  max_sensors_per_cell={MSPC}  NK={NK}  N={NPHOT}", flush=True)
print(f"{'param':>7} {'E[AD]':>12} {'sem':>8} {'dE[loss]/dθ (FD)':>18} {'sem':>9} {'ratio':>7}", flush=True)
kp = jax.random.split(jax.random.PRNGKey(11), NK)
km = jax.random.split(jax.random.PRNGKey(22), NK)
for pi, pname in enumerate(H.PARAM_NAMES):
    hh = 0.15 * float(H.PARAM_SCALE[pi])
    lp = np.array([float(lfn(theta0 + hh * eye[pi], k)) for k in kp])
    lm = np.array([float(lfn(theta0 - hh * eye[pi], k)) for k in km])
    fd = (lp.mean() - lm.mean()) / (2 * hh)
    fd_sem = np.sqrt(lp.var() + lm.var()) / np.sqrt(NK) / (2 * hh)
    ratio = E_ad[pi] / (fd + 1e-9)
    print(f"{pname:>7} {E_ad[pi]:>12.3f} {sem_ad[pi]:>8.3f} {fd:>18.3f} {fd_sem:>9.3f} {ratio:>7.2f}", flush=True)
