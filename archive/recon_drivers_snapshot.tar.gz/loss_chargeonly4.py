"""CHARGE-ONLY clean test — the user's point: SIREN truth + small/zero TTS should reconstruct ~perfectly.
The charge term (Poisson mu vs oc) has NO t0 and NO TTS dependence, so its 1D argmin is degeneracy-free and
is the cleanest test of forward consistency. If charge-only argmin is AT truth (esp. z=longitudinal, E), the
charge forward (EXPECTED predictor vs SAMPLE truth) is consistent; if z/E are biased, there is a real charge
forward bug. Also: direct per-PMT charge consistency mu_pred vs <oc>_sample at truth (total + longitudinal
profile along the track). NREAL averages out photon noise so any residual is SYSTEMATIC.
Env: NPHOT NREAL NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_chargeonly.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '32')); NKEYS = int(os.environ.get('NKEYS', '6'))
K = 8; MC = 16
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
print(f"# CHARGE-ONLY PRED_TEMP-configurable NPH={NPH} NREAL={NREAL} NKEYS={NKEYS}", flush=True)
import os as _o2; _TMP=_o2.environ.get('PRED_TEMP','0.1'); pred = H.build_predictor(temperature=(None if _TMP=='none' else float(_TMP)), K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk = sc2track(jnp.asarray(th9_true))
oc_acc = np.zeros(ND)
for r in range(NREAL):
    c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r + int(os.environ.get('SEED_OFF','0')))))
    oc_acc += np.asarray(c)
oc_mean = jnp.asarray(oc_acc / NREAL)

@jax.jit
def charge_loss(th9, key):
    _, _, _, tot = pred(sc2track(th9), key); mu = jnp.maximum(tot, 1e-8)
    return jnp.sum(mu - oc_mean * jnp.log(mu))
@jax.jit
def pred_charge(th9, key):
    _, _, _, tot = pred(sc2track(th9), key); return tot
KEYS = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def avgloss(th9): return float(np.mean([float(charge_loss(jnp.asarray(th9), k)) for k in KEYS]))
def vertex(prof, sv):
    A = np.vstack([sv**2, sv, np.ones_like(sv)]).T; a, b, c = np.linalg.lstsq(A, prof, rcond=None)[0]
    return -b / (2 * a) if a > 0 else sv[np.argmin(prof)]

# per-PMT charge consistency at truth
mu_pred = np.mean([np.asarray(pred_charge(jnp.asarray(th9_true), k)) for k in KEYS], 0)
oc_m = np.asarray(oc_mean)
print(f"#  total charge: pred={mu_pred.sum():.0f}  sample={oc_m.sum():.0f}  ratio={mu_pred.sum()/max(oc_m.sum(),1):.4f}", flush=True)
# longitudinal profile: project lit-PMT positions onto track dir? simpler: per-occupancy-bucket pred/sample
for lo, hi in [(0.05,0.2),(0.2,0.5),(0.5,1.0),(1.0,2.0),(2.0,100)]:
    sel = np.where((mu_pred > lo) & (mu_pred <= hi))[0]
    if sel.size: print(f"#   occ {lo:.2f}-{hi:<4.1f}: Npmt {sel.size:5d}  pred {mu_pred[sel].sum():8.1f}  samp {oc_m[sel].sum():8.1f}  ratio {mu_pred[sel].sum()/max(oc_m[sel].sum(),1e-9):.4f}", flush=True)

print(f"#  CHARGE-ONLY argmin off-truth (NO time, NO t0, NO TTS — should be ~0 for self-consistent SIREN):", flush=True)
for i, nm in enumerate(NAMES):
    if nm in ('t0',): continue
    sv = np.linspace(-4 * SCALE9[i], 4 * SCALE9[i], 25)
    prof = np.array([avgloss(th9_true + s * np.eye(9)[i]) for s in sv])
    v = vertex(prof, sv)
    print(f"#   {nm:6s} {v:+10.4f} ({v/SCALE9[i]:+6.2f} scale)", flush=True)
print(f"# READ: if z/energy argmin ~0 => charge forward consistent (TTS=0 residual is the TIME term);", flush=True)
print(f"#       if z/energy biased => EXPECTED-vs-SAMPLE charge-shape bug (the real issue).", flush=True)
