"""Debug AD=FD of the Poisson FA time term — isolate rate vs survival, and the numerical variant that fixes it.
AD vs FD-CRN (same key for +/-h) for t0 and x at theta0, averaged over keys. Variants of the time term:
  base   : current (hard maximum floor, exp(log_w))
  safew  : w = where(log_w>-20, exp(log_w), 0)  + softplus floor on -log r
  rate   : -log r only ;  surv : R only  (each, base impl) -> which breaks AD=FD
Env: NPHOT NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_poisfa_debug.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '32')); K = 8; SIGMA = 2.5
PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0, 0, 0.0175, 0, 0.5]); theta0 = theta_true + delta
LOGN_C = float(np.log(SIGMA * np.sqrt(2 * np.pi))); SQ = float(np.sqrt(2.0))
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
cs, ts = [], []
for s in range(24):
    c, t = jax.lax.stop_gradient(tsim(H.theta_to_track(jnp.asarray(theta_true)), jax.random.PRNGKey(10000 + s)))
    cs.append(np.asarray(c)); ts.append(np.where(np.asarray(c) > 0, np.asarray(t), np.nan))
oc = jax.lax.stop_gradient(jnp.asarray(np.mean(cs, 0))); hit = jax.lax.stop_gradient(jnp.asarray(np.mean(cs, 0) > 1e-6))
ot = jax.lax.stop_gradient(jnp.asarray(np.nan_to_num(np.nanmean(ts, 0))))

def time_loss(variant):
    def loss(theta, key):
        log_w, ft, fi, tot = pred(H.theta_to_track(theta), key)
        d = (ot - theta[6])[fi] - ft
        valid = log_w > -20.0
        if variant in ('safew', 'surv_safe'):
            w = jnp.where(valid, jnp.exp(jnp.where(valid, log_w, 0.0)), 0.0)
        else:
            w = jnp.exp(log_w)
        log_r = segment_logsumexp(jnp.where(valid, log_w, -1e6) + (-0.5 * (d / SIGMA) ** 2 - LOGN_C), fi, ND)
        R = jax.ops.segment_sum(w * 0.5 * (1.0 + erf(d / (SIGMA * SQ))), fi, num_segments=ND)
        if variant == 'safew':
            lr = log_r - jax.nn.softplus(-(log_r + 60.0)) * 0.0 + jnp.where(log_r < -60, -60.0 - jax.lax.stop_gradient(log_r) + log_r, 0.0)  # smooth-ish
            lr = jnp.maximum(log_r, -60.0)
        else:
            lr = jnp.maximum(log_r, -60.0)
        empty = log_r <= -59.0
        if variant == 'rate':
            term = -lr
        elif variant in ('surv', 'surv_safe'):
            term = R
        else:
            term = -lr + R
        return jnp.sum(jnp.where(hit & (~empty), term, 0.0))
    return loss

keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def adfd(variant):
    lossj = jax.jit(time_loss(variant)); gradj = jax.jit(jax.grad(time_loss(variant)))
    out = {}
    for nm, i in [('t0', 6), ('x', 1)]:
        gA = np.mean([np.asarray(gradj(jnp.asarray(theta0), k))[i] for k in keys])
        h = 0.01 * PS[i]; e = np.zeros(7); e[i] = h
        gF = np.mean([(float(lossj(jnp.asarray(theta0 + e), k)) - float(lossj(jnp.asarray(theta0 - e), k))) / (2 * h) for k in keys])
        out[nm] = (gA, gF)
    return out

print(f"# Poisson FA time-term AD vs FD-CRN  NKEYS={NKEYS}", flush=True)
for v in ['base', 'rate', 'surv', 'safew']:
    o = adfd(v)
    print(f"#  {v:6s}  t0: AD {o['t0'][0]:+10.2f} FD {o['t0'][1]:+10.2f} ratio {o['t0'][0]/(o['t0'][1]+1e-9):+.2f} | "
          f"x: AD {o['x'][0]:+10.2f} FD {o['x'][1]:+10.2f} ratio {o['x'][0]/(o['x'][1]+1e-9):+.2f}", flush=True)
print(f"# READ: which term (rate/surv) has AD!=FD; does safew fix it -> the exp(log_w)/floor was the numerical break.", flush=True)
