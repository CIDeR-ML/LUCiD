"""Clean GRADIENT test, fixing both earlier probe bugs:
  (1) per-KEY AD vs FD on the SAME stochastic realization q(theta,key) -> no Monte-Carlo noise; a
      deterministic differentiation-correctness check (report mean over keys).
  (2) offset (1.0*SC) >> FD step (0.02*SC) so the central difference never straddles the minimum.
Loss = charge MSE sum((q-oc)^2): clean (no log/division) and position-sensitive. For temp=None the
FORWARD uses the hard overlap, so FD measures the TRUE charge->position slope while AD measures the soft
backward surrogate -> they DISAGREE iff the forward/backward mismatch distorts the gradient. For the
consistent overlaps (interp C0, erf C-inf) forward==backward so AD should match small-step FD.
Modes (env): PRED_TEMP='' -> temp=None straight-through; 0.1 -> consistent. OVERLAP=erf -> C-inf.
Usage: CUDA_VISIBLE_DEVICES=g PRED_TEMP=0.1 OVERLAP=erf python grad_clean2.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW
OV = os.environ.get('OVERLAP', '')
if OV: os.environ['OVERLAP_ANALYTIC'] = OV
import recon_ps_setup as PS, recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=140)
PT = os.environ.get('PRED_TEMP', ''); temp = None if PT in ('', 'none', 'None') else float(PT)
NKEYS = int(os.environ.get('NKEYS', '24')); NPH = 40000; SC = np.array(H.PARAM_SCALE)
OFF = float(os.environ.get('OFF', '1.0')); FDH = float(os.environ.get('FDH', '0.02'))
ZOFF = float(os.environ.get('ZOFF', '0.0'))                  # move eval point OFF the z=0 symmetry plane
S = PS.setup(event=0, nphot=NPH, truth_source='siren', pred_temperature=temp, truth_key=0)
ts = np.array(S['theta_star']); pred = S['pred']; oc = S['oc']

def mse(th, k):
    q = pred(H.theta_to_track(th), k)[3]
    return jnp.sum((q - oc) ** 2)
g = jax.jit(jax.grad(mse)); l = jax.jit(mse)
thg = ts.copy(); thg[1] += OFF * SC[1]; thg[3] += ZOFF * SC[3]   # offset in x (and z if ZOFF!=0)

pb = slice(1, 4)
fcoss, fmags, pcoss, pmags = [], [], [], []
ad_acc = np.zeros(7); fd_acc = np.zeros(7)
for i in range(NKEYS):
    k = jax.random.PRNGKey(60000 + i)
    gad = np.array(g(jnp.asarray(thg), k)) * SC            # SAME key for AD and FD
    gfd = np.array([(float(l(jnp.asarray(thg + np.eye(7)[j] * FDH * SC[j]), k)) -
                     float(l(jnp.asarray(thg - np.eye(7)[j] * FDH * SC[j]), k))) /
                    (2 * FDH) * SC[j] for j in range(7)])
    ad_acc += gad; fd_acc += gfd
    fcoss.append(gad @ gfd / (np.linalg.norm(gad) * np.linalg.norm(gfd) + 1e-12))
    fmags.append(np.linalg.norm(gad) / (np.linalg.norm(gfd) + 1e-12))
    pcoss.append(gad[pb] @ gfd[pb] / (np.linalg.norm(gad[pb]) * np.linalg.norm(gfd[pb]) + 1e-12))
    pmags.append(np.linalg.norm(gad[pb]) / (np.linalg.norm(gfd[pb]) + 1e-12))
print(f"MODE temp={PT or 'None'} overlap={OV or 'default'} NK={NKEYS} OFF={OFF} FDH={FDH}: "
      f"per-key mean FULL cos={np.mean(fcoss):.3f}+-{np.std(fcoss):.3f} mag={np.mean(fmags):.3f} | "
      f"POS cos={np.mean(pcoss):.3f}+-{np.std(pcoss):.3f} mag={np.mean(pmags):.3f}", flush=True)
print("  mean AD pos grad:", ad_acc[pb] / NKEYS, " mean FD pos grad:", fd_acc[pb] / NKEYS, flush=True)
