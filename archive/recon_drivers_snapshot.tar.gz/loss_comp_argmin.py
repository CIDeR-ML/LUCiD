"""COMPONENT ISOLATION using the ARGMIN metric (the centroid is too coarse -- the -6cm vertex is a tiny
charge-shape diff AMPLIFIED by the weak longitudinal direction). Fixed predictor = EXP per_photon, temp=None.
Truth = each of the 4 combos {STEP: EXP/SMP} x {READOUT: per_photon(tot)/realistic(charge)}, all temp=None.
For each truth, charge-only z & energy argmin (vs the predictor). Self-truth (EXP_pp) ~0 = sanity. Whichever
single flip drives z to ~-6cm is cause #2, measured in the metric that matters.
Env: NPHOT NREAL NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_comp_argmin.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '64')); NKEYS = int(os.environ.get('NKEYS', '16'))
K = 8; MC = 16; POL, AZ = 0.6, 0.8
th9 = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
SC9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# COMP-ARGMIN  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS}  predictor=EXP per_photon temp=None", flush=True)
def build(use_ev, hm):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=use_ev,
        hit_mode=hm, max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
        wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
PRED = build(True, 'per_photon'); ND = H.num_detectors(PRED)
@jax.jit
def pred_mu(t9, key): return PRED(sc(t9), key)[3]
KEYS = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def vertex(prof, sv):
    A=np.vstack([sv**2,sv,np.ones_like(sv)]).T; a,b,c=np.linalg.lstsq(A,prof,rcond=None)[0]
    return -b/(2*a) if a>0 else sv[np.argmin(prof)]
def argmin_for(oc_mean):
    oc=jnp.asarray(oc_mean)
    def closs(t9): return float(np.mean([float(jnp.sum(jnp.maximum(pred_mu(jnp.asarray(t9),k),1e-8) - oc*jnp.log(jnp.maximum(pred_mu(jnp.asarray(t9),k),1e-8)))) for k in KEYS]))
    res={}
    for i in [0,3]:  # energy, z
        sv=np.linspace(-4*SC9[i],4*SC9[i],19)
        prof=np.array([closs(th9+s*np.eye(9)[i]) for s in sv]); res[i]=vertex(prof,sv)
    return res[0], res[3]

for use_ev, tag in [(True,'EXP'),(False,'SMP')]:
    for hm, rt, ci in [('per_photon','pp',3),('realistic','rl',0)]:
        sim=build(use_ev,hm); seed0=(1000 if not use_ev else 0)+(500 if hm=='realistic' else 0)
        acc=np.zeros(ND)
        for r in range(NREAL):
            out=jax.lax.stop_gradient(sim(sc(jnp.asarray(th9)), jax.random.PRNGKey(seed0+r)))
            acc+=np.asarray(out[ci])
        E,Z=argmin_for(acc/NREAL)
        note = '(self=sanity~0)' if tag=='EXP' and rt=='pp' else ('(REAL TRUTH)' if tag=='SMP' and rt=='rl' else '')
        print(f"#  truth={tag}_{rt}  E argmin {E:+7.1f}MeV   z argmin {Z*100:+6.1f}cm   {note}", flush=True)
print(f"# READ: which truth-combo flip drives z to ~-6cm vs the EXP_pp self (~0) => STEP(SMP_pp) or READOUT(EXP_rl).", flush=True)
