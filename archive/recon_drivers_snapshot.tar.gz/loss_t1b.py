"""TIER 1b — MATCHED-KEY self-consistency, the clean loss-form test (FAST).
Truth = predictor's OWN count-conditioned model at forward(KEY0). The loss core() reuses the SAME
KEY0 forward -> at theta_true the forward is BYTE-IDENTICAL, so any argmin offset is the LOSS FORM,
not photon key-noise. CONTROL: KEYX (different key) shows how much of T1's residual was key-noise.
EFFICIENT: forward (expensive, depends on theta,key only) computed ONCE per point; the cheap
count-cond loss is vmapped over all realizations. Center the profile AT truth, global-parabola vertex.
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t1b.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '32'))
K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
ASC = 0.02
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, ASC, ASC, ASC, ASC, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    theta = jnp.arctan2(st, ct); phi = jnp.arctan2(sp, cp)
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=theta, phi=phi, t0=th9[8])
print(f"# T1b MATCHED-KEY  NPH={NPH} NREAL={NREAL}  (loss reuses the SAME forward key that generated truth)", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
KEY0 = jax.random.PRNGKey(0); KEYX = jax.random.PRNGKey(7)

@jax.jit
def forward(th9, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key)
    return jnp.exp(jnp.clip(log_w, -60, 20)), ft, fi, tot

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def cheaploss(ww, ft, fi, tot, t0, oc, ot):
    tobs = (ot - t0)[fi]; mu = jnp.maximum(tot, 1e-8)
    Rlo = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs - DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Rhi = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs + DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rlo) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rhi) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(oc > 0, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
vloss = jax.jit(jax.vmap(cheaploss, in_axes=(None, None, None, None, None, 0, 0)))

# ---- truth realizations from forward(KEY0) ----
ww0, ft0, fi0, tot0 = [np.asarray(a) for a in jax.lax.stop_gradient(forward(jnp.asarray(th9_true), KEY0))]
mu = tot0
order = np.argsort(fi0); fi_s = fi0[order]; w_s = ww0[order]; ft_s = ft0[order]
bounds = np.searchsorted(fi_s, np.arange(ND + 1)); lit = np.where(mu > 1e-6)[0]
print(f"#  lit PMTs={lit.size}  mean mu(lit)={mu[lit].mean():.2f}  total mu={mu.sum():.0f}", flush=True)
rng = np.random.default_rng(12345)
OC = np.zeros((NREAL, ND)); OT = np.zeros((NREAL, ND))
for r in range(NREAL):
    ns = rng.poisson(mu[lit])
    for p, n in zip(lit, ns):
        if n == 0: continue
        a, b = bounds[p], bounds[p + 1]; wj = w_s[a:b]; tj = ft_s[a:b]
        comp = rng.choice(b - a, size=int(n), p=wj / wj.sum())
        OC[r, p] = n; OT[r, p] = (tj[comp] + SIGMA * rng.standard_normal(int(n))).min()
OC = jnp.asarray(OC); OT = jnp.asarray(OT)

def avgloss(th9, key):
    ww, ft, fi, tot = forward(th9, key)
    return float(jnp.mean(vloss(ww, ft, fi, tot, th9[8], OC, OT)))
def vertex(prof, sv):
    A = np.vstack([sv**2, sv, np.ones_like(sv)]).T; a, b, c = np.linalg.lstsq(A, prof, rcond=None)[0]
    return -b / (2 * a) if a > 0 else sv[np.argmin(prof)]

print(f"#  {'param':6s} | MATCHED-KEY argmin off-truth | CONTROL diff-key argmin", flush=True)
for i, nm in enumerate(NAMES):
    sv = np.linspace(-4 * SCALE9[i], 4 * SCALE9[i], 33)
    pm = np.array([avgloss(jnp.asarray(th9_true + s * np.eye(9)[i]), KEY0) for s in sv])
    px = np.array([avgloss(jnp.asarray(th9_true + s * np.eye(9)[i]), KEYX) for s in sv])
    vm, vx = vertex(pm, sv), vertex(px, sv)
    print(f"#  {nm:6s} | {vm:+11.4f} ({vm/SCALE9[i]:+5.2f} sc) | diff-key {vx:+11.4f} ({vx/SCALE9[i]:+5.2f} sc)", flush=True)
print(f"# READ: MATCHED-KEY argmin ~0 => loss form EXACTLY unbiased; T1 residual was FORWARD key-noise (-> Tier 2).", flush=True)
print(f"#       MATCHED-KEY argmin != 0 => the LOSS FORM itself is biased (-> Tier 1c: which approximation).", flush=True)
