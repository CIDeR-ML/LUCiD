"""ISOLATED source check (no propagation, no overlap, no loss, no optimization):
directly compare the EMITTED photons of the SIREN surrogate vs the real PhotonSim photons at the SAME
true track. Decompose by:
  (1) EMISSION ANGLE  = angle between each photon's direction and the track direction (the Cherenkov angle).
      A peak-angle offset => SIREN's Cherenkov angle / n(lambda) differs; a width difference => spectral/MS.
  (2) EMISSION ORIGIN longitudinal profile = distance of emission point along the track from the vertex.
This isolates whether (and how) the SIREN emission differs from Geant4, mechanistically.
Usage: CUDA_VISIBLE_DEVICES=g python isolated_source.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.siren.core import create_photonsim_siren_grid
from lucid.siren.training.inference import SIRENPredictor
from lucid.sources.siren_rays import photonsim_differentiable_get_rays
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=4, suppress=True)
NPHOT = 80_000

# --- the true track (same target as recon_ps_setup) ---
raw = PS.read_photon_data_from_photonsim(PS.ROOT, 0)
n = int(raw['photon_origins'].shape[0])
P = np.array(raw['photon_origins'])/100.0
C = P - P.mean(0); _,_,vt = np.linalg.svd(C, full_matrices=False); d0 = vt[0]
if d0[2] < 0: d0 = -d0
proj = (P-P.mean(0))@d0; vtx0 = P.mean(0)+proj.min()*d0
tp, ta = 0.6, 0.8
dt = np.array([np.sin(tp)*np.cos(ta), np.sin(tp)*np.sin(ta), np.cos(tp)])
axis = np.cross(d0, dt); axis/= (np.linalg.norm(axis)+1e-12)
ang = float(np.arccos(np.clip(d0@dt,-1,1)))
def rod(v): return v*np.cos(ang)+np.cross(axis,v)*np.sin(ang)+axis*(axis@v)*(1-np.cos(ang))
trans = np.zeros(3) - rod(vtx0)
E = float(raw['energy']); vtx = np.zeros(3)

# --- (A) real PhotonSim photons rotated/translated to the target track ---
Dps = np.array(raw['photon_directions'])
Dps_rot = np.array([rod(v) for v in Dps])                    # rotate directions
emis_ps = np.degrees(np.arccos(np.clip(Dps_rot @ dt, -1, 1)))      # emission angle to track
Ops = np.array([rod(p) for p in P]) + trans                 # rotated/translated origins (m)
s_ps = (Ops - vtx) @ dt                                      # longitudinal coord along track

# --- (B) SIREN emitted photons at the same track ---
dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
material = dg.medium.material
pp = unpack_photonsim_params('muon', material)
pred = SIRENPredictor(pp['siren_model_path']); grid = create_photonsim_siren_grid(pred)
na, nb, nc = pp['num_seeds']
rv, ro, w = photonsim_differentiable_get_rays(jnp.array(vtx), jnp.array(dt), E, NPHOT,
                                              grid, pred.params, jax.random.PRNGKey(0), na, nb, nc)
rv = np.array(rv); ro = np.array(ro); w = np.array(w)
emis_si = np.degrees(np.arccos(np.clip(rv @ dt, -1, 1)))
s_si = (ro - vtx) @ dt

def wstats(ang, wt):
    m = float((wt*ang).sum()/wt.sum()); sd = float(np.sqrt((wt*(ang-m)**2).sum()/wt.sum()))
    return m, sd
mps, sps = wstats(emis_ps, np.ones(len(emis_ps)))
msi, ssi = wstats(emis_si, w)
print(f"=== (1) EMISSION ANGLE to track (Cherenkov) ===")
print(f"  PhotonSim: mean={mps:.2f} deg  std={sps:.2f}  (N={len(emis_ps)})")
print(f"  SIREN    : mean={msi:.2f} deg  std={ssi:.2f}  (weighted)")
print(f"  => peak offset = {msi-mps:+.2f} deg ; width ratio SIREN/PS = {ssi/sps:.2f}")
edges = np.linspace(20, 65, 19); mid = 0.5*(edges[:-1]+edges[1:])
hps,_ = np.histogram(emis_ps, edges); hps = hps/hps.sum()
hsi,_ = np.histogram(emis_si, edges, weights=w); hsi = hsi/hsi.sum()
print("  angle:   "+" ".join(f"{m:4.0f}" for m in mid))
print("  PS  (%): "+" ".join(f"{v*100:4.0f}" for v in hps))
print("  SIR (%): "+" ".join(f"{v*100:4.0f}" for v in hsi))
print(f"\n=== (2) EMISSION ORIGIN longitudinal profile (m along track from vertex) ===")
print(f"  PhotonSim: <s>={s_ps.mean():.2f}  max={s_ps.max():.2f}  (track length proxy)")
print(f"  SIREN    : <s>={float((w*s_si).sum()/w.sum()):.2f}  max={s_si.max():.2f}")
print(f"  Sigma weights SIREN intensity-norm vs PhotonSim N: w.sum()={w.sum():.3f}")
