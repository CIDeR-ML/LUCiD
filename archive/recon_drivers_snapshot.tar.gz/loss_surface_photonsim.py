"""1D loss-surface scans of each track parameter around the (shifted/rotated) PhotonSim truth.
For each assigned param, scans a grid of offsets, averaging charge-only / time-only / full loss over
NKEYS prediction keys, and records the argmin (=bias) + local curvature. Writes /tmp/lsurf_<p>.npz.
Usage: CUDA_VISIBLE_DEVICES=g python loss_surface_photonsim.py P0,P1[,...]   (param indices 0..6)
Env: WT (time weight, def 0.03), TAU (def 4.0), NKEYS (def 8), NPHOT (def 80000).
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

WT    = float(os.environ.get('WT', '0.03'))
TAU   = float(os.environ.get('TAU', '4.0'))
NKEYS = int(os.environ.get('NKEYS', '8'))
NPHOT = int(os.environ.get('NPHOT', '80000'))
SRC   = os.environ.get('TRUTH_SOURCE', 'photonsim')
OUT   = os.environ.get('OUT', 'lsurf')
IDX   = [int(x) for x in sys.argv[1].split(',')]

# scan half-range per param (physical units) and number of grid points
HALF = np.array([400.0, 1.0, 1.0, 1.0, 0.35, 0.35, 4.0])   # E,x,y,z,polar,azim,t0
NPTS = 31

S = PS.setup(event=0, nphot=NPHOT, truth_source=SRC)
theta_star = jnp.array(S['theta_star'])
loss = PS.make_loss(S, WT=WT, TAU=TAU)
loss_j = jax.jit(loss)
keys = [jax.random.PRNGKey(1000 + k) for k in range(NKEYS)]
print(f"setup done: ND={S['ND']} nhit={S['nhit']} sumobs={S['sumobs']:.0f} "
      f"WT={WT} TAU={TAU} NKEYS={NKEYS}", flush=True)

def eval_point(theta):
    cs, ts, fs = [], [], []
    for k in keys:
        c, t, f = loss_j(theta, k)
        cs.append(float(c)); ts.append(float(t)); fs.append(float(f))
    return np.mean(cs), np.mean(ts), np.mean(fs), np.std(fs)

for p in IDX:
    offs = np.linspace(-HALF[p], HALF[p], NPTS)
    C = np.zeros(NPTS); T = np.zeros(NPTS); Fm = np.zeros(NPTS); Fs = np.zeros(NPTS)
    for i, o in enumerate(offs):
        th = theta_star.at[p].add(float(o))
        C[i], T[i], Fm[i], Fs[i] = eval_point(th)
    # argmin (bias) for each loss channel; curvature from a parabola fit near truth
    def amin(y):  # quadratic-interpolated argmin offset
        j = int(np.argmin(y));
        if 0 < j < NPTS-1:
            a, b, c = y[j-1], y[j], y[j+1]
            denom = (a - 2*b + c)
            sub = 0.5*(a - c)/denom if abs(denom) > 1e-12 else 0.0
            return offs[j] + sub*(offs[1]-offs[0])
        return offs[j]
    # curvature near truth: central 2nd difference at the grid point closest to 0
    j0 = int(np.argmin(np.abs(offs)))
    h = offs[1] - offs[0]
    curv_full = (Fm[min(j0+1,NPTS-1)] - 2*Fm[j0] + Fm[max(j0-1,0)]) / h**2
    np.savez(f'/tmp/{OUT}_{p}.npz', offs=offs, C=C, T=T, Fm=Fm, Fs=Fs,
             bias_c=amin(C), bias_t=amin(T), bias_f=amin(Fm), curv_full=curv_full,
             p=p, name=H.PARAM_NAMES[p], scale=float(H.PARAM_SCALE[p]))
    print(f"[{H.PARAM_NAMES[p]:6s}] argmin: charge={amin(C):+.4g} time={amin(T):+.4g} "
          f"full={amin(Fm):+.4g}  curv_full={curv_full:.4g}  "
          f"full@truth={Fm[j0]:.3f} min={Fm.min():.3f}", flush=True)
