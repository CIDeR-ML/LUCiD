# PhotonSim recon: degeneracy + bias — principled (calculation-based) diagnosis [2026-06-08]

Goal: understand WHY the PhotonSim vertex floor is a flat 9–27 cm trough (not a sharp point), separate the
INCONSISTENCY from the BIAS, and find the SOURCE of any bias — using calculations at the truth, not just the
optimizer. Tools: `loss_t4_fisher.py` (expected gradient + Hessian eigenspectrum), `loss_t4_scan.py` (loss profile),
`time_bias.py` (occupancy-binned first-arrival), `emission_map.py` (per-PMT charge residual vs track geometry).
Config: SIREN predictor vs PhotonSim/GEANT4 truth (and SIREN self-consistency control), NPHP=1.5M, count-cond loss
+ AMP_DETACH + OVERLAP_RENORM, MAXCELL=4, TTS 2.5. Near-vertical muons (pol 1.5–5.3°), so longitudinal ≈ z.

## 1. THE DEGENERACY — the truth is a SADDLE, with a flat longitudinal direction (generic, 4 events)
FD Hessian of the full loss at truth (scaled), eigenvalues:
  ev0 [-14.9 -0.63 -0.07 1.7 12 17 63 89 176]   ev1 [-9.9 -1.4 -0.2 -0.01 8 23 41 64 159]
  ev2 [-4.9 -0.8 -0.01 1.1 12 31 49 70 155]      ev3 [-3.5 -0.84 -0.03 2.5 13 39 57 111 184]
- ALWAYS INDEFINITE (negative eigenvalues) => truth is NOT a minimum; loss decreases away from it (that's the bias).
- Near-ZERO eigenvalues (|ev|<0.1) = the flat longitudinal-z direction; smallest-ev eigenvector mixes the ANGLES
  (s_t,c_t,s_p,c_p) and z/t0. cond ~1e11 (singular). Direct scan: total loss varies only ~5–60 over ±0.1–0.2 m in z
  while stiff directions move by thousands. => the vertex is genuinely UNCONSTRAINED at the ~±15 cm scale = the trough.
- This is an INFORMATION limit of (charge + first-arrival) for near-vertical tracks, computed independent of any fit.

## 2. THE INCONSISTENCY (9–27 cm spread) = optimizer freezing the flat direction, NOT bias
- More photons does NOT shrink the trough (500k→1.5M→3M: fit lands 9–27 cm at ~equal loss; far-start even reaches a
  slightly lower loss at 11 cm than truth-start at 25 cm). The loss is just flat there.
- The positive-eigen-CLIP (ev -> CLIP_FRAC*max|ev|) is REQUIRED (negative evs would diverge) but it replaces the
  tiny true curvature of the flat direction with a large floor => the Newton step along it is under-taken =>
  the flat direction FREEZES near the start => start-dependent stopping = the 9–27 cm spread. Ridge adds to this.
- AMP_DETACH uses stop_gradient: changes only the GRADIENT path, NOT the loss value => cannot move the argmin or the
  Hessian. So none of the optimizer mods (clip/ridge/AMP_DETACH) BIAS the minimum; they only pick where in the
  flat trough you stop. The inconsistency is fundamental (no info), not an optimizer defect.

## 3. THE BIAS — two DISTINCT sources, both localized (generic across events)
Expected gradient E_keys[grad L] at truth (=0 if unbiased), scaled, charge vs time, PhotonSim(PS) vs SIREN-self(SN):
  |g charge|: PS 195–353 (BIASED, 20–51σ)  | SN 3.7–8.7 (consistent with 0 ✓)
  |g time  |: PS 21–44   (small)            | SN 563–602 (BIASED, z & t0 at 85–171σ)

### 3a. CHARGE bias = SIREN-vs-GEANT4 EMISSION-SHAPE mismatch (dominates the REAL PhotonSim floor)
- Charge is UNBIASED in self-consistency (SN ~6) => the loss + derive_truth charge reference are correct.
- Against GEANT4 it is biased, concentrated in POLAR ANGLE (s_t grad ~330) and VERTEX (x,y,z ~50–88).
- `emission_map.py` localizes it (total charge conserved 0.99; the bias is SHAPE):
    ANGULAR (cos_view): SIREN OVER-lights backward/wide (cos<0: ×1.09–1.12) and UNDER-lights the forward cone edge
      (cos 0.3–0.6: ×0.92) and dead-forward (cos 0.95–1: ×0.87); the ring (cos 0.6–0.8) is fine (×0.98).
    LONGITUDINAL (s along track): SIREN OVER-lights BEHIND the vertex (s<0: ×1.10–1.12), UNDER-lights just AFTER it
      (s 0–1: ×0.87) and far-forward (s 5–9: ×0.88).
  => the asymmetric longitudinal/angular profile forces the fit to slide the vertex + tip the polar angle = the
     charge bias. SOURCE = SIREN emitter fidelity vs GEANT4 (~10–20% profile shape error). Fix = better emitter only.

### 3b. TIME bias = count-conditioned first-arrival LOSS-FORM defect (dominates the SIREN self-consistency residual)
- Present with NO emission mismatch (SN time |g|=560–600, almost entirely z=-570 / t0=+160). Small vs GEANT4 (21–44).
- `time_bias.py`: the MODEL predicted first-arrival is +3.7 ns LATE vs the truth empirical first-arrival, and the
  offset is OCCUPANCY-DEPENDENT: +8.3 ns at n≈1, +3.7 at n≈2, +2.0 at n≈4.
- Mechanism: the survival mixture F(t)=R/μ is built from ALL photons incl. the late SCATTERED/REFLECTED tail
  (weighted), whereas the truth's hard first-arrival is the earliest DIRECT photon. The order-statistic min pulls
  into F's early tail only at high n; at low n the model first-arrival stays late => occupancy-dependent lateness.
- Why it biases the VERTEX: a CONSTANT lateness is fully absorbed by the free t0 (harmless). The OCCUPANCY-SLOPE
  cannot be (occupancy correlates with geometry) => it leaks into z/t0. SOURCE = first-arrival model uses the full
  (scattered-tail-inclusive) arrival mixture; fixable by matching the survival to the earliest-direct generation
  (e.g. down-weight/limit the late tail, or correct the order-stat for the scattered component).

## 3c. CRB REFRAME — the trough is BIAS-limited, NOT information-limited (crb_long.py)
Fisher information at truth (SIREN self-consistency = clean, PSD charge Fisher Jmu^T diag(1/mu) Jmu + data-avg time):
  CHARGE-only : sigma_long 2.99cm  sigma_trans 7.30cm  sigma_worst-dir 9.23cm
  CHARGE+TIME : sigma_long 2.96cm  sigma_trans 2.40cm  sigma_worst-dir 2.98cm
=> the vertex INFORMATION bound is ~3cm (charge+time), FAR below the observed 9-27cm trough. So the trough is NOT a
fundamental information limit (corrects the earlier framing) — it is BIAS-INDUCED: the emission-shape + time-form
biases flatten/saddle the EFFECTIVE loss surface. Consistent with "more photons didn't shrink it" (bias is
photon-independent). Charge alone has a TRUE null direction (longitudinal-vertex+t0+E); timing fills it
(worst-dir 9.2->3.0cm). Caveat: time Fisher not perfectly PSD (same order-stat defect) so ~3cm is approximate; the
charge-only worst-dir is ridge-sensitive. Robust conclusion: information ~3cm << 15-27cm trough => FIX THE BIASES
to recover the floor (more light won't help).

## 3d. TIME-FIX PROTOTYPE (a) — naive direct-window FAILS (timefix_probe.py)
Restricting the survival to an early-arrival window (drop the scattered tail) DEGENERATES the time term: |g_time|->0
at EVERY window (incl 30ns) because S=1-R/mu saturates to its clip when mu_S and R use only early photons (the
observed first-arrival sits past them). The late tail is what keeps the survival non-degenerate. So the fix is NOT
photon removal; it needs an order-statistic/TTS correction that keeps the full population (the bias is the known
~2ns soft-min/first-arrival effect; t0-argmin ~-1.9ns).

## 3e. ATTRIBUTION MATRIX — WHICH bias specifically (charge/time/full x PhotonSim/SIREN fits)
Vertex displacement (cm), gnrec start@truth, LOSS_MODE in loss_t4.py & opt_lab.py (4 PS events / 1-3 SN keys):
                  charge-only   time-only   full
  PhotonSim          56            29         18
  SIREN-self          8            13         11
- charge-only: 8cm(SN, shot noise) -> 56cm(PS). The +48cm is ENTIRELY emission mismatch (charge unbiased in
  self-consistency). EMISSION is the DOMINANT, specific bias (per-event 38-78cm raw).
- time-only: 13cm on SIREN with NO emission = the pure ~2ns soft-min/order-stat TIME loss-form bias (secondary).
- full(18) << charge-only(56): TIMING CONSTRAINS the emission-biased vertex (~8x suppression). The 18cm full floor =
  ~11cm SIREN-floor(shot+time-form) + ~7cm residual emission. So emission is the ROOT/largest source (56cm raw),
  heavily reined in by timing; the time term both adds ~13cm of its own bias AND suppresses the emission bias.
- LEVER: emitter is the bigger lever (56 vs 13cm); fixing the time likelihood compounds (lets timing constrain harder).

## 4. BOTTOM LINE  (UPDATED by the CRB: trough is BIAS-limited, info supports ~3cm)
- NOT broken: the optimizer correctly finds the loss minimum; that minimum is a flat trough displaced from truth.
- The vertex INFORMATION bound is ~3cm (CRB, charge+time). The 9-27cm trough is BIAS-INDUCED (emission+time flatten
  the surface), NOT a fundamental info limit. => the lever is FIXING THE BIASES, not more light.
- INCONSISTENCY (9-27 cm) = flat-direction freezing by clip/ridge, riding on the bias-flattened surface.
- BIAS source #1 (charge/emission, dominates PhotonSim) = SIREN profile shape vs GEANT4 (~10–20%); needs a better emitter.
- BIAS source #2 (time/loss-form, dominates SIREN self-consistency) = first-arrival survival includes the scattered
  late tail => occupancy-dependent lateness leaking into z; fixable in the LOSS without touching the emitter.
- Neither bias comes from AMP_DETACH/ridge/clip (those affect only convergence, proven via stop_gradient & Hessian).

## Next checks (not yet run)
- Prototype the time fix: build the survival from DIRECT (early-tail) photons only, or add an occupancy-aware
  first-arrival correction; re-measure SN time-grad (should drop) and the SN floor (should approach the ~cm charge floor).
- Quantify the longitudinal information bound (CRB along the flat direction) to state the irreducible vertex sigma.
