"""Isolate the NaN-gradient source and the prediction/truth coverage mismatch."""
import os, jax, jax.numpy as jnp
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import ParticleParams
from lucid.losses import poisson_nll, counts_loss, first_arrival_nll
from lucid.sources.event_io import read_photon_data_from_photonsim

GEOM='config/SK_geom_config.json'; PHYS='config/SK_physics_config.json'
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
NPHOT=50_000; K=7; TAU=1.5

data_sim = setup_event_simulator(GEOM, n_photons=NPHOT, temperature=0.0, K=K, is_data=True,
    max_sensors_per_cell=4, physics_config=PHYS, default_detector_params=True, particle='muon')
pred_sim = setup_event_simulator(GEOM, n_photons=NPHOT, temperature=0.1, K=K, is_data=False,
    hit_mode='per_photon', max_sensors_per_cell=4, physics_config=PHYS,
    default_detector_params=True, particle='muon')
ND = data_sim.default_detector_params.qe_corrections.shape[0]

raw = read_photon_data_from_photonsim(ROOT, 0); n=int(raw['photon_origins'].shape[0])
pd = {'photon_origins':raw['photon_origins'],'photon_directions':raw['photon_directions'],
      'photon_times':raw['photon_times'],'N':n,'apply_rotation':False,
      'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),
      'apply_translation':False,'translation_vector':jnp.zeros(3)}
if 'wavelengths' in raw: pd['wavelengths']=raw['wavelengths']

track = ParticleParams(energy=jnp.array(float(raw['energy'])), position=jnp.zeros(3),
                       theta=jnp.array(0.0), phi=jnp.array(0.0), t0=jnp.array(0.0))
key = jax.random.PRNGKey(0)

oc, ot = jax.lax.stop_gradient(data_sim(track, key, pd))
truth_hit = oc > 0
ot = jnp.where(truth_hit, ot, 0.0)

log_w, ftimes, fidx, total_charge = pred_sim(track, key)
pred_hit = total_charge > 0
print(f"truth_hit sensors = {int(jnp.sum(truth_hit))}  total truth charge = {float(jnp.sum(oc)):.1f}")
print(f"pred_hit  sensors = {int(jnp.sum(pred_hit))}  total pred charge  = {float(jnp.sum(total_charge)):.3f}")
print(f"overlap (truth&pred) = {int(jnp.sum(truth_hit & pred_hit))}")
print(f"max total_charge = {float(jnp.max(total_charge)):.4e}   max obs = {float(jnp.max(oc)):.2f}")
print(f"total_charge finite? {bool(jnp.all(jnp.isfinite(total_charge)))}  log_w finite? {bool(jnp.all(jnp.isfinite(jnp.where(log_w>-1e9,log_w,0.0))))}  ftimes finite? {bool(jnp.all(jnp.isfinite(ftimes)))}")
print(f"counts_loss formula check: poisson_nll==counts_loss? {poisson_nll is counts_loss}")

# Isolate nan: charge-only grad vs time-only grad vs raw-prediction grad
def charge_only(tr):
    _,_,_,tc = pred_sim(tr, key)
    return jnp.sum(poisson_nll(oc, tc))
def time_only(tr):
    lw, ft, fi, tc = pred_sim(tr, key)
    nll = first_arrival_nll(lw, ft, fi, ot, TAU, ND)
    return jnp.sum(jnp.where(truth_hit, nll, 0.0))
def rawpred_sum(tr):  # does the prediction simulator itself have nan grads wrt track?
    lw, ft, fi, tc = pred_sim(tr, key)
    return jnp.sum(tc)

for name, fn in [("charge_only", charge_only), ("time_only", time_only), ("rawpred_sum", rawpred_sum)]:
    v, g = jax.value_and_grad(fn)(track)
    gfin = all(bool(jnp.all(jnp.isfinite(x))) for x in (g.energy, g.position, g.theta, g.phi))
    print(f"  {name:12s}: val={float(v):.4f}  grad_finite={gfin}  "
          f"(E={float(g.energy):.2e} pos={[round(float(c),3) for c in g.position]} th={float(g.theta):.2e} ph={float(g.phi):.2e})")
