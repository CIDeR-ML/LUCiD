"""DIAGNOSTIC — why is the PhotonSim recon floor ~22cm? Scan the loss along z(longitudinal), x(transverse),
and E AROUND the derived truth, for TWO references:
  (PS)  PhotonSim GEANT4 truth  (data_sim is_data fed the event's real photons)
  (SN)  SIREN self-consistency   (build_truth_sim sample at the SAME derive_truth params)
If the PS argmin is offset but the SN argmin sits at 0 -> the bias is SIREN-vs-GEANT4 EMISSION mismatch.
If BOTH are offset -> derive_truth's vertex CONVENTION disagrees with the forward model (a reference bug).
Also splits charge-only vs full loss to see which term drives the offset.
Env: EVENT MAXCELL AXES.  Usage: CUDA_VISIBLE_DEVICES=0 EVENT=0 MAXCELL=4 python loss_t4_scan.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '4'); os.environ.setdefault('AMP_DETACH', '1')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=4, suppress=True, linewidth=160)
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
NBUF = 400_000; MC = int(os.environ['MAXCELL']); K = 8; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
EV = int(os.environ.get('EVENT', '0')); NKEYS = int(os.environ.get('NKEYS', '4')); NPHP = int(os.environ.get('NPHP', '500000'))
SCALE9 = np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NAMES=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
def sc2track(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times'])
    C=P-P.mean(0); _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d; proj=-proj
    vtx=P.mean(0)+proj.min()*d; pol=float(np.arccos(np.clip(d[2],-1,1))); az=float(np.arctan2(d[1],d[0]))
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]), d, P, proj
print(f"# SCAN ev{EV} MC={MC} AMP_DETACH={os.environ.get('AMP_DETACH')}", flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
truth_sn=H.build_truth_sim(K=K,n_photons=500_000)   # SIREN sample truth (make_hits_data, hard, Bernoulli, TTS)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
_AMP=bool(os.environ.get('AMP_DETACH'))
@jax.jit
def loss_split(t9,oc,ot,key):
    lw,ft,fi,tot=pred(sc2track(t9),key); ww=jnp.exp(jnp.clip(lw,-60,20)); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8)
    wR=jax.lax.stop_gradient(ww) if _AMP else ww; muS=jax.lax.stop_gradient(mu) if _AMP else mu
    Rlo=jax.ops.segment_sum(wR*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(wR*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    chg=jnp.sum(mu-oc*jnp.log(mu)); tim=jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
    return chg, tim
KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
def L(t9,oc,ot):
    cs=[];ts=[]
    for k in KEYS: c,t=loss_split(jnp.asarray(t9),oc,ot,k); cs.append(float(c)); ts.append(float(t))
    return np.mean(cs),np.mean(ts)
raw=read_photon_data_from_photonsim(ROOT,EV); th9,d,P,proj=derive_truth(raw); pd,n=pad_event(raw)
print(f"# derive_truth vtx=({th9[1]:+.3f},{th9[2]:+.3f},{th9[3]:+.3f}) pol={np.degrees(np.arccos(d[2])):.1f}deg  proj range=[{proj.min():.2f},{proj.max():.2f}]m len={proj.max()-proj.min():.2f}m", flush=True)
# observed from PhotonSim (PS) and from SIREN self-consistency (SN), both sampled
cP,tP=jax.lax.stop_gradient(data_sim(sc2track(jnp.asarray(th9)),jax.random.PRNGKey(7000+EV),pd))
ocP=jnp.asarray(np.asarray(cP)); otP=jnp.asarray(np.where(np.asarray(cP)>0,np.asarray(tP),0.))
cS,tS=jax.lax.stop_gradient(truth_sn(sc2track(jnp.asarray(th9)),jax.random.PRNGKey(7000+EV)))
ocS=jnp.asarray(np.asarray(cS)); otS=jnp.asarray(np.where(np.asarray(cS)>0,np.asarray(tS),0.))
print(f"# QtotPS={float(np.asarray(cP).sum()):.0f} hitsPS={int((np.asarray(cP)>0).sum())}  |  QtotSN={float(np.asarray(cS).sum()):.0f} hitsSN={int((np.asarray(cS)>0).sum())}", flush=True)
AXES=[int(x) for x in os.environ.get('AXES','3,1,0,8').split(',')]
for idx in AXES:
    rng=np.linspace(-0.6,0.6,13) if idx in (1,2,3) else (np.linspace(-300,300,13) if idx==0 else np.linspace(-3,3,13))
    print(f"\n## axis {NAMES[idx]} (offset in {'m' if idx in(1,2,3) else ('MeV' if idx==0 else 'ns')})", flush=True)
    print(f"#  off     PS:chg   PS:tim   PS:tot  ||  SN:chg   SN:tim   SN:tot", flush=True)
    rowsP=[];rowsS=[]
    for o in rng:
        t9=th9.copy(); t9[idx]=th9[idx]+o
        cP_,tP_=L(t9,ocP,otP); cS_,tS_=L(t9,ocS,otS)
        rowsP.append((o,cP_,tP_,cP_+tP_)); rowsS.append((o,cS_,tS_,cS_+tS_))
        print(f"#  {o:+6.2f}  {cP_:8.1f} {tP_:8.1f} {cP_+tP_:8.1f}  ||  {cS_:8.1f} {tS_:8.1f} {cS_+tS_:8.1f}", flush=True)
    rowsP=np.array(rowsP);rowsS=np.array(rowsS)
    aPc=rng[np.argmin(rowsP[:,1])];aPt=rng[np.argmin(rowsP[:,2])];aPtot=rng[np.argmin(rowsP[:,3])]
    aSc=rng[np.argmin(rowsS[:,1])];aSt=rng[np.argmin(rowsS[:,2])];aStot=rng[np.argmin(rowsS[:,3])]
    print(f"#  ARGMIN {NAMES[idx]}: PS chg={aPc:+.2f} tim={aPt:+.2f} tot={aPtot:+.2f}  ||  SN chg={aSc:+.2f} tim={aSt:+.2f} tot={aStot:+.2f}  (0=derive_truth)", flush=True)
print("# DONE", flush=True)
