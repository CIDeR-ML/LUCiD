"""Diagnose the TIME-term energy bias (~-13MeV exposed once charge/overlap is fixed). Count-conditioned time
term uses survival S(t)=1-R(t)/mu with mu = predicted total charge (ENERGY-dependent). Isolate the time term,
GRID-MIN the energy argmin (NOT parabola), and ask which knob it rides on:
  - CHARGE-only vs TIME-only vs FULL energy argmin.
  - TIME with mu DETACHED from energy (mu fixed at theta_true in S) -> if bias vanishes, the mu-normalization
    coupling is the cause.
  - sweep sigma and Delta.
Setup matches Tier-5 ON: pred temp=0.1 + OVERLAP_RENORM (set in env), sample truth, NREAL-averaged.
Env: NPHOT NREAL NKEYS OVERLAP_RENORM.  Usage: CUDA_VISIBLE_DEVICES=g OVERLAP_RENORM=1.009 python loss_timeenergy.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '64')); NKEYS = int(os.environ.get('NKEYS', '8'))
K = 8; MC = 16; SQ = float(np.sqrt(2.0)); POL, AZ = 0.6, 0.8
th9 = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# TIME-ENERGY diag  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS} OVERLAP_RENORM={os.environ.get('OVERLAP_RENORM','1.0')}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk = sc(jnp.asarray(th9))
OC=np.zeros(ND); OTw=np.zeros(ND); OTn=np.zeros(ND)
for r in range(NREAL):
    c,t=jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(9000+r))); c=np.asarray(c); t=np.asarray(t)
    OC+=c; m=c>0; OTw+=np.where(m,t,0.0); OTn+=m
oc=jnp.asarray(OC/NREAL); ot=jnp.asarray(np.where(OTn>0, OTw/np.maximum(OTn,1), 0.0))  # mean charge, mean first-arrival
mu_true = jnp.maximum(jnp.mean(jnp.stack([pred(trk,jax.random.PRNGKey(s))[3] for s in range(NKEYS)]),0),1e-8)
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
PKEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]

def comps(t9, SIGMA, DELTA, mu_fixed=False):
    L_c=0.0; L_t=0.0
    for key in PKEYS:
        lw,ft,fi,tot=pred(sc(jnp.asarray(t9)),key); w=jnp.exp(jnp.clip(lw,-60,20)); mu=jnp.maximum(tot,1e-8)
        L_c=L_c+jnp.sum(mu - oc*jnp.log(mu))
        muS = mu_true if mu_fixed else mu
        tobs=(ot)[fi]
        Rlo=jax.ops.segment_sum(w*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
        Rhi=jax.ops.segment_sum(w*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
        Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.0); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.0)
        n=jnp.maximum(oc,0.0); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
        L_t=L_t+jnp.sum(jnp.where(oc>0, -n*jnp.log(Slo)-log1mexp(a), 0.0))
    return float(L_c)/NKEYS, float(L_t)/NKEYS
comps=jax.jit(comps, static_argnums=(3,)) if False else comps  # keep python (SIGMA/DELTA scalars)

def egrid(fn, half=200.0, n=41):
    sv=np.linspace(-half,half,n); prof=np.array([fn(th9+s*np.eye(9)[0]) for s in sv]); j=int(np.argmin(prof))
    if 0<j<n-1:
        y0,y1,y2=prof[j-1],prof[j],prof[j+1]; d=(y0-2*y1+y2); sref=sv[j]+(0.5*(y0-y2)/d*(sv[1]-sv[0]) if abs(d)>1e-12 else 0)
    else: sref=sv[j]
    return sv[j], sref

# charge-only, full, time-only @ sigma=2.5 delta=1
ec=egrid(lambda t: comps(t,2.5,1.0)[0]); print(f"#  CHARGE-only  E argmin grid {ec[0]:+6.1f} local {ec[1]:+6.1f} MeV", flush=True)
ef=egrid(lambda t: sum(comps(t,2.5,1.0))); print(f"#  FULL         E argmin grid {ef[0]:+6.1f} local {ef[1]:+6.1f} MeV", flush=True)
for SIG in [1.5,2.5,3.5]:
    for DEL in [0.5,1.0,2.0]:
        et=egrid(lambda t: comps(t,SIG,DEL)[1])
        print(f"#  TIME-only  sigma={SIG} Delta={DEL}:  E argmin grid {et[0]:+6.1f} local {et[1]:+6.1f} MeV", flush=True)
etf=egrid(lambda t: comps(t,2.5,1.0,mu_fixed=True)[1]); print(f"#  TIME-only mu-DETACHED (sig2.5 d1):  E argmin grid {etf[0]:+6.1f} local {etf[1]:+6.1f} MeV", flush=True)
print(f"# READ: if TIME-only E argmin <0 and mu-DETACHED ->~0 => the S=1-R/mu energy coupling is the bias; else it is R-shape/sigma.", flush=True)
