"""Correct CRB via the OBSERVED FISHER = Hessian of the raw NLL at truth (scales correctly with N, unlike
the gradient-noise covariance). FD Hessian of the key-averaged gradient of the RAW Poisson charge NLL and
the RAW first-arrival time NLL; CRB_i = sqrt(diag(H^-1)). Reports charge-only, time-only, full (charge+time).
Usage: CUDA_VISIBLE_DEVICES=g [NPHOT=80000 TAU=1.0 TEMP=0.1 THR=4 SRC=siren NKEYS=48 DSTEP=0.3] python crb_hessian.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import first_arrival_nll
np.set_printoptions(precision=3, suppress=True, linewidth=140)
N=int(float(os.environ.get('NPHOT','80000'))); TAU=float(os.environ.get('TAU','1.0'))
TEMP=float(os.environ.get('TEMP','0.1')); THR=float(os.environ.get('THR','4'))
SRC=os.environ.get('SRC','siren'); NKEYS=int(os.environ.get('NKEYS','48')); DSTEP=float(os.environ.get('DSTEP','0.3'))
SC=np.array(H.PARAM_SCALE); names=H.PARAM_NAMES; U=['MeV','m','m','m','rad','rad','ns']

S=PS.setup(event=0,nphot=N,truth_source=SRC,pred_temperature=TEMP,truth_key=0)
ts=np.array(S['theta_star']); pred=S['pred']; oc=S['oc']; hitf=S['hit']; otf=S['ot']; ND=S['ND']
tmask=jax.lax.stop_gradient(hitf&(oc>=THR))
def lc(th,k):                                            # raw Poisson charge NLL
    _,_,_,q=pred(H.theta_to_track(th),k); return jnp.sum(q-oc*jnp.log(q+1e-8))
def lt(th,k):                                            # raw first-arrival time NLL
    lw,ft,fi,_=pred(H.theta_to_track(th),k); return jnp.sum(jnp.where(tmask,first_arrival_nll(lw,ft,fi,otf-th[6],TAU,ND),0.0))
gc=jax.jit(jax.grad(lc)); gt=jax.jit(jax.grad(lt))
ks=[jax.random.PRNGKey(30000+i) for i in range(NKEYS)]
def gbar(gfn,th):                                        # key-averaged gradient (removes DiCE noise)
    return np.mean([np.array(gfn(jnp.asarray(th),k)) for k in ks],0)
def hessian(gfn):
    Hn=np.zeros((7,7))                                   # normalized (theta in SCALE units)
    for j in range(7):
        d=DSTEP*SC[j]
        gp=gbar(gfn, ts+np.eye(7)[j]*d); gm=gbar(gfn, ts-np.eye(7)[j]*d)
        Hn[:,j]=(gp-gm)/(2*DSTEP)*SC                     # d g_norm / d theta_norm
    return 0.5*(Hn+Hn.T)
def crb(Hn):
    ev=np.linalg.eigvalsh(Hn)
    Hi=np.linalg.pinv(Hn + 1e-9*np.eye(7)*max(abs(ev).max(),1e-12))
    return np.sqrt(np.clip(np.diag(Hi),0,None))*SC, ev[0]/max(ev[-1],1e-12)
def marg(Hn): return np.sqrt(1.0/np.clip(np.diag(Hn),1e-30,None))*SC

print(f"=== CRB(Hessian) N={N} TAU={TAU} TEMP={TEMP} THR={THR} SRC={SRC} NKEYS={NKEYS} ===",flush=True)
Hc=hessian(gc); Ht=hessian(gt); Hf=Hc+Ht
for lbl,Hn in [('charge',Hc),('time',Ht),('full',Hf)]:
    cj,evr=crb(Hn); mg=marg(Hn)
    print(f"[{lbl:6}] joint CRB: "+"  ".join(f"{names[i][:3]}={cj[i]:.3g}{U[i]}" for i in range(7)),flush=True)
    print(f"         margnl  : "+"  ".join(f"{names[i][:3]}={mg[i]:.3g}{U[i]}" for i in range(7)),flush=True)
