"""Forward-charge convergence vs K (number of scatter/bounce iterations) -> the least K we can get
away with (K is linear-cost: each bounce is one more lax.scan step). Expected-value predictor (mean
charge, low noise), averaged over a few keys. Saves each K's per-sensor charge to /tmp/qK_<K>.npy so a
separate pass computes total-charge fraction and per-sensor pattern error vs the converged reference.
Usage: CUDA_VISIBLE_DEVICES=g MAXCELL=16 OVERLAP_ANALYTIC=cubic KLIST=1,2 python forward_K.py
"""
import os, jax, numpy as np
import recon_harness as H
NPH = 40000; NKEYS = 8
KLIST = [int(x) for x in os.environ['KLIST'].split(',')]
import jax.numpy as jnp
ts = jnp.array([1050., 0., 0., 0., 0.6, 0.8, 0.])
trk = H.theta_to_track(ts)
ks = [jax.random.PRNGKey(7000 + i) for i in range(NKEYS)]
for K in KLIST:
    pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH)
    q = np.mean([np.array(pred(trk, k)[3]) for k in ks], 0)
    np.save(f'/tmp/qK_{K}.npy', q)
    print(f'K={K} sumq={q.sum():.2f} nhit={(q>0.01).sum()}', flush=True)
