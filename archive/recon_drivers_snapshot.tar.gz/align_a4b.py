"""ALIGNMENT A4b — is the SIM<->TRUE per-PMT charge L1 pure truth MC noise?

A4 showed the predictor-vs-hard-truth L1 (~44%) is FLAT in temperature -> not overlap. Hypothesis:
it is the truth's own Monte-Carlo noise (hard Bernoulli at ~0.5 PE/PMT). If so, averaging the truth
over more keys must drop the L1 as 1/sqrt(NKT) toward a small engine+QE floor.

Smooth reference = SIM predictor (temperature=0.1, K=8) averaged over NREF keys (low variance).
Truth = hard sample, K=8; cumulative mean over NKT in {8,16,32,64,128,256}. Report L1(pred, truth_NKT),
corr, and the truth half-vs-half noise floor at each NKT. A 1/sqrt(NKT) fall confirms pure noise;
the extrapolated NKT->inf intercept is the true forward-model floor.

Everything else @ A3 config (SIREN, same track, MAXCELL=8, MIE off, same optics).
Env: NPHOT NREF NMAX MAXCELL.  Usage: CUDA_VISIBLE_DEVICES=g python align_a4b.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NPH = int(os.environ.get('NPHOT', '100000')); NREF = int(os.environ.get('NREF', '16'))
NMAX = int(os.environ.get('NMAX', '256')); MAXCELL = int(os.environ.get('MAXCELL', '8')); K = 8
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NUM_SENSORS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NUM_SENSORS)
dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A4b truth-key convergence  NPH={NPH} NREF={NREF} NMAX={NMAX} MAXCELL={MAXCELL} K={K} MIE off", flush=True)

pred = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False,
    use_expected_value=True, hit_mode='per_photon', max_sensors_per_cell=MAXCELL,
    physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
    pos_grad_threshold=K, n_grad_iters=K)
samp = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
    use_expected_value=False, hit_mode='realistic', max_sensors_per_cell=MAXCELL,
    physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
    apply_smearing=False)

q_pred = np.mean([np.asarray(jax.lax.stop_gradient(pred(track, jax.random.PRNGKey(1000 + s)))[3]) for s in range(NREF)], 0)
# also predictor self-noise floor (half vs half) to confirm the reference is smooth
pA = np.mean([np.asarray(jax.lax.stop_gradient(pred(track, jax.random.PRNGKey(1000 + s)))[3]) for s in range(NREF // 2)], 0)
pB = np.mean([np.asarray(jax.lax.stop_gradient(pred(track, jax.random.PRNGKey(1000 + s)))[3]) for s in range(NREF // 2, NREF)], 0)
print(f"# predictor(temp0.1) ref over {NREF} keys: tot {q_pred.sum():.1f}; self half-vs-half L1 "
      f"{np.abs(pA-pB).sum()/q_pred.sum():.2%} (reference smoothness)", flush=True)

truths = [np.asarray(jax.lax.stop_gradient(samp(track, jax.random.PRNGKey(s)))[0]) for s in range(NMAX)]
def L1(a, b): return np.abs(a - b).sum() / (b.sum() + 1e-9)
def corr(a, b):
    lit = (a > 1e-6) | (b > 1e-6); return np.corrcoef(a[lit], b[lit])[0, 1]
print(f"#  NKT    truth_tot   Δtot    L1(pred,truth)   corr     half-vs-half FLOOR L1   1/sqrt(NKT)", flush=True)
NKTS = [n for n in [8, 16, 32, 64, 128, 256] if n <= NMAX]
for nkt in NKTS:
    qt = np.mean(truths[:nkt], 0)
    qa = np.mean(truths[:nkt // 2], 0); qb = np.mean(truths[nkt // 2:nkt], 0)
    print(f"#  {nkt:4d}   {qt.sum():8.1f}  {100*(qt.sum()-q_pred.sum())/q_pred.sum():+5.1f}%   "
          f"{L1(q_pred, qt):7.2%}        {corr(q_pred, qt):.4f}   {np.abs(qa-qb).sum()/qt.sum():7.2%}            {1/np.sqrt(nkt):.3f}", flush=True)
print(f"\n# VERDICT: if L1(pred,truth) falls ~1/sqrt(NKT) -> the SIM<->TRUE per-PMT difference IS truth MC noise,", flush=True)
print(f"#   i.e. the forward models AGREE (the predictor is the correct mean). Extrapolated NKT->inf = forward floor.", flush=True)
