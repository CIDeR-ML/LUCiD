"""GENERALIZED TIME-CHARGE LIKELIHOOD refiner. The principled loss (extended/marked Poisson, fiTQun-style):
  L = wC * [full per-PMT POISSON charge]  +  wT * [count-decoupled first-arrival TIMING]
charge supplies LONGITUDINAL vertex + energy (its proper observable); timing supplies TRANSVERSE vertex +
direction + t0 (its proper observable). Replaces the old lE(total)+lCEN(centroid) summary which discarded
~970x the longitudinal charge info.

Seed uses each observable for what it's good at:
  transverse vertex <- timing TOF point-fit (hierarchical_position_grid_search_4d)
  direction         <- charge-weighted ring axis
  energy            <- total charge
  LONGITUDINAL      <- full-POISSON-charge 1D line-search along d (proper replacement for the lCEN line-search)
  t0                <- timing line-search at the corrected vertex
then a sigma-annealed Adam joint refine on all 7 params.

Run truth=SIREN (well-specified; "assume SIREN is good") to see if the optimizer REACHES the CRB.
Env: TRUTH TTS_NS NPHOT WC WT THR NKG TKS EVENT. Usage: CUDA_VISIBLE_DEVICES=g TRUTH=siren TTS_NS=2.5 python endtoend_glike.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.grid_search import hierarchical_position_grid_search_4d, get_detector_bounds
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'siren'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
WC = float(os.environ.get('WC', '1.0')); WT = float(os.environ.get('WT', '0.1')); NKG = int(os.environ.get('NKG', '3'))
EVENT = int(os.environ.get('EVENT', '0')); NW = float(os.environ.get('NW', '1.34')); SIGEND = float(os.environ.get('SIGEND', '2.5'))
FLR = float(os.environ.get('FLR', '0.03')); SPS = int(os.environ.get('SPS', '20'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3,4,5').split(',')]
SC = np.array(H.PARAM_SCALE); SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2*np.pi); C = 0.299792; G = float(np.sqrt(NW**2-1.0))
FINE_SIG = [s for s in [12, 8, 5, 3, SIGEND] if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points)); BOUNDS = get_detector_bounds(det)
def dvec(pol, az): return jnp.array([jnp.sin(pol)*jnp.cos(az), jnp.sin(pol)*jnp.sin(az), jnp.cos(pol)])

def charge_poisson(q, oc):                       # full per-PMT Poisson NLL, normalized
    return jnp.sum(q - oc*jnp.log(q + 1e-8)) / (jnp.sum(oc) + 1e-9) * 100.0

def timing_decoupled(lw, ft, fi, tobs_sensor, hi, oc, sig):   # count-decoupled Gaussian first-arrival
    tobs = tobs_sensor[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5*x**2 - jnp.log(sig*SQ2PI); log1mF = jnp.log(jnp.clip(0.5*(1.0+jax.lax.erf(-x/SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF+1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns-1.0)*l1mf, 0.0))

def charge_loss(theta, key, oc):
    return charge_poisson(pred(H.theta_to_track(theta), key)[3], oc)
def timing_loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    return timing_decoupled(lw, ft, fi, ot - theta[6], hi, oc, sig)
gcfn = jax.jit(jax.grad(charge_loss)); gtfn = jax.jit(jax.grad(timing_loss))
qfn = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key)[3])   # per-PMT mean charge for seed line-search

LRV = np.array([0.04, FLR, FLR, FLR, 0.03, 0.03, 0.12])    # per-param LR (t0 large enough to traverse residual)

def proj_grad(th, k, oc, ot, hi, sig):
    """COMPLEMENTARITY in the gradient: charge drives E + vertex-ALONG-d (longitudinal); timing drives
    vertex-PERP-d (transverse) + direction + t0. Each observable moves only the subspace it constrains
    well, so charge's weak/biased transverse and timing's degenerate longitudinal never corrupt the fit."""
    gc = np.array(gcfn(th, k, oc)); gt = np.array(gtfn(th, k, oc, ot, hi, sig))
    d = np.array(dvec(th[4], th[5])); gcv = gc[1:4]; gtv = gt[1:4]
    g = np.zeros(7)
    g[0] = WC*gc[0]                                            # energy <- charge
    g[1:4] = WC*(gcv@d)*d + WT*(gtv - (gtv@d)*d)               # along-d <- charge ; perp-d <- timing
    g[4:6] = WC*gc[4:6] + WT*gt[4:6]                           # direction <- charge ring + timing
    g[6] = WT*gt[6]                                            # t0 <- timing
    return g

def adam_phase(th, sigs, nsteps, oc, ot, hi, seed):
    m = np.zeros(7); v = np.zeros(7); t = 0; b1, b2 = 0.9, 0.999
    for sig in sigs:
        for s in range(nsteps):
            ks = [jax.random.PRNGKey(800 + 91*seed + 7*t + j) for j in range(NKG)]
            g = np.mean([proj_grad(th, k, oc, ot, hi, sig) for k in ks], 0) * SC
            t += 1; m = b1*m + (1-b1)*g; v = b2*v + (1-b2)*g*g; mh = m/(1-b1**t); vh = v/(1-b2**t)
            th = th - jnp.array(LRV * (mh/(np.sqrt(vh)+1e-8)) * SC)
    return np.array(th)

def geom_seed(oc, ot, hi):
    hm = np.array(hi); Pn = np.array(DP)[hm]; tobs = np.array(ot)[hm]; q = np.array(oc)[hm]
    r = hierarchical_position_grid_search_4d(jnp.array(Pn), jnp.array(tobs), jnp.array(q), true_position=ts[1:4],
        true_t0=ts[6], t0_guess=0.0, detector_bounds=BOUNDS, n_div=5, t0_n_div=5, levels=6, fraction=1.0,
        t0_min=-15.0, t0_max=15.0, verbosity=0)
    V = np.array(r['best_position']); dv = Pn - V[None, :]; dv = dv/(np.linalg.norm(dv, axis=1, keepdims=True)+1e-9)
    ax = (q[:, None]*dv).sum(0); ax = ax/(np.linalg.norm(ax)+1e-9)
    E = float(estimate_muon_energy_from_photon_count(float(q.sum())))
    pol = float(np.arccos(np.clip(ax[2], -1, 1))); az = float(np.arctan2(ax[1], ax[0]))
    return np.array([E, V[0], V[1], V[2], pol, az, 0.0])

def lon_linesearch(th, oc, span=12.0, n=61):
    """full-Poisson-charge 1D line-search along d -> longitudinal vertex (charge's proper observable)."""
    dd = np.array(dvec(th[4], th[5]))
    def pc(thx):
        qm = np.mean([np.array(qfn(jnp.array(thx), jax.random.PRNGKey(500+j))) for j in range(4)], 0)
        return float(np.sum(qm - np.array(oc)*np.log(qm + 1e-8)))
    lams = np.linspace(-span, span, n)
    vals = [pc(th + np.array([0, dd[0]*l, dd[1]*l, dd[2]*l, 0, 0, 0])) for l in lams]
    th = th.copy(); th[1:4] = th[1:4] + lams[int(np.argmin(vals))]*dd; return th

def t0_linesearch(th, oc, ot, hi, span=6.0, n=49):
    """timing line-search for t0 at fixed vertex (degeneracy broken once longitudinal is charge-pinned).
    pred is t0-independent -> evaluate it ONCE, vary only the observed-time shift (ot - t0)."""
    lw, ft, fi, _ = pred(H.theta_to_track(jnp.array(th)), jax.random.PRNGKey(500))
    t0s = th[6] + np.linspace(-span, span, n)
    vals = [float(timing_decoupled(lw, ft, fi, jnp.array(ot)-t0, hi, oc, 3.0)) for t0 in t0s]
    th = th.copy(); th[6] = float(t0s[int(np.argmin(vals))]); return th

def optimize(th0, oc, ot, hi, seed):
    th = lon_linesearch(th0, oc)                          # charge 1D along d -> longitudinal (transverse seed kept)
    th = t0_linesearch(th, oc, ot, hi)                    # timing -> t0 at the charge-pinned vertex
    th = adam_phase(th, FINE_SIG, SPS, oc, ot, hi, seed)  # projected combined: charge->lon/E, timing->trans/dir/t0
    th = lon_linesearch(th, oc, span=3.0, n=61)           # final longitudinal re-pin (dir/transverse now settled)
    th = t0_linesearch(th, oc, ot, hi, span=3.0)          # final t0 polish at the clean vertex
    return th

def vtx(t): return float(np.linalg.norm((np.array(t)-ts)[1:4])*100)
def lon(t): return float(((np.array(t)-ts)[1:4] @ np.array(dvec(ts[4], ts[5])))*100)
def trans(t): return float(np.sqrt(max(vtx(t)**2 - lon(t)**2, 0)))
def degf(t): return float(np.degrees(np.arccos(np.clip(np.array(dvec(t[4], t[5])) @ np.array(dvec(ts[4], ts[5])), -1, 1))))
def report(tag, th): return f"{tag} vtx={vtx(th):6.1f}cm (lon={lon(th):+6.1f} tr={trans(th):5.1f}) dir={degf(th):5.2f}deg t0={th[6]-ts[6]:+5.2f}ns E={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"
print(f"# ENDTOEND_GLIKE TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} WC={WC} WT={WT} FINE{FINE_SIG} (full Poisson charge + decoupled timing)", flush=True)
print(f"#   truth = {ts}", flush=True)
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0 = geom_seed(oc, ot, hi); thf = optimize(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    print(f"  k{tk} {report('SEED ', th0)}", flush=True); print(f"  k{tk} {report('FINAL', thf)}", flush=True)
SE = np.array([[vtx(s), abs(lon(s)), trans(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), abs(lon(f)), trans(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():5.1f} |lon|={SE[:,1].mean():5.1f} tr={SE[:,2].mean():5.1f} dir={SE[:,3].mean():4.2f} t0={SE[:,4].mean():4.2f} E={SE[:,5].mean():4.1f}", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():5.1f} |lon|={FE[:,1].mean():5.1f} tr={FE[:,2].mean():5.1f} dir={FE[:,3].mean():4.2f} t0={FE[:,4].mean():4.2f} E={FE[:,5].mean():4.1f}   TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
