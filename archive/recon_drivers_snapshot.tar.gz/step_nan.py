"""Reproduce the 2nd-order NaN on the ISOLATED DiCE photon step, wrt the track-relevant inputs
(position, direction). Tests grad and hessian of a scalar over the step outputs.
Usage: CUDA_VISIBLE_DEVICES=g python step_nan.py
"""
import jax, jax.numpy as jnp, numpy as np
from lucid.simulation.photon_step import photon_iteration_update_factors as STEP
np.set_printoptions(precision=4, suppress=True)

# realistic single-photon inputs
pos = jnp.array([1.0, 2.0, 3.0])
dir = jnp.array([0.3, 0.4, 0.866])  # ~unit
time = jnp.array(5.0)
surf = jnp.array(8.0)                # surface distance
normal = jnp.array([0.0, 0.0, -1.0])
scatter_length = jnp.array(100.0)
mie = jnp.array(1e9)                 # no Mie (default) -> p_mie ~ 0
g = jnp.array(0.9)
wall_r = jnp.array(0.3); sens_r = jnp.array(0.1)
absn = jnp.array(50.0)
c = jnp.array(0.21)
key = jax.random.PRNGKey(0)

def f(pos, dir, hit):
    o = STEP(pos, dir, time, surf, normal, scatter_length, mie, g, wall_r, sens_r, absn, hit, key, c)
    new_pos, new_dir, new_time, detect, refl, cont, logp = o
    return jnp.sum(new_pos) + jnp.sum(new_dir) + new_time + detect + refl + cont + logp

for hit in [False, True]:
    g1 = jax.grad(f, argnums=0)(pos, dir, hit)
    g2 = jax.grad(f, argnums=1)(pos, dir, hit)
    print(f"hit={hit}: grad_pos finite={bool(np.isfinite(np.array(g1)).all())}  grad_dir finite={bool(np.isfinite(np.array(g2)).all())}")
    try:
        Hp = jax.hessian(f, argnums=0)(pos, dir, hit)
        Hd = jax.hessian(f, argnums=1)(pos, dir, hit)
        print(f"        hess_pos finite={bool(np.isfinite(np.array(Hp)).all())}  hess_dir finite={bool(np.isfinite(np.array(Hd)).all())}")
    except Exception as e:
        print(f"        hessian FAILED {type(e).__name__}: {str(e)[:80]}")
