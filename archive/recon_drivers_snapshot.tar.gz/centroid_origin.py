"""Find the ORIGIN of the 0.43 m predicted-vs-observed charge-centroid offset at the true track.
Disambiguate: (1) setup bug -- my PCA-derived theta_star not matching the rotated/translated real photons;
(2) the soft overlap (temp=0.1) shifting the centroid; (3) genuine SIREN-vs-PhotonSim source mismatch.
Tests centroid offset for: photonsim+soft, photonsim+hard, SIREN-self-consistent+soft. Also checks how well
the obs photons' own emission track (origins PCA + Cherenkov-corrected directions) matches theta_star.
Usage: CUDA_VISIBLE_DEVICES=g python centroid_origin.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=4, suppress=True)
NK=8
dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4); sp=np.array(dg.sensor_points)
def cen(w): return (w[:,None]*sp).sum(0)/(w.sum()+1e-9)
def offset(truth_source, pt):
    S=PS.setup(event=0,nphot=80_000,truth_source=truth_source,pred_temperature=pt)
    ts=np.array(S['theta_star']); oc=np.array(S['oc'])
    q=np.mean([np.array(jax.jit(S['pred'])(H.theta_to_track(jnp.asarray(ts)),jax.random.PRNGKey(9000+k))[3]) for k in range(NK)],0)
    pol,az=ts[4],ts[5]; dvec=np.array([np.sin(pol)*np.cos(az),np.sin(pol)*np.sin(az),np.cos(pol)])
    perp=np.array([-dvec[1],dvec[0],0.]); perp/=np.linalg.norm(perp)
    off=cen(q)-cen(oc)
    return off, off@dvec, off@perp, q.sum()/oc.sum()

for src,pt,lab in [('photonsim',0.1,'PhotonSim + soft(0.1)'),
                   ('photonsim',None,'PhotonSim + hard'),
                   ('siren',0.1,'SIREN self-consistent + soft(0.1)')]:
    off,al,pe,r=offset(src,pt)
    print(f"[{lab:32}] |offset|={np.linalg.norm(off):.3f} m  along-track={al:+.3f}  along-perp={pe:+.3f}  Sq/So={r:.3f}",flush=True)

# how well does theta_star match the obs photons' own track? (origins PCA + direction)
raw=PS.read_photon_data_from_photonsim(PS.ROOT,0)
P=np.array(raw['photon_origins'])/100.0; D=np.array(raw['photon_directions'])
C=P-P.mean(0); _,_,vt=np.linalg.svd(C,full_matrices=False); d0=vt[0]
if d0[2]<0: d0=-d0
# mean photon direction ~ track direction (Cherenkov azimuth cancels); compare to PCA d0
dmean=D.mean(0); dmean/=np.linalg.norm(dmean)
print(f"\n[theta_star sanity] PCA d0={d0}  mean_photon_dir={dmean}  angle(PCA,meandir)="
      f"{np.degrees(np.arccos(np.clip(d0@dmean,-1,1))):.2f} deg",flush=True)
print(f"  (if these disagree, the PCA-derived track direction used to build theta_star is off => setup bias)",flush=True)
