"""TIER 3 — the DECISIVE loss-argmin test with REAL SAMPLE-ENGINE truth (not the predictor's own model).
T1b showed self-consistent (predictor-own-model) argmin AT truth. This uses the ACTUAL sample engine
(make_hits_data: binary hard detection + first-arrival + TTS) as the truth/data, and profiles the SAME
count-conditioned loss with the EXP predictor. The argmin offset from truth = the REAL forward-induced bias.
Then toggle predictor fixes via PSTEP_DBG (detect_hard, ...) to see which moves the argmin back to truth.
  PSTEP_DBG unset      -> baseline forward bias.
  PSTEP_DBG=detect_hard-> time-faithful deposit (no scatter-RB).
Env: NPHOT NREAL NKEYS PSTEP_DBG.  Usage: CUDA_VISIBLE_DEVICES=g [PSTEP_DBG=detect_hard] python loss_t3.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '32')); NKEYS = int(os.environ.get('NKEYS', '4'))
K = 8; MC = 16; SIGMA = 2.5; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
ASC = 0.02
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, ASC, ASC, ASC, ASC, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
print(f"# T3 SAMPLE-TRUTH loss argmin  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS} PSTEP_DBG={os.environ.get('PSTEP_DBG','')}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk = sc2track(jnp.asarray(th9_true))

# REAL sample-engine truth realizations
OC = np.zeros((NREAL, ND)); OT = np.zeros((NREAL, ND))
for r in range(NREAL):
    c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r)))
    OC[r] = np.asarray(c); OT[r] = np.where(np.asarray(c) > 0, np.asarray(t), 0.0)
OC = jnp.asarray(OC); OT = jnp.asarray(OT)
print(f"#  sample truth: mean lit/event={np.mean([(OC[r]>0).sum() for r in range(NREAL)]):.0f}  mean tot charge={float(OC.sum(1).mean()):.0f}", flush=True)

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def forward(th9, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key)
    return jnp.exp(jnp.clip(log_w, -60, 20)), ft, fi, tot
@jax.jit
def cheaploss(ww, ft, fi, tot, t0, oc, ot):
    tobs = (ot - t0)[fi]; mu = jnp.maximum(tot, 1e-8)
    Rlo = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs - DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Rhi = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs + DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rlo) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rhi) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(oc > 0, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
vloss = jax.jit(jax.vmap(cheaploss, in_axes=(None, None, None, None, None, 0, 0)))
KEYS = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def avgloss(th9):
    tot = 0.0
    for key in KEYS:
        ww, ft, fi, t = forward(th9, key); tot += float(jnp.mean(vloss(ww, ft, fi, t, th9[8], OC, OT)))
    return tot / len(KEYS)
def vertex(prof, sv):
    A = np.vstack([sv**2, sv, np.ones_like(sv)]).T; a, b, c = np.linalg.lstsq(A, prof, rcond=None)[0]
    return -b / (2 * a) if a > 0 else sv[np.argmin(prof)]

print(f"#  {'param':6s} | SAMPLE-truth argmin off-truth (the REAL forward-induced bias)", flush=True)
for i, nm in enumerate(NAMES):
    sv = np.linspace(-4 * SCALE9[i], 4 * SCALE9[i], 25)
    prof = np.array([avgloss(jnp.asarray(th9_true + s * np.eye(9)[i])) for s in sv])
    v = vertex(prof, sv)
    print(f"#  {nm:6s} | {v:+11.4f} ({v / SCALE9[i]:+6.2f} scale)", flush=True)
print(f"# READ: x/y/z argmin = the real forward bias (~-0.14m baseline). Re-run with PSTEP_DBG=detect_hard to see if it moves.", flush=True)
