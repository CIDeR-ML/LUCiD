"""TIER 5 — multi-event reality check: does the forward implicit-capture bias matter vs the ~16cm photon floor?
For each event: ONE sample-engine realization (realistic: hard detect + first-arrival + TTS) at theta_true,
then JOINT-fit all 9 params (count-conditioned loss, sin/cos angles, FREE t0) from truth with Adam, averaging
the gradient over NKEYS predictor keys (common-random-numbers). Collect per-event residuals -> mean (systematic
forward bias) + RMS (realized resolution). If mean |vtx| ~few cm and RMS ~ the 14-16cm photon floor, the forward
bias is sub-dominant (benign). Single-realization fit => cheaploss is ONE call (no realization-vmap OOM).
Parallelize: EVENT_START/EVENT_COUNT slice the event set per GPU.
Env: NPHOT NKEYS STEPS EVENT_START EVENT_COUNT.  Usage: CUDA_VISIBLE_DEVICES=g EVENT_START=0 EVENT_COUNT=4 python loss_t5.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np, optax
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NKEYS = int(os.environ.get('NKEYS', '4')); STEPS = int(os.environ.get('STEPS', '180'))
E0 = int(os.environ.get('EVENT_START', '0')); EC = int(os.environ.get('EVENT_COUNT', '4'))
SIGMA = float(os.environ.get("LOSS_SIGMA","2.5")); DELTA = 1.0; SQ = float(np.sqrt(2.0))
# truth kept HIGH (reference); predictor K/MAXCELL varied independently to probe the model approximation.
TRUTH_K = int(os.environ.get('TRUTH_K', '8')); TRUTH_MC = int(os.environ.get('TRUTH_MC', '16'))
PRED_K = int(os.environ.get('PRED_K', '8')); PRED_MC = int(os.environ.get('PRED_MC', '16'))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2]); NAMES = ['E', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
def th9_dir(th9):                                                  # unit direction from sin/cos
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = np.hypot(st, ct); npp = np.hypot(sp, cp); st, ct, sp, cp = st/nt, ct/nt, sp/npp, cp/npp
    return np.array([st*cp, st*sp, ct])
print(f"# T5 multi-event  NPH={NPH} NKEYS={NKEYS} STEPS={STEPS} events[{E0}:{E0+EC}] TTS={os.environ['TTS_NS']} "
      f"predK={PRED_K} predMC={PRED_MC} truthK={TRUTH_K} truthMC={TRUTH_MC} renorm={os.environ.get('OVERLAP_RENORM','1.0')} amp={bool(os.environ.get('AMP_DETACH'))}", flush=True)
os.environ['MAXCELL'] = str(PRED_MC)                              # H.build_predictor reads MAXCELL from env
pred = H.build_predictor(temperature=float(os.environ.get("PRED_TEMP","0.1")), K=PRED_K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=TRUTH_K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=TRUTH_MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk_true = sc2track(jnp.asarray(th9_true)); dir_true = th9_dir(th9_true)

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
_MU_DETACH = bool(os.environ.get('MU_DETACH'))      # detach only mu in S (BROKE the joint fit)
_AMP_DETACH = bool(os.environ.get('AMP_DETACH'))    # detach the whole AMPLITUDE (weights ww AND mu); keep times ft live
@jax.jit
def loss_one(th9, oc, ot, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key); ww = jnp.exp(jnp.clip(log_w, -60, 20))
    tobs = (ot - th9[8])[fi]; mu = jnp.maximum(tot, 1e-8)
    # AMP_DETACH: time term should constrain arrival TIMES (geometry/t0) only, not photon counts (charge's job).
    # Detach the amplitude (ww, mu) CONSISTENTLY in R and S; ft (times) stay live -> energy/charge-neutral time term.
    wR = jax.lax.stop_gradient(ww) if _AMP_DETACH else ww
    Rlo = jax.ops.segment_sum(wR * 0.5 * (1.0 + erf((tobs - DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Rhi = jax.ops.segment_sum(wR * 0.5 * (1.0 + erf((tobs + DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    muS = jax.lax.stop_gradient(mu) if (_MU_DETACH or _AMP_DETACH) else mu
    S_lo = jnp.clip((muS - Rlo) / muS, 1e-12, 1.0); S_hi = jnp.clip((muS - Rhi) / muS, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(oc > 0, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
gradone = jax.jit(jax.value_and_grad(loss_one))
SC = jnp.asarray(SCALE9); T0 = jnp.asarray(th9_true)
def fit_event(oc, ot):
    opt = optax.adam(3e-2); z = jnp.zeros(9); st = opt.init(z)
    for i in range(STEPS):
        th = T0 + z * SC; G = jnp.zeros(9)
        for s in range(NKEYS):
            _, g = gradone(th, oc, ot, jax.random.PRNGKey(s)); G = G + g
        upd, st = opt.update((G / NKEYS) * SC, st); z = optax.apply_updates(z, upd)
    return np.asarray(T0 + z * SC)

rows = []
for ev in range(E0, E0 + EC):
    c, t = jax.lax.stop_gradient(truth(trk_true, jax.random.PRNGKey(5000 + ev)))
    oc = jnp.asarray(np.asarray(c)); ot = jnp.asarray(np.where(np.asarray(c) > 0, np.asarray(t), 0.0))
    th = fit_event(oc, ot); d = th - th9_true
    dvtx = float(np.sqrt(d[1]**2 + d[2]**2 + d[3]**2))
    dd = th9_dir(th); dang = float(np.degrees(np.arccos(np.clip(np.dot(dd, dir_true), -1, 1))))
    rows.append([ev, d[0], d[1], d[2], d[3], dvtx, dang, d[8]])
    print(f"#  ev{ev:3d}  E{d[0]:+7.1f}  vtx({d[1]:+.3f},{d[2]:+.3f},{d[3]:+.3f}) |{dvtx:.3f}|  dir{dang:5.2f}deg  t0{d[8]:+.3f}", flush=True)
TAG = os.environ.get('TAG', 'x')
np.savetxt(f"/tmp/t5_{TAG}_ev_{E0}.txt", np.array(rows), fmt="%.5f")
print(f"# SLICE[{E0}:{E0+EC}] saved /tmp/t5_{TAG}_ev_{E0}.txt", flush=True)
