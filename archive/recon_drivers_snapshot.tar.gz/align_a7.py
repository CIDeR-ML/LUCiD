"""ALIGNMENT A7 — first-arrival TIMING: SIM soft-min vs TRUE hard segment_min (+/- TTS).

The timing observable drives direction/t0. TRUE (make_hits_data) = hard segment_min over detected
photons, optionally + per-photon TTS (env TTS_NS) . SIM (make_hits_simulation, 'aggregated') = soft
order-stat first-arrival (make_hits temperature 0.1). We compare per-PMT first-arrival on commonly-lit
PMTs, key-averaged, and bucket by PMT occupancy (the soft-min early bias and the hard-min order-stat
late bias both depend on photon count).

Run TWICE with TTS_NS=0 and TTS_NS=2.5 (env read at sensor_response import). Same SIREN source+key,
K=8, MAXCELL=8, MIE off.
Env: NPHOT NKT MAXCELL TTS_NS.  Usage: CUDA_VISIBLE_DEVICES=g TTS_NS=2.5 python align_a7.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NPH = int(os.environ.get('NPHOT', '100000')); NKT = int(os.environ.get('NKT', '16'))
MAXCELL = int(os.environ.get('MAXCELL', '8')); TTS = float(os.environ.get('TTS_NS', '0')); K = 8
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NUM_SENSORS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NUM_SENSORS)
dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A7 timing  NPH={NPH} NKT={NKT} MAXCELL={MAXCELL} K={K} TTS_NS={TTS} MIE off", flush=True)

sim_agg = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False,
    use_expected_value=True, hit_mode='aggregated', max_sensors_per_cell=MAXCELL,
    physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
    pos_grad_threshold=K, n_grad_iters=K)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
    use_expected_value=False, hit_mode='realistic', max_sensors_per_cell=MAXCELL,
    physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
    apply_smearing=False)

# SIM soft-min per-PMT time (expected, low variance) averaged over a few keys
qc_s, t_sim = [], []
for s in range(4):
    c, t = [np.asarray(x) for x in jax.lax.stop_gradient(sim_agg(track, jax.random.PRNGKey(s)))]
    qc_s.append(c); t_sim.append(np.where(c > 1e-6, t, np.nan))
q_sim = np.nanmean(qc_s, 0); T_sim = np.nanmean(t_sim, 0)

# collect per-(key,PMT) Δt = SIM_soft - TRUE_hard over PMTs lit in BOTH
dts, occs = [], []
for s in range(NKT):
    c, t = [np.asarray(x) for x in jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(s)))]
    lit = (c > 1e-6) & (t > 0) & np.isfinite(T_sim) & (q_sim > 1e-6)
    dts.append(T_sim[lit] - t[lit]); occs.append(c[lit])
dt = np.concatenate(dts); occ = np.concatenate(occs)
print(f"# common-lit (key,PMT) pairs: {dt.size}   Δt = SIM_softmin - TRUE_hardmin  [ns]", flush=True)
print(f"#  ALL:        median {np.median(dt):+.3f}  mean {dt.mean():+.3f}  std {dt.std():.3f}  ns", flush=True)
for lo, hi in [(0, 1), (1, 2), (2, 5), (5, 1e9)]:
    m = (occ >= lo) & (occ < hi)
    if m.sum() > 20:
        print(f"#  occ[{lo:>2.0f},{hi:>3.0f}) n={m.sum():6d}: median {np.median(dt[m]):+.3f}  mean {dt[m].mean():+.3f}  std {dt[m].std():.3f}", flush=True)
print(f"# (occ = TRUE per-PMT charge; soft-min biases EARLY with photon count, hard-min biases LATE for few photons;", flush=True)
print(f"#  TTS_NS>0 pushes TRUE first-arrival EARLIER -> Δt more positive. Compare TTS=0 vs 2.5 runs.)", flush=True)
