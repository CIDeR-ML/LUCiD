"""Systematic end-to-end test of the tau_SMOOTH (spatial charge smoothing) recon vs the others.
Charge term = Poisson NLL on tau_SMOOTH-smoothed charge (energy + transverse vertex); time term = first
arrival (tau_TIME). Energy FREE. Annealed tau_TIME. Cold start, N seeds. Scan tau_SMOOTH (0=raw).
This is the head-to-head for the user's smoothed-charge idea; adopt only if it beats raw / the separation.
Usage: CUDA_VISIBLE_DEVICES=g TAU_SMOOTH=2.0 [WT=0.05] python smooth_recon.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=3, suppress=True)
TS = float(os.environ.get('TAU_SMOOTH', '2.0'))         # 0 = raw per-sensor
WT = float(os.environ.get('WT', '0.05')); THR = float(os.environ.get('THR', '4'))
SEEDS = [int(x) for x in os.environ.get('SEEDS', '1,2,3,4,5,6').split(',')]
SCHED = [float(x) for x in os.environ.get('SCHED', '2,1,0.5').split(',')]
STEPS = int(os.environ.get('STEPS', '90')); SC = np.array(H.PARAM_SCALE)

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; oc = jnp.asarray(S['oc']); SUMOBS = S['sumobs']
hitf = S['hit']; otf = S['ot']; ND = S['ND']
tmask = jax.lax.stop_gradient(hitf & (oc >= THR))
from lucid.losses import first_arrival_nll
if TS > 0:
    dg = DetectorGeometry.from_config(H.GEOM, temperature=None, max_sensors_per_cell=4)
    sp = jnp.asarray(np.array(dg.sensor_points)); a = jnp.sum(sp**2, 1); Gm = sp @ sp.T
    d2 = jnp.clip(a[:, None] + a[None, :] - 2*Gm, 0.0, None)
    W = jnp.exp(-d2/(2*TS**2)); W = W/(jnp.sum(W, 0, keepdims=True)+1e-8)
    ocs = W @ oc
def charge_loss(q):
    if TS > 0:
        qs = W @ q; return jnp.sum(qs - ocs*jnp.log(qs+1e-8))
    return jnp.sum(q - oc*jnp.log(q+1e-8))
def mkgrad(tau):
    def loss(th, k):
        lw, ft, fi, q = pred(H.theta_to_track(th), k)
        c = charge_loss(q)/SUMOBS*100.0
        t = jnp.sum(jnp.where(tmask, first_arrival_nll(lw, ft, fi, otf-th[6], tau, ND), 0.0))
        return c + WT*t
    return jax.jit(jax.grad(loss))
gtot = {tau: mkgrad(tau) for tau in SCHED}
def gnlm(theta, gfn, steps, tag=0, LR=0.4, LM=0.05, tail=30):
    T=[]
    for s in range(steps):
        kk=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in kk]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st)
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t): return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t): return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
print(f"SMOOTH_RECON tau_smooth={TS} tau_time_sched={SCHED} WT={WT} THR={THR}", flush=True)
Vs=[];Ds=[];Es=[];Tt=[]
for sd in SEEDS:
    rng=np.random.default_rng(sd)
    th=jnp.array(ts + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
    for j,tau in enumerate(SCHED): th=gnlm(th, gtot[tau], STEPS, tag=2+j)
    Vs.append(vtx(th));Ds.append(deg(th));Es.append(Ep(th));Tt.append(float(th[6]-ts[6]))
    print(f"  seed {sd}: vtx={vtx(th):5.1f}cm E={Ep(th):+.1f}% dir={deg(th):.2f}deg t0={Tt[-1]:+.2f}", flush=True)
print(f"SMOOTH SUMMARY tau_smooth={TS}: vtx={np.mean(Vs):.1f}+-{np.std(Vs):.1f}cm (med {np.median(Vs):.1f}) "
      f"dir={np.mean(Ds):.2f}deg E={np.mean(Es):+.1f}+-{np.std(Es):.1f}% t0={np.mean(Tt):+.2f}ns", flush=True)
