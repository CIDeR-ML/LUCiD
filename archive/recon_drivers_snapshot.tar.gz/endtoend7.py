"""END-TO-END v7: SK-style vertex-time COORDINATE DESCENT seed (t0 fit from data; hard case). The
longitudinal-vertex<->t0 degeneracy is broken by ALTERNATING 1D line-searches, each scored by the loss that
is well-posed for that DOF (line-searches along single DOFs, NOT volume grids):
  per iter:  t0      <- lT_gd line-search (vertex fixed)            [well-posed once vertex pinned]
             long.   <- iter0: lCEN line-search (coarse, t0-indep, breaks degeneracy)
                        iter>0: lT_gd line-search (FINE, UNBIASED, t0 fixed -> escapes the lCEN ~50cm charge floor)
             dir     <- re-estimate charge-axis from the UPDATED vertex (cures transverse-corruption-from-slide)
Start: radial point-fit (origin_time_loss) transverse vtx + charge-axis dir + total-charge E. Then refiner
lE + WCEN*lCEN + WT*lT_gd. Env: TRUTH TTS_NS NKG SPS WT WCEN TKS EVENT NW NITER.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim TTS_NS=2.5 python endtoend7.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
from lucid.optimization.grid_search import hierarchical_position_grid_search_4d, get_detector_bounds
from lucid.optimization.utils.functions import estimate_muon_energy_from_photon_count
np.set_printoptions(precision=3, suppress=True)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '120000')); THR = float(os.environ.get('THR', '4.0'))
WT = float(os.environ.get('WT', '1.0')); WCEN = float(os.environ.get('WCEN', '2.0')); NITER = int(os.environ.get('NITER', '3'))
NKG = int(os.environ.get('NKG', '3')); SPS = int(os.environ.get('SPS', '16')); LR = float(os.environ.get('LR', '0.03'))
SIGEND = float(os.environ.get('SIGEND', '2.5')); EVENT = int(os.environ.get('EVENT', '0')); NW = float(os.environ.get('NW', '1.34'))
TKS = [int(x) for x in os.environ.get('TKS', '0,1,2,3').split(',')]
SC = np.array(H.PARAM_SCALE); SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2 * np.pi); C = 0.299792; G = float(np.sqrt(NW ** 2 - 1.0))
SIGSCHED = sorted(set([30, 15, 8, 4, SIGEND]), reverse=True); SIGSCHED = [s for s in SIGSCHED if s >= SIGEND]
S = PS.setup(event=EVENT, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points)); BOUNDS = get_detector_bounds(det)
def dvec(pol, az): return jnp.array([jnp.sin(pol) * jnp.cos(az), jnp.sin(pol) * jnp.sin(az), jnp.cos(pol)])

def lcen_only(theta, key, oc):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    d = dvec(theta[4], theta[5]); cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / sumobs
    return ((cen_p - cen_o) @ d) ** 2
lcen_j = jax.jit(lcen_only)
def lt_only(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
lt_j = jax.jit(lt_only)

def chg_axis(V, Pn, q):
    dv = Pn - V[None, :]; dv = dv / (np.linalg.norm(dv, axis=1, keepdims=True) + 1e-9)
    ax = (q[:, None] * dv).sum(0); return ax / (np.linalg.norm(ax) + 1e-9)

def geom_seed(oc, ot, hi):
    ocj, otj, hij = jnp.array(oc), jnp.array(np.array(ot)), jnp.array(np.array(hi))
    hm = np.array(hi); Pn = np.array(DP)[hm]; tobs = np.array(ot)[hm]; q = np.array(oc)[hm]
    r = hierarchical_position_grid_search_4d(jnp.array(Pn), jnp.array(tobs), jnp.array(q), true_position=ts[1:4],
        true_t0=ts[6], t0_guess=0.0, detector_bounds=BOUNDS, n_div=5, t0_n_div=5, levels=6, fraction=1.0,
        t0_min=-15.0, t0_max=15.0, verbosity=0)
    V = np.array(r['best_position']); t0 = float(r['best_t0']); ax = chg_axis(V, Pn, q)
    E = float(estimate_muon_energy_from_photon_count(float(q.sum())))
    def scan_t0(V, ax, t0c):
        ts_ = t0c + np.linspace(-8, 8, 33); pol = float(np.arccos(np.clip(ax[2], -1, 1))); az = float(np.arctan2(ax[1], ax[0]))
        vv = [float(lt_j(jnp.array([E, V[0], V[1], V[2], pol, az, tt]), jax.random.PRNGKey(13), ocj, otj, hij, 4.0)) for tt in ts_]
        return float(ts_[int(np.argmin(vv))])
    def scan_long(V, ax, t0, span, n, use_lcen):
        pol = float(np.arccos(np.clip(ax[2], -1, 1))); az = float(np.arctan2(ax[1], ax[0])); lam = np.linspace(-span, span, n); vv = []
        for L in lam:
            th = jnp.array([E, V[0] + L * ax[0], V[1] + L * ax[1], V[2] + L * ax[2], pol, az, t0])
            vv.append(float(lcen_j(th, jax.random.PRNGKey(11), ocj)) if use_lcen else float(lt_j(th, jax.random.PRNGKey(13), ocj, otj, hij, 6.0)))
        return V + lam[int(np.argmin(vv))] * ax
    for it in range(NITER):
        t0 = scan_t0(V, ax, t0)
        V = scan_long(V, ax, t0, 12.0, 49, True) if it == 0 else scan_long(V, ax, t0, 1.5, 31, False)
        ax = chg_axis(V, Pn, q)
    t0 = scan_t0(V, ax, t0)
    pol = float(np.arccos(np.clip(ax[2], -1, 1))); az = float(np.arctan2(ax[1], ax[0]))
    return np.array([E, V[0], V[1], V[2], pol, az, t0])

def loss(theta, key, oc, ot, hi, sig):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key); sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
    lE = ((sumq - sumobs) / sumobs) ** 2 * 100.0
    d = dvec(theta[4], theta[5]); cen_p = (q[:, None] * DP).sum(0) / (sumq + 1e-9); cen_o = (oc[:, None] * DP).sum(0) / sumobs
    lCEN = ((cen_p - cen_o) @ d) ** 2 * 100.0
    tobs = (ot - theta[6])[fi]; x = (tobs - ft) / sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    log_dens = -0.5 * x ** 2 - jnp.log(sig * SQ2PI); log1mF = jnp.log(jnp.clip(0.5 * (1.0 + jax.lax.erf(-x / SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn + log_dens, fi, ND); l1mf = segment_logsumexp(lwn + log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    lT = jnp.sum(jnp.where((hi & (oc >= THR)) & (~empty), -lf - (Ns - 1.0) * l1mf, 0.0))
    return lE + WCEN * lCEN + WT * lT
gfn = jax.jit(jax.grad(loss))
def refine(th0, oc, ot, hi, seed):
    th = jnp.array(th0); m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999; t = 0
    for sig in SIGSCHED:
        for s in range(SPS):
            ks = [jax.random.PRNGKey(800 + 91 * seed + 7 * t + j) for j in range(NKG)]
            g = np.mean([np.array(gfn(th, k, oc, ot, hi, sig)) for k in ks], 0) * SC
            t += 1; m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g; mh = m / (1 - b1 ** t); vh = v / (1 - b2 ** t)
            th = th - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SC)
    return np.array(th)

def vtx(t): return float(np.linalg.norm((np.array(t) - ts)[1:4]) * 100)
def degf(t): return float(np.degrees(np.arccos(np.clip(np.array(dvec(t[4], t[5])) @ np.array(dvec(ts[4], ts[5])), -1, 1))))
def lon(t): return float(((np.array(t) - ts)[1:4] @ np.array(dvec(ts[4], ts[5]))) * 100)
def report(tag, th): return f"{tag}: vtx={vtx(th):6.1f}cm (lon={lon(th):+5.0f}) dir={degf(th):5.2f}deg t0_err={abs(th[6]-ts[6]):5.2f}ns E_err={abs(th[0]-ts[0])/ts[0]*100:5.1f}%"
print(f"# ENDTOEND7 TRUTH={TRUTH} TTS={os.environ.get('TTS_NS','0')} NW={NW} WCEN={WCEN} NITER={NITER} (vertex-time coord-descent seed + refiner)", flush=True)
print(f"#   truth theta = {ts}", flush=True)
seeds = []; finals = []
for tk in TKS:
    oc, ot, hi = regen(tk)
    th0 = geom_seed(oc, ot, hi); thf = refine(th0, oc, ot, hi, tk)
    seeds.append(th0); finals.append(thf)
    print(f"  key {tk}  {report('SEED ', th0)}", flush=True); print(f"  key {tk}  {report('FINAL', thf)}", flush=True)
SE = np.array([[vtx(s), degf(s), abs(s[6]-ts[6]), abs(s[0]-ts[0])/ts[0]*100] for s in seeds])
FE = np.array([[vtx(f), degf(f), abs(f[6]-ts[6]), abs(f[0]-ts[0])/ts[0]*100] for f in finals])
print(f"# MEAN SEED : vtx={SE[:,0].mean():6.1f}cm dir={SE[:,1].mean():5.2f}deg t0={SE[:,2].mean():5.2f}ns E={SE[:,3].mean():5.1f}%", flush=True)
print(f"# MEAN FINAL: vtx={FE[:,0].mean():6.1f}cm dir={FE[:,1].mean():5.2f}deg t0={FE[:,2].mean():5.2f}ns E={FE[:,3].mean():5.1f}%  TARGETS vtx<15 dir<2 t0<1 E<20", flush=True)
