"""ALIGNMENT A10 — wavelength_mode on/off. Total + per-PMT charge of predictor (SIM) and truth (TRUE)
with wavelength_mode True (per-photon lambda physics) vs False (scalar). Confirms lambda physics is
applied identically in TRUE and SIM and quantifies the scalar-vs-lambda charge difference.
Same SIREN source, track, K=8, MIE off. Env: NPHOT NKG NKT.  Usage: CUDA_VISIBLE_DEVICES=g python align_a10.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '100000')); NKG = int(os.environ.get('NKG', '4')); NKT = int(os.environ.get('NKT', '16')); K = 8
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NS); dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A10 wavelength_mode on/off  NPH={NPH} NKG={NKG} NKT={NKT} K={K} MIE off", flush=True)
def pred(wl):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False, use_expected_value=True,
        hit_mode='per_photon', max_sensors_per_cell=8, physics_config=H.PHYS, default_detector_params=dp_off,
        particle='muon', wavelength_mode=wl, pos_grad_threshold=K, n_grad_iters=K)
def truth(wl):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
        hit_mode='realistic', max_sensors_per_cell=8, physics_config=H.PHYS, default_detector_params=dp_off,
        particle='muon', wavelength_mode=wl, apply_smearing=False)
for wl in [True, False]:
    qp = np.mean([np.asarray(jax.lax.stop_gradient(pred(wl)(track, jax.random.PRNGKey(s)))[3]) for s in range(NKG)], 0)
    qt = np.mean([np.asarray(jax.lax.stop_gradient(truth(wl)(track, jax.random.PRNGKey(s)))[0]) for s in range(NKT)], 0)
    print(f"#  wavelength_mode={str(wl):5s}: SIM tot {qp.sum():8.1f}  TRUE tot {qt.sum():8.1f}  (SIM vs TRUE Δtot {100*(qp.sum()-qt.sum())/qt.sum():+.1f}%)", flush=True)
print(f"# VERDICT: lambda physics applied identically TRUE vs SIM (Δtot consistent across wl on/off); scalar-vs-lambda total-charge difference quantified.", flush=True)
