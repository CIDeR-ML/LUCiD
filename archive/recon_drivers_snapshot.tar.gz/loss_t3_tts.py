"""TIER 3 vs TTS — does the forward time bias (t0 offset / vertex residual) vanish as TTS -> 0?
Repeat the T3 loss-argmin analysis (count-conditioned loss, REAL sample-engine truth, 1D profiles) at a given
TTS. The loss sigma TRACKS the truth TTS (sigma = max(TTS, 0.1); floored to keep erf non-singular at TTS->0),
since sigma is exactly the per-photon time resolution being modeled. TTS_NS is read at sensor_response IMPORT,
so ONE PROCESS PER TTS (set TTS_NS in the env before launch). Report argmin off-truth for all 9 params; the
headline is t0 and |vtx| vs TTS.
Env: TTS_NS NPHOT NREAL NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g TTS_NS=2.0 python loss_t3_tts.py
"""
import os
assert 'TTS_NS' in os.environ, "set TTS_NS explicitly (per-process)"
os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
TTS = float(os.environ['TTS_NS']); SIGMA = max(TTS, 0.1)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '32')); NKEYS = int(os.environ.get('NKEYS', '4'))
K = 8; MC = 16; DELTA = 1.0; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
SCALE9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2]); NAMES = ['energy', 'x', 'y', 'z', 's_t', 'c_t', 's_p', 'c_p', 't0']
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
print(f"# T3-vs-TTS  TTS={TTS} SIGMA={SIGMA}  NPH={NPH} NREAL={NREAL} NKEYS={NKEYS}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
trk = sc2track(jnp.asarray(th9_true))
OC = np.zeros((NREAL, ND)); OT = np.zeros((NREAL, ND))
for r in range(NREAL):
    c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r)))
    OC[r] = np.asarray(c); OT[r] = np.where(np.asarray(c) > 0, np.asarray(t), 0.0)
OC = jnp.asarray(OC); OT = jnp.asarray(OT)

def log1mexp(a): a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
@jax.jit
def forward(th9, key):
    log_w, ft, fi, tot = pred(sc2track(th9), key); return jnp.exp(jnp.clip(log_w, -60, 20)), ft, fi, tot
@jax.jit
def cheaploss(ww, ft, fi, tot, t0, oc, ot):
    tobs = (ot - t0)[fi]; mu = jnp.maximum(tot, 1e-8)
    Rlo = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs - DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    Rhi = jax.ops.segment_sum(ww * 0.5 * (1.0 + erf((tobs + DELTA / 2 - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    S_lo = jnp.clip((mu - Rlo) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - Rhi) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0); a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    time = jnp.sum(jnp.where(oc > 0, -n * jnp.log(S_lo) - log1mexp(a), 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + time
vloss = jax.jit(jax.vmap(cheaploss, in_axes=(None, None, None, None, None, 0, 0)))
KEYS = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def avgloss(th9):
    tot = 0.0
    for key in KEYS:
        ww, ft, fi, t = forward(th9, key); tot += float(jnp.mean(vloss(ww, ft, fi, t, th9[8], OC, OT)))
    return tot / len(KEYS)
def vertex(prof, sv):
    A = np.vstack([sv**2, sv, np.ones_like(sv)]).T; a, b, c = np.linalg.lstsq(A, prof, rcond=None)[0]
    return -b / (2 * a) if a > 0 else sv[np.argmin(prof)]
res = {}
for i, nm in enumerate(NAMES):
    sv = np.linspace(-4 * SCALE9[i], 4 * SCALE9[i], 25)
    prof = np.array([avgloss(jnp.asarray(th9_true + s * np.eye(9)[i])) for s in sv])
    res[nm] = vertex(prof, sv)
vtx = float(np.sqrt(res['x']**2 + res['y']**2 + res['z']**2))
print(f"#  TTS={TTS}: t0={res['t0']:+.4f}ns  vtx=({res['x']:+.4f},{res['y']:+.4f},{res['z']:+.4f}) |vtx|={vtx:.4f}m  E={res['energy']:+.2f}MeV", flush=True)
with open(f"/tmp/t3tts_{TTS}.txt", "w") as f:
    f.write(f"{TTS} {res['t0']:.5f} {res['x']:.5f} {res['y']:.5f} {res['z']:.5f} {vtx:.5f} {res['energy']:.4f}\n")
print(f"# DONE TTS={TTS}", flush=True)
