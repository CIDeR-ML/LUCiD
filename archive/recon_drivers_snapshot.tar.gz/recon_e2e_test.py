"""End-to-end smoke test of the time-NLL reconstruction pipeline on the mie branch.

Verifies:
  (1) the mie-branch simulator API (max_sensors_per_cell) builds a per-photon track predictor,
  (2) the bug-fixed data-like (is_data=True) path generates truth from real PhotonSim ROOT photons,
  (3) the combined charge (poisson_nll) + first-arrival time (first_arrival_nll) loss runs and is
      differentiable end-to-end (finite loss + finite gradient wrt track params).

Usage:  CUDA_VISIBLE_DEVICES=<g> XLA_PYTHON_CLIENT_PREALLOCATE=false python recon_e2e_test.py
"""
import os, jax, jax.numpy as jnp

from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import ParticleParams
from lucid.losses import poisson_nll, first_arrival_nll
from lucid.sources.event_io import read_photon_data_from_photonsim

GEOM = 'config/SK_geom_config.json'
PHYS = 'config/SK_physics_config.json'
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
NPHOT = 50_000
TEMPERATURE = 0.1
K = 7
TAU_TIME = 1.5

print("=" * 70, flush=True)
print("Building data-like TRUTH simulator (is_data=True, bug-fixed scatter path)", flush=True)
data_simulator = setup_event_simulator(
    GEOM, n_photons=NPHOT, temperature=0.0, K=K,
    is_data=True, is_calibration=False,
    max_sensors_per_cell=4, physics_config=PHYS,
    default_detector_params=True, particle='muon')

print("Building per-photon PREDICTION simulator (track/SIREN, hit_mode='per_photon')", flush=True)
prediction_simulator = setup_event_simulator(
    GEOM, n_photons=NPHOT, temperature=TEMPERATURE, K=K,
    is_data=False, is_calibration=False, hit_mode='per_photon',
    max_sensors_per_cell=4, physics_config=PHYS,
    default_detector_params=True, particle='muon')

num_detectors = data_simulator.default_detector_params.qe_corrections.shape[0]
print(f"  num_detectors = {num_detectors}", flush=True)

# ---- Load one real PhotonSim event for the data-like truth -------------------
print(f"Loading event 0 from {ROOT}", flush=True)
raw = read_photon_data_from_photonsim(ROOT, 0)
n = int(raw['photon_origins'].shape[0])
event_energy = float(raw['energy'])
print(f"  event photons N={n}, primary energy={event_energy:.1f} MeV", flush=True)

photon_data = {
    'photon_origins': raw['photon_origins'],          # cm (simulator /100 -> m)
    'photon_directions': raw['photon_directions'],
    'photon_times': raw['photon_times'],
    'N': n,
    'apply_rotation': False,
    'rotation_axis': jnp.array([1.0, 0.0, 0.0]),
    'rotation_angle': jnp.array(0.0),
    'apply_translation': False,
    'translation_vector': jnp.array([0.0, 0.0, 0.0]),
}
if 'wavelengths' in raw:
    photon_data['wavelengths'] = raw['wavelengths']

# ---- True track (photons emitted at detector center, +z) ---------------------
true_track = ParticleParams(
    energy=jnp.array(event_energy),
    position=jnp.zeros(3),
    theta=jnp.array(0.0),     # +z
    phi=jnp.array(0.0),
    t0=jnp.array(0.0))

key = jax.random.PRNGKey(0)
print("Generating data-like truth observables ...", flush=True)
observed_counts, observed_times = jax.lax.stop_gradient(
    data_simulator(true_track, key, photon_data))
hit_mask_truth = observed_counts > 0
# Sanitize: non-hit sensors carry an inf/1e6 sentinel from make_hits_data smearing.
# They are masked out of the loss, but the sentinel must not poison segment ops / grads.
observed_times = jnp.where(hit_mask_truth, observed_times, 0.0)
nhit = int(jnp.sum(hit_mask_truth))
t_hit = jnp.where(hit_mask_truth, observed_times, jnp.inf)
print(f"  truth: {nhit} sensors hit, total charge={float(jnp.sum(observed_counts)):.1f}, "
      f"t(hit) range=[{float(jnp.min(t_hit)):.2f}, "
      f"{float(jnp.max(jnp.where(hit_mask_truth, observed_times, -jnp.inf))):.2f}] ns", flush=True)

# ---- Combined time-NLL reconstruction loss -----------------------------------
def combined_loss(track, key):
    log_w, flat_times, flat_indices, total_charge = prediction_simulator(track, key)
    charge_loss = jnp.sum(poisson_nll(observed_counts, total_charge))
    # first_arrival_nll is now empty-segment safe (floors -inf terms, zeroes the
    # gradient there), so we mask on truth-hit alone; truth-hit sensors with no
    # predicted photon contribute 0 to the time term (charge term penalises them).
    per_sensor_nll = first_arrival_nll(
        log_w, flat_times, flat_indices, observed_times, TAU_TIME, num_detectors)
    time_loss = jnp.sum(jnp.where(hit_mask_truth, per_sensor_nll, 0.0))
    n_eval = jnp.sum(hit_mask_truth & (total_charge > 0))
    return charge_loss + time_loss, (charge_loss, time_loss, n_eval)

# Forward-only diagnostic first (isolate value-NaN from gradient-NaN)
fwd_loss, (fwd_c, fwd_t, fwd_n) = combined_loss(true_track, key)
print(f"  [forward] charge={float(fwd_c):.4f} time={float(fwd_t):.4f} total={float(fwd_loss):.4f} "
      f"(time NLL evaluated on {int(fwd_n)} sensors)", flush=True)

print("Evaluating combined loss + gradient at the true track ...", flush=True)
(loss_val, (closs, tloss, neval)), grads = jax.value_and_grad(
    combined_loss, has_aux=True)(true_track, key)

print("=" * 70, flush=True)
print(f"  charge_loss = {float(closs):.4f}", flush=True)
print(f"  time_loss   = {float(tloss):.4f}", flush=True)
print(f"  TOTAL loss  = {float(loss_val):.4f}", flush=True)
print(f"  grad energy = {float(grads.energy):.4e}", flush=True)
print(f"  grad position = {grads.position}", flush=True)
print(f"  grad theta = {float(grads.theta):.4e}  grad phi = {float(grads.phi):.4e}", flush=True)
allfinite = all(bool(jnp.all(jnp.isfinite(g))) for g in
                (loss_val, grads.energy, grads.position, grads.theta, grads.phi))
print(f"  ALL FINITE: {allfinite}", flush=True)
print("END-TO-END TIME-NLL PIPELINE: " + ("PASS" if allfinite else "FAIL"), flush=True)
