"""POISSON FIRST-ARRIVAL likelihood — the principled time term.

Detected photons at PMT i = inhomogeneous Poisson process, rate lambda_i(t)=sum_j w_ij delta(t-tau_ij),
TTS-convolved -> r_i(t)=sum_j w_ij N(t;tau_ij,sigma^2). First-arrival density (time to first event):
  p(t_i) = r_i(t_i) exp(-R_i(t_i)),  R_i(t)=sum_j w_ij Phi((t-tau_ij)/sigma)
  NLL_time_i = -log r_i(t_i) + R_i(t_i)
Coherent JOINT likelihood with RAW Poisson charge (same NLL units): L = sum_i[mu_i - n_i log mu_i] + sum_i NLL_time_i.
Well-behaved for dim PMTs (no (N_s-1) exponent); TTS = sigma; uses the full predicted distribution.

Tests per-event bias (x, energy) for charge-only / time-only / joint, vs charge threshold. K=8, MAXCELL=16,
truth carries TTS. Env: TTS_NS NPHOT NKEYS NEV SIGMA THR.  Usage: CUDA_VISIBLE_DEVICES=g python loss_poisson_fa.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '16')); NEV = int(os.environ.get('NEV', '12'))
SIGMA = float(os.environ.get('SIGMA', '2.5')); K = 8; PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
LOGN_C = float(np.log(SIGMA * np.sqrt(2 * np.pi))); SQRT2 = float(np.sqrt(2.0))
print(f"# POISSON FIRST-ARRIVAL  TTS={os.environ['TTS_NS']} NPH={NPH} NKEYS={NKEYS} NEV={NEV} SIGMA={SIGMA} K={K} MC={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH, apply_smearing=False)
ND = H.num_detectors(pred); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def make_loss(oc, ot, hit, THR, wc, wt):
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hit = jax.lax.stop_gradient(hit)
    def loss(theta, key):
        log_w, ft, fi, total_charge = pred(H.theta_to_track(theta), key)
        d = (ot - theta[6])[fi] - ft                              # t_obs - tau (per photon)
        logN = -0.5 * (d / SIGMA) ** 2 - LOGN_C
        log_r = segment_logsumexp(log_w + logN, fi, ND)           # log rate at t_obs
        Phi = 0.5 * (1.0 + erf(d / (SIGMA * SQRT2)))
        R = jax.ops.segment_sum(jnp.exp(log_w) * Phi, fi, num_segments=ND)   # expected # before t_obs
        FL = -60.0; lr = jnp.maximum(log_r, FL); empty = log_r <= (FL + 1.0)
        nll_t = -lr + R
        usable = hit & (oc > THR) & (~empty)
        time = jnp.sum(jnp.where(usable, nll_t, 0.0))
        mu = jnp.maximum(total_charge, 1e-8)                      # RAW Poisson charge (coherent units)
        charge = jnp.sum(mu - oc * jnp.log(mu))
        return wc * charge + wt * time
    return loss

def argmin(lj, i, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts)
    c = np.array([np.mean([float(lj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

CFG = [('charge', 0.0, 1.0, 0.0), ('time(THR0)', 0.0, 0.0, 1.0), ('time(THR3)', 3.0, 0.0, 1.0),
       ('joint(THR0)', 0.0, 1.0, 1.0), ('joint(THR3)', 3.0, 1.0, 1.0)]
acc = {n: {'x': [], 'e': []} for n, _, _, _ in CFG}
for ev in range(NEV):
    oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(5000 + ev))
    for nm, thr, wc, wt in CFG:
        lj = jax.jit(make_loss(oc, ot, hit, thr, wc, wt))
        acc[nm]['x'].append(argmin(lj, 1)); acc[nm]['e'].append(argmin(lj, 0))
print(f"# === per-event argmin: MEAN(bias) +/- STD over {NEV} events ===", flush=True)
for nm, _, _, _ in CFG:
    x = np.array(acc[nm]['x']); e = np.array(acc[nm]['e'])
    print(f"#  {nm:12s}  x bias {x.mean():+.3f} std {x.std():.3f} m | energy bias {e.mean():+6.1f} std {e.std():.1f} MeV", flush=True)
print(f"# READ: Poisson first-arrival joint should be UNBIASED (x bias ~ charge floor) if the order-stat was the bad loss.", flush=True)
