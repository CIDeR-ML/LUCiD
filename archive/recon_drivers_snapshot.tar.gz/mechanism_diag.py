"""SYSTEMATIC per-parameter / per-mechanism bias table (no sweeping). For each of the 7 params, scan it
alone (all others at truth) and report the argmin of EACH loss mechanism separately:
  E_tot  = total-charge energy term         (low spatial freq)
  shape  = scale-invariant charge multinomial (the spatial PATTERN)
  time   = count-decoupled first-arrival     (geometric timing)
Where shape and time DISAGREE on a parameter = a competing mechanism; the one nearer 0 is unbiased and
should own that parameter. Also reports the along-track (longitudinal) vs perpendicular vertex split.
Usage: CUDA_VISIBLE_DEVICES=g [TAU=0.3 THR=4] python mechanism_diag.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
TAU=float(os.environ.get('TAU','0.3')); THR=float(os.environ.get('THR','4')); NK=int(os.environ.get('NKEYS','8'))
S=PS.setup(event=0,nphot=80_000,truth_source='photonsim',pred_temperature=0.1)
ts=np.array(S['theta_star'])
mk=PS.make_loss_sep(S,wE=1,wS=1,wT=1,TAU=TAU,THR=THR)
fE=jax.jit(lambda th,k: mk(th,k)[0]); fS=jax.jit(lambda th,k: mk(th,k)[1]); fT=jax.jit(lambda th,k: mk(th,k)[2])
keys=[jax.random.PRNGKey(11000+i) for i in range(NK)]
def val(fn,theta): return float(np.mean([float(fn(jnp.asarray(theta),k)) for k in keys]))
def amin(offs,ys):
    j=int(np.argmin(ys))
    if 0<j<len(ys)-1:
        a,b,c=ys[j-1],ys[j],ys[j+1]; den=a-2*b+c
        return offs[j]+(0.5*(a-c)/den if abs(den)>1e-9 else 0)*(offs[1]-offs[0])
    return offs[j]
# track direction (for longitudinal/transverse vertex split)
pol,az=ts[4],ts[5]; dvec=np.array([np.sin(pol)*np.cos(az),np.sin(pol)*np.sin(az),np.cos(pol)])
HALF=np.array([300.,1.,1.,1.,0.30,0.30,4.]); NPTS=15
U=['MeV','m','m','m','rad','rad','ns']
print(f"=== MECHANISM bias table (others@truth), TAU={TAU} THR={THR} ===",flush=True)
print(f"{'param':6} {'E_tot':>9} {'shape':>9} {'time':>9}   {'unit'}",flush=True)
for p in range(7):
    offs=np.linspace(-HALF[p],HALF[p],NPTS)
    aE=amin(offs,[val(fE,ts+np.eye(7)[p]*o) for o in offs])
    aS=amin(offs,[val(fS,ts+np.eye(7)[p]*o) for o in offs])
    aT=amin(offs,[val(fT,ts+np.eye(7)[p]*o) for o in offs])
    print(f"{H.PARAM_NAMES[p]:6} {aE:+9.3g} {aS:+9.3g} {aT:+9.3g}   {U[p]}",flush=True)
# longitudinal vs perpendicular vertex: scan vertex along dvec and along a perp axis
perp=np.array([-dvec[1],dvec[0],0.0]); perp/=np.linalg.norm(perp)
for name,axis in [('vtx_long(along track)',dvec),('vtx_perp',perp)]:
    offs=np.linspace(-1.0,1.0,15)
    def shift(o): t=ts.copy(); t[1:4]=ts[1:4]+o*axis; return t
    aE=amin(offs,[val(fE,shift(o)) for o in offs])
    aS=amin(offs,[val(fS,shift(o)) for o in offs])
    aT=amin(offs,[val(fT,shift(o)) for o in offs])
    print(f"{name:20} E_tot={aE:+.3f} shape={aS:+.3f} time={aT:+.3f} m",flush=True)
