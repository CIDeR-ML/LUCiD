"""ANALYTICAL diagnosis of the PhotonSim degeneracy + bias (NOT an optimizer run). At derive_truth:
  (A) EXPECTED GRADIENT  E_keys[grad L]  for charge-only & time-only, for PhotonSim(PS) & SIREN-self-consist(SN).
      Unbiased estimator => 0. Nonzero charge-grad = MODEL/emission bias; nonzero SN time-grad = LOSS-FORM bias.
      Reports the gradient (scaled), its norm, dominant params, and the per-key noise (is the bias significant?).
  (B) FD HESSIAN (scaled) of charge / time / full, eigendecomposed. Smallest eigenvalue + its eigenvector =
      the DEGENERATE direction (which params mix). Condition number. Charge-only vs time-only curvature per param.
  (C) CLIP-FREEZE ratio: how much the positive-eigen-clip (CLIP_FRAC*max_ev) under-steps the flat direction.
Env: EVENT NPHP NKEYS MAXCELL CLIP_FRAC.  Usage: CUDA_VISIBLE_DEVICES=0 EVENT=0 NPHP=1500000 NKEYS=8 python loss_t4_fisher.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=3, suppress=True, linewidth=170)
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
NBUF=400_000; MC=int(os.environ['MAXCELL']); K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0))
EV=int(os.environ.get('EVENT','0')); NKEYS=int(os.environ.get('NKEYS','8')); NPHP=int(os.environ.get('NPHP','1500000'))
CLIP_FRAC=float(os.environ.get('CLIP_FRAC','0.05'))
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times'])
    C=P-P.mean(0); _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d
    vtx=P.mean(0)+proj.min()*d; pol=float(np.arccos(np.clip(d[2],-1,1))); az=float(np.arctan2(d[1],d[0]))
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]),d
print(f"# FISHER ev{EV} NPHP={NPHP} NKEYS={NKEYS} MC={MC} CLIP_FRAC={CLIP_FRAC}",flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
truth_sn=H.build_truth_sim(K=K,n_photons=NPHP)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def split(t9,oc,ot,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8); muS=jax.lax.stop_gradient(mu)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    chg=jnp.sum(mu-oc*jnp.log(mu)); tim=jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.)); return chg,tim
gc=jax.jit(jax.grad(lambda t,oc,ot,k: split(t,oc,ot,k)[0]))
gt=jax.jit(jax.grad(lambda t,oc,ot,k: split(t,oc,ot,k)[1]))
SC=jnp.asarray(SCALE9); KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
def fd_hess(gfn,th,oc,ot):
    Hf=np.zeros((9,9))
    for j in range(9):
        h=0.4*SCALE9[j]
        gp=np.mean([np.asarray(gfn(jnp.asarray(th+h*np.eye(9)[j]),oc,ot,k)) for k in KEYS],0)
        gm=np.mean([np.asarray(gfn(jnp.asarray(th-h*np.eye(9)[j]),oc,ot,k)) for k in KEYS],0)
        Hf[:,j]=(gp-gm)/(2*h)
    H=0.5*(Hf+Hf.T); return H*np.outer(SCALE9,SCALE9)   # scaled
raw=read_photon_data_from_photonsim(ROOT,EV); th9,d=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
cP,tP=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+EV),pd)); ocP=jnp.asarray(np.asarray(cP)); otP=jnp.asarray(np.where(np.asarray(cP)>0,np.asarray(tP),0.))
cS,tS=jax.lax.stop_gradient(truth_sn(sc2(T0),jax.random.PRNGKey(7000+EV))); ocS=jnp.asarray(np.asarray(cS)); otS=jnp.asarray(np.where(np.asarray(cS)>0,np.asarray(tS),0.))
print(f"# derive_truth pol={np.degrees(np.arccos(d[2])):.1f}deg  QPS={float(np.asarray(cP).sum()):.0f} QSN={float(np.asarray(cS).sum()):.0f}",flush=True)
for nm,oc,ot in [('PhotonSim',ocP,otP),('SIREN-self',ocS,otS)]:
    print(f"\n================= {nm} =================",flush=True)
    # (A) expected gradient at truth (scaled), per-key noise
    for gnm,gfn in [('charge',gc),('time',gt)]:
        gk=np.array([np.asarray(gfn(T0,oc,ot,k))*SCALE9 for k in KEYS])   # scaled per key
        gm=gk.mean(0); gsd=gk.std(0)/np.sqrt(NKEYS)                       # mean & SE
        sig=np.abs(gm)/np.maximum(gsd,1e-9)
        print(f"# (A) E[grad {gnm:6s}] scaled |g|={np.linalg.norm(gm):8.2f}  per-param:",flush=True)
        print(f"#     {nm[:4]} g    = {gm}",flush=True)
        print(f"#     signif(|g|/SE)= {sig}   ({'BIASED' if np.linalg.norm(gm)>3*np.linalg.norm(gsd) else 'consistent w/ 0'})",flush=True)
    # (B) Hessian eigenspectrum
    Hf=fd_hess(gc,th9,oc,ot)+fd_hess(gt,th9,oc,ot)   # full = charge + time
    Hc=fd_hess(gc,th9,oc,ot)
    ev,V=np.linalg.eigh(Hf); order=np.argsort(ev)
    print(f"# (B) FULL Hessian eigenvalues (scaled, sorted): {ev[order]}",flush=True)
    print(f"#     cond={ev[order][-1]/max(ev[order][0],1e-9):.1e}  smallest ev={ev[order][0]:.2f}",flush=True)
    vmin=V[:,order[0]]; print(f"#     SMALLEST-ev eigenvector (degenerate dir): {vmin}",flush=True)
    print(f"#       dominant params: {[NM[i] for i in np.argsort(-np.abs(vmin))[:3]]}",flush=True)
    print(f"#     charge-only diag (curvature/param): {np.diag(Hc)}",flush=True)
    # (C) clip-freeze
    maxev=np.abs(ev).max(); clipped=CLIP_FRAC*maxev; frz=max(ev[order][0],1e-9)/clipped
    print(f"# (C) clip floor={clipped:.1f}; smallest true ev={ev[order][0]:.2f} -> step UNDER-taken x{frz:.3f} (frozen if <<1)",flush=True)
print("\n# DONE",flush=True)
