"""PHASE 1 GATE — is there a PSD Gauss-Newton metric for the count-conditioned first-arrival TIME term?
The time term is NOT least-squares, so JᵀWJ doesn't apply directly. Two candidate metrics at the truth:
  (H)  FD HESSIAN of the time NLL (data-averaged)        -> curvature; may be INDEFINITE (saddle/bias).
  (F)  SCORE COVARIANCE / empirical Fisher E_data[g gᵀ]  -> PSD BY CONSTRUCTION (g = ∇L_time per data realization).
Also the CHARGE Fisher J_muᵀ diag(1/mu) J_mu (PSD). Report eigenvalues for charge / time-H / time-F / full(charge+F),
across VARIED (isotropic direction + fiducial shift) PhotonSim events — to see if (F) gives us a clean PSD GN metric
(=> no eigen-clip needed) and whether it differs from calibration. Env: EVENTS NPHP NKEYS NDATA.
Usage: CUDA_VISIBLE_DEVICES=0 EVENTS=0,1,2 python time_fisher_psd.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
np.set_printoptions(precision=3, suppress=True, linewidth=170)
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NBUF=400_000
MC=int(os.environ['MAXCELL']); K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0))
NKEYS=int(os.environ.get('NKEYS','6')); NPHP=int(os.environ.get('NPHP','1000000')); NDATA=int(os.environ.get('NDATA','10'))
EVENTS=[int(x) for x in os.environ.get('EVENTS','0,1,2').split(',')]; FIDR=12.; FIDZ=12.
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def _rotax(u,deg):
    a=np.radians(deg); ca,sa=np.cos(a),np.sin(a); u=u/np.linalg.norm(u)
    ux=np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]]); return np.eye(3)*ca+sa*ux+(1-ca)*np.outer(u,u)
def rand_tf(raw,ev):
    rng=np.random.default_rng(100003+ev); beta=np.degrees(np.arccos(rng.uniform(-1,1))); al=rng.uniform(0,2*np.pi)
    axis=np.array([-np.sin(al),np.cos(al),0.]); rr=FIDR*np.sqrt(rng.uniform()); ph=rng.uniform(0,2*np.pi)
    sh=np.array([rr*np.cos(ph),rr*np.sin(ph),rng.uniform(-FIDZ,FIDZ)])*100.0
    raw=dict(raw); O=np.asarray(raw['photon_origins']).astype(float); D=np.asarray(raw['photon_directions']).astype(float); R=_rotax(axis,beta); c=O.mean(0)
    raw['photon_origins']=(O-c)@R.T+c+sh; raw['photon_directions']=D@R.T; return raw,beta
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); C=P-P.mean(0)
    _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d
    vtx=P.mean(0)+proj.min()*d; pol=float(np.arccos(np.clip(d[2],-1,1))); az=float(np.arctan2(d[1],d[0]))
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]),d
print(f"# TIME_FISHER_PSD events={EVENTS} NPHP={NPHP} NDATA={NDATA}",flush=True)
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def time_nll(t9,oc,ot,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; muS=jax.lax.stop_gradient(jnp.maximum(tot,1e-8))
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
gtime=jax.jit(jax.grad(time_nll)); SC=jnp.asarray(SCALE9)
@jax.jit
def mu_fn(t9,key): return jnp.maximum(pred(sc2(t9),key)[3],1e-8)
def mu_avg(t9,keys): return np.mean([np.asarray(mu_fn(jnp.asarray(t9),k)) for k in keys],0)
KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
def esum(ev,fr=0):  # eigen summary
    e=np.linalg.eigvalsh(0.5*(ev+ev.T)); return e.min(),e.max(),int((e<-1e-6*max(abs(e).max(),1e-9)).sum())
for ev in EVENTS:
    raw,beta=rand_tf(read_photon_data_from_photonsim(ROOT,ev),ev); th9,d=derive_truth(raw); pd,n=pad_event(raw); T0=jnp.asarray(th9)
    # CHARGE Fisher (FD jacobian, PSD)
    mu0=mu_avg(th9,KEYS); J=np.zeros((ND,9))
    for j in range(9):
        h=0.4*SCALE9[j]; J[:,j]=(mu_avg(th9+h*np.eye(9)[j],KEYS)-mu_avg(th9-h*np.eye(9)[j],KEYS))/(2*h)
    Fc=((J/np.sqrt(mu0)[:,None]).T@(J/np.sqrt(mu0)[:,None]))*np.outer(SCALE9,SCALE9)
    # TIME: (H) FD Hessian (data-avg) and (F) score covariance (data-avg), both at truth
    Ht=np.zeros((9,9)); Ft=np.zeros((9,9))
    for r in range(NDATA):
        c,t=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+ev+1000*r),pd)); oc=jnp.asarray(np.asarray(c)); ot=jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
        g=np.mean([np.asarray(gtime(T0,oc,ot,k)) for k in KEYS],0)*SCALE9; Ft+=np.outer(g,g)   # score cov (scaled)
        Hf=np.zeros((9,9))
        for j in range(9):
            h=0.4*SCALE9[j]
            gp=np.mean([np.asarray(gtime(jnp.asarray(th9+h*np.eye(9)[j]),oc,ot,k)) for k in KEYS],0)
            gm=np.mean([np.asarray(gtime(jnp.asarray(th9-h*np.eye(9)[j]),oc,ot,k)) for k in KEYS],0)
            Hf[:,j]=(gp-gm)/(2*h)
        Ht+=0.5*(Hf+Hf.T)*np.outer(SCALE9,SCALE9)
    Ht/=NDATA; Ft/=NDATA
    pol=np.degrees(np.arccos(np.clip(d[2],-1,1)))
    cmin,cmax,cneg=esum(Fc); hmin,hmax,hneg=esum(Ht); fmin,fmax,fneg=esum(Ft); Min,Mx,Mneg=esum(Fc+Ft)
    print(f"# ev{ev} pol{pol:4.0f}:",flush=True)
    print(f"#   CHARGE Fisher  eig[{cmin:+.2g},{cmax:.2g}] neg={cneg}  (expect PSD)",flush=True)
    print(f"#   TIME  Hessian  eig[{hmin:+.2g},{hmax:.2g}] neg={hneg}  (curvature; may be indefinite)",flush=True)
    print(f"#   TIME  ScoreCov eig[{fmin:+.2g},{fmax:.2g}] neg={fneg}  (empirical Fisher; expect PSD)",flush=True)
    print(f"#   FULL charge+ScoreCov eig[{Min:+.2g},{Mx:.2g}] neg={Mneg}  (the candidate GN metric -> 0 neg => NO clip needed)",flush=True)
print("# DONE",flush=True)
