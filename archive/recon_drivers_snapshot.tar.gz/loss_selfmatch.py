"""MATCHED-KEY self-consistency for the charge-only z-argmin. truth oc = pred(theta_true, k0); predictor =
pred(., k0) SAME key. Gibbs => argmin EXACTLY at theta_true. If the profile still reports z=-6cm it is a pure
FIT/WINDOW artifact (asymmetric weakly-curved z-profile + parabola fit), NOT physics. Also: report the raw grid
min and parabola vertex over 3 windows; and the DIFF-KEY (k0 vs k1) and KEY-AVERAGED-LOSS (Jensen) cases for contrast.
Env: NPHOT.  Usage: CUDA_VISIBLE_DEVICES=g python loss_selfmatch.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); K = 8; MC = 16; POL, AZ = 0.6, 0.8
th9 = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
PRED = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=True,
    hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K); ND = H.num_detectors(PRED)
print(f"# SELF-MATCH charge-only z-argmin  NPH={NPH}", flush=True)
@jax.jit
def mu(t9, key): return jnp.maximum(PRED(sc(t9), key)[3], 1e-8)
def pvertex(prof, sv):
    A=np.vstack([sv**2,sv,np.ones_like(sv)]).T; a,b,c=np.linalg.lstsq(A,prof,rcond=None)[0]
    return (-b/(2*a) if a>0 else np.nan)
k0, k1 = jax.random.PRNGKey(0), jax.random.PRNGKey(1)
oc_match = np.asarray(mu(jnp.asarray(th9), k0))                       # truth = pred at k0 (EXACT same realization)

def zprof(loss_fn, half):
    sv = np.linspace(-half, half, 41)
    prof = np.array([loss_fn(th9 + s*np.eye(9)[3]) for s in sv])
    return sv[np.argmin(prof)], pvertex(prof, sv)                     # (grid-min, parabola-vertex) in m

# (1) MATCHED key: predictor uses k0, truth=oc_match (=mu(k0))
ocm = jnp.asarray(oc_match)
def loss_match(t9): m=mu(jnp.asarray(t9),k0); return float(jnp.sum(m - ocm*jnp.log(m)))
# (2) DIFF key: predictor uses k1, truth=oc_match (=mu(k0))  -> forward key-noise
def loss_diff(t9): m=mu(jnp.asarray(t9),k1); return float(jnp.sum(m - ocm*jnp.log(m)))
# (3) KEY-AVERAGED LOSS (Jensen): mean over 8 keys of the loss, truth=oc_match
KS=[jax.random.PRNGKey(s) for s in range(2,10)]
def loss_javg(t9): return float(np.mean([float(jnp.sum(mu(jnp.asarray(t9),k) - ocm*jnp.log(mu(jnp.asarray(t9),k)))) for k in KS]))
# (4) MU-AVERAGED then loss (Jensen-free): truth=oc_match, mu=mean over same 8 keys
def loss_muavg(t9):
    mbar=jnp.mean(jnp.stack([mu(jnp.asarray(t9),k) for k in KS]),0); return float(jnp.sum(mbar - ocm*jnp.log(mbar)))

for half in [0.2, 0.4, 0.8]:
    gm,pv = zprof(loss_match, half)
    print(f"#  MATCHED  window±{half}m:  grid-min z {gm*100:+6.1f}cm   parabola-vertex z {pv*100:+6.1f}cm   (Gibbs => 0)", flush=True)
gm,pv = zprof(loss_diff, 0.8);  print(f"#  DIFF-KEY window±0.8m:  grid-min {gm*100:+6.1f}cm  parabola {pv*100:+6.1f}cm  (forward key-noise)", flush=True)
gm,pv = zprof(loss_javg, 0.8);  print(f"#  KEY-AVG-LOSS (Jensen) ±0.8m:  grid-min {gm*100:+6.1f}cm  parabola {pv*100:+6.1f}cm", flush=True)
gm,pv = zprof(loss_muavg, 0.8); print(f"#  MU-AVG (Jensen-free) ±0.8m:  grid-min {gm*100:+6.1f}cm  parabola {pv*100:+6.1f}cm", flush=True)
print(f"# READ: MATCHED ~0 across windows => Gibbs holds (the -6cm is key-noise/Jensen/window, not forward).", flush=True)
print(f"#       if MATCHED parabola != 0 but grid-min ~0 => parabola-on-asymmetric-profile FIT artifact.", flush=True)
