"""ALIGNMENT A4 — overlap soft-vs-hard. Drive the SIM predictor's temperature from hard(None)
to 0.30 and compare per-PMT charge to the HARD sample truth (saved from A3, _a3_samp_K8.npy).

Isolates the soft-overlap contribution to the TRUE<->SIM per-PMT L1: at temperature=None the
predictor uses HARD overlap (like truth) -> residual = engine(~truth) + QE(expectation) + MC noise
= the FLOOR. As temperature grows, the Gaussian acceptance blurs the ring -> L1 rises. Pins the
residual at temperature=0.1 (the value recon uses).

Everything else fixed @ A3 config (SIREN source, same key, K=8, MAXCELL=8, MIE off, same optics).
A noise-floor reference is computed by splitting the truth keys into two independent halves.
Env: NPHOT NKG NKT MAXCELL.  Usage: CUDA_VISIBLE_DEVICES=g python align_a4.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NPH = int(os.environ.get('NPHOT', '100000')); NKG = int(os.environ.get('NKG', '4'))
NKT = int(os.environ.get('NKT', '16')); MAXCELL = int(os.environ.get('MAXCELL', '8')); K = 8
TEMPS = [None, 0.02, 0.05, 0.10, 0.30]
ts = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.array(ts))
NUM_SENSORS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NUM_SENSORS)
dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# A4 overlap soft-vs-hard  NPH={NPH} NKG={NKG} NKT={NKT} MAXCELL={MAXCELL} K={K} MIE off", flush=True)

def build_exp(temp):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=temp, K=K, is_data=False,
        use_expected_value=True, hit_mode='per_photon', max_sensors_per_cell=MAXCELL,
        physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
        pos_grad_threshold=K, n_grad_iters=K)
def build_samp():
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False,
        use_expected_value=False, hit_mode='realistic', max_sensors_per_cell=MAXCELL,
        physics_config=H.PHYS, default_detector_params=dp_off, particle='muon', wavelength_mode=True,
        apply_smearing=False)

# truth (hard) + its noise floor: two independent halves of NKT keys
samp = build_samp()
qt_all = [np.asarray(jax.lax.stop_gradient(samp(track, jax.random.PRNGKey(s)))[0]) for s in range(NKT)]
qt = np.mean(qt_all, 0)
qtA = np.mean(qt_all[:NKT // 2], 0); qtB = np.mean(qt_all[NKT // 2:], 0)
lit_t = (qtA > 1e-6) | (qtB > 1e-6)
floor_L1 = np.abs(qtA - qtB).sum() / (qt.sum() + 1e-9)
floor_cc = np.corrcoef(qtA[lit_t], qtB[lit_t])[0, 1]
print(f"# truth K=8 hard: tot {qt.sum():.1f}  litPMT {(qt>1e-6).sum()}  "
      f"NOISE FLOOR (half-vs-half over {NKT} keys): L1 {floor_L1:.2%}  corr {floor_cc:.4f}", flush=True)

def cmp(a, b):
    d = np.abs(a - b); lit = (a > 1e-6) | (b > 1e-6)
    cc = np.corrcoef(a[lit], b[lit])[0, 1] if lit.sum() > 2 else float('nan')
    return a.sum(), d.sum() / (b.sum() + 1e-9), d.max(), cc, int(lit.sum())

print(f"#  temperature   tot      Δtot     L1     max|Δ|   corr    litPMT   (vs HARD truth; floor L1 {floor_L1:.1%})", flush=True)
for temp in TEMPS:
    q = np.mean([np.asarray(jax.lax.stop_gradient(build_exp(temp)(track, jax.random.PRNGKey(s)))[3]) for s in range(NKG)], 0)
    tot, l1, mx, cc, lit = cmp(q, qt)
    tag = 'None(hard)' if temp is None else f'{temp:.2f}'
    print(f"#  {tag:>11s}  {tot:8.1f}  {100*(tot-qt.sum())/qt.sum():+5.1f}%  {l1:6.2%}  {mx:6.3f}  {cc:.4f}  {lit:6d}", flush=True)

print(f"\n# VERDICT: L1 at temperature=None ~ noise floor -> overlap is the per-PMT L1 driver; L1 rises with", flush=True)
print(f"#   temperature. Residual at 0.10 (recon's value) = the soft-overlap blur the predictor carries vs hard truth.", flush=True)
