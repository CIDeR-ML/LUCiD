# Reconstruction worktree setup (2026-06-03)

**Pivot:** from calibration (mie_hunter) → **track RECONSTRUCTION** using the **time NLL**.

## Worktree
- Path: `/sdf/group/neutrino/omara/LUCiD_recon`
- Branch: `reconstruction-mie` (created off `mie_scattering_implementation` @ 19a282a — has the mie engine AND the
  per-photon likelihood reconstruction path).
- Main repo (calibration): `/sdf/group/neutrino/omara/LUCiD` on `mie_scattering_implementation` (mie_hunter/ is
  UNCOMMITTED there).

## THE reconstruction notebook (uses the time NLL) — "refactor v2" = the `refactor-v2` branch
**`good_notebooks/tracking_opt_development_likelihood.ipynb`** — "S3DF Pipeline Development Notebook
(Likelihood-Based Loss)". 5-stage track fit (position grid search → direction cone → energy scan → Adam).
Loss = `create_combined_loss_function` → `combined_product_loss`:
- charge: `poisson_nll(observed_counts, total_charge)`
- **time: `first_arrival_nll(log_w, flat_times, flat_indices, t_obs_shifted, tau_time, num_detectors)`** (order-
  statistic first-arrival NLL); fed via `hit_mode='per_photon'` (`make_hits_likelihood` → log_w, flat_times)
- vertex: `origin_time_loss_configurable(...)` with dynamic energy-dependent `tau_vtx` (`get_optimal_tau_vtx`,
  `TAU_VTX_PARAM_A/B/C`). Matches `run_eval_with_parametrization.py`.
Imports VERIFIED to resolve on the mie-branch lucid (losses time-NLL+tau_vtx, setup_event_simulator,
grid_search, opt.functions, ParticleParams — all OK).

## Notebooks brought from refactor-v2 → good_notebooks/ (this worktree)
- tracking_opt_development_likelihood.ipynb  ← THE one (time NLL recon pipeline)
- tracking_opt_joint_loss.ipynb              ← newest, "factored-sum loss" (does NOT use first_arrival_nll)
- tracking_opt_with_gif.ipynb                ← same likelihood loss + GIF viz
- visualize_3D_track_optimization.ipynb      ← 3D recon viz (time NLL)
- event_likelihood_diagnostics.ipynb         ← per-sensor likelihood vs observed time diagnostics
- parameter_scans_1D_likelihood.ipynb, grad_loss_and_opt_in_2D_likelihood.ipynb, per_sensor_tau_analysis.ipynb
  ← likelihood scans/landscapes (time NLL), for reference
NOT the one: `parameter_scans_1D_v2.ipynb` (literal "v2" filename) uses `cone_time_loss`, NOT the NLL.

## Calibration mie_hunter (copied here for reference: `mie_hunter/`, 413 entries)
Key engines/harnesses: implicit_engine.py, implicit_engine_lik.py (per-photon time output), gn_full.py (diag-GN
+decoupled+Polyak optimizer), gn_k.py / gn_profk.py (per-PMT k; profile-k fix for the L_M↔k bias), lik_variants.py.
Key docs: GN_OPTIMIZER_LM.md (best HP set: diag ridge λ=0.02 + decoupled + FRESH + τ≈0.85–1.0 + Polyak +
Hessian-refresh~100), TIMING_FINDINGS.md, TIMING_COMBINATION.md, CONSOLIDATED_FINDINGS.md, HANDOVER.md.

## lucid divergence note (mie branch vs refactor-v2)
simulator.py (~359 lines) and sensor_response.py (~288 lines) differ (the mie-scattering engine edits live on the
mie branch). The notebook's IMPORTS all resolve on the mie branch, but if a run hits a per-photon/hit-mode
behavioral mismatch, reconcile by porting only the needed refactor-v2 reconstruction logic — do NOT blindly
overwrite simulator.py/sensor_response.py (would lose the mie engine work).

## ⚠️ API MISMATCH found (2026-06-03) — the real reconciliation point
Imports resolve, but BUILDING the simulator FAILS on the mie branch:
`setup_event_simulator(GEOM, Nphot, T, max_candidates_per_ray=4, K=7, is_data=False, hit_mode='per_photon', ...)`
→ `TypeError: Cylinder.configure_grid() got an unexpected keyword argument 'max_candidates_per_ray'`.
So the **geometry/simulator API diverged**: refactor-v2 added `max_candidates_per_ray` (and the ~359-line
simulator.py / ~288-line sensor_response.py changes) that the mie branch (`mie_scattering_implementation`) does
NOT have. To run the refactor-v2 reconstruction notebook here, reconcile one of:
  (a) PORT refactor-v2's reconstruction-relevant simulator.py / sensor_response.py / geometry (configure_grid)
      updates onto the mie branch, PRESERVING the mie-scattering engine edits (careful 3-way merge), or
  (b) ADAPT the notebook calls to the mie-branch API (drop/rename max_candidates_per_ray etc.) — quicker but
      may miss per-photon/grid behavior the NLL path needs, or
  (c) base reconstruction on `refactor-v2` directly and port the MIE engine into it instead (reverse direction).
Decision pending. Data download (`scripts/download_data.sh`: SIREN nets + PhotonSim tables) launched in background.

## DECISION (2026-06-03): direction (b) — adapt notebook to the mie branch; DiCE for sim, data-like for truth.

## DONE: data-like min(L_R,L_M) bug FIXED (`lucid/simulation/photon_step.py` photon_iteration_sample)
Two coupled bugs in the SAMPLING (data-like, is_data=True) path:
1. `scatter_length = jnp.minimum(scatter_length, mie_scatter_length)` → replaced with RATE combination
   `1/(1/L_R + 1/L_M)` (+ `p_mie = (1/L_M)/(1/L_R+1/L_M)`). min() underestimates scattering.
2. line ~106 ALWAYS used the Mie (forward-peaked) direction for every scatter (`scatter_dir` Rayleigh computed
   but unused). Now chooses Mie vs Rayleigh per scatter by `is_mie = uniform(k5) < p_mie` (~5% Mie at physical
   L_R=342/L_M=6770 ⇒ p_mie≈0.048). Split rng into 5 keys (added k5). Compiles + imports OK.
   (The EXPECTED-VALUE path photon_iteration_update_factors already combines correctly via 1/L_R+(1-g)/L_M
   transport approx — left unchanged; it's a different, intentional model.)
DATA NOW PRESENT: SIREN net `data/water/muon/siren_training/trained_model/`; event ROOT
`data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root`; photonsim_params.json, range_params.json, t0.json.

## Integration plan (remaining)
1. ADAPT notebook to the mie-branch API: `setup_event_simulator(... max_candidates_per_ray=4 ...)` fails →
   `Cylinder.configure_grid()` on the mie branch lacks that kwarg. Find the mie-branch grid-sizing API and
   drop/rename the kwarg in the notebook (or thread it through configure_grid). Keep the mie engine intact.
2. SIM via DiCE: replace the SIREN track source with the DTRAX/dtrax Cherenkov→LUCiD source
   (DTRAX `Cherenkov→LUCiD source BUILT+committed a6c9bfa`, emit `want="segments"` SegmentStream bridge);
   feed its differentiable rays into the per-photon (hit_mode='per_photon') prediction simulator for the time NLL.
3. TRUTH via data-like mode (now bug-fixed): generate observed (counts, first-arrival times) with the is_data
   simulator (hard min, make_hits_data).
4. Then run single-event time-NLL combined loss; iterate the reconstruction.

## ═══ DECISION SUPERSEDED (2026-06-03 pm): NO dtrax. PORT the implicit/DiCE step into LUCiD. ═══
User: "We take nothing from dtrax. everything is inside mie_hunter. We have our new photon step there."
The plan is **`mie_hunter/PORT_PLAN.md`**: port the implicit/DiCE hard-sample step (`mie_hunter/implicit_engine.py`,
+ per-photon-time `implicit_engine_lik.py`) INTO production `lucid/simulation/photon_step.py::photon_iteration_update_factors`,
replacing the soft-STE/`effective_ratio` step. The SAMPLE step `photon_iteration_sample` is ported to the SAME
analog two-channel physics (else truth≠prediction). Caveats: drop in-step QE (stays in make_hits — DON'T change
QE handling per user); pre-step `logp` in the implicit-capture deposit; keep `d`/`Dd` detached in the score so it
carries ONLY optical gradients; geometry LIVE for the pathwise track gradient.

### Gradient-estimator taxonomy (VALIDATED by `mie_hunter/toy_time_grad.py` + `toy_reparam_vs_score.py`)
- **Track params (t0, position, direction, energy)** → **PATHWISE** (they enter the deterministic SOURCE upstream of
  the randomness; cost is a smooth fn of them). Toy: pathwise grad matches finite-diff to **0.1%** even for a
  scatter-only sensor. NEITHER DiCE-score NOR free-path-reparam is needed for reconstruction.
- **Optical scatter-rate/angle (L_R, L_M, g)** → enter only through the random scatter decision:
  - discrete `is_scat`/Mie-Rayleigh Bernoulli → **DiCE = score/MagicBox** `exp(logp−sg(logp))` (B). The ONLY option.
  - continuous free-path length → arrival **time** → **reparameterization live-path** (C) `d_live=−log(u)/mu` live in mu.
    Chosen over scoring the time (B): toy shows score is **5–16× higher variance** and the gap GROWS with K (REINFORCE).
- **Decision (2026-06-03): include C** (reparam live-path) so the time also carries the optical gradient at low
  variance — for FUTURE optical+timing calibration. In production no new carry needed: `PhotonState.times` already
  accumulates the path; C = "use `d_live` in the time segment, detached `d` in position/decision".
- DiCE ≡ the score method (B). C (reparam) is NOT DiCE.

### Fixes LANDED this session (all on branch `reconstruction-mie`)
- `lucid/detector_params.py` `_project_missing_scalars`: `g`/`mie_scatter_length` were loaded **NaN** (configs omit
  them) → poisoned the expected-value step (`(1-g)/L_M`→NaN→zero charge+NaN grad) AND silently killed the truth
  path's ~5% Mie photons. FIX: project from medium when present (SK→g=0.95, L_M=9886), else default to **no-Mie**
  (`mie_scatter_length=1e9, g=0`) — never raise (scalar configs like EOS have no medium), never NaN.
- `lucid/losses.py::first_arrival_nll`: empty/degenerate-segment safety (floor −inf logsumexp terms) — a truth-hit
  sensor with no predicted photon gave inf−inf=NaN value AND poisoned the gradient (0·NaN). Now finite everywhere.
- `lucid/simulation/photon_step.py::photon_iteration_sample`: the min(L_R,L_M)→rate-combine + per-scatter Mie/Rayleigh
  fix (above).

### Port progress
- **Phase 1 DONE (mechanical log_p carry, no-op):** `PhotonState`+`PhotonStepResult` got `log_p`/`logp_increment`
  fields (`types.py`); scan body inits/accumulates `log_p` and unpacks the **7-tuple** step return (`simulator.py`);
  BOTH step fns return a 7th `logp_increment=0.0`; custom-VJP `_bwd` updated to 7 cotangents (`photon_step.py`).
  `lf+la=0` ⇒ provable no-op. END-TO-END `recon_e2e_test.py` PASSES (g-fix → time NLL now on 2576 sensors not 0;
  finite grads wrt energy/pos/theta). Fast test `test_pipeline_types.py` updated for the new fields.
- **Phase 2 NEXT:** port the diff-step physics (analog free path, Mie/Rayleigh, scores, implicit-capture deposit,
  live-path time C). Add `hg_logpdf`/`rayleigh_logpdf` to `lucid/wavelength/scattering.py`; shared
  `sample_scatter_event` helper.
- **Phase 3:** port `photon_iteration_sample` to the same physics (physics-only; give absorption its own key).
- **Phase 4:** re-baseline the SLOW physics tests (`test_photon_step_physics.py` etc. — already pre-broken: their
  `_base_args` lacks `mie_scatter_length`/`g`; AND Phase 2 changes the asserted physics) + MC-vs-expected parity +
  FD gradient check for g/L_R/L_M.

## ═══ SESSION 2026-06-03 (10h autonomous): gradient pathway FIXED, recon partially working ═══

### Port DONE + validated (Phases 1-3)
- Phase 1 (log_p carry, no-op), Phase 2 (implicit/DiCE step in photon_iteration_update_factors),
  Phase 3 (sample step same physics + absorption-key + make_hits_data time-gate fixes). Fast suite
  GREEN. MC-vs-expected parity = 0.9978 (unbiased). Files: photon_step.py, simulator.py, types.py,
  losses.py (first_arrival_nll empty-segment safety), detector_params.py (g/mie NaN projection fix),
  wavelength/scattering.py (hg_logpdf/rayleigh_logpdf), sensor_response.py.

### Gradient-estimator taxonomy (validated): for RECONSTRUCTION params (t0/pos/dir/energy)
- Track params enter the SOURCE upstream of randomness → PATHWISE (validated 0.1% toy). DiCE-score is
  for OPTICAL discrete decisions only; not needed for track gradient. (mie_hunter/toy_time_grad.py)

### THREE gradient leaks found + FIXED (each preserves the forward):
1. SIREN g/mie_scatter_length loaded NaN → poisoned the expected step. FIX: project from medium
   (detector_params.py). [[recon-g-mie-nan-loader-bug]]
2. **SIREN energy↔emission-geometry detached** (argsort top-k selection non-diff): energy only flowed
   through the weight, not which (angle,dist) bins. d(mean range)/dE AD=0 though profile moves.
   FIX (siren_rays.py, validated by 3 parallel agents + sample_methods.py): sample bins ∝ density via
   SYSTEMATIC resample + weight = density·DiCE-score (exp(logp-sg logp)) → correct gradient of the
   density-weighted forward; + FROZEN (E_CAL=1050, detached) occupancy scale to keep occupancy ~5072.
   Validated: occupancy [3523,5067,6593]@[800,1050,1300]MeV; d(charge)/dE AD/FD≈0.88 (was 1.85 wrong).
   1 SIREN call (was 2). Agents proved my "can't preserve forward AND fix gradient" assumption WRONG.
3. **Hard-overlap (temperature=None) kills charge→position gradient** (overlap_prob = step, d/d=0;
   pathwise misses the boundary-crossing term). FIX (overlap.py): STRAIGHT-THROUGH overlap — forward =
   hard step (occupancy byte-identical, NOT soft temperature), backward = smooth sigmoid surrogate.
   Result: charge grad-vs-truth cos 0.145→0.559; full loss gradient aligns 6/7 params (cos 0.71).

### LOSS findings (critical for recon — task #7):
- **counts_loss (poisson_nll) is normalized by sum(true)** → nearly scale-INVARIANT → barely constrains
  ENERGY (2× charge moves loss by 0.6). It's O(1) while first_arrival_nll is O(600) → charge IGNORED.
  FIX for recon: UN-normalized Poisson NLL ×100 (magnitude balance) → energy constraint restored.
- **first_arrival_nll's -log_w_total term rewards total photon count → pulls energy UP** unbounded.
- **t0 has a ~2ns systematic bias** = the soft-min/order-statistic-vs-hard-first-arrival bias
  (memory [[wc-smooth-loss-bias]] / softmin-time). tau_time is the lever.

### Recon status (recon_resolution.py, Adam, AD gradient, 50k photons, temperature=None):
- POSITION x,y → mm-cm (err 0.01-0.26 scale); z → 4-25cm. Direction polar OK, AZIM poor.
- ENERGY → ~150 MeV high (much better after charge fix; still pulled by time -log_w_total).
- t0 → ~2ns biased (soft-min). Single-event resolution is observable-limited (~0.5-1 PARAM_SCALE).
- The CRB oracle (crb_oracle.py) was UNRELIABLE (variance underestimate from SIREN upsampling + FD
  jumps → 0.3mm, vs actual ~cm-dm). Recompute with straight-through (smooth AD) Cov(g) at truth.

### Key scratch files (worktree root): recon_harness.py (predictor/truth/loss), recon_resolution.py
(Adam recon, LOSS=nll/gauss/fixedN, WC/WT/TAU env), recon_optimizer.py (GN-LM, FD Jacobian),
crb_oracle.py, sample_methods.py + mie_hunter agent test scripts, grad_hess_check.py,
diag_grad_direction.py, decompose_grad.py, toy_time_grad.py, toy_reparam_vs_score.py.

### NEXT (remaining): tune tau for t0 bias; decouple energy from first_arrival_nll's count term;
fix azim; recompute reliable CRB; multi-realization resolution + bias; multi-GPU LM optimizer polish.

## ═══ RECON WORKS — final resolution (recon_resolution.py, Adam, 50k photons, 5 realizations) ═══
Best single-stage config WT=0.03 TAU=4.0 (raw charge NLL x100 + first_arrival_nll):
  param   bias        resolution(std)
  x       -9 cm       8 cm
  y       ~0          11 cm
  z       -5 cm       7 cm
  polar   ~0          4 mrad     <- direction excellent
  azim    -12 mrad    18 mrad
  t0      +0.36 ns    0.39 ns    <- TAU=4.0 killed the soft-min bias (was -2.7ns @ TAU=1.5)
  energy  +113 MeV    34 MeV     <- the only biased param (time -log_w_total count-pull)
ENERGY fix = staged / charge-dominated: charge-only (WT=0) energy = 1052,1058 MeV (~exact) -> bias ~+33MeV(3%).
HP levers (task #7): WT controls energy bias (0.1->+144MeV, 0.03->+28..113); TAU controls t0 bias
(1.5->-2.7ns, 4.0->+0.2ns); charge MUST be raw Poisson NLL (counts_loss normalization kills energy).
Optimizer: Adam on AD gradient converges; recon_optimizer.py (GN-LM/FD-Jacobian) needs the raw-charge loss
(its mean-time residual diverges). RECOMMENDED next: 2-stage fit (charge->energy/pos, then +time->dir/t0)
and/or decouple first_arrival_nll's count term for an unbiased single-stage energy.

## ═══ FINAL: staged GN-LM recon works (recon_gnlm.py + recon_staged.py) ═══
Optimizer (task #8) = empirical-Fisher F=E[g g^T] + LM diag ridge + eigenvalue clip + Polyak (the
calibration GN-LM), on the TUNED loss (raw Poisson charge NLL x100 + first_arrival_nll), pure AD
gradient (DiCE sampler + straight-through overlap). Off-diagonal F^-1 handles param COUPLING.
TWO-STAGE (recon_staged.py) removes the energy count-pull bias:
  stage1 charge-dominated (WT=0) -> ENERGY (from charge) + rough pos/dir
  stage2 full (WT=0.03,TAU=4.0), FREEZE energy -> refine pos/dir/t0
Result (5 realizations): energy +40MeV(4%)/33MeV, x -8cm/10cm, y ~0/4cm, z ~0/9cm, polar ~0/6mrad,
azim -11mrad/8mrad, t0 +0.19ns/0.36ns. ALL 7 params ~unbiased. (Single-stage joint: energy +103MeV.)
Scratch: recon_gnlm.py (single-stage GN-LM), recon_staged.py (2-stage). Both Adam (recon_resolution.py)
and GN-LM give the same physics — the LOSS (raw NLL, WT, TAU, staging) is what determines the result,
not the optimizer. Remaining +40MeV energy = charge-only resolution (improve with photons / charge model).
