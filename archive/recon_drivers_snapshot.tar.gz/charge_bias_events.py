"""CHARGE-FORM BIAS vs SCATTER over MANY events. The single-event profile was misleading (event-0 luck);
the longitudinal argmin scatters 10-35cm event-to-event = the REAL per-event charge resolution under the
SIREN<->PhotonSim mismatch. This measures, per charge form, the MEAN argmin (BIAS) and STD (SCATTER) over
N independent PhotonSim events on the SAME target track.

Efficiency: the predicted mu(lambda) longitudinal grid is IDENTICAL for every event (same target track),
so it is computed ONCE; only the cheap observed charge Q_P is regenerated per event. pred + data_sim are
built ONCE (no per-event recompile). Env: NPHOT NKG NKT NEV NW.  Usage: CUDA_VISIBLE_DEVICES=g python charge_bias_events.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.geometry import generate_detector
np.set_printoptions(precision=3, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKG = int(os.environ.get('NKG', '3'))
NKT = int(os.environ.get('NKT', '4')); NEV = int(os.environ.get('NEV', '20')); NW = float(os.environ.get('NW', '1.34'))
ROOT = PS_ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '16')); EPS = 1e-6
TGT_VTX = np.array([0.0, 0.0, 0.0]); TGT_POL = 0.6; TGT_AZ = 0.8

def _rod(v, axis, ang):
    axis = axis/(np.linalg.norm(axis)+1e-12)
    return v*np.cos(ang) + np.cross(axis, v)*np.sin(ang) + axis*(axis@v)*(1-np.cos(ang))

def photon_data_for(event):
    """Replicate recon_ps_setup.setup's rotate/shift of one PhotonSim event onto the fixed target track."""
    raw = read_photon_data_from_photonsim(ROOT, event); n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins'])/100.0; Cc = P - P.mean(0)
    _, _, vt = np.linalg.svd(Cc, full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    proj = (P-P.mean(0))@d0; vtx0 = P.mean(0)+proj.min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    axis = np.cross(d0, dt)
    if np.linalg.norm(axis) < 1e-7: axis = np.array([1.0, 0, 0]); ang = 0.0
    else: ang = float(np.arccos(np.clip(d0@dt, -1, 1)))
    trans = TGT_VTX - _rod(vtx0, axis, ang)
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(axis/(np.linalg.norm(axis)+1e-12)), 'rotation_angle': jnp.array(ang),
          'apply_translation': True, 'translation_vector': jnp.array(trans)}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd, float(raw['energy'])

# build pred + data_sim ONCE (geometry-only; events differ only in photon_data passed at call time)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHOT)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True,
    particle='muon', wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(pred)
ts = np.array([1050.0, TGT_VTX[0], TGT_VTX[1], TGT_VTX[2], TGT_POL, TGT_AZ, 0.0])
det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(pol, az): return np.array([np.sin(pol)*np.cos(az), np.sin(pol)*np.sin(az), np.cos(pol)])
d_true = dvec(ts[4], ts[5]); c_axis = DP @ d_true
e_perp = np.cross(d_true, np.array([0, 0, 1.0])); e_perp /= np.linalg.norm(e_perp)

qof = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key)[3])
def mu_at(theta): return np.mean([np.array(qof(jnp.array(theta), jax.random.PRNGKey(1000+13*k))) for k in range(NKG)], 0)
dummy = H.theta_to_track(jnp.array(ts))
mu0 = mu_at(ts)

# scan grids + predicted means (ONCE) for longitudinal AND transverse
lam = np.unique(np.concatenate([np.arange(-1.5, 1.501, 0.04), np.arange(-0.1, 0.1001, 0.01)]))
def build(u, l): return ts + np.array([0, u[0]*l, u[1]*l, u[2]*l, 0, 0, 0])
MU = {'LON': np.stack([mu_at(build(d_true, l)) for l in lam]),
      'TRANS': np.stack([mu_at(build(e_perp, l)) for l in lam])}
print(f"# CHARGE-BIAS-EVENTS NEV={NEV} NPHOT={NPHOT} NKG={NKG} NKT={NKT} ND={ND}  {len(lam)} pts/axis  bright(mu0>10): {(mu0>10).sum()} PMTs", flush=True)

# charge-loss forms. mask = subset of PMTs (None=all). bright-core masks test the dim-halo-mismatch hypothesis.
M_ALL = mu0 > -1; M_Q2 = mu0 > 2.0; M_Q10 = mu0 > 10.0
def poisson(mask):
    def f(m, q): mc = np.clip(m[mask], EPS, None); return np.sum(mc - q[mask]*np.log(mc))
    return f
def L_sqrtmse(m, q):  return np.sum((np.sqrt(np.clip(m, 0, None))-np.sqrt(np.clip(q, 0, None)))**2)
def L_logmse(m, q):   return np.sum((np.log1p(np.clip(m, 0, None))-np.log1p(np.clip(q, 0, None)))**2)
def L_shape(m, q):    p = np.clip(m/(m.sum()+EPS), EPS, None); return -np.sum(q*np.log(p))
FORMS = [('POISSON', poisson(M_ALL)), ('SHAPE', L_shape), ('POIS_Q>2', poisson(M_Q2)),
         ('POIS_Q>10', poisson(M_Q10)), ('SQRTMSE', L_sqrtmse), ('LOGMSE', L_logmse)]

def argmin_cm(curve):
    j = int(np.argmin(curve)); lo = max(0, j-2); hi = min(len(lam), j+3)
    a, b, cc = np.polyfit(lam[lo:hi], curve[lo:hi], 2)
    return (-b/(2*a) if a > 0 else lam[j])*100

# per-event observed charge (mean over NKT detection keys) -> per-form argmin, per axis
amins = {ax: {n: [] for n, _ in FORMS} for ax in MU}
for ev in range(NEV):
    pd, _ = photon_data_for(ev)
    Q = np.mean([np.array(jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev+j), pd))[0]) for j in range(NKT)], 0)
    for ax in MU:
        for name, fn in FORMS:
            amins[ax][name].append(argmin_cm(np.array([fn(MU[ax][i], Q) for i in range(len(lam))])))
    print(f"#   ev{ev:2d}  LON " + "  ".join(f"{n}:{amins['LON'][n][-1]:+6.1f}" for n, _ in FORMS), flush=True)

for ax in MU:
    print(f"\n# {ax} vertex over {NEV} events: BIAS=mean  SCATTER=std  RMS=sqrt(bias^2+scatter^2)  [cm]", flush=True)
    print(f"#   {'FORM':10s} {'bias':>8s} {'scatter':>8s} {'RMS':>8s}", flush=True)
    for name, _ in FORMS:
        a = np.array(amins[ax][name]); print(f"#   {name:10s} {a.mean():+8.1f} {a.std():8.1f} {np.sqrt(a.mean()**2+a.std()**2):8.1f}", flush=True)
print(f"\n# TARGET: total vertex<15cm.  bright-core (POIS_Q>10) better than POISSON => the mismatch lives in the DIM scattered-light HALO.", flush=True)
