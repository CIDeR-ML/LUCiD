# PhotonSim-truth reconstruction: thorough analysis (gradients, loss surface, CRB, HP, overlap backward)

Truth = `is_data` simulator fed the event's **real PhotonSim Cherenkov photons** (SK geometry, 1050 MeV
muon, event 0). The track is rigidly **shifted + rotated** (via `photon_data` rotation/translation) to a
clean central, non-axial target (vertex (0,0,0), polar 0.6, azim 0.8) to avoid the near-axial degeneracy
and wall edge of the raw event. Predictor = SIREN+DiCE expected per-photon simulator.
Scripts: `recon_ps_setup.py` (setup + `make_loss`), `loss_surface_photonsim.py`, `grad_crb_photonsim.py`,
`ring_compare.py`, `emission_diag.py`, `tau_scan.py`, `surrogate_evidence.py`, `recon_ps_run.py`.

## UPDATE (post-overlap-fix + explicit decomposition) — read §7,§8 first
After switching the predictor to the **temp=0.1 soft overlap** (honest gradient, §6) and adding **TAU
annealing**, the self-consistent recon reaches **vertex 3.6 cm, dir 0.18°, t0 0.4 ns** (§7). On real
PhotonSim, an **explicit channel-by-channel decomposition** (§8) overturned the "irreducible model
mismatch" reading below: the gradients are honest vs FD on PhotonSim (charge 0.99, time 0.999, full
0.996), and **given the correct energy the vertex recovers to ~6–18 cm and the direction to ~0.1°** — so
neither is model-walled. **The single blocker is the ENERGY**: the per-sensor charge NLL is +15.7 % at the
true vertex (the sharp SIREN ring forces it up to fill the data's wider ring), while the **shape-robust
total charge is only +1.8 %**. The residual is the energy↔vertex coupling, not the gradient/optimizer.

## TL;DR (original first pass — partially superseded by §8)
- **The reconstruction machinery is correct.** Self-consistent control (truth = the SIREN model itself)
  recovers vertex ~25 cm (→3.6 cm after the temp=0.1 + annealing fix), direction ~0.2°, t0 sub-ns.
- **The dominant limit against real PhotonSim data is a SIREN-vs-PhotonSim emission-model mismatch**, not
  the optimizer. SIREN's Cherenkov ring is too sharp: at equal total charge the real light spreads over
  **2271 sensors vs SIREN's 836** (radial width 2.37 m vs 1.87 m). This biases the charge fit's vertex by
  ~0.5–1 m and energy by +(4–14)%. No loss hyperparameter removes it.
- **Direction (polar) is robust and unbiased**; it is the one parameter decoupled from the
  energy↔vertex↔t0 axial degeneracy (Fisher correlations 0.8–0.98 among those four; polar ~0).
- **Overlap backward (the user's question): the hard-step + sigmoid straight-through surrogate is a poor
  gradient** (magnitude ~15% of the true finite-difference gradient; wrong sign at truth). The
  **soft overlap weight at temperature 0.1** (Gaussian-acceptance integral, consistent forward/backward)
  is far better: AD↔FD cosine 0.96–0.999, magnitude 76–85%, correct sign, forward occupancy preserved
  (Σq ratio 0.955–0.977). Pure-hard with **no** backward smoothing has essentially **zero** charge→position
  gradient (recon fails even self-consistently: vertex 120–139 cm). ⇒ some pathwise overlap smoothing is
  structurally required; **temp=0.1 is the right one, the sigmoid is not.**

## 1. Loss-surface scans (around PhotonSim truth, full loss WT=0.03 TAU=4, noise ~5)
| param | argmin (bias) | curvature | note |
|---|---|---|---|
| energy | +150 MeV (+14%) | shallow | charge-driven; charge wants +138, time wants −124 |
| x | +0.60 m | real | charge-driven |
| y | **−0.66 m** | real | charge-driven, **no WT/TAU removes it** |
| z | −0.55 m | shallow/noisy | charge/time tug |
| polar | **~0** | sharp | **unbiased, well-constrained** |
| azim | −0.07 rad (−4°) | sharp | small stuck bias |
| t0 | +2.6 ns | — | time-driven (soft first-arrival) |

WT scan (analytic, `full = C + WT·T`): energy bias crosses 0 near WT≈0.2 (charge↔time cancellation), but
y stays −0.66 m and azim −0.08 rad for **all** WT — a ~1 m vertex floor. TAU scan: smaller TAU reduces the
t0 bias (+1.1 ns at TAU=1.5 vs +2.7 ns at TAU=4); y/vertex are TAU-independent.

## 2. Source mismatch (root cause), `ring_compare.py` / `emission_diag.py`
At the same true track, realistic sampling:
- PhotonSim: **2271 sensors**, 2.22 PE/hit, participation 979, ring radial width **2.37 m**.
- SIREN:     **836 sensors**, 6.16 PE/hit, participation 338, ring radial width **1.87 m**.
- Total yield matches (ratio 0.985); longitudinal profile roughly right but the real ring extends further
  (obs/pred = 0.51 at s≈+22 m). The ROOT file has **no per-photon wavelengths** — the real photon
  *directions* already bake in Geant4 chromatic dispersion + muon multiple scattering, which SIREN
  under-models. This radial-width deficit is the charge vertex/energy bias.

## 3. Gradient quality (AD vs finite-difference), `grad_crb_photonsim.py`
- t0 and energy gradients: AD≈FD (ratio ~1.0). Spatial params (x,y,azim,polar): the **straight-through
  sigmoid** AD is directionally OK at the loss-min (cosine 0.86) but ~3–6× too small; at truth it can
  sign-flip (x: AD +0.66 vs FD −3.73). See §6 for the fix.
- Descent points to the (source-mismatch-biased) loss minimum, not to truth — by design, not a bug.

## 4. CRB / Fisher (empirical F=E[gg^T] at truth)
Per-param CRB σ (80k photons): energy 80 MeV, x/y/z 0.50/0.54/0.42 m, polar 0.026 rad, azim 0.033 rad,
t0 1.9 ns. **These are inflated by an extreme energy↔vertex↔t0↔azim degeneracy** (|corr| 0.8–0.98); only
polar is decoupled (corr ~0). cond(F)≈2.3e3. The systematic biases are ~1–2.4σ of these statistical σ —
real, and not removable by collecting more light (they are model-systematic, not statistical).

## 5. Achievable reconstruction (staged GN-LM: charge→energy, then time→pos/dir/t0 with energy frozen)
| truth | overlap | energy | vertex | direction | t0 |
|---|---|---|---|---|---|
| self-consistent (SIREN) | temp=0.1 soft | +4.1% | **25±4 cm** | **0.2°** | sub-ns |
| **PhotonSim (real)** | temp=0.1 soft | +9% | **49±20 cm** | **1.4°** | ~0 ns |
| PhotonSim (real) | sigmoid straight-through | +11% | ~56 cm | 1.9° | ~0 ns |

Decomposition of the PhotonSim residual: ~25 cm / +4% is the self-consistent floor (axial degeneracy +
an expected-vs-realistic charge normalization), and the source mismatch adds ~+25 cm / +5% / +1.2°.

## 6. Overlap backward pass — evidence (`surrogate_evidence.py`), the user's question
Arbiter = charge-only gradient vs central finite-difference (FD), self-consistent (true gradient at truth
= 0; from a +0.8 m offset the gradient must be restoring and match FD).

| overlap backward | cos(AD,FD) off-min | magnitude AD/FD | self-consistent recon vertex |
|---|---|---|---|
| pure hard (no smoothing) | 0.10–0.23 | ~0 (no gradient) | **120–139 cm (fails)** |
| hard + sigmoid straight-through (0.2) | 0.88–0.98 | 0.15–0.17 | 17–36 cm |
| **soft overlap weight, temp=0.1** | **0.98–0.999** | **0.76–0.85** | **20–31 cm** |

Why: the vertex enters charge **only through geometric propagation → overlap**; a hard step has zero
gradient and the SIREN emission density is translation-invariant in the track frame, so DiCE's score
carries no vertex information (there is no sampled variable at the overlap to score). A pathwise smoothing
is therefore required. The sigmoid straight-through uses a *forward-hard / backward-soft* mismatch that
cripples and can sign-flip the gradient; the **temp=0.1 Gaussian overlap is consistent fwd/bwd**, honest
(matches FD), and keeps the forward occupancy. **Recommendation: use temp=0.1 soft overlap for recon, not
the sigmoid.** (Code knob: predictor `temperature=0.1`; `lucid/overlap.py` `ST_WIDTH_FRAC` env added only
for the diagnostic.)

## Open items / next levers
- Push below the floors requires fixing the **source model** (broaden SIREN's ring: chromatic Cherenkov +
  multiple-scattering angular spread) — the charge systematic, not the optimizer.
- The ~+4% self-consistent energy is an expected-value-vs-realistic-sampling normalization (calibratable).
- Timing is the untapped lever for the axial degeneracy (all charge work saturates on it).

## 7. temp=0.1 soft overlap + TAU annealing — the recon METHOD now reaches few-cm self-consistently
Switching the predictor to `temperature=0.1` (soft Gaussian overlap, §6) gives an honest gradient. The
time loss `first_arrival_nll(tau)` plus a **sensor charge THReshold** (only sensors with obs charge ≥ THR
contribute a first-arrival time — low-occupancy times are noisy) are the time knobs the user flagged.
HP sweep (self-consistent, 8 seeds, staged charge→energy then time):
- **smaller TAU sharply improves the vertex** (TAU 0.3→13 cm, 1.5→27 cm); truth has no time smearing so a
  sharp kernel is well-posed. THR≈4 helps. Direction stays 0.1–0.2° throughout.
- single-TAU fits left an occasional degenerate-axis outlier (seed scatter to ~25 cm). **TAU ANNEALING**
  (2→1→0.5→0.3→0.2, each a GN-LM block) removes the outliers (global basin → sharp precision).
- Best self-consistent (temp=0.1, THR=4, anneal): **vertex 3.6±3.0 cm (median 2.0), dir 0.18°, t0 0.4 ns,
  E +4.1 %** (the +4 % is the expected-vs-realistic charge normalization, common-mode/calibratable).
Scripts: `hp_sweep.py`, `recon_robust.py`.

## 8. EXPLICIT channel decomposition on PhotonSim — energy is the blocker, NOT a vertex/dir model wall
(`explicit_check.py`, `iterate_test.py`, `iterate2.py`, `decisive.py`, `final_recipe.py`.)
Gradient honesty at truth (AD/DiCE vs central FD), temp=0.1, sharp HP:
| channel | cosine(AD,FD) on PhotonSim |
|---|---|
| charge | 0.990 |
| time   | 0.999 |
| full   | 0.996 |
=> the gradient is **honest** on real data. The full-loss minimum *is* offset from truth (init-at-truth
drifts to 56 cm), but the explicit decomposition localizes it:
- **Given the correct energy (frozen at truth), bad init:** full annealed loss → **vertex 6–18 cm**;
  time-only → **direction 0.04–0.16°**. So vertex and direction are *recoverable* — not model-walled.
- **Energy is the blocker.** With pos/dir frozen at truth, the per-sensor charge NLL fits **E = +15.7 %**
  (the sharp SIREN ring concentrates light on 836 vs the data's 2271 sensors; the optimizer inflates
  energy to fill the wider data ring). The **shape-robust TOTAL charge gives E = +1.8 %** at the true
  vertex — the per-sensor Poisson likelihood, not the total yield, is what the ring-shape mismatch
  corrupts.
- **Residual difficulty = energy↔vertex coupling.** total-charge E is +1.8 % only at the true vertex but
  ~+10 % at a 30–50 cm-off vertex, so a cold-start alternation (total-charge E ↔ full-loss vertex) lands
  in a biased basin (~30 cm / +10 %) rather than the truth basin (~12 cm / +1.8 %). This is the open item,
  not the gradient or the SIREN time model.

### Corrected conclusion
The earlier "irreducible SIREN emission mismatch" reading was wrong as a recon verdict. The SIREN forward
*does* mis-shape the ring, but that only corrupts the **per-sensor charge energy estimate**; the gradients
are honest and the time model matches the data (truth is a time-min; dir→0.1°, vertex→~12 cm given E).
Path to good real-data recon: a **shape-robust / total-charge energy** decoupled from the per-sensor ring
shape, fed into the honest time-driven direction + vertex — breaking the energy↔vertex basin (better
geometric vertex init, or transverse-charge + longitudinal-time split) is the remaining work.
