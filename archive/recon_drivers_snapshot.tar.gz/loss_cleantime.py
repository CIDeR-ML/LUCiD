"""CLEAN time loss (Form 2) — predicted first-arrival vs observed first-arrival, Gaussian/robust, width~TTS,
charge-THRESHOLDED. Tests whether a PHYSICAL time loss (not the order-stat first_arrival_nll) is UNBIASED,
so the bias proof isn't contaminated by a bad loss.

predicted first-arrival per PMT = charge-weighted soft-min of predicted photon times (temperature SOFT~TTS):
   that_i = -SOFT * (logsumexp_i(log_w - t/SOFT) - logsumexp_i(log_w))
time loss = sum_{hit & charge>THR} rho((t_obs - that - t0)/SIGMA),  rho = gauss or huber(delta)
Truth carries realistic TTS (env TTS_NS, set BEFORE import). Charge term = Poisson (unbiased backbone).
Per-event argmin for x, energy vs THR. K=8, MAXCELL=16.
Env: TTS_NS NPHOT NKEYS NEV SOFT SIGMA RHO WC.  Usage: CUDA_VISIBLE_DEVICES=g TTS_NS=2.5 python loss_cleantime.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')   # set BEFORE lucid import
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import segment_logsumexp, poisson_nll
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '16')); NEV = int(os.environ.get('NEV', '12'))
SOFT = float(os.environ.get('SOFT', '2.5')); SIGMA = float(os.environ.get('SIGMA', '2.5')); RHO = os.environ.get('RHO', 'gauss')
WC = float(os.environ.get('WC', '1.0')); K = 8; PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
print(f"# CLEAN time loss  TTS={os.environ['TTS_NS']} NPH={NPH} NKEYS={NKEYS} NEV={NEV} SOFT={SOFT} SIGMA={SIGMA} RHO={RHO} WC={WC} K={K} MC={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH, apply_smearing=False)
ND = H.num_detectors(pred); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def make_clean_loss(oc, ot, hitm, THR):
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hitm = jax.lax.stop_gradient(hitm)
    def loss(theta, key):
        log_w, flat_times, flat_idx, total_charge = pred(H.theta_to_track(theta), key)
        num = segment_logsumexp(log_w - flat_times / SOFT, flat_idx, ND)
        den = segment_logsumexp(log_w, flat_idx, ND)
        that = -SOFT * (num - den)                                  # predicted first-arrival per PMT
        r = (ot - theta[6] - that) / SIGMA
        if RHO == 'huber':
            d = 1.345; rho = jnp.where(jnp.abs(r) <= d, 0.5 * r**2, d * (jnp.abs(r) - 0.5 * d))
        else:
            rho = 0.5 * r**2
        usable = hitm & (oc > THR) & jnp.isfinite(that)
        time = jnp.sum(jnp.where(usable, rho, 0.0))
        charge = jnp.sum(poisson_nll(oc, total_charge))
        return WC * charge + time
    return loss

def argmin(lj, i, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts)
    c = np.array([np.mean([float(lj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

for THR in [0.0, 3.0, 8.0]:
    bx, be = [], []
    for ev in range(NEV):
        oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(5000 + ev))
        lj = jax.jit(make_clean_loss(oc, ot, hit, THR))
        bx.append(argmin(lj, 1)); be.append(argmin(lj, 0))
    bx, be = np.array(bx), np.array(be)
    print(f"#  THR={THR:4.0f}: x bias {bx.mean():+.3f} m std {bx.std():.3f} | energy bias {be.mean():+6.1f} MeV std {be.std():.1f}", flush=True)
print(f"# READ: if clean first-arrival loss (esp. with THR) is UNBIASED (x bias ~ charge's 0.15m floor) ->", flush=True)
print(f"#   the -0.58m was the ORDER-STAT loss being bad (dim-PMT first-arrival + N_s amplification), not physics.", flush=True)
