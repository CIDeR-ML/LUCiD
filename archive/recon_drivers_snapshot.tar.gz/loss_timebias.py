"""TIME-BIAS DECOMP — find which part of the loss biases the vertex/energy.

Skeptical decomposition at the PHYSICAL config (K=8, MAXCELL=16). Splits the loss into:
  charge      = poisson_nll(obs, pred)  (NORMALIZED -> O(1))
  t_count     = sum -log_w_total        (order-stat count term, rewards charge)
  t_density   = sum -log_f              (logistic-kernel density at t_obs)
  t_tail      = sum -(N_s-1)*log(1-F)   (order-stat tail, amplified by occupancy N_s)
Reports each term's MAGNITUDE at theta_true (scale mismatch) and its per-param ARGMIN offset (which term
biases). Profiles x, z, energy. Truth MEAN over NTRUTH realizations (charge + first-arrival time).
Env: NPHOT NKEYS NTRUTH TAU.  Usage: CUDA_VISIBLE_DEVICES=g python loss_timebias.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.losses import segment_logsumexp, poisson_nll
np.set_printoptions(precision=4, suppress=True, linewidth=160)
os.environ.setdefault('MAXCELL', '16')
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '24'))
NTRUTH = int(os.environ.get('NTRUTH', '48')); TAU = float(os.environ.get('TAU', '1.5'))
K = 8; PS = np.asarray(H.PARAM_SCALE); PN = H.PARAM_NAMES
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
print(f"# TIME-BIAS DECOMP  NPH={NPH} NKEYS={NKEYS} NTRUTH={NTRUTH} TAU={TAU} K={K} MAXCELL={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)
cs, tsa = [], []
for s in range(NTRUTH):
    c, t = jax.lax.stop_gradient(tsim(H.theta_to_track(jnp.asarray(theta_true)), jax.random.PRNGKey(10000 + s)))
    cs.append(np.asarray(c)); tsa.append(np.where(np.asarray(c) > 0, np.asarray(t), np.nan))
oc = jnp.asarray(np.mean(cs, 0)); hitm = jnp.asarray(np.mean(cs, 0) > 1e-6)
ot = jnp.asarray(np.nan_to_num(np.nanmean(np.where(np.array(cs) > 0, np.array(tsa), np.nan), 0)))

def time_terms(theta, key):
    log_w, flat_times, flat_idx, total_charge = pred(H.theta_to_track(theta), key)
    t_obs = (ot - theta[6])[flat_idx]
    xx = (t_obs - flat_times) / TAU
    valid = log_w > -20.0; slw = jnp.where(valid, log_w, -1e6)
    lwt = segment_logsumexp(slw, flat_idx, ND); lwn = slw - lwt[flat_idx]
    log_k = jax.nn.log_sigmoid(xx) + jax.nn.log_sigmoid(-xx) - jnp.log(TAU)
    log_f = segment_logsumexp(lwn + log_k, flat_idx, ND)
    log_1mF = segment_logsumexp(lwn + jax.nn.log_sigmoid(-xx), flat_idx, ND)
    FL = -60.0; empty = lwt <= (FL + 1.0)
    lwt_s = jnp.maximum(lwt, FL); lf_s = jnp.maximum(log_f, FL); l1_s = jnp.maximum(log_1mF, FL)
    N_s = jnp.exp(jnp.clip(lwt_s, FL, 50.0))
    g = lambda v: jnp.sum(jnp.where(empty | (~hitm), 0.0, v))
    return g(-lwt_s), g(-lf_s), g(-(N_s - 1) * l1_s), jnp.sum(poisson_nll(oc, total_charge))
ttj = jax.jit(time_terms); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def mean_terms(theta):
    r = np.mean([np.array([float(v) for v in ttj(jnp.asarray(theta), k)]) for k in keys], 0)
    return dict(t_count=r[0], t_density=r[1], t_tail=r[2], charge=r[3])

base = mean_terms(theta_true)
print(f"# MAGNITUDE @theta_true: charge {base['charge']:.3f} | t_count {base['t_count']:.1f} | "
      f"t_density {base['t_density']:.1f} | t_tail {base['t_tail']:.1f}  (time terms >> charge => scale mismatch)", flush=True)

def argmin_each(i):
    sv = np.linspace(-4 * PS[i], 4 * PS[i], 17); curves = {k: [] for k in ['charge', 't_count', 't_density', 't_tail', 'time_all']}
    for s in sv:
        d = mean_terms(theta_true + s * np.eye(7)[i])
        for k in ['charge', 't_count', 't_density', 't_tail']: curves[k].append(d[k])
        curves['time_all'].append(d['t_count'] + d['t_density'] + d['t_tail'])
    out = {}
    for k, c in curves.items():
        c = np.array(c); j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(len(sv), j + 3)
        a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2); out[k] = (-b / (2 * a) if a > 0 else sv[j])
    return out

for nm, i in [('x', 1), ('z', 3), ('energy', 0)]:
    o = argmin_each(i); u = {'x': 'm', 'z': 'm', 'energy': 'MeV'}[nm]
    print(f"# argmin offset {nm:6s}[{u}]: charge {o['charge']:+.4f} | t_count {o['t_count']:+.4f} | "
          f"t_density {o['t_density']:+.4f} | t_tail {o['t_tail']:+.4f} | time_all {o['time_all']:+.4f}", flush=True)
print(f"# READ: the sub-term whose argmin is far from 0 (and dominates the magnitude) = the bias source.", flush=True)
