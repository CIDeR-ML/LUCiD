"""CHARGE-TERM FORMS: profile likelihood (BIAS + curvature) for several charge-loss forms, along THREE
axes (longitudinal / transverse vertex, energy), under BOTH truths -- to thoroughly understand the
information vs the model-mismatch bias and how the loss form controls it.

Forms L_charge(mu, Q) over per-PMT predicted mean mu_i and observed Q_i:
  POISSON   sum_i [mu_i - Q_i log mu_i]                     (MLE; Fisher = Poisson CRB; 1/mu weights the ring EDGE)
  SQRTMSE   sum_i (sqrt(mu_i)-sqrt(Q_i))^2                  (variance-stabilized: near-uniform PMT weights)
  ANSCOMBE  sum_i (sqrt(mu_i+3/8)-sqrt(Q_i+3/8))^2         (Anscombe; stable at mu->0)
  LOGMSE    sum_i (log1p(mu_i)-log1p(Q_i))^2               (relative / multiplicative)
  SHAPE     -sum_i Q_i log(mu_i/sum mu)                      (scale-invariant Poisson; energy removed) = old lS
  CENTROID  ((cen_mu-cen_Q).e)^2  [ref]    TOTAL ((sum mu-sum Q)/sum Q)^2 [ref]

Truths: Q_SIREN = mu(truth) self-consistent (loss-form intrinsic bias only); Q_PHOTON = mean PhotonSim
charge (real photons + SIREN model => + model-mismatch bias). Env: NPHOT NKG NKT EVENT NW.
Usage: CUDA_VISIBLE_DEVICES=g EVENT=0 python charge_forms.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import recon_ps_setup as PS, recon_harness as H
from lucid.geometry import generate_detector
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKG = int(os.environ.get('NKG', '3'))
NKT = int(os.environ.get('NKT', '4')); EVENT = int(os.environ.get('EVENT', '0')); NW = float(os.environ.get('NW', '1.34'))
EPS = 1e-6

S = PS.setup(event=EVENT, nphot=NPHOT, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']
det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(pol, az): return np.array([np.sin(pol)*np.cos(az), np.sin(pol)*np.sin(az), np.cos(pol)])
d_true = dvec(ts[4], ts[5]); c_axis = DP @ d_true
e_perp = np.cross(d_true, np.array([0, 0, 1.0])); e_perp /= np.linalg.norm(e_perp)   # a transverse unit dir

qof = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key)[3])
def mu_at(theta):
    return np.mean([np.array(qof(jnp.array(theta), jax.random.PRNGKey(1000+13*k))) for k in range(NKG)], 0)

mu0 = mu_at(ts); Q_S = mu0.copy()
Q_P = np.mean([np.array(regen(tk)[0]) for tk in range(NKT)], 0)
print(f"# CHARGE-FORMS EVENT={EVENT} NPHOT={NPHOT} NKG={NKG} NKT={NKT} ND={ND}  sum mu0={mu0.sum():.0f} sum Q_PS={Q_P.sum():.0f} (ratio {Q_P.sum()/mu0.sum():.3f})", flush=True)

def L_poisson(m, q):  mc = np.clip(m, EPS, None); return np.sum(mc - q*np.log(mc))
def L_sqrtmse(m, q):  return np.sum((np.sqrt(np.clip(m, 0, None))-np.sqrt(np.clip(q, 0, None)))**2)
def L_anscombe(m, q): return np.sum((np.sqrt(m+0.375)-np.sqrt(q+0.375))**2)
def L_logmse(m, q):   return np.sum((np.log1p(np.clip(m, 0, None))-np.log1p(np.clip(q, 0, None)))**2)
def L_shape(m, q):    p = np.clip(m/(m.sum()+EPS), EPS, None); return -np.sum(q*np.log(p))
def L_centroid(m, q): return ((m@c_axis)/(m.sum()+EPS)-(q@c_axis)/(q.sum()+EPS))**2 * 1e4
def L_total(m, q):    return ((m.sum()-q.sum())/(q.sum()+EPS))**2 * 1e4
FORMS = [('POISSON', L_poisson), ('SQRTMSE', L_sqrtmse), ('ANSCOMBE', L_anscombe),
         ('LOGMSE', L_logmse), ('SHAPE', L_shape), ('CENTROID', L_centroid), ('TOTAL', L_total)]

# axes: (name, theta-delta builder lambda l -> dtheta(7), grid in native units, unit label, cm-per-unit for reporting)
AXES = {
    'LON':   (lambda l: np.array([0, d_true[0]*l, d_true[1]*l, d_true[2]*l, 0, 0, 0]),
              np.unique(np.concatenate([np.arange(-2, 2.001, 0.04), np.arange(-0.1, 0.1001, 0.01)])), 'cm', 100.0),
    'TRANS': (lambda l: np.array([0, e_perp[0]*l, e_perp[1]*l, e_perp[2]*l, 0, 0, 0]),
              np.unique(np.concatenate([np.arange(-1, 1.001, 0.04), np.arange(-0.1, 0.1001, 0.01)])), 'cm', 100.0),
    'ENERGY': (lambda l: np.array([l, 0, 0, 0, 0, 0, 0]), np.arange(-300, 300.1, 15.0), 'MeV', 1.0),
}

def argmin_sigma(lam, curve):
    j = int(np.argmin(curve)); lo = max(0, j-2); hi = min(len(lam), j+3)
    a, b, cc = np.polyfit(lam[lo:hi], curve[lo:hi], 2)
    x0 = -b/(2*a) if a > 0 else lam[j]; sig = (1.0/np.sqrt(2*a)) if a > 0 else np.inf
    return x0, sig

ALL = {}
for axname, (build, lam, unit, conv) in AXES.items():
    MU = np.stack([mu_at(ts + build(l)) for l in lam])
    print(f"\n# AXIS={axname}  argmin(BIAS) & sigma  [{unit}]   ({len(lam)} pts)", flush=True)
    print(f"#   {'FORM':9s} | {'SIREN bias':>11s} {'sig':>7s} | {'PhotonSim bias':>14s} {'sig':>7s}", flush=True)
    ax_res = {}
    for name, fn in FORMS:
        cS = np.array([fn(MU[i], Q_S) for i in range(len(lam))]); cP = np.array([fn(MU[i], Q_P) for i in range(len(lam))])
        aS, sS = argmin_sigma(lam, cS); aP, sP = argmin_sigma(lam, cP)
        ax_res[name] = (lam, cS, cP, aS, sS, aP, sP)
        print(f"#   {name:9s} | {aS*conv:8.1f}{unit:>3s} {sS*conv:7.2f} | {aP*conv:11.1f}{unit:>3s} {sP*conv:7.2f}    SUMMARY ev={EVENT} ax={axname} {name} {aS*conv:.2f} {aP*conv:.2f}", flush=True)
    ALL[axname] = ax_res

# plot LON + TRANS for the 6 physical forms
forms_plot = ['POISSON', 'SQRTMSE', 'ANSCOMBE', 'LOGMSE', 'SHAPE', 'CENTROID']
fig, axes = plt.subplots(2, 6, figsize=(26, 8))
for r, axname in enumerate(['LON', 'TRANS']):
    for c, name in enumerate(forms_plot):
        lam, cS, cP, aS, sS, aP, sP = ALL[axname][name]; ax = axes[r, c]; x = lam*100
        ax.plot(x, cS-cS.min(), 'b-', lw=1.3, label=f'SIREN ({aS*100:+.0f},σ{sS*100:.1f})')
        ax.plot(x, cP-cP.min(), 'r-', lw=1.3, label=f'PhotonSim ({aP*100:+.0f},σ{sP*100:.1f})')
        ax.axvline(0, color='k', ls=':', lw=0.7); ax.axvline(aP*100, color='r', ls='--', lw=0.7)
        ax.set_title(f'{axname} {name}', fontsize=9); ax.legend(fontsize=6); ax.set_xlabel('shift (cm)')
        ax.set_ylim(-0.05*max((cP-cP.min()).max(), 1e-9), np.percentile(cP-cP.min(), 96))
plt.suptitle(f'Charge-form profile likelihood EVENT={EVENT} (blue=self-consistent, red=PhotonSim; truth=0). bias(cm) in legend', fontsize=12)
plt.tight_layout(); fn = f'charge_forms_ev{EVENT}.png'; plt.savefig(fn, dpi=100, bbox_inches='tight')
print(f"\n# saved {fn}", flush=True)
