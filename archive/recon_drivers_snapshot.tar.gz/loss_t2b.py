"""TIER 2b — decompose the forward TIME mismatch: SOFT overlap (temp=0.1, needed for gradients) vs
IMPLICIT-CAPTURE late-photon weighting. Compare the model first-arrival mean under TWO predictors:
  P_soft  = temp=0.1  (the one the loss uses; gradient-enabling)
  P_hard  = temp=None (hard overlap, same expected-value engine otherwise) == sample's geometry
against the SAMPLE engine (temp=None, realistic). Per occupancy bucket, dt = <t>model - <t>sample.
  If P_hard dt ~ 0 (global)  => the soft overlap (temp=0.1) is the WHOLE cause -> the gradient smoothing
                                introduces the timing bias (fix: build R(t) from a temp=None forward).
  If P_hard dt still varies   => implicit-capture late-photon weighting is the cause (soft overlap secondary).
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t2b.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '40'))
K = 8; MC = 16; SIGMA = 2.5; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
print(f"# T2b SOFT(0.1) vs HARD(None) overlap  NPH={NPH} NREAL={NREAL}", flush=True)
trk = sc2track(jnp.asarray(th9_true))
ND = None

def model_first_arrival(log_w, ft, fi, nd):
    w = jnp.exp(jnp.clip(log_w, -60, 20))
    tg = jnp.asarray(np.linspace(float(np.nanpercentile(np.asarray(ft), 0.05)) - 15, float(np.nanpercentile(np.asarray(ft), 99.95)) + 40, 800))
    Rg = jax.lax.map(lambda t: jax.ops.segment_sum(w * 0.5 * (1.0 + erf((t - ft) / (SIGMA * SQ))), fi, num_segments=nd), tg)
    S = jnp.exp(-Rg); f = jnp.clip(-jnp.gradient(S, axis=0), 0.0, None); Z = jnp.sum(f, axis=0)
    tm = jnp.where(Z > 1e-6, jnp.sum(tg[:, None] * f, axis=0) / jnp.maximum(Z, 1e-6), jnp.nan)
    return np.asarray(tm)

# two predictors
P_soft = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(P_soft)
P_hard = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=True,
    hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True,
    particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)

lw_s, ft_s, fi_s, tot_s = [a for a in jax.lax.stop_gradient(P_soft(trk, jax.random.PRNGKey(0)))]
lw_h, ft_h, fi_h, tot_h = [a for a in jax.lax.stop_gradient(P_hard(trk, jax.random.PRNGKey(0)))]
mu_s = np.asarray(tot_s); mu_h = np.asarray(tot_h)
tm_soft = model_first_arrival(lw_s, ft_s, fi_s, ND)
tm_hard = model_first_arrival(lw_h, ft_h, fi_h, ND)

# sample engine
sc = np.zeros((NREAL, ND)); st_ = np.full((NREAL, ND), np.nan)
for r in range(NREAL):
    c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r)))
    c = np.asarray(c); sc[r] = c; st_[r] = np.where(c > 0, np.asarray(t), np.nan)
samp_tm = np.nanmean(st_, 0); samp_ct = sc.mean(0)
print(f"#  total mu  soft={mu_s.sum():.0f} hard={mu_h.sum():.0f} sample={samp_ct.sum():.0f}", flush=True)

edges = [0.05, 0.2, 0.5, 1.0, 2.0, 100]
g_soft = np.nanmedian((tm_soft - samp_tm)[mu_s > 1e-6]); g_hard = np.nanmedian((tm_hard - samp_tm)[mu_h > 1e-6])
print(f"#  GLOBAL median dt(model-sample): soft {g_soft:+.3f} ns   hard {g_hard:+.3f} ns", flush=True)
print(f"#  occ-bucket | Npmt | dt_soft | resid_soft | dt_hard | resid_hard  (dt = <t>model-<t>sample, ns)", flush=True)
for lo, hi in zip(edges[:-1], edges[1:]):
    sel = np.where((mu_s > lo) & (mu_s <= hi))[0]
    if sel.size == 0: continue
    ds = (tm_soft - samp_tm)[sel]; dh = (tm_hard - samp_tm)[sel]
    ds, dh = np.nanmean(ds), np.nanmean(dh)
    print(f"#  {lo:4.2f}-{hi:<5.2f}| {sel.size:5d} | {ds:+7.3f} | {ds-g_soft:+7.3f} | {dh:+7.3f} | {dh-g_hard:+7.3f}", flush=True)
print(f"# READ: if HARD resid ~FLAT 0 => soft overlap(temp=0.1) causes the timing bias (gradient smoothing).", flush=True)
print(f"#       if HARD resid still VARIES => implicit-capture late-photon weighting is the cause.", flush=True)
