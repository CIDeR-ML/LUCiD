"""Robust temp=0.1 staged recon with TAU ANNEALING to kill the degenerate-axis outliers.
Stage 1: charge -> energy + rough vertex/dir.
Stage 2: time-annealed -- TAU schedule large->small (smooth global basin -> sharp precision), THR gate.
Each TAU level is a discrete GN-LM block (avoids per-step recompile). Reports per-seed + summary.
Usage: CUDA_VISIBLE_DEVICES=g [TRUTH_SOURCE=siren|photonsim] [PRED_TEMP=0.1] [WT=0.05] [THR=2]
       [TAUS=2,1,0.5,0.3,0.2] [SEEDS=1..8] python recon_robust.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

SRC   = os.environ.get('TRUTH_SOURCE', 'siren')
PT    = os.environ.get('PRED_TEMP', '0.1')
WT    = float(os.environ.get('WT', '0.05'))
THR   = float(os.environ.get('THR', '2'))
SCHED = [float(x) for x in os.environ.get('TAUS', '2,1,0.5,0.3,0.2').split(',')]
SEEDS = [int(x) for x in os.environ.get('SEEDS', '1,2,3,4,5,6,7,8').split(',')]
SC = np.array(H.PARAM_SCALE)

S = PS.setup(event=0, nphot=80_000, truth_source=SRC, pred_temperature=float(PT))
theta_star = np.array(S['theta_star'])
_lc = PS.make_loss(S, WT=0.0, TAU=4.0, THR=0.0)
gchrg = jax.jit(jax.grad(lambda th, k: _lc(th, k)[2]))
# one full-loss grad per TAU level (compiled once, reused across seeds)
gfull = {}
for tau in SCHED:
    _lf = PS.make_loss(S, WT=WT, TAU=tau, THR=THR)
    gfull[tau] = jax.jit(jax.grad(lambda th, k, f=_lf: f(th, k)[2]))
print(f"=== ROBUST recon TRUTH={SRC} PRED_TEMP={PT} WT={WT} THR={THR} ntime={PS.n_time_sensors(S,THR)} "
      f"sched={SCHED} ===", flush=True)

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T = []
    for s in range(steps):
        keys = jax.random.split(jax.random.PRNGKey(101 + 7919*tag + s), 6)
        G = np.stack([np.array(gfn(theta, k)) * SC for k in keys])
        g = G.mean(0); F = (G.T @ G) / 6
        dd = np.clip(np.diag(F), 1e-12, None)
        ev, V = np.linalg.eigh(F + LM*np.diag(dd) + 1e-9*np.eye(7)*(dd.max()+1e-12))
        ev = np.clip(ev, 2e-2*ev.max(), None)
        step = np.clip(V @ np.diag(1/ev) @ V.T @ g, -0.35, 0.35) * SC
        theta = theta - LR * jnp.array(step * (1 - fr))
        if s >= steps - tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))

def dirv(p): return np.array([np.sin(p[4])*np.cos(p[5]), np.sin(p[4])*np.sin(p[5]), np.cos(p[4])])

Vs=[]; Ds=[]; Es=[]; Ts=[]
for seed in SEEDS:
    rng = np.random.default_rng(seed)
    th = jnp.array(theta_star + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
    th = gnlm(th, gchrg, 90, tag=1)                       # energy + rough vertex
    for j, tau in enumerate(SCHED):                       # annealed time refinement, energy frozen
        th = gnlm(th, gfull[tau], 50, freeze=[0], tag=2+j)
    p = np.array(th); err = p - theta_star
    v = np.linalg.norm(err[1:4])*100; d = np.degrees(np.arccos(np.clip(dirv(p)@dirv(theta_star),-1,1)))
    Vs.append(v); Ds.append(d); Es.append(err[0]/theta_star[0]*100); Ts.append(err[6])
    print(f"  seed {seed}: vertex {v:5.1f}cm  dir {d:.3f}deg  E {err[0]/theta_star[0]*100:+.1f}%  t0 {err[6]:+.2f}ns", flush=True)
print(f"SUMMARY vertex {np.mean(Vs):5.1f}+-{np.std(Vs):4.1f}cm (median {np.median(Vs):.1f}) "
      f"dir {np.mean(Ds):.3f}deg  E {np.mean(Es):+.1f}%  t0 {np.mean(Ts):+.2f}+-{np.std(Ts):.2f}ns", flush=True)
