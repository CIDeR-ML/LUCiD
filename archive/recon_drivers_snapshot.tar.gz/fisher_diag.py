"""DIAGNOSTIC 3 (Gauss-Newton / Fisher part). At TRUTH, over M DATA realizations, compute per term the
score (gradient) MEAN -> bias check (0 = unbiased min), and COVARIANCE -> the true Fisher. Then for the
combined lE+WT*lT loss: CRB=sqrt(diag(F^-1)), correlation matrix (degeneracies), eigenvalues (conditioning).
Compares the timing-only geometry block to the targets and shows whether the JOINT landscape has nasty
correlated valleys (that need the GN metric) beyond the convex 1D scans.
Usage: CUDA_VISIBLE_DEVICES=g TRUTH=photonsim python fisher_diag.py
  RECON_K=8 MAXCELL=16 OVERLAP_ANALYTIC=cubic SIREN_IMPORTANCE=1
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import segment_logsumexp
np.set_printoptions(precision=3, suppress=True, linewidth=160)
TRUTH = os.environ.get('TRUTH', 'photonsim'); NPHOT = int(os.environ.get('NPHOT', '150000'))
M = int(os.environ.get('M', '48')); TAU = float(os.environ.get('TAU', '0.3')); THR = float(os.environ.get('THR', '4.0'))
WT = float(os.environ.get('WT', '1.0')); NAMES = H.PARAM_NAMES; SC = np.array(H.PARAM_SCALE)
S = PS.setup(event=0, nphot=NPHOT, truth_source=TRUTH, pred_temperature=0.1)
ts = jnp.array(S['theta_star']); pred = S['pred']; ND = S['ND']; regen = S['regen']

def fa_shape(lw, ft, fi, tobs, tau):
    t_obs = tobs[fi]; x = (t_obs - ft) / tau
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(slw, fi, ND); lwn = slw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(tau)
    lf = segment_logsumexp(lwn + logk, fi, ND); l1mf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    LF = -60.0; empty = lwt <= (LF + 1.0)
    lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return jnp.where(empty, 0.0, -lf - (Ns - 1.0) * l1mf)

def mk(term):
    def f(theta, key, oc, ot, hi):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key)
        sumq = jnp.sum(q); sumobs = jnp.sum(oc) + 1e-9
        if term == 'E': return ((sumq - sumobs) / sumobs) ** 2 * 100.0
        if term == 'S':
            phat = q / (sumq + 1e-8); return -jnp.sum(oc * jnp.log(phat + 1e-8)) / sumobs * 100.0
        tmask = hi & (oc >= THR); return jnp.sum(jnp.where(tmask, fa_shape(lw, ft, fi, ot - theta[6], TAU), 0.0))
    return jax.jit(jax.grad(f))
gE, gS, gT = mk('E'), mk('S'), mk('T')

GE, GS, GT = [], [], []
for m in range(M):
    oc, ot, hi = regen(2000 + m); pk = jax.random.PRNGKey(m)
    GE.append(np.array(gE(ts, pk, oc, ot, hi)) * SC)
    GS.append(np.array(gS(ts, pk, oc, ot, hi)) * SC)
    GT.append(np.array(gT(ts, pk, ot if False else oc, ot, hi)) * SC)
GE, GS, GT = np.array(GE), np.array(GS), np.array(GT)

def report(name, G):
    mean = G.mean(0); se = G.std(0) / np.sqrt(M)
    bias = "  ".join(f"{NAMES[i]}={mean[i]:+.2f}({se[i]:.2f})" for i in range(7))
    print(f"[{name}] score MEAN@truth (bias; >>SE means biased min): {bias}", flush=True)
report('lE', GE); report('lS', GS); report('lT', GT)

# Combined lE + WT*lT Fisher (DROP lS). geometry+energy.
G = GE + WT * GT
F = (G.T @ G) / M
def crbblock(F, idx):
    Fs = F[np.ix_(idx, idx)]; Fs = Fs + 1e-9 * np.trace(Fs) / len(idx) * np.eye(len(idx))
    C = np.linalg.inv(Fs); return np.sqrt(np.clip(np.diag(C), 0, None)), C
crb7, C7 = crbblock(F, list(range(7)))
deg = 180 / np.pi
vtxc = np.sqrt(sum((crb7[i] * SC[i]) ** 2 for i in [1, 2, 3])) * 100
dirc = np.sqrt(sum((crb7[i] * SC[i]) ** 2 for i in [4, 5])) * deg
print(f"\n[lE+{WT}*lT Fisher CRB]  E={crb7[0]*SC[0]/float(ts[0])*100:.2f}%  vtx={vtxc:.1f}cm  dir={dirc:.2f}deg  t0={crb7[6]*SC[6]:.2f}ns", flush=True)
ev = np.linalg.eigvalsh(F + 1e-9 * np.trace(F) * np.eye(7))
print(f"  Fisher eigenvalues (cond#={ev.max()/max(ev.min(),1e-12):.1e}): {ev}", flush=True)
Cn = C7 / np.sqrt(np.outer(np.diag(C7), np.diag(C7)) + 1e-30)
print("  CRB correlation matrix (|rho|>0.7 = degeneracy):", flush=True)
for i in range(7):
    print("   ", NAMES[i], " ".join(f"{Cn[i,j]:+.2f}" for j in range(7)), flush=True)
