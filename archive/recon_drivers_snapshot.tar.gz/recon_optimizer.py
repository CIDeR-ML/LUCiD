"""Track reconstruction: Gauss-Newton optimizer (residual Jacobian H = J^T J — the model
CURVATURE, not the gradient-noise) + Levenberg-Marquardt diagonal ridge + eigenvalue clipping
+ Polyak tail averaging. Residuals = per-sensor sqrt-charge and charge-weighted-mean time.
Pure-AD Jacobian (DiCE emission sampler makes energy correct). Params normalized by PARAM_SCALE;
parameter COUPLING handled via the full off-diagonal J^TJ inverse.

Usage: CUDA_VISIBLE_DEVICES=g [OFF=1.0 NKJ=4 STEPS=120 LR=0.7 LM=0.05 WT=1.0] python recon_optimizer.py [SEED]
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True)

K, NPHOT = 7, 30_000
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 0
NKJ = int(os.environ.get('NKJ', '4'))          # keys averaged per Jacobian/residual
STEPS = int(os.environ.get('STEPS', '120'))
LR = float(os.environ.get('LR', '0.7'))
LM = float(os.environ.get('LM', '0.05'))
TAIL = int(os.environ.get('TAIL', '40'))
OFF = float(os.environ.get('OFF', '1.0'))
WT = float(os.environ.get('WT', '1.0'))
SIG_T = float(os.environ.get('SIGT', '3.0'))
SCALE = jnp.array(H.PARAM_SCALE)
e = 1e-6

theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 5.0])
pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(truth, theta_star, jax.random.PRNGKey(7))
hitf = hit.astype(jnp.float32)

def resid(theta, key):
    log_w, ft, fi, q = pred(H.theta_to_track(theta), key)
    rc = jnp.sqrt(jnp.clip(q, 0.0, None) + e) - jnp.sqrt(oc + e)             # sqrt-charge residual
    w = jnp.exp(jnp.clip(log_w, -50.0, 10.0))
    sw = jax.ops.segment_sum(w, fi, ND); swt = jax.ops.segment_sum(w * ft, fi, ND)
    t_pred = swt / (sw + 1e-6)
    rt = jnp.where(hit, (t_pred - (ot - theta[6])) / SIG_T, 0.0)             # charge-weighted mean-time residual
    return jnp.concatenate([rc, WT * rt])

resid_jit = jax.jit(resid)
HJ = 0.06 * np.array(SCALE)                                                  # FD Jacobian step per param
_eye = np.eye(7)

def gn_system(theta, keys):
    """Average H=J^T J and g=J^T r over keys via a FINITE-DIFFERENCE Jacobian (forward-only —
    the custom_vjp photon step blocks forward-mode AD; FD also captures the true energy dep.)."""
    th = np.array(theta)
    Hm = np.zeros((7, 7)); gm = np.zeros(7)
    for k in keys:
        r0 = np.array(resid_jit(theta, k))
        J = np.zeros((r0.shape[0], 7))
        for i in range(7):
            rp = np.array(resid_jit(jnp.array(th + HJ[i] * _eye[i]), k))
            rm = np.array(resid_jit(jnp.array(th - HJ[i] * _eye[i]), k))
            J[:, i] = (rp - rm) / (2 * HJ[i]) * float(SCALE[i])              # normalized column
        Hm += J.T @ J; gm += J.T @ r0
    return Hm / len(keys), gm / len(keys)

rng = np.random.default_rng(SEED)
off = rng.uniform(-1, 1, 7) * OFF
theta = jnp.array(np.array(theta_star) + off * np.array(SCALE))
print(f"SEED={SEED} OFF={OFF}  initial |dθ|/scale = {np.abs(off)}", flush=True)
lfn = jax.jit(H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5))

tail = []
for s in range(STEPS):
    keys = jax.random.split(jax.random.PRNGKey(1000 + 7 * SEED + s), NKJ)
    Hm, gm = gn_system(theta, keys)
    d = np.clip(np.diag(Hm), 1e-12, None)
    Hr = Hm + LM * np.diag(d) + 1e-9 * np.eye(7) * (d.max() + 1e-12)
    ev, V = np.linalg.eigh(Hr)
    ev = np.clip(ev, 1e-3 * ev.max(), None)                                  # eigenvalue clip
    step_norm = V @ np.diag(1.0 / ev) @ V.T @ gm                             # GN step (normalized)
    step = np.clip(step_norm, -0.4, 0.4) * np.array(SCALE)
    theta = theta - LR * jnp.array(step)
    if s >= STEPS - TAIL:
        tail.append(np.array(theta))
    if (s + 1) % 20 == 0:
        err = np.abs(np.array(theta) - np.array(theta_star)) / np.array(SCALE)
        L = float(lfn(theta, keys[0]))
        print(f"  step {s+1}: loss={L:.1f}  |dθ|/scale = {err}", flush=True)

pa = np.mean(tail, 0)
err = np.abs(pa - np.array(theta_star))
UNITS = ['MeV', 'm', 'm', 'm', 'rad', 'rad', 'ns']
print("\n== FINAL (Polyak) recovery ==", flush=True)
for i, nm in enumerate(H.PARAM_NAMES):
    print(f"  {nm:6s} true={float(theta_star[i]):+9.4f} est={pa[i]:+9.4f} err={err[i]:.4g} {UNITS[i]}  ({err[i]/float(SCALE[i]):.2f} scale)", flush=True)
