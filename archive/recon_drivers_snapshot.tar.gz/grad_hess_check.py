"""Validate the ported step's GRADIENT and HESSIAN vs finite-difference (AD ground-truth).

Fixed prediction key (common random numbers) so loss(theta) is deterministic in theta:
then AD grad must match CRN finite-difference, and AD Hessian must match FD-of-the-gradient.
This confirms the pathwise track gradient is correct on the REAL sim (not just the toy) and
that the Hessian is sane for the LM optimizer (incl. parameter coupling / off-diagonals).
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H

K, NPHOT = 7, 30_000
pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)   # HARD overlap (DiCE step)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)

# True track: slightly off-axis so polar/azim are non-degenerate.
theta_star = jnp.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 0.0])
oc, ot, hit = H.gen_truth(truth, theta_star, jax.random.PRNGKey(7))
print(f"truth: {int(hit.sum())} sensors hit, total charge {float(oc.sum()):.0f}", flush=True)

loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5)
key = jax.random.PRNGKey(123)
L = jax.jit(lambda th: loss(th, key))
grad = jax.jit(jax.grad(lambda th: loss(th, key)))

# Evaluate at a perturbed point so the gradient is non-trivial.
theta0 = theta_star + 0.5 * H.PARAM_SCALE
print(f"loss(theta0) = {float(L(theta0)):.3f}", flush=True)

# ---- GRADIENT: AD vs central finite-difference (CRN) ----
g_ad = np.array(grad(theta0))
h = 0.04 * np.array(H.PARAM_SCALE)
eye = np.eye(7)
g_fd = np.array([(float(L(theta0 + h[i] * eye[i])) - float(L(theta0 - h[i] * eye[i]))) / (2 * h[i])
                 for i in range(7)])
print("\n== GRADIENT  AD vs FD ==", flush=True)
print(f"{'param':>7} {'AD':>14} {'FD':>14} {'rel-err':>9}", flush=True)
for i, nm in enumerate(H.PARAM_NAMES):
    rel = abs(g_ad[i] - g_fd[i]) / (abs(g_fd[i]) + 1e-6)
    print(f"{nm:>7} {g_ad[i]:>14.4f} {g_fd[i]:>14.4f} {rel*100:>8.1f}%", flush=True)
cos = float(np.dot(g_ad, g_fd) / (np.linalg.norm(g_ad) * np.linalg.norm(g_fd) + 1e-12))
print(f"  cosine(AD, FD) = {cos:.5f}   ||AD||/||FD|| = {np.linalg.norm(g_ad)/np.linalg.norm(g_fd):.4f}", flush=True)

# ---- HESSIAN: AD vs FD-of-gradient ----
H_ad = np.array(jax.jit(jax.hessian(lambda th: loss(th, key)))(theta0))
hh = 0.04 * np.array(H.PARAM_SCALE)
H_fd = np.zeros((7, 7))
for j in range(7):
    gp = np.array(grad(theta0 + hh[j] * eye[j]))
    gm = np.array(grad(theta0 - hh[j] * eye[j]))
    H_fd[:, j] = (gp - gm) / (2 * hh[j])
H_fd = 0.5 * (H_fd + H_fd.T)   # symmetrize FD
print("\n== HESSIAN diagonal  AD vs FD ==", flush=True)
print(f"{'param':>7} {'AD':>14} {'FD':>14} {'rel-err':>9}", flush=True)
for i, nm in enumerate(H.PARAM_NAMES):
    rel = abs(H_ad[i, i] - H_fd[i, i]) / (abs(H_fd[i, i]) + 1e-6)
    print(f"{nm:>7} {H_ad[i,i]:>14.3e} {H_fd[i,i]:>14.3e} {rel*100:>8.1f}%", flush=True)
offmax = np.max(np.abs(H_ad - np.diag(np.diag(H_ad))))
fro = np.linalg.norm(H_ad - H_fd) / (np.linalg.norm(H_fd) + 1e-12)
asym = np.linalg.norm(H_ad - H_ad.T) / (np.linalg.norm(H_ad) + 1e-12)
print(f"  Hessian ||AD-FD||_F/||FD||_F = {fro*100:.1f}%   asymmetry = {asym*100:.2f}%", flush=True)
print(f"  max |off-diagonal| (coupling) = {offmax:.3e}", flush=True)
if np.all(np.isfinite(H_ad)):
    ev = np.linalg.eigvalsh(H_ad)
    print(f"  AD Hessian eigenvalues: min={ev.min():.3e} max={ev.max():.3e} cond={ev.max()/ (abs(ev.min())+1e-12):.2e}", flush=True)
    print(f"  n_negative_eigs = {int((ev<0).sum())}  (clip these for the LM optimizer)", flush=True)
else:
    print(f"  AD Hessian has NON-FINITE entries ({int((~np.isfinite(H_ad)).sum())}/49) -> full Hessian via custom_vjp unusable; use Gauss-Newton (J^T J).", flush=True)
# Gauss-Newton diagonal proxy from the gradient outer product is not meaningful here;
# the GN Hessian is built from the per-sensor residual Jacobian in the optimizer script.
