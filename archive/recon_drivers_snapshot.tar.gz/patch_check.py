import jax, jax.numpy as jnp
import lucid.simulation.photon_step as PS
import lucid.simulation.simulator as SIM
print("SIM has _safe:", hasattr(SIM, 'photon_iteration_update_factors_safe'))
print("SIM._safe is PS._safe:", getattr(SIM, 'photon_iteration_update_factors_safe', None) is PS.photon_iteration_update_factors_safe)
args = (jnp.zeros(3), jnp.array([0., 0, 1.]), jnp.array(0.0), jnp.array(20.0), jnp.array([0., 0, 1.]),
        jnp.array(175.0), jnp.array(1e9), jnp.array(0.0), jnp.array(0.2), jnp.array(0.2),
        jnp.array(400.0), jnp.array(False), jax.random.PRNGKey(1), 0.2247)
out0 = PS.photon_iteration_update_factors_safe(*args)
def OLD(*a):
    z = jnp.array(0.0); return (a[0], a[1], a[2], jnp.array(0.111), jnp.array(0.222), jnp.array(0.333), z)
PS.photon_iteration_update_factors = OLD
out1 = PS.photon_iteration_update_factors_safe(*args)
print("patch PS.inner -> _safe continuing:", float(out0[5]), "->", float(out1[5]), "(changed if != 0)")
SIM.photon_iteration_update_factors_safe = OLD
print("patch SIM._safe directly -> continuing:", float(SIM.photon_iteration_update_factors_safe(*args)[5]))
