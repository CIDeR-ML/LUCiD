"""HONEST per-event bias — is the time-term bias real, or an artifact of the mean-obs construction?

Recon fits SINGLE events. For NEV single truth realizations, profile the loss in x and energy, take the
per-event argmin, and average. mean(argmin) = BIAS ; std = per-event noise floor. If charge-only argmin
~truth and full(charge+time) argmin shifted CONSISTENTLY across events -> the time bias is REAL (not a
Jensen/mean-of-minima artifact). K=8, MAXCELL=16. Env: NPHOT NKEYS NEV TAU WT.
Usage: CUDA_VISIBLE_DEVICES=g python loss_perevent.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
os.environ.setdefault('MAXCELL', '16')
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '16'))
NEV = int(os.environ.get('NEV', '12')); TAU = float(os.environ.get('TAU', '1.5')); K = 8
PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0])
print(f"# HONEST per-event bias  NPH={NPH} NKEYS={NKEYS} NEV={NEV} TAU={TAU} K={K} MAXCELL={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred); keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def argmin(lossj, i, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts)
    c = np.array([np.mean([float(lossj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

res = {('charge', 'x'): [], ('charge', 'energy'): [], ('full', 'x'): [], ('full', 'energy'): []}
for ev in range(NEV):
    oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(5000 + ev))
    for tag, wt in [('charge', 0.0), ('full', 1.0)]:
        lj = jax.jit(H.make_loss(pred, oc, ot, hit, ND, tau_time=TAU, w_charge=1.0, w_time=wt))
        res[(tag, 'x')].append(argmin(lj, 1)); res[(tag, 'energy')].append(argmin(lj, 0))
    print(f"#  ev{ev:2d}: charge x {res[('charge','x')][-1]:+.3f} E {res[('charge','energy')][-1]:+6.1f} | "
          f"full x {res[('full','x')][-1]:+.3f} E {res[('full','energy')][-1]:+6.1f}", flush=True)
print(f"\n# === per-event argmin: MEAN(bias) +/- STD(noise) over {NEV} events ===", flush=True)
for tag in ['charge', 'full']:
    ax = np.array(res[(tag, 'x')]); ae = np.array(res[(tag, 'energy')])
    print(f"#  {tag:6s}  x  bias {ax.mean():+.3f} m  std {ax.std():.3f} | energy bias {ae.mean():+6.1f} MeV  std {ae.std():.1f}", flush=True)
print(f"# READ: charge bias~0 (unbiased); if full x-bias >> charge x-bias and consistent (small std) => time bias REAL.", flush=True)
