"""Decompose the simulation to localize where the position/direction gradient dies.
Stages: (1) SIREN source rays, (2) propagator outputs (sensor_weights/times/positions),
(3) one photon step bare vs custom_vjp-safe, (4) full charge. Use temperature=1.0 (smooth,
reliable FD). Report AD vs FD gradient magnitude at each stage."""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.geometry.detector_geometry import DetectorGeometry
from lucid.simulation.optics import normalize as _n
from lucid.simulation.photon_step import (photon_iteration_update_factors,
                                           photon_iteration_update_factors_safe)
GEOM = 'config/SK_geom_config.json'
np.set_printoptions(precision=3, suppress=True)

# ---------- Stage 2: propagator differentiability ----------
dg = DetectorGeometry.from_config(GEOM, temperature=1.0, max_sensors_per_cell=4)
propagate = dg.propagator
N = 2000
key = jax.random.PRNGKey(0)
k1, k2 = jax.random.split(key)
# random photon positions inside the tank, directions roughly inward
pos0 = jax.random.uniform(k1, (N, 3), minval=-5.0, maxval=5.0)
dirs = _n(jax.random.normal(k2, (N, 3)))

def prop_sum_weights(shift):
    r = propagate(pos0 + shift, dirs)
    return jnp.sum(r['sensor_weights'])

def prop_sum_times(shift):
    r = propagate(pos0 + shift, dirs)
    return jnp.sum(r['times'])

print("== Stage 2: propagator d/d(global shift of all photon positions) ==", flush=True)
for nm, f in [('sum sensor_weights', prop_sum_weights), ('sum times', prop_sum_times)]:
    g_ad = np.array(jax.grad(f)(jnp.zeros(3)))
    h = 1e-3
    g_fd = np.array([(float(f(jnp.zeros(3).at[i].set(h))) - float(f(jnp.zeros(3).at[i].set(-h)))) / (2 * h)
                     for i in range(3)])
    cos = float(np.dot(g_ad, g_fd) / (np.linalg.norm(g_ad) * np.linalg.norm(g_fd) + 1e-12))
    print(f"  {nm:20s}: AD={g_ad}  FD={g_fd}  cos={cos:+.3f}  |AD|/|FD|={np.linalg.norm(g_ad)/(np.linalg.norm(g_fd)+1e-12):.3f}", flush=True)

# ---------- Stage 3: one photon step, bare vs custom_vjp-safe ----------
print("\n== Stage 3: single photon step d(detect_prob)/d(position), bare vs _safe ==", flush=True)
base = dict(direction=jnp.array([0.0, 0.0, 1.0]), time=0.0, surface_distance=12.0,
            normal=jnp.array([0.0, 0.0, -1.0]), scatter_length=175.0, mie_scatter_length=9886.0,
            g=0.95, wall_reflection_rate=0.2, sensor_reflection_rate=0.2, absorption_length=400.0,
            hit_sensor=True, rng_key=jax.random.PRNGKey(3), speed_of_light=0.2248)

def step_detect(fn):
    def f(pos):
        out = fn(pos, base['direction'], base['time'], base['surface_distance'], base['normal'],
                 base['scatter_length'], base['mie_scatter_length'], base['g'],
                 base['wall_reflection_rate'], base['sensor_reflection_rate'],
                 base['absorption_length'], base['hit_sensor'], base['rng_key'], base['speed_of_light'])
        return out[3]   # detect_prob
    return f

for nm, fn in [('bare', photon_iteration_update_factors), ('safe', photon_iteration_update_factors_safe)]:
    f = step_detect(fn)
    p0 = jnp.array([0.0, 0.0, 0.0])
    g_ad = np.array(jax.grad(f)(p0))
    h = 1e-3
    g_fd = np.array([(float(f(p0.at[i].set(h))) - float(f(p0.at[i].set(-h)))) / (2 * h) for i in range(3)])
    print(f"  {nm:5s}: AD={g_ad}  FD={g_fd}", flush=True)

# also d(detect_prob)/d(surface_distance) -- the main pathwise track channel (reach)
print("\n== Stage 3b: single step d(detect_prob)/d(surface_distance) ==", flush=True)
def step_detect_Dd(fn):
    def f(Dd):
        out = fn(base['direction'] * 0 + jnp.array([0., 0., 0.]), base['direction'], base['time'], Dd,
                 base['normal'], base['scatter_length'], base['mie_scatter_length'], base['g'],
                 base['wall_reflection_rate'], base['sensor_reflection_rate'],
                 base['absorption_length'], base['hit_sensor'], base['rng_key'], base['speed_of_light'])
        return out[3]
    return f
for nm, fn in [('bare', photon_iteration_update_factors), ('safe', photon_iteration_update_factors_safe)]:
    f = step_detect_Dd(fn)
    g_ad = float(jax.grad(f)(12.0))
    h = 1e-3
    g_fd = (float(f(12.0 + h)) - float(f(12.0 - h))) / (2 * h)
    print(f"  {nm:5s}: AD={g_ad:.5f}  FD={g_fd:.5f}", flush=True)
