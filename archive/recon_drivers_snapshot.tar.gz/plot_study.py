#!/usr/bin/env python3
"""Analyze the 1000-event study (mg_study_*.log): resolution distributions, wanderer fraction, vs start offset."""
import glob,re,numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rows=[]
RX=re.compile(r'ev\s*(\d+)\s+pol\s*([0-9]+)\s+soff\s*([0-9.]+)cm E\s*([+-][0-9.]+)\s+\|vtx\|\s*([0-9.]+)cm \(lon\s*([0-9.]+) tra\s*([0-9.]+)\) dir\s*([0-9.]+) t0\s*([+-][0-9.]+)')
for f in sorted(glob.glob('/tmp/mg_study_*.log')):
    for l in open(f):
        m=RX.search(l)
        if m: rows.append([float(m.group(i)) for i in range(1,10)])
a=np.array(rows)  # ev,pol,soff,E,vtx,lon,tra,dir,t0
ev,pol,soff,E,V,LON,TRA,D,T=a.T
N=len(a); rms=lambda x:float(np.sqrt((x**2).mean())); p68=lambda x:float(np.percentile(np.abs(x),68))
# wanderer = vtx>25 (the t0<->lon flat-direction tail)
wand=V>25; clean=~wand
print(f'N={N} | wanderers(vtx>25)={wand.sum()} ({wand.mean()*100:.1f}%)')
print(f'ALL    : E {E.mean():+.1f}/{rms(E):.0f}(p68 {p68(E):.0f}) | vtx med {np.median(V):.1f} rms {rms(V):.1f} (lon {rms(LON):.1f}/tra {rms(TRA):.1f}) | dir med {np.median(D):.2f} p68 {p68(D):.2f} | t0 {rms(T):.2f}')
print(f'CLEAN  : E {E[clean].mean():+.1f}/{rms(E[clean]):.0f} | vtx med {np.median(V[clean]):.1f} rms {rms(V[clean]):.1f} (lon {rms(LON[clean]):.1f}/tra {rms(TRA[clean]):.1f}) | dir med {np.median(D[clean]):.2f} p68 {p68(D[clean]):.2f} | t0 {rms(T[clean]):.2f}')

# Panel 1: distributions
fig,ax=plt.subplots(2,3,figsize=(15,9)); ax=ax.ravel()
for a_,(x,lab,sg) in zip(ax,[(E,'energy residual (MeV)',1),(V,'|vertex| (cm)',0),(LON,'longitudinal (cm)',0),(TRA,'transverse (cm)',0),(D,'direction (deg)',0),(T,'t0 residual (ns)',1)]):
    xc=np.clip(x,np.percentile(x,0.5),np.percentile(x,99.5))
    a_.hist(xc,bins=40,color='C0',edgecolor='k',lw=0.3,alpha=0.85)
    a_.axvline(np.median(x),color='r',lw=1.3,label=f'med {np.median(x):.2f}'); a_.axvline(np.percentile(np.abs(x),68)*(1 if not sg else 1),color='orange',ls='--',label=f'p68 {p68(x):.2f}')
    if sg: a_.axvline(0,color='k',lw=0.5,ls=':')
    a_.set_xlabel(lab); a_.set_ylabel('events'); a_.set_title(f'{lab.split(" (")[0]}: med={np.median(x):+.2f} rms={rms(x):.2f} p68={p68(x):.2f}',fontsize=10); a_.legend(fontsize=8); a_.grid(alpha=0.3)
fig.suptitle(f'1000-event study (N={N} done): parameter resolution, 1-sigma jitter start',fontsize=13)
fig.tight_layout(rect=[0,0,1,0.97]); fig.savefig('recon_plots/study_distributions.png',dpi=110); print('wrote study_distributions.png')

# Panel 2: wanderer structure (lon vs t0) + resolution vs start offset
fig2,(b1,b2,b3)=plt.subplots(1,3,figsize=(16,5))
b1.scatter(T[clean],LON[clean],s=4,alpha=0.3,c='C0',label='converged'); b1.scatter(T[wand],LON[wand],s=8,alpha=0.5,c='C3',label='wanderer')
b1.set_xlabel('t0 residual (ns)'); b1.set_ylabel('longitudinal (cm)'); b1.set_title('t0<->longitudinal correlation (wanderer tail)'); b1.legend(); b1.grid(alpha=0.3)
# vtx vs start offset
sb=np.linspace(soff.min(),soff.max(),12); ic=np.digitize(soff,sb); bc=0.5*(sb[1:]+sb[:-1])
vmed=[np.median(V[ic==i]) if (ic==i).sum() else np.nan for i in range(1,len(sb))]; wfr=[ (V[ic==i]>25).mean()*100 if (ic==i).sum() else np.nan for i in range(1,len(sb))]
b2.plot(bc,vmed,'o-'); b2.set_xlabel('start vertex offset (cm)'); b2.set_ylabel('vtx median (cm)'); b2.set_title('resolution vs start offset (flat=basin ok)'); b2.grid(alpha=0.3); b2.set_ylim(0,None)
b3.plot(bc,wfr,'s-',color='C3'); b3.set_xlabel('start vertex offset (cm)'); b3.set_ylabel('wanderer fraction (%)'); b3.set_title('wanderer fraction vs start offset'); b3.grid(alpha=0.3); b3.set_ylim(0,None)
fig2.suptitle(f'Study structure: wanderers {wand.mean()*100:.1f}% (t0<->lon tail), basin/offset dependence',fontsize=12)
fig2.tight_layout(rect=[0,0,1,0.96]); fig2.savefig('recon_plots/study_structure.png',dpi=110); print('wrote study_structure.png')
