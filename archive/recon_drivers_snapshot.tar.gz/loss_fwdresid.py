"""FORWARD timing residual — does the predictor's modeled first-arrival systematically differ from the
truth's at theta_true? (the loss-level, order-stat version of A7). A systematic offset, amplified by the
order-stat (N_s-1) exponent, would bias the vertex/energy.

Compares per-PMT at theta_true:
  pred_t  = predictor 'aggregated' soft-min first-arrival (the modeled first-arrival, avg over keys)
  truth_t = sample hard first-arrival (mean over realizations)
bucketed by occupancy. Reports the median/mean offset (pred - truth) and how a vertex shift along the
track would compensate it. K=8, MAXCELL=16. Env: NPHOT NKEYS NTRUTH.
Usage: CUDA_VISIBLE_DEVICES=g python loss_fwdresid.py
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import load_detector_params
from lucid.geometry import generate_detector
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '8')); NTRUTH = int(os.environ.get('NTRUTH', '24')); K = 8; MC = 16
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.asarray(theta_true))
NS = int(np.asarray(generate_detector(H.GEOM).all_points).shape[0])
dp = load_detector_params(H.PHYS, num_sensors=NS); dp_off = dp._replace(mie_scatter_length=jnp.asarray(1e9, dtype=jnp.float32))
print(f"# FWD timing residual @theta_true  NPH={NPH} NKEYS={NKEYS} NTRUTH={NTRUTH} K={K} MAXCELL={MC}", flush=True)
sim_agg = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=0.1, K=K, is_data=False, use_expected_value=True,
    hit_mode='aggregated', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=dp_off,
    particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=dp_off,
    particle='muon', wavelength_mode=True, apply_smearing=False)
qc, tp = [], []
for s in range(NKEYS):
    c, t = [np.asarray(x) for x in jax.lax.stop_gradient(sim_agg(track, jax.random.PRNGKey(s)))]
    qc.append(c); tp.append(np.where(c > 1e-6, t, np.nan))
q_pred = np.nanmean(qc, 0); T_pred = np.nanmean(tp, 0)
qt, tt = [], []
for s in range(NTRUTH):
    c, t = [np.asarray(x) for x in jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(s)))]
    qt.append(c); tt.append(np.where(c > 1e-6, t, np.nan))
q_tru = np.nanmean(qt, 0); T_tru = np.nanmean(tt, 0)
m = np.isfinite(T_pred) & np.isfinite(T_tru) & (q_tru > 1e-6) & (q_pred > 1e-6)
d = (T_pred - T_tru)[m]; occ = q_tru[m]
print(f"# common-lit PMTs {m.sum()}   offset = pred_softmin - truth_hardmin [ns]:", flush=True)
print(f"#  ALL: median {np.median(d):+.3f} mean {d.mean():+.3f} std {d.std():.3f}", flush=True)
for lo, hi in [(0, 1), (1, 3), (3, 8), (8, 1e9)]:
    mm = (occ >= lo) & (occ < hi)
    if mm.sum() > 20: print(f"#  occ[{lo:>2.0f},{hi:>4.0f}) n={mm.sum():5d}: median {np.median(d[mm]):+.3f} mean {d[mm].mean():+.3f}", flush=True)
cw = 0.299792458 / 1.34  # m/ns in water
print(f"# a vertex shift Δs along track shifts arrival ~Δs/c; median offset {np.median(d):+.2f}ns ~ {np.median(d)*cw:+.2f}m of vertex compensation", flush=True)
print(f"# READ: a systematic pred-EARLIER (negative) offset => loss moves vertex BACK to delay predicted times => the -0.7m bias.", flush=True)
