"""PHASE 5 — Gauss-Newton recon with the FISHER Hessian (the AD Hessian is BROKEN/indefinite for geometry, see
adfd_hessian.py). Metric H = J_mu^T diag(1/mu) J_mu (charge Poisson Fisher, PSD) [+ optional FD-full curvature].
Step in SCALED z: dz = -(Hz + lam I)^-1 gz,  gz from the FULL-loss AD gradient (charge+time), key-averaged.
  RIDGE = mean|median : lam = RIDGE_EPS * {mean|median}(diag Hz).
  CLIP_POS=1 : eigen-clip Hz to >= CLIP_FRAC*max(ev) (Fisher is already PSD; clip lifts the weak/timing directions).
  HESS = fisher (charge Fisher) | fdfull (FD Hessian of full loss, key-avg, pos-clipped) | mix.
Start = truth + START_OFF*SC on axis START_PIDX. Reports trajectory + final errors; runs ADAM from same start to compare.
Env: RIDGE CLIP_POS RIDGE_EPS CLIP_FRAC HESS START_OFF START_PIDX NITERS NKEYS DAMP TR.
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ['MAXCELL']='16'; os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np, optax
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=170)
NPH=int(os.environ.get('NPHOT','500000')); NKEYS=int(os.environ.get('NKEYS','6')); NITERS=int(os.environ.get('NITERS','30'))
RIDGE=os.environ.get('RIDGE','median'); CLIP_POS=bool(int(os.environ.get('CLIP_POS','1'))); HESS=os.environ.get('HESS','fisher')
RIDGE_EPS=float(os.environ.get('RIDGE_EPS','0.3')); CLIP_FRAC=float(os.environ.get('CLIP_FRAC','0.05'))
DAMP=float(os.environ.get('DAMP','1.0')); TR=float(os.environ.get('TR','0.5'))
START_OFF=float(os.environ.get('START_OFF','0')); START_PIDX=int(os.environ.get('START_PIDX','3'))
K=8; MC=16; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0)); POL,AZ=0.6,0.8
th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
SC=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
AMP=bool(int(os.environ.get('AMP','1')))
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def th9dir(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=np.hypot(st,ct); npp=np.hypot(sp,cp); st,ct,sp,cp=st/nt,ct/nt,sp/npp,cp/npp
    return np.array([st*cp,st*sp,ct])
print(f"# GN HESS={HESS} RIDGE={RIDGE} CLIP_POS={CLIP_POS} eps={RIDGE_EPS} clipfrac={CLIP_FRAC} damp={DAMP} TR={TR} startoff={START_OFF}({NM[START_PIDX]}) NKEYS={NKEYS}",flush=True)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); ND=H.num_detectors(pred)
truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=K,is_data=False,use_expected_value=False,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
TRUTHKEY=int(os.environ.get('TRUTHKEY','5000'))
trk=sc2(jnp.asarray(th9)); dtrue=th9dir(th9)
c,t=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(TRUTHKEY))); oc=jnp.asarray(np.asarray(c)); ot=jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def loss(t9,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jnp.exp(jnp.clip(lw,-60,20)); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8)
    wR=jax.lax.stop_gradient(ww) if AMP else ww; muS=jax.lax.stop_gradient(mu) if AMP else mu
    Rlo=jax.ops.segment_sum(wR*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(wR*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(mu-oc*jnp.log(mu))+jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
gradf=jax.jit(jax.grad(loss))
@jax.jit
def mu_fn(t9,key): return jnp.maximum(pred(sc2(t9),key)[3],1e-8)
jmu=jax.jit(jax.jacfwd(mu_fn))
@jax.jit
def fisher_charge(t9,key):
    J=jmu(t9,key); mu=mu_fn(t9,key); return J.T@(J/mu[:,None])
@jax.jit
def hvp(t9,v,key): return jax.jvp(lambda tt: gradf(tt,key),(t9,),(v,))[1]
KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
def errs(th):
    d=th-th9; return np.sqrt(d[1]**2+d[2]**2+d[3]**2), np.degrees(np.arccos(np.clip(np.dot(th9dir(th),dtrue),-1,1))), d[0], d[8]
def avgloss(th): return float(np.mean([float(loss(jnp.asarray(th),k)) for k in KEYS]))
def fd_hess(th, nk=None):  # FD Hessian of the FULL loss (reverse-mode grad; custom_vjp-safe), key-avg
    ks=KEYS if nk is None else [jax.random.PRNGKey(s) for s in range(nk)]
    Hf=np.zeros((9,9))
    for j in range(9):
        h=0.4*SC[j]
        gp=np.mean([np.asarray(gradf(jnp.asarray(th+h*np.eye(9)[j]),k)) for k in ks],0)
        gm=np.mean([np.asarray(gradf(jnp.asarray(th-h*np.eye(9)[j]),k)) for k in ks],0)
        Hf[:,j]=(gp-gm)/(2*h)
    return 0.5*(Hf+Hf.T)
start=th9+START_OFF*SC*np.eye(9)[START_PIDX]; th=start.copy()
M_fixed = fd_hess(start, nk=max(NKEYS,12)) if HESS=='fdfixed' else None  # compute ONCE (well-averaged)
def getH(th):
    if HESS=='fdfixed': return M_fixed
    return fd_hess(th)   # fdfull: recompute each iter
print(f"#  it | loss      | vtxcm dir E t0     | stepnorm",flush=True)
for it in range(NITERS):
    g=np.mean([np.asarray(gradf(jnp.asarray(th),k)) for k in KEYS],0)
    Hh=getH(th); gz=g*SC; Hz=Hh*np.outer(SC,SC); Hz=0.5*(Hz+Hz.T)
    if CLIP_POS:
        ev,V=np.linalg.eigh(Hz); ev=np.clip(ev,CLIP_FRAC*max(np.abs(ev).max(),1e-9),None); Hz=V@np.diag(ev)@V.T
    lam=RIDGE_EPS*(np.median(np.diag(Hz)) if RIDGE=='median' else np.mean(np.diag(Hz)))
    dz=-np.linalg.solve(Hz+lam*np.eye(9),gz); dz=np.clip(dz,-TR,TR)
    th=th+DAMP*dz*SC
    if it%4==0 or it==NITERS-1:
        v,a,e,t0=errs(th); print(f"#  {it:2d} | {avgloss(th):9.1f} | {v*100:5.1f} {a:4.1f} {e:+6.0f} {t0:+.2f} | {np.linalg.norm(dz):.3f}",flush=True)
v,a,e,t0=errs(th); print(f"#  GN FINAL: vtx {v*100:.1f}cm  dir {a:.2f}deg  E {e:+.1f}MeV  t0 {t0:+.3f}ns",flush=True)
# ADAM from same start
opt=optax.adam(3e-2); z=(jnp.asarray(start)-jnp.asarray(th9))/jnp.asarray(SC); st=opt.init(z); SCj=jnp.asarray(SC); T0=jnp.asarray(th9)
for i in range(250):
    thh=T0+z*SCj; G=jnp.zeros(9)
    for s in range(NKEYS): G=G+gradf(thh,KEYS[s])
    u,st=opt.update((G/NKEYS)*SCj,st); z=optax.apply_updates(z,u)
tha=np.asarray(T0+z*SCj); va,aa,ea,t0a=errs(tha); print(f"#  ADAM FINAL(same start): vtx {va*100:.1f}cm dir {aa:.2f}deg E {ea:+.1f}MeV t0 {t0a:+.3f}ns",flush=True)
vg,ag,eg,t0g=errs(th)
with open(f"/tmp/gnres_{os.environ.get('TAG','x')}_{TRUTHKEY}.txt","w") as f:
    f.write(f"{TRUTHKEY} {vg*100:.3f} {ag:.3f} {eg:.2f} {t0g:.4f}  {va*100:.3f} {aa:.3f} {ea:.2f} {t0a:.4f}\n")
print(f"# DONE gn HESS={HESS} RIDGE={RIDGE} CLIP_POS={CLIP_POS} startoff={START_OFF}",flush=True)
