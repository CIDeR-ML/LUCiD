"""Decisive test: is the PhotonSim vertex recoverable GIVEN the correct energy (=> energy is the sole
culprit, set by the charge ring-shape mismatch), or is the vertex itself model-limited?
A) energy FIXED at truth, bad pos init, annealed FULL loss (pos/dir/t0 free)  -> vertex?
B) energy FIXED at truth, bad pos init, annealed TIME-only                     -> vertex?
C) energy FREE, high time weight WT=1.0, normal init                           -> vertex, E?
Usage: CUDA_VISIBLE_DEVICES=g python decisive.py SEED
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True)
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
THR = 4.0; SC = np.array(H.PARAM_SCALE); SCHED = [2, 1, 0.5, 0.3, 0.2]
S = PS.setup(event=0, nphot=80_000, truth_source='photonsim', pred_temperature=0.1)
ts = np.array(S['theta_star'])
def gchan(WT_, TAU_, chan):
    f = PS.make_loss(S, WT=WT_, TAU=TAU_, THR=THR); return jax.jit(jax.grad(lambda th,k: f(th,k)[chan]))
gchrg = gchan(0.0, 0.3, 0)
gfull = {tau: gchan(0.05, tau, 2) for tau in SCHED}
gtime = {tau: gchan(1.0, tau, 1) for tau in SCHED}
gfullW = {tau: gchan(1.0, tau, 2) for tau in SCHED}
def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=30, tag=0):
    fr=np.zeros(7)
    if freeze:
        for i in freeze: fr[i]=1.0
    T=[]
    for s in range(steps):
        ks=jax.random.split(jax.random.PRNGKey(101+7919*tag+s),6)
        G=np.stack([np.array(gfn(theta,k))*SC for k in ks]); g=G.mean(0); F=(G.T@G)/6
        dd=np.clip(np.diag(F),1e-12,None); ev,V=np.linalg.eigh(F+LM*np.diag(dd)+1e-9*np.eye(7)*(dd.max()+1e-12))
        ev=np.clip(ev,2e-2*ev.max(),None); st=np.clip(V@np.diag(1/ev)@V.T@g,-0.35,0.35)*SC
        theta=theta-LR*jnp.array(st*(1-fr))
        if s>=steps-tail: T.append(np.array(theta))
    return jnp.array(np.mean(T,0))
def vtx(t): return np.linalg.norm((np.array(t)-ts)[1:4])*100
def Ep(t): return (float(t[0])-ts[0])/ts[0]*100
def deg(t):
    dv=lambda p:np.array([np.sin(p[4])*np.cos(p[5]),np.sin(p[4])*np.sin(p[5]),np.cos(p[4])])
    return float(np.degrees(np.arccos(np.clip(dv(np.array(t))@dv(ts),-1,1))))
def anneal(th, gd, freeze, t0, steps=50):
    for j,tau in enumerate(SCHED): th=gnlm(th, gd[tau], steps, freeze=freeze, tag=t0+j)
    return th
rng=np.random.default_rng(SEED)
bad=jnp.array(ts + rng.uniform(-1,1,7)*np.array([3,1.5,1.5,1.5,0.15,0.15,3])*SC)
print(f"DECISIVE seed={SEED} bad-init vtx={vtx(bad):.0f}cm", flush=True)
# A) energy fixed at truth, full loss
a=bad.at[0].set(ts[0]); a=anneal(a, gfull, [0], 100)
print(f"  A) E=truth(fixed) + full annealed: vtx={vtx(a):5.1f}cm dir={deg(a):.2f} t0={float(a[6]-ts[6]):+.2f}", flush=True)
# B) energy fixed at truth, time only
b=bad.at[0].set(ts[0]); b=anneal(b, gtime, [0], 200)
print(f"  B) E=truth(fixed) + time-only:     vtx={vtx(b):5.1f}cm dir={deg(b):.2f} t0={float(b[6]-ts[6]):+.2f}", flush=True)
# C) energy free, high time weight, charge init
c=gnlm(bad, gchrg, 90, tag=1); c=anneal(c, gfullW, None, 300)
print(f"  C) WT=1.0 E-free joint:            vtx={vtx(c):5.1f}cm dir={deg(c):.2f} E={Ep(c):+.1f}%", flush=True)
