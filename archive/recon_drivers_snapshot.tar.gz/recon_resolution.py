"""Measure the actual single-event reconstruction resolution + bias: for each TRUTH realization
(different data key), start near truth and converge to the local MLE with Adam on the (now
correct) AD gradient — DiCE emission sampler (energy) + straight-through overlap (position).
The scatter of MLEs around theta_star = resolution; the mean offset = bias.
Usage: CUDA_VISIBLE_DEVICES=g python recon_resolution.py TRUTH_KEY  (prints the MLE row)
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H

K, NPHOT = 7, 50_000
TK = int(sys.argv[1])
NK = int(os.environ.get('NK', '6'))
STEPS = int(os.environ.get('STEPS', '220'))
LR = float(os.environ.get('LR', '0.25'))
SCALE = np.array(H.PARAM_SCALE)
theta_star = np.array([1050.0, 0.3, -0.2, 0.4, 0.35, 0.6, 5.0])

pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)
truth = H.build_truth_sim(K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
oc, ot, hit = H.gen_truth(truth, jnp.array(theta_star), jax.random.PRNGKey(TK))   # realization TK
WC = float(os.environ.get('WC', '1.0')); WT = float(os.environ.get('WT', '1.0'))
TAU = float(os.environ.get('TAU', '1.5')); LOSS = os.environ.get('LOSS', 'nll')
SIG_T = 3.0
from lucid.losses import poisson_nll, first_arrival_nll
ocf = jax.lax.stop_gradient(oc); otf = jax.lax.stop_gradient(ot); hitf = jax.lax.stop_gradient(hit)
SUMOBS = float(jnp.sum(oc))

def charge_nll_raw(q):
    # UN-normalized Poisson NLL (constrains the absolute energy scale, unlike counts_loss which
    # divides by sum(true)); rescaled by 1/sum(obs) only to keep the magnitude comparable to time.
    return jnp.sum(q - ocf * jnp.log(q + 1e-8)) / SUMOBS * 100.0

def loss_nll(theta, key):
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    c = charge_nll_raw(q)
    t = jnp.sum(jnp.where(hitf, first_arrival_nll(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
    return WC * c + WT * t

def loss_gauss(theta, key):
    """Energy-DECOUPLED: sqrt-charge (magnitude) + charge-weighted MEAN time (count normalizes out)."""
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    rc = jnp.sqrt(jnp.clip(q, 0.0, None) + 1e-6) - jnp.sqrt(ocf + 1e-6)
    w = jnp.exp(jnp.clip(lw, -50.0, 10.0))
    sw = jax.ops.segment_sum(w, fi, ND); swt = jax.ops.segment_sum(w * ft, fi, ND)
    t_pred = swt / (sw + 1e-6)
    rt = jnp.where(hitf, (t_pred - (otf - theta[6])) / SIG_T, 0.0)
    return WC * jnp.sum(rc ** 2) + WT * jnp.sum(rt ** 2)

from lucid.losses import segment_logsumexp
def loss_fixedN(theta, key):
    """first-arrival time NLL but with the OBSERVED photon count in the order statistic, so the
    time fits position/direction/t0 (time SHAPE) and does NOT pull energy (charge owns energy)."""
    lw, ft, fi, q = pred(H.theta_to_track(theta), key)
    c = jnp.sum(poisson_nll(ocf, q))
    t_obs = (otf - theta[6])[fi]
    x = (t_obs - ft) / TAU
    valid = lw > -20.0
    safe_lw = jnp.where(valid, lw, -1e6)
    lwt = segment_logsumexp(safe_lw, fi, ND)
    lwn = safe_lw - lwt[fi]
    logk = jax.nn.log_sigmoid(x) + jax.nn.log_sigmoid(-x) - jnp.log(TAU)
    log_f = segment_logsumexp(lwn + logk, fi, ND)
    log_omf = segment_logsumexp(lwn + jax.nn.log_sigmoid(-x), fi, ND)
    No = jnp.clip(jax.lax.stop_gradient(ocf), 1.0, None)                 # observed count (detached)
    empty = lwt <= -59.0
    nll = -log_f - (No - 1.0) * jnp.maximum(log_omf, -60.0)              # no -log_w_total energy pull
    nll = jnp.where(hitf & (~empty) & jnp.isfinite(nll), nll, 0.0)
    return WC * c + WT * jnp.sum(nll)

loss = {'gauss': loss_gauss, 'fixedN': loss_fixedN}.get(LOSS, loss_nll)
gfn = jax.jit(jax.grad(loss))
print(f"# TK={TK} LOSS={LOSS} WC={WC} WT={WT} TAU={TAU}", flush=True)

rng = np.random.default_rng(1000 + TK)
theta = jnp.array(theta_star + rng.uniform(-1, 1, 7) * 0.3 * SCALE)               # start near truth
m = np.zeros(7); v = np.zeros(7); b1, b2 = 0.9, 0.999
tail = []
for s in range(STEPS):
    keys = jax.random.split(jax.random.PRNGKey(7 * TK + s), NK)
    g = np.mean([np.array(gfn(theta, k)) for k in keys], 0) * SCALE              # normalized grad
    m = b1 * m + (1 - b1) * g; v = b2 * v + (1 - b2) * g * g
    mh = m / (1 - b1 ** (s + 1)); vh = v / (1 - b2 ** (s + 1))
    theta = theta - LR * jnp.array(mh / (np.sqrt(vh) + 1e-8) * SCALE)
    if s >= STEPS - 60:
        tail.append(np.array(theta))
mle = np.mean(tail, 0)
err = (mle - theta_star) / SCALE
print("MLE " + str(TK) + " " + " ".join(f"{mle[i]:.5f}" for i in range(7))
      + " | err/scale " + " ".join(f"{err[i]:+.2f}" for i in range(7)), flush=True)
