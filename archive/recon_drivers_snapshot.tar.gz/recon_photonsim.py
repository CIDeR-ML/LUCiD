"""Reconstruct a track against REAL PhotonSim ROOT truth (not self-consistent SIREN truth).
Truth = is_data simulator fed the event's Cherenkov photons (make_hits_data, hard first-arrival).
Prediction = SIREN+DiCE expected per-photon simulator. Staged GN-LM fit; compare to the event's
true track (derived from photon origins). Usage: CUDA_VISIBLE_DEVICES=g python recon_photonsim.py EVENT
"""
import os, sys, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.losses import first_arrival_nll
np.set_printoptions(precision=4, suppress=True)

ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
EVENT = int(sys.argv[1]) if len(sys.argv) > 1 else 0
K, NPHOT = 7, 80_000
SCALE = np.array(H.PARAM_SCALE)

# ---- load ROOT event + derive the true track from photon origins ----
raw = read_photon_data_from_photonsim(ROOT, EVENT)
n = int(raw['photon_origins'].shape[0])
P = np.array(raw['photon_origins']) / 100.0                    # cm -> m
C = P - P.mean(0); _, _, vt = np.linalg.svd(C, full_matrices=False); d = vt[0]
if d[2] < 0: d = -d
proj = (P - P.mean(0)) @ d; vtx = P.mean(0) + proj.min() * d
polar = float(np.arccos(np.clip(d[2], -1, 1))); azim = float(np.arctan2(d[1], d[0]))
theta_star = np.array([float(raw['energy']), vtx[0], vtx[1], vtx[2], polar, azim, 0.0])
print(f"EVENT {EVENT}: N={n}  true track = E{theta_star[0]:.0f} vtx({vtx[0]:.3f},{vtx[1]:.3f},{vtx[2]:.3f}) "
      f"polar={polar:.4f} azim={azim:.4f}", flush=True)

photon_data = {
    'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
    'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': False,
    'rotation_axis': jnp.array([1., 0., 0.]), 'rotation_angle': jnp.array(0.),
    'apply_translation': False, 'translation_vector': jnp.zeros(3)}
if 'wavelengths' in raw: photon_data['wavelengths'] = raw['wavelengths']

data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True,
    hit_mode='realistic', max_sensors_per_cell=4, physics_config=H.PHYS,
    default_detector_params=True, particle='muon', wavelength_mode=True, apply_smearing=False)
pred = H.build_predictor(temperature=None, K=K, n_photons=NPHOT)
ND = H.num_detectors(pred)
dummy = H.theta_to_track(jnp.array(theta_star))
oc, ot = jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(0), photon_data))
hit = oc > 0
ot = jnp.where(hit, ot, 0.0)
ocf, otf, hitf = jax.lax.stop_gradient(oc), jax.lax.stop_gradient(ot), jax.lax.stop_gradient(hit)
SUMOBS = float(jnp.sum(oc))
print(f"  truth: {int(hit.sum())} sensors hit, total charge {SUMOBS:.0f}", flush=True)

def make_gfn(WT, TAU):
    def loss(theta, key):
        lw, ft, fi, q = pred(H.theta_to_track(theta), key)
        c = jnp.sum(q - ocf * jnp.log(q + 1e-8)) / SUMOBS * 100.0
        t = jnp.sum(jnp.where(hitf, first_arrival_nll(lw, ft, fi, otf - theta[6], TAU, ND), 0.0))
        return c + WT * t
    return jax.jit(jax.grad(loss))

def gnlm(theta, gfn, steps, freeze=None, LR=0.4, LM=0.05, tail=45, tag=0):
    fr = np.zeros(7)
    if freeze:
        for i in freeze: fr[i] = 1.0
    T = []
    for s in range(steps):
        keys = jax.random.split(jax.random.PRNGKey(13 + 9000 * tag + s), 6)
        G = np.stack([np.array(gfn(theta, k)) * SCALE for k in keys])
        g = G.mean(0); F = (G.T @ G) / 6
        dd = np.clip(np.diag(F), 1e-12, None)
        ev, V = np.linalg.eigh(F + LM * np.diag(dd) + 1e-9 * np.eye(7) * (dd.max() + 1e-12))
        ev = np.clip(ev, 2e-2 * ev.max(), None)
        step = np.clip(V @ np.diag(1 / ev) @ V.T @ g, -0.35, 0.35) * SCALE
        theta = theta - LR * jnp.array(step * (1 - fr))
        if s >= steps - tail: T.append(np.array(theta))
    return jnp.array(np.mean(T, 0))

rng = np.random.default_rng(EVENT)
theta0 = jnp.array(theta_star + rng.uniform(-1, 1, 7) * np.array([4, 2, 2, 2, 0, 0, 5]) * SCALE
                   + np.array([0, 0, 0, 0, 0.3, 0.0, 0]))   # offset; perturb polar a bit (true~0)
t1 = gnlm(theta0, make_gfn(0.0, 4.0), 90, tag=1)                 # stage 1: energy from charge
t2 = gnlm(t1, make_gfn(0.03, 4.0), 110, freeze=[0], tag=2)       # stage 2: pos/dir/t0
pa = np.array(t2); err = pa - theta_star
# angular error of the recovered direction
def dirv(p):
    return np.array([np.sin(p[4])*np.cos(p[5]), np.sin(p[4])*np.sin(p[5]), np.cos(p[4])])
ang = float(np.degrees(np.arccos(np.clip(dirv(pa) @ dirv(theta_star), -1, 1))))
U = ['MeV', 'm', 'm', 'm', 'rad', 'rad', 'ns']
print(f"RESULT E1={float(t1[0]):.0f} | recovered " + " ".join(f"{pa[i]:.4f}" for i in range(7)), flush=True)
print(f"  err: " + " ".join(f"{H.PARAM_NAMES[i]}={err[i]:+.3g}{U[i]}" for i in range(7)), flush=True)
print(f"  energy err = {err[0]:+.0f} MeV ({err[0]/theta_star[0]*100:+.1f}%) | vertex err = "
      f"{np.linalg.norm(err[1:4])*100:.1f} cm | direction err = {ang:.2f} deg", flush=True)
