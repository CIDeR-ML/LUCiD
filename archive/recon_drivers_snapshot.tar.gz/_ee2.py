import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
NPH=50000; NT=24; SIGMA=2.5; K=8
tt=np.array([1050.,0,0,0,0.6,0.8,0.]); track=H.theta_to_track(jnp.asarray(tt))
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPH); tsim=H.build_truth_sim(K=K,n_photons=NPH)
ND=H.num_detectors(pred); SQ=float(np.sqrt(2.))
# fixed predictor rate (avg a few keys): per-PMT we need per-photon arrays -> use one rep key set
reps=[ [np.asarray(x) for x in jax.lax.stop_gradient(pred(track, jax.random.PRNGKey(100+s)))] for s in range(6)]
def R_at(tobs):  # tobs per-PMT array -> mean predictor R over rep keys
    acc=np.zeros(ND)
    for lw,ft,fi,tot in reps:
        w=np.exp(np.clip(lw,-60,10)); tob=tobs[fi]
        c=w*0.5*(1+erf((tob-ft)/(SIGMA*SQ)))
        acc+=np.bincount(fi,weights=np.where(np.isfinite(tob),c,0.),minlength=ND)
    return acc/len(reps)
# per-realization R, averaged
accR=np.zeros(ND); accN=np.zeros(ND); qsum=np.zeros(ND)
for s in range(NT):
    c,t=[np.asarray(x) for x in jax.lax.stop_gradient(tsim(track, jax.random.PRNGKey(s)))]
    tob=np.where(c>0,t,np.nan); R=R_at(tob)
    good=(c>0)&np.isfinite(t)
    accR+=np.where(good,R,0.); accN+=good; qsum+=c
Rpe=np.where(accN>0,accR/np.maximum(accN,1),np.nan); occ=qsum/np.maximum(accN,1)
m=accN>=3
print(f"# PER-REALIZATION R(t1) (should ~1)  lit {m.sum()}")
for lo,hi in [(0,1),(1,3),(3,8),(8,1e9)]:
    mm=m&(occ>=lo)&(occ<hi)
    if mm.sum()>20: print(f"#  occ[{lo:>2.0f},{hi:>4.0f}) n={mm.sum():5d}: mean R {np.nanmean(Rpe[mm]):.3f} median {np.nanmedian(Rpe[mm]):.3f}")
