"""Gradient quality (AD-vs-FD), FD Hessian, and CRB/Fisher resolution vs PhotonSim truth.
At theta (truth by default; ANCHOR=min uses the WT-scan biased argmin per param):
  - AD gradient (DiCE) averaged over keys, with per-key noise;
  - central finite-difference gradient (PARAM_SCALE steps) averaged over keys; AD<->FD cosine + ratios;
  - empirical Fisher F=E[g g^T] over keys -> CRB sigma_i=sqrt(diag(F^-1)) (normalized units) + corr matrix;
  - FD Hessian of the (key-averaged) gradient -> curvature, compared to F.
Usage: CUDA_VISIBLE_DEVICES=g [ANCHOR=truth|min] [NKEYS=16] python grad_crb_photonsim.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS
import recon_harness as H
np.set_printoptions(precision=3, suppress=True, linewidth=140)

NKEYS  = int(os.environ.get('NKEYS', '16'))
ANCHOR = os.environ.get('ANCHOR', 'truth')
WT, TAU = float(os.environ.get('WT', '0.03')), float(os.environ.get('TAU', '4.0'))
SC = np.array(H.PARAM_SCALE)

S = PS.setup(event=0, nphot=80_000, truth_source='photonsim')
theta_star = np.array(S['theta_star'])
loss = PS.make_loss(S, WT=WT, TAU=TAU)
full = lambda th, k: loss(th, k)[2]
gfn = jax.jit(jax.grad(lambda th, k: loss(th, k)[2]))
lfn = jax.jit(full)

theta = theta_star.copy()
if ANCHOR == 'min':                          # biased per-param argmin from the WT-scan (approx min)
    bias = np.array([150., 0.605, -0.663, -0.549, -0.003, -0.080, 2.57])
    theta = theta_star + bias
th = jnp.array(theta)
keys = [jax.random.PRNGKey(2000 + k) for k in range(NKEYS)]
print(f"ANCHOR={ANCHOR} WT={WT} TAU={TAU} NKEYS={NKEYS}  theta-truth={theta-theta_star}", flush=True)

# ---- AD gradient (normalized by PARAM_SCALE), per-key ----
Gad = np.stack([np.array(gfn(th, k)) * SC for k in keys])      # (NKEYS,7)
g_ad = Gad.mean(0); g_ad_se = Gad.std(0) / np.sqrt(NKEYS)

# ---- FD gradient (central, normalized) per-key, shared keys ----
def fd_grad(k):
    g = np.zeros(7)
    for i in range(7):
        hp = jnp.array(theta).at[i].add(0.5 * SC[i]); hm = jnp.array(theta).at[i].add(-0.5 * SC[i])
        g[i] = (float(lfn(hp, k)) - float(lfn(hm, k)))            # d loss per (0.5+0.5)=1 scale-unit
    return g
Gfd = np.stack([fd_grad(k) for k in keys])
g_fd = Gfd.mean(0)

cos = float(g_ad @ g_fd / (np.linalg.norm(g_ad) * np.linalg.norm(g_fd) + 1e-12))
print("\n== AD vs FD gradient (normalized units, key-averaged) ==")
print("  param   ", "  ".join(f"{n:>8s}" for n in H.PARAM_NAMES))
print("  g_AD    ", "  ".join(f"{v:8.3f}" for v in g_ad))
print("  g_AD_SE ", "  ".join(f"{v:8.3f}" for v in g_ad_se))
print("  g_FD    ", "  ".join(f"{v:8.3f}" for v in g_fd))
print("  ratio   ", "  ".join(f"{(g_ad[i]/g_fd[i]) if abs(g_fd[i])>1e-3 else np.nan:8.3f}" for i in range(7)))
print(f"  cosine(AD,FD) = {cos:.4f}   |g_AD|={np.linalg.norm(g_ad):.3f} |g_FD|={np.linalg.norm(g_fd):.3f}")

# alignment of the descent direction toward truth
to_truth = (theta_star - theta) / SC
if np.linalg.norm(to_truth) > 1e-9:
    align = float((-g_ad) @ to_truth / (np.linalg.norm(g_ad) * np.linalg.norm(to_truth) + 1e-12))
    print(f"  cosine(-g_AD, toward-truth) = {align:.4f}  (does descent point to truth?)")

# ---- empirical Fisher + CRB ----
F = (Gad.T @ Gad) / NKEYS
ev = np.linalg.eigvalsh(F)
Finv = np.linalg.pinv(F + 1e-6 * np.eye(7) * np.trace(F) / 7)
sig = np.sqrt(np.clip(np.diag(Finv), 0, None))                 # normalized-unit CRB sigma
Dinv = np.diag(1 / np.sqrt(np.clip(np.diag(F), 1e-12, None)))
corr = Dinv @ F @ Dinv
print("\n== Empirical Fisher F=E[gg^T] (normalized) ==")
print(f"  eigenvalues: {ev}")
print(f"  cond(F) = {ev[-1]/max(ev[0],1e-12):.3e}")
print("  CRB sigma (normalized): ", "  ".join(f"{n}={sig[i]:.3f}" for i, n in enumerate(H.PARAM_NAMES)))
print("  CRB sigma (physical):   ", "  ".join(f"{n}={sig[i]*SC[i]:.4g}{u}"
      for i, (n, u) in enumerate(zip(H.PARAM_NAMES, ['MeV','m','m','m','rad','rad','ns']))))
print("  Fisher correlation matrix (coupling):")
for i in range(7):
    print("   ", H.PARAM_NAMES[i][:5].ljust(6), "  ".join(f"{corr[i,j]:+.2f}" for j in range(7)))
np.savez(f'/tmp/gradcrb_{ANCHOR}.npz', g_ad=g_ad, g_fd=g_fd, F=F, corr=corr, sig=sig,
         theta=theta, theta_star=theta_star, cos=cos)
