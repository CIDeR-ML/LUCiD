"""COMBINATION check (disciplined, NO optimizer): profile the loss on the DEGENERATE (longitudinal lambda, t0)
plane for CHARGE-only, TIMING-only, and CHARGE+TIMING, over several PhotonSim events. The decisive test of
whether the generalized time-charge likelihood actually BREAKS the lon<->t0 degeneracy: timing-only should
show a degenerate VALLEY (lambda = c*t0), charge-only a t0-flat trough, and the COMBINATION a LOCALIZED well.

Per-term-optimal hyperparameters (from term_crb.py + timing_bias_events.py): charge THR=0 (all PMTs);
timing THR=0, sigma=1.5 (best for t0). Longitudinal pred grid is event-independent -> cached once; pred is
t0-independent -> t0 swept for free. Reports the 2D argmin (lon,t0) bias+scatter per loss; saves a heatmap.
Env: NPHOT NEV WC WT.  Usage: CUDA_VISIBLE_DEVICES=g python combo_profile.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.losses import segment_logsumexp
from lucid.geometry import generate_detector
np.set_printoptions(precision=3, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NEV = int(os.environ.get('NEV', '8'))
WC = float(os.environ.get('WC', '1.0')); WT = float(os.environ.get('WT', '1.0')); SIG = float(os.environ.get('SIG', '1.5'))
NW = float(os.environ.get('NW', '1.34')); K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '16'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
C = 0.299792; SQ2 = np.sqrt(2.0); SQ2PI = np.sqrt(2*np.pi); EPS = 1e-8
TGT_VTX = np.array([0.0, 0.0, 0.0]); TGT_POL = 0.6; TGT_AZ = 0.8
ts = np.array([1050.0, 0.0, 0.0, 0.0, TGT_POL, TGT_AZ, 0.0])

def _rod(v, ax, an):
    ax = ax/(np.linalg.norm(ax)+1e-12); return v*np.cos(an)+np.cross(ax, v)*np.sin(an)+ax*(ax@v)*(1-np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins'])/100.0; _, _, vt = np.linalg.svd(P-P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0@dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax/(np.linalg.norm(ax)+1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(TGT_VTX-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPHOT)
data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(pred); det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(pol, az): return np.array([np.sin(pol)*np.cos(az), np.sin(pol)*np.sin(az), np.cos(pol)])
d_true = dvec(ts[4], ts[5]); dummy = H.theta_to_track(jnp.array(ts))
predf = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key))

def t_decoupled(lw, ft, fi, tobs_sensor, hi, oc, sig):
    tobs = tobs_sensor[fi]; x = (tobs-ft)/sig
    valid = lw > -20.0; slw = jnp.where(valid, lw, -1e6); lwt = segment_logsumexp(slw, fi, ND); lwn = slw-lwt[fi]
    log_dens = -0.5*x**2-jnp.log(sig*SQ2PI); log1mF = jnp.log(jnp.clip(0.5*(1.0+jax.lax.erf(-x/SQ2)), 1e-12, 1.0))
    lf = segment_logsumexp(lwn+log_dens, fi, ND); l1mf = segment_logsumexp(lwn+log1mF, fi, ND)
    LF = -60.0; empty = lwt <= (LF+1.0); lf = jnp.maximum(lf, LF); l1mf = jnp.maximum(l1mf, LF)
    Ns = jax.lax.stop_gradient(jnp.exp(jnp.clip(jnp.maximum(lwt, LF), LF, 50.0)))
    return float(jnp.sum(jnp.where((hi & (oc > 0)) & (~empty), -lf-(Ns-1.0)*l1mf, 0.0)))

# longitudinal pred grid (event-independent): cache mu and (lw,ft,fi) per lambda
lam = np.linspace(-1.0, 1.0, 41); t0g = np.linspace(-4.0, 4.0, 41)
GRID = []
for l in lam:
    lw, ft, fi, q = predf(jnp.array(ts + np.array([0, d_true[0]*l, d_true[1]*l, d_true[2]*l, 0, 0, 0])), jax.random.PRNGKey(123))
    GRID.append((np.array(lw), np.array(ft), np.array(fi), np.array(q)))
print(f"# COMBO-PROFILE NEV={NEV} NPHOT={NPHOT} WC={WC} WT={WT} SIG={SIG}  grid {len(lam)}x{len(t0g)} (lon,t0)", flush=True)

def loss_planes(oc, ot, hi):
    # RAW -log-likelihoods (NO normalization) so charge + timing add with weight 1 each (== Fisher F_c+F_t).
    ocj = jnp.array(oc); hij = jnp.array(hi); Lc = np.zeros(len(lam)); LT = np.zeros((len(lam), len(t0g)))
    for i, (lw, ft, fi, q) in enumerate(GRID):
        Lc[i] = float(np.sum(q - oc*np.log(np.clip(q, EPS, None))))      # raw Poisson NLL
        lwj, ftj, fij = jnp.array(lw), jnp.array(ft), jnp.array(fi)
        for j, t0 in enumerate(t0g):
            LT[i, j] = t_decoupled(lwj, ftj, fij, jnp.array(ot)-t0, hij, ocj, SIG)
    return Lc[:, None] + 0*LT, LT      # charge plane (t0-flat), timing plane

def argmin2d(Z): i, j = np.unravel_index(np.argmin(Z), Z.shape); return lam[i]*100, t0g[j]
WCS = [1.0, 5.0, 15.0, 30.0, 60.0, 120.0]                       # charge-weight scan (timing weight = 1)
biasT = []; bias_wc = {w: [] for w in WCS}; charge_lon = []
PC0 = PT0 = None
for ev in range(NEV):
    pd = photon_data_for(ev); oc, ot = jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev), pd)); hi = oc > 0
    oc = np.array(oc); ot = np.array(ot); hi = np.array(hi)
    PC, PT = loss_planes(oc, ot, hi)
    if ev == 0: print(f"#   plane span: charge {np.ptp(PC):.0f}  timing {np.ptp(PT):.0f}", flush=True); PC0, PT0 = PC, PT
    biasT.append(argmin2d(PT)); charge_lon.append(argmin2d(PC*np.ones_like(PT))[0])
    for w in WCS: bias_wc[w].append(argmin2d(w*PC + PT))
    print(f"#   ev{ev:2d}  charge->lon{charge_lon[-1]:+6.1f}  timing->({argmin2d(PT)[0]:+6.1f},{argmin2d(PT)[1]:+5.2f})  " +
          "  ".join(f"WC{int(w)}->{argmin2d(w*PC+PT)[0]:+5.0f}" for w in WCS), flush=True)

cl = np.array(charge_lon); bT = np.array(biasT)
print(f"\n# (lon,t0) 2D argmin over {NEV} events  [cm, ns].  TRUTH=(0,0); charge-only lon: bias {cl.mean():+5.1f} scat {cl.std():4.1f}", flush=True)
print(f"#   TIMING only   lon {bT[:,0].mean():+6.1f}+-{bT[:,0].std():4.1f} | t0 {bT[:,1].mean():+5.2f}+-{bT[:,1].std():4.2f}   (degenerate valley, mismatch-tilted)", flush=True)
for w in WCS:
    b = np.array(bias_wc[w]); print(f"#   COMBO WC={w:5.0f}  lon {b[:,0].mean():+6.1f}+-{b[:,0].std():4.1f} | t0 {b[:,1].mean():+5.2f}+-{b[:,1].std():4.2f}", flush=True)
print(f"# degeneracy BREAKS when COMBO lon locks onto charge-only lon (~{cl.mean():+.0f}+-{cl.std():.0f}) and t0->~0.", flush=True)

fig, axes = plt.subplots(1, 3, figsize=(16, 5))
for ax, Z, ttl in zip(axes, [PT0, 30.0*PC0+PT0, PC0*np.ones_like(PT0)], ['TIMING only', 'CHARGE*30+TIMING', 'CHARGE only (t0-flat)']):
    ax.imshow(Z.T-Z.min(), origin='lower', aspect='auto', extent=[lam[0]*100, lam[-1]*100, t0g[0], t0g[-1]], cmap='viridis_r', vmax=np.percentile(Z-Z.min(), 60))
    ax.axhline(0, color='w', ls=':', lw=0.8); ax.axvline(0, color='w', ls=':', lw=0.8)
    ax.set_title(f'ev0  {ttl}'); ax.set_xlabel('longitudinal (cm)'); ax.set_ylabel('t0 (ns)')
plt.suptitle('Loss on the degenerate (longitudinal,t0) plane: timing=mismatch-tilted valley, charge=t0-flat trough, weighted-combination=localized', fontsize=11)
plt.tight_layout(); plt.savefig('combo_profile.png', dpi=110, bbox_inches='tight'); print(f"\n# saved combo_profile.png", flush=True)
