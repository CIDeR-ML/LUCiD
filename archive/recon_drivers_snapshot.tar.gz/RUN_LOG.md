# Alignment run log

One record per executed test. Every record carries the FULL canonical param block
(ALIGNMENT_PLAN.md §0.1) and the DELTA vs the previous run. Numbers are never quoted
without their params.

---

### A1/A2 — photon-iteration STEP unit test (per-step TRUE vs SIM expectation)   [2026-06-04]

PURPOSE: confirm `photon_iteration_sample` (TRUE, hard) and `photon_iteration_update_factors`
(SIM, expected) agree per step in expectation — detect deposit (A1) and continuing/survival (A2).

PARAMS:
  SOURCE   : none (direct step-function call; synthetic single photon at origin, dir +z, normal +z)
  TRACK θ  : n/a (unit test of the step, not a track)
  ENGINE   : BOTH photon_iteration_sample AND photon_iteration_update_factors, same inputs
  HIT_MODE : n/a (step level, below make_hits)
  TEMP     : n/a (step level, below overlap)
  K        : 1 (single step)
  MAXCELL  : n/a
  N_PHOT   : 1 photon × N_avg keys
  WLMODE   : n/a (scalar optics @400nm passed directly)
  SMEAR    : n/a ; TTS_NS=0
  PHYS     : config/SK_physics_config.json @ ref 400 nm
  OPTICS   : scatter_length=175.663 m, mie_scatter_length=9.886e3 m (WEAK MIE ON, from config medium),
             g=0.95, wall_refl=0.20, sensor_refl=0.20, absorption_length=400.422 m, qe n/a
  GRAD     : n/a (forward only)
  RNG      : key seed 0, folded by Dd; N_avg = 200000 keys
  DBG      : (none)
  c_med    : 0.299792458/1.34 m/ns  (value irrelevant to the alignment ratio)
  GRID     : Dd ∈ {0.5,1,2,4,8,16,24,32,40} m ; hit_sensor ∈ {False(wall), True(sensor)}

DELTA: (first logged run — baseline)

RESULT:
  A1 detect deposit  E[detect_prob·refl_atten]: max relErr TRUE-vs-SIM = 0.31% (MC floor 0.22%);
     both match analytic exp(-Dd/Ls)(1-r)exp(-Dd/La) to <0.3% across all Dd.
  A2 continuing       E[continuing_factor]:      max relErr = 1.09% (~5× floor, non-systematic, both signs).
  new_time agreed (not tabled; deterministic+stochastic parts consistent).
  wall vs sensor identical here (refl rates equal 0.20 in config).

VERDICT: ALIGNED. No unintended step-level mismatch. SIM = per-step expectation of TRUE; the only
  structural difference is hard (TRUE) vs continuous-weight (SIM), which cancels in expectation.
  NOTE: this is per-step; the K>=2 trajectory-survival question (mean-field STE vs hard) is A3, not here.

NEXT: A0 (propagation determinism across TRUE/SIM builds) + A3 (full per-PMT forward charge:
  current DiCE vs refactor-v2 STE vs sample-averaged, K∈{1,2,4,8}, Mie fully off).

---

### A0+A3 — full per-PMT forward CHARGE: DiCE vs refactor-v2 STE vs sample truth   [2026-06-04]

PURPOSE: A0 = propagation/emission/first-deposit engine-independence (K=1). A3 = how much the
photon-iteration engine changed from refactor-v2 (STE) to current (DiCE), and which matches truth.
METHOD NOTE: monkeypatching the shared custom_vjp mid-process collides with JAX's primal-jaxpr
cache (first A3 attempt gave false byte-identical DiCE==STE). Valid result is from align_a3b.py,
which runs each engine in a SEPARATE PROCESS and patches simulator.photon_iteration_update_factors_safe
to the refactor-v2 STE body BEFORE any build. (align_a3.py is superseded/buggy — kept for the record.)

PARAMS:
  SOURCE   : SIREN (particle='muon'), track below; SAME key per comparison
  TRACK θ  : energy 1050 MeV, pos (0,0,0) m, polar 0.6, azim 0.8, t0 0
  ENGINE   : expected predictors {DiCE(current), STE(refactor-v2 patched)} + sample truth, all use_expected_value
             (expected) except sample truth (use_expected_value=False)
  HIT_MODE : expected->per_photon (charge=4th return total_charge); truth->realistic (counts, Bernoulli QE)
  TEMP     : expected 0.1 (soft overlap); truth None (hard overlap)
  K        : {1, 8}
  MAXCELL  : 8
  N_PHOT   : 100000
  WLMODE   : True
  SMEAR    : apply_smearing=False ; TTS_NS=0
  PHYS     : config/SK_physics_config.json
  OPTICS   : L_scat 175.7, L_abs 400.4, wall_refl 0.20, sensor_refl 0.20, qe 0.226,
             *** mie_scatter_length FORCED 1e9 (MIE OFF) ***, g 0 (off)
  GRAD     : pos_grad_threshold=K, n_grad_iters=K (forward-irrelevant)
  RNG      : predictors avg NKG=4 keys (seeds 0..3); truth avg NKT=16 keys (seeds 0..15)
  c_med    : SPEED_OF_LIGHT_MATERIAL (wavelength medium)

DELTA vs A1/A2: now FULL pipeline (was step-only). Added: SIREN source; real track; overlap
  (temp 0.1 vs None); make_hits (per_photon vs realistic/Bernoulli); K=8; MAXCELL=8; MIE forced
  fully off (A1/A2 had weak config Mie 9886m); process-isolated engine patch.

RESULT:
  K=1  DiCE vs STE   : Δtot -0.3%  L1 0.27%  corr 1.00000   (== A0: engine-independent emission+prop+deposit)
       DiCE vs SAMP  : Δtot -0.2%  L1 35.3%  corr 0.957     (overlap soft-vs-hard + Bernoulli + 16-key noise)
  K=8  DiCE vs STE   : Δtot -4.6%  L1 9.54%  corr 0.99884   (== ENGINE change from refactor-v2, all multi-bounce)
       DiCE vs SAMP  : Δtot -1.1%  L1 44.1%  corr 0.953
       STE  vs SAMP  : Δtot +3.7%  L1 44.7%  corr 0.953
  totals: dice K1 3088.8 / K8 5134.8 ; ste K1 3097.0 / K8 5384.2 ; samp K1 3094.1 / K8 5190.8

VERDICT:
  - A0 confirmed: K=1 charge is engine-independent (corr 1.0).
  - Engine DID change from refactor-v2: ~4.6% total / 9.5% per-PMT L1 at K=8, entirely multi-bounce.
  - But the change is TOWARD truth: DiCE total gap to sampled truth -1.1% vs STE +3.7%. Current engine
    is the unbiased MC; refactor-v2 STE over-counts multi-bounce survival (mean-field double-count).
  => The photon-iteration engine is NOT a regression away from truth. "How did the fit get worse"
     is unlikely to be the engine. The remaining DiCE<->SAMPLE per-PMT 44% is the KNOWN overlap
     (soft 0.1 vs hard) + Bernoulli QE + truth MC noise -> isolate next (A4 overlap, A6 QE).

NEXT: A4 — drive predictor temperature 0.30->0.01 vs hard truth; confirm soft-overlap explains the
  bulk of the per-PMT L1 and quantify the residual at temp=0.1 (the value recon uses).

---

### A4 — overlap soft-vs-hard (per-PMT charge vs hard truth)   [2026-06-04]

PURPOSE: isolate the soft-overlap contribution to the SIM<->TRUE per-PMT L1 by sweeping the
predictor temperature None(hard)->0.30 vs the hard sample truth.

PARAMS: identical to A3 EXCEPT predictor temperature swept {None,0.02,0.05,0.10,0.30}; K=8 only;
  truth NKT=16 (hard, MIE off, SIREN source, same track, MAXCELL=8). Predictor NKG=4.
DELTA vs A3: temperature is now the swept variable (A3 fixed it at 0.1); added truth half-vs-half
  noise-floor reference; dropped K=1.

RESULT:
  truth K=8 hard NOISE FLOOR (half-vs-half, 16 keys): L1 70.26%  corr 0.8232   <-- truth is VERY noisy per-PMT
  temp None(hard): tot -0.1%  L1 44.25%  corr 0.9526
  temp 0.02      : tot -0.2%  L1 44.22%  corr 0.9527
  temp 0.05      : tot -0.6%  L1 44.15%  corr 0.9528
  temp 0.10      : tot -1.1%  L1 44.05%  corr 0.9530
  temp 0.30      : tot -2.7%  L1 43.75%  corr 0.9538

VERDICT: L1 is FLAT in temperature (44.25% hard -> 43.75% soft-0.30); it does NOT drop as overlap
  hardens. So soft overlap is NOT the per-PMT L1 driver. The 44% L1 is dominated by TRUTH MC NOISE
  (half-vs-half floor 70% at 8 keys/half, ~0.5 PE/PMT hard Bernoulli). Total charge matches to 0.1%
  at hard overlap. Soft overlap only shifts total charge slightly (-2.7% at temp 0.30 = ring spill).
  => The SIM<->TRUE per-PMT charge difference is truth stochasticity, not a forward mismatch.
NEXT: A4b — average truth over NKT={8..256}; confirm L1(pred,truth) ~ 1/sqrt(NKT) and extrapolate
  the NKT->inf forward floor (proves predictor == correct truth mean).

---

### A4b — truth-key convergence: is the SIM<->TRUE per-PMT charge L1 pure MC noise?   [2026-06-04]

PURPOSE: prove the predictor is the correct mean of the truth by averaging truth over NKT={8..256}
and checking L1(pred,truth) ~ 1/sqrt(NKT) toward a small forward floor.
PARAMS: identical to A3/A4 (SIREN, track, K=8, MAXCELL=8, MIE off, temp 0.1 predictor). Predictor
  reference averaged NREF=16 keys; truth averaged cumulatively NKT in {8,16,32,64,128,256}.
DELTA vs A4: predictor temperature fixed back to 0.1; NKT now the swept variable up to 256;
  added predictor self-noise reference and half-vs-half truth floor at each NKT.

RESULT:
  predictor(temp0.1) self half-vs-half L1 = 10.49% over 16 keys (reference is smooth, ~5% mean-noise)
  NKT   L1(pred,truth)  corr    Δtot    truth half-vs-half floor
    8     58.63%        0.9214  +0.8%   91.50%
   16     43.48%        0.9558  +1.0%   70.26%
   32     30.72%        0.9772  +1.2%   55.14%
   64     21.70%        0.9882  +1.5%   40.99%
  128     15.94%        0.9934  +1.2%   29.12%
  256     11.99%        0.9962  +1.1%   20.87%
  L1*sqrt(NKT) ~ const (166,174,174,174,181,193) => L1 = C/sqrt(NKT) + small floor.
  Fit L1^2 = a/NKT + b^2 -> b ~ 6% per-PMT (and predictor's own NREF=16 noise ~5% accounts for most of it).

VERDICT: CONFIRMED. The SIM<->TRUE per-PMT charge difference is TRUTH MONTE-CARLO NOISE (1/sqrt(NKT)),
  extrapolating to a <=6% forward floor that is mostly the predictor's residual sampling noise. The
  predictor == the correct truth mean; total charge agrees ~1%, corr -> 0.996. FORWARD CHARGE MODEL
  IS ALIGNED (TRUE vs SIM). Recon implication: a single event (NKT=1) carries >58% per-PMT charge noise;
  the predictor is the smooth mean => per-event fit scatter is photon statistics, NOT forward mismatch
  (consistent with the charge-observable CRB ~1cm vs realized ~15cm being per-event Poisson, not bias).
NEXT: A7 — first-arrival TIMING alignment (TRUE hard segment_min +/- TTS  vs  SIM soft order-stat),
  the second observable (drives dir/t0); then Part B (PhotonSim vs SIREN emission).

---

### A7 — first-arrival TIMING: SIM soft-min vs TRUE hard segment_min (+/- TTS)   [2026-06-04]

PURPOSE: check the timing observable aligns; quantify the TTS-smearing knob.
PARAMS: SIREN source, track θ as A3, K=8, MAXCELL=8, MIE off. SIM = hit_mode 'aggregated'
  (make_hits_simulation soft-min, make_hits temperature 0.1), averaged 4 keys. TRUE = hit_mode
  'realistic' hard segment_min, NKT=16. TTS_NS run at {0, 2.5}. Δt = SIM_softmin - TRUE_hardmin [ns],
  over PMTs lit in both, bucketed by TRUE per-PMT charge (occupancy).
DELTA vs A4b: observable is now first-arrival TIME (was charge); SIM hit_mode aggregated (was per_photon);
  added TTS_NS sweep {0,2.5}.

RESULT:
  TTS=0.0  ALL median -2.65 mean -29.7 std 56.4 ; occ[2,5) med -4.09 ; occ>=5 med -1.73 mean -3.12 std 10.6
  TTS=2.5  ALL median -3.17 mean -29.4 std 56.6 ; occ[2,5) med -5.77 ; occ>=5 med -0.59 mean -1.84 std 11.0
  TTS effect at occ>=5: median -1.73 -> -0.59 ns  => TTS smear pulls TRUE first-arrival ~1.1 ns EARLIER.

VERDICT: well-lit PMTs (occ>=5) AGREE to a small known soft-min(temp0.1) early bias (median ~ -1 to -2 ns,
  std ~11 ns = per-event order-stat noise). Low-occupancy PMTs are dominated by few-photon order-statistic
  noise (mean/std huge) — same stochastic floor as charge. TTS is a clean ~1ns-earlier knob.
  CAVEAT: this uses the 'aggregated' soft-min mode; RECON uses per-photon first_arrival_nll (tau=1.5),
  so the -1.7ns soft-min bias is mode-specific, NOT a fundamental TRUE/SIM disagreement. A loss-level
  timing alignment (per-photon time distribution) is the proper deeper check, deferred.
NEXT: PART B — PhotonSim vs SIREN emission (origins/dirs/times/wavelengths/yield + detector coverage),
  the other half: where a real TRUE-vs-SIM difference (mean-field SIREN vs per-event PhotonSim) can live.

---

### PART B (B1-B3) — PhotonSim vs SIREN EMISSION (origins, cone, yield)   [2026-06-04]

PURPOSE: compare the two emission models' raw photons in the track frame (longitudinal/transverse/
Cherenkov cone) — the "other half" (mean-field surrogate vs per-event GEANT4).
PARAMS:
  SOURCE   : PhotonSim ROOT data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root, NEV=5 events
             vs SIREN (muon model via unpack_photonsim_params/SIRENPredictor), NPHOT_SIREN=200000
  TRACK    : SIREN track_origin (0,0,0) dir +z; PhotonSim track frame from SVD of origins (per event)
  ENERGY   : 1050 MeV both
  (forward pipeline NOT involved here — emission only)
DELTA vs A7: switched from forward-pipeline alignment to raw EMISSION comparison (no propagation/overlap/
  make_hits). New source: direct SIREN ray generation + raw PhotonSim photons.

RESULT (track-frame emission):
  longitudinal s:  PhotonSim mean 2.209 P95 4.366 m  |  SIREN mean 2.257 P95 4.425 m   -> MATCH (~2%)
  Cherenkov cone:  PhotonSim cosθ 0.7350           |  SIREN cosθ 0.7295  (θc cosθ=0.746) -> MATCH (~0.7%)
  transverse r:    PhotonSim mean 0.0270 m         |  SIREN 0.0000 m (pure line source) -> small real diff (2.7cm)
  yield:           PhotonSim ~357144 photons/event (raw optical); SIREN normalized via tot_n_photons power law

VERDICT: SIREN reproduces the PhotonSim emission GEOMETRY well — longitudinal profile (~2%) and Cherenkov
  cone (~0.7%) match; only a minor 2.7cm transverse line-source idealization. The CHARGE-relevant emission
  (where photons go) is aligned. Open: emission TIME model (B4, predict_t0) and per-event stochastic spread
  (B7-B9) — the timing side.

---

### PART B (B4 corrected) — emission TIME model: predict_t0(distance) vs PhotonSim t_emit   [2026-06-04]

PURPOSE: SIREN path adds t0=predict_t0(distance_to_vertex,energy) (NOT emission time 0 — my first B4
panel mis-referenced it). Check predict_t0 reproduces PhotonSim t_emit(distance) and quantify omitted jitter.
PARAMS: PhotonSim NEV=5 (1,785,721 photons), ENERGY=1050; SIREN t0_params via unpack_t0_params('muon','water');
  distance-to-vertex binned; compare de-meaned trends + within-bin residual spread.
DELTA vs B1-B3: observable = emission TIME vs distance (was spatial/cone); added SIREN predict_t0 baseline.

RESULT:
  PhotonSim t_emit overall: mean 7.47 ns, std 4.50 ns.
  distance-dependence de-meaned: PhotonSim -7.76..7.88 ns ; predict_t0 -7.69..7.88 ns ; TREND RMSE 0.02 ns.
  within-distance-bin residual (stochastic, NOT captured by deterministic t0): median 0.12 ns.

VERDICT: SIREN's predict_t0(distance) captures the FULL 4.5 ns emission-time structure to 0.02 ns trend
  RMSE; only 0.12 ns per-photon jitter omitted (negligible vs 2.5 ns TTS). Emission-time model ALIGNED.
  (Supersedes the "SIREN emit t=0" annotation in _alignB_emission.png — that panel compared the wrong ref.)

=== PART B SUMMARY: SIREN emission matches PhotonSim in ALL dimensions — longitudinal ~2%, Cherenkov
    cone ~0.7%, emission-time trend 0.02 ns (0.12 ns jitter omitted); only a 2.7 cm transverse line-source
    idealization. Combined with Part A (forward pipeline aligned), there is NO unexplained TRUE-vs-SIM
    forward mismatch. Remaining differences are intentional knobs (overlap, Bernoulli QE, TTS) or
    irreducible per-event photon-counting noise. => the recon regression is NOT in the forward model. ===

---

### B7 — detector COVERAGE: PhotonSim vs SIREN through the SAME hard truth pipeline   [2026-06-04]

PURPOSE: the residual map (H6). Feed PhotonSim photons (is_data=True) and SIREN photons (is_data=False
sample) through the IDENTICAL hard pipeline; compare per-PMT charge MEANS. Does SIREN-mean reproduce
PhotonSim-mean detector response?
PARAMS: target track θ as A3; both temperature=None (hard), realistic Bernoulli QE, K=8, MAXCELL=8,
  MIE off, wavelength_mode. PhotonSim: NEV=20 events x 2 keys (rotated/translated onto target track, SVD
  frame) = 40 ev-keys. SIREN: NKT=40 keys. NPHOT=100000.
DELTA vs B4: detector-level (full pipeline) instead of raw emission; both sources now go through make_hits.

RESULT:
  PhotonSim mean tot 5114.2 (40 ev-keys) | SIREN mean tot 5184.0 (40 keys) | Δtot +1.4%
  per-PMT L1 37.96%  corr 0.9416  litPMT 11001
  NOISE CONTEXT: A4b smooth-vs-truth L1 was 21.7% @64 keys; two INDEPENDENTLY-noisy 40-key means give
  ~sqrt(2)*27% ~ 38% => the 37.96% L1 is ENTIRELY combined MC noise of the two finite means, NOT surrogate error.
  Figure _alignB7_coverage.png: per-PMT scatter (corr 0.94, noise-limited) + Cherenkov ring profile overlay.

VERDICT: SIREN-mean == PhotonSim-mean at the detector to +1.4% total (only real residual; consistent with
  yield + 2.7cm transverse idealization). Per-PMT agreement is MC-noise-limited. ANSWERS H6: the SIREN mean
  reproduces the PhotonSim mean coverage; a single PhotonSim event differs from it ONLY by that event's
  photon-counting noise = the irreducible recon floor, NOT a model mismatch.

=== ALIGNMENT CAMPAIGN COMPLETE (charge + emission). Forward model TRUE<->SIM is ALIGNED end-to-end.
    The recon regression is NOT the forward simulation -> next lever = LOSS/OPTIMIZER. Remaining optional:
    A5 MAXCELL, A6 QE unit, A8 smear, A10 wavelength (minor confirmations); B9 per-event stochasticity
    quantification; loss-level timing alignment (per-photon first_arrival_nll). ===

---

### A5/A6/A8/A10/B9 — remaining rungs (completeness)   [2026-06-04]

Common params: SK geom/physics, 1050 MeV muon track θ as A3, K=8, MIE off (L_M=1e9), SIREN source
(except A6 synthetic, B9 PhotonSim+SIREN). Each run's deltas noted inline.

A6 (QE unit, synthetic flat arrays N=400000 ND=120, M=64 Bernoulli keys, qe=0.226, non-trivial qe_corrections):
  Bernoulli-avg total 54103 vs weight 54115 (Δtot -0.02%); per-sensor relErr mean 0.35% max 1.44%; corr 0.99990.
  => Bernoulli QE (TRUE) == multiplicative QE weight (SIM) in expectation; qe_corrections identical. ALIGNED.

A5 (MAXCELL convergence, SIM predictor temp0.1 NKG=4, max_sensors_per_cell swept):
  mc 4: 4994.6 | 8: 5134.8 (+2.8%) | 16: 5249.5 (+2.2%) | 32: 5350.4 (+1.9%)  [litPMT 11096 all]
  => overlap truncation NOT converged at 32 (~2%/doubling); mc4 undercounts ~7% vs mc32. SHARED by TRUE+SIM
     (no TRUE-SIM mismatch) but absolute charge is MAXCELL-dependent — keep TRUE/SIM on the same MAXCELL.

A8 (per-sensor SK smear toggle, TRUE realistic NKT=24, apply_smearing False vs True, TTS_NS=0):
  total charge Δtot +0.0% (gain smear mean-preserving), per-PMT charge corr 1.0000 mean|Δq|/q 0.40%;
  first-arrival time Δ(smear-nosmear) median -0.002 ns std 0.311 ns.
  => SK smear is a small mean-preserving knob (charge ~0, time +0.31ns jitter) the SIM omits. Quantified.

A10 (wavelength_mode on/off, SIM NKG=4 + TRUE NKT=16):
  wl=True : SIM 5134.8  TRUE 5190.8  (SIM-vs-TRUE Δtot -1.1%)
  wl=False: SIM 41799.1 TRUE 42226.7 (SIM-vs-TRUE Δtot -1.0%)
  => λ physics applied IDENTICALLY TRUE vs SIM (Δtot consistent on/off). NOTE scalar mode ~8x total charge
     (different QE/spectrum normalization) — recon uses wl=True. ALIGNED.

B9 (per-event stochasticity, PhotonSim NEV=30 events vs SIREN NKT=30 keys, hard pipeline):
  PhotonSim: total-charge event-to-event fluct 1.19% ; median per-PMT fractional spread 238%.
  SIREN    : total-charge key-to-key   fluct 3.12% ; median per-PMT fractional spread 374%.
  *** longitudinal charge-centroid (proj on track axis) spread: PhotonSim 0.161 m (16 cm) ; SIREN 0.228 m. ***
  => the per-event longitudinal charge-centroid fluctuates 16 cm = THE ~15 cm longitudinal recon floor,
     now shown to be irreducible per-event PHOTON STATISTICS (not model mismatch). SIREN injects somewhat
     MORE variance (23 cm, fewer effective photons + DiCE noise) than real GEANT4 event-to-event.

=== ALL PLANNED RUNGS COMPLETE (A0-A10, B1-B9). Forward model TRUE<->SIM ALIGNED end-to-end; every
    residual is an intentional knob or per-event photon noise. B9 ties the 16cm longitudinal floor to
    per-event statistics. Lever for the recon regression = LOSS/OPTIMIZER, not the forward simulation. ===
