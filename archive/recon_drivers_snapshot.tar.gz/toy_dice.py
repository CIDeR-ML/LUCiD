"""TOY 1 — score-function vs pathwise vs detached for a reflection-like chain.
Chaotic circle map (Chirikov standard map): phi_{k+1} = phi_k + omega + Kc*sin(phi_k) + sigma*eps_k.
- bounded state (circle), per-step sensitivity 1+Kc*cos(phi) can be >1 -> pathwise dphi_K/dphi_0 = prod -> EXPLODES.
- sigma*eps = the 'diffuse' sampled step (the score-function handle).
- theta enters at phi_0 (the 'emission angle'); the Kc*sin term is the position-dependent 'normal/reflection'.
Estimators of d E[L]/dtheta, L = sum_k G(phi_k) (von Mises bump):
  PATHWISE  : jax.grad (reparam) -> exact, per-sample ~ prod(1+Kc cos) -> variance EXPLODES with K.
  DETACHED  : sg() the Kc*sin term (= engine's normal detach) -> per-step deriv=1, NO compounding but BIASED.
  SCORE     : L * d/dtheta log p(phi_1 | phi_0=theta)  (REINFORCE, theta only at phi_0) -> ONE factor, unbiased,
              variance grows LINEARLY (L is O(K), score is O(1)). No compounding. = the DiCE add-in we want.
Usage: python toy_dice.py
"""
import jax, jax.numpy as jnp, numpy as np
Kc = 1.2; OM = 0.6; SIG = 0.35; T = 1.5; WID = 2.0; THETA = 1.0; N = 60000
def G(phi): return jnp.exp(jnp.cos(phi - T) / WID)
def step(phi, e, detach):
    drift = Kc * jnp.sin(phi); drift = jax.lax.stop_gradient(drift) if detach else drift
    return phi + OM + drift + SIG * e
def chain(theta, eps, detach=False):
    phi = theta; L = 0.0; phi1 = None
    for k in range(eps.shape[0]):
        phi = step(phi, eps[k], detach); L = L + G(phi)
        if k == 0: phi1 = phi
    return L, phi1
print(f"# TOY DICE  Kc={Kc} OM={OM} SIG={SIG}  N={N}", flush=True)
print(f"#  K |   truth  | PATHWISE mean/std        | DETACHED mean/std (BIAS) | SCORE mean/std", flush=True)
for K in [2, 4, 8, 12, 16]:
    eps = np.asarray(jax.random.normal(jax.random.PRNGKey(K), (N, K)))
    EL = lambda th: float(jnp.mean(jax.vmap(lambda e: chain(th, e)[0])(jnp.asarray(eps))))
    truth = (EL(THETA + 1e-3) - EL(THETA - 1e-3)) / 2e-3
    gpath = np.asarray(jax.vmap(lambda e: jax.grad(lambda th: chain(th, e)[0])(THETA))(jnp.asarray(eps)))
    gdet = np.asarray(jax.vmap(lambda e: jax.grad(lambda th: chain(th, e, True)[0])(THETA))(jnp.asarray(eps)))
    mu1 = THETA + OM + Kc * np.sin(THETA); dmu1 = 1 + Kc * np.cos(THETA)
    def parts(e):
        L, phi1 = chain(THETA, e); return L, (phi1 - mu1) / SIG**2 * dmu1
    Ls, scores = [np.asarray(a) for a in jax.vmap(parts)(jnp.asarray(eps))]
    gs = Ls * scores                                              # naive score
    b = Ls.mean(); gs_b = (Ls - b) * scores                       # constant-baseline score (unbiased, lower var)
    # CONTROL VARIATE: the DETACHED pathwise gradient (biased, low-var, correlated) -> subtract its centered part.
    c = np.cov(gs_b, gdet)[0, 1] / (np.var(gdet) + 1e-12)
    g_cv = gs_b - c * (gdet - gdet.mean())                        # unbiased (E[gdet-mean]=0), lower var if correlated
    print(f"#  {K:2d} | {truth:+6.3f} | path {gpath.std():6.3f} | det {gdet.mean()-truth:+5.1f}b/{gdet.std():4.2f} | "
          f"score {gs.std():6.1f} | +base {gs_b.mean():+5.2f}/{gs_b.std():5.2f} | +CV {g_cv.mean():+5.2f}/{g_cv.std():5.2f}", flush=True)
print(f"# READ: detached BIASED (grows w/K); pure score unbiased huge-std; +baseline 25x less; +control-variate", flush=True)
print(f"#       (detached as CV) approaches pathwise std while staying UNBIASED. That is the DiCE add-in to build.", flush=True)
