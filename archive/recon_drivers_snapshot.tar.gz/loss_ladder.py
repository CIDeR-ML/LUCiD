"""BIAS-DECOMPOSITION LADDER — attribute the loss-surface bias to each part, exactly.

MODEL (always): predictor = expected engine + soft overlap 0.1 + per_photon + binned Poisson first-arrival loss.
TRUTH rungs (add ONE difference at a time):
  R0 self    : obs SAMPLED from the predictor's OWN first-arrival distribution (R-inversion) + Poisson charge.
               -> MUST be ~0 if the loss form is correct (pure loss validation; no engine/overlap/hit-mode diff).
  R1 exp_soft: expected engine + SOFT overlap 0.1 + realistic (Bernoulli QE + hard min) + TTS.  diff = QE/hit-mode.
  R2 exp_hard: expected engine + HARD overlap None + realistic + TTS.                            R2-R1 = OVERLAP.
  R3 smp_hard: SAMPLE engine + hard overlap + realistic + TTS.                                   R3-R2 = ENGINE.
TTS=2.5 throughout (per-photon). Per-event JOINT argmin x, energy. K=8 MAXCELL=16.
Env: NPHOT NKEYS NEV SIGMA DELTA NGRID.  Usage: CUDA_VISIBLE_DEVICES=g python loss_ladder.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '16')); NEV = int(os.environ.get('NEV', '20'))
SIGMA = float(os.environ.get('SIGMA', '2.5')); DELTA = float(os.environ.get('DELTA', '1.0')); NGRID = int(os.environ.get('NGRID', '400')); K = 8
PS = np.asarray(H.PARAM_SCALE); theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.asarray(theta_true)); SQ = float(np.sqrt(2.0))
MC = int(os.environ['MAXCELL'])
print(f"# BIAS LADDER  NPH={NPH} NKEYS={NKEYS} NEV={NEV} SIGMA={SIGMA} DELTA={DELTA} K={K} MC={MC} TTS={os.environ['TTS_NS']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
def mk(uev, hm, **kw): return setup_event_simulator(H.GEOM, n_photons=NPH, K=K, hit_mode=hm, max_sensors_per_cell=MC,
    physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True, is_data=False, **kw)
exp_soft = mk(True, 'realistic', temperature=0.1, use_expected_value=True)
exp_hard = mk(True, 'realistic', temperature=None, use_expected_value=True)
smp_hard = mk(True, 'realistic', temperature=None, use_expected_value=False)
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

def log1mexp(a):
    a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
def make(oc, ot, hit):
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hit = jax.lax.stop_gradient(hit)
    def loss(theta, key):
        log_w, ft, fi, tot = pred(H.theta_to_track(theta), key)
        w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - theta[6])[fi]
        def Rof(tt): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf((tt - ft) / (SIGMA * SQ))), fi, num_segments=ND)
        R_lo = Rof(tobs - DELTA / 2); dR = jnp.maximum(Rof(tobs + DELTA / 2) - R_lo, 1e-12)
        time = jnp.sum(jnp.where(hit & (dR > 1e-9), R_lo - log1mexp(-dR), 0.0)); mu = jnp.maximum(tot, 1e-8)
        return jnp.sum(mu - oc * jnp.log(mu)) + time
    return loss
def argmin(lj, i, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts)
    c = np.array([np.mean([float(lj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

rungs = [('R1 exp_soft', exp_soft), ('R2 exp_hard', exp_hard), ('R3 smp_hard', smp_hard)]
res = {nm: {'x': [], 'e': []} for nm, _ in rungs}
for ev in range(NEV):
    for nm, sim in rungs:
        oc, ot = jax.lax.stop_gradient(sim(track, jax.random.PRNGKey(7 * ev + 1))); hit = oc > 0; ot = jnp.where(hit, ot, 0.0)
        lj = jax.jit(make(oc, ot, hit)); res[nm]['x'].append(argmin(lj, 1)); res[nm]['e'].append(argmin(lj, 0))
    print(f"#   ...event {ev} done", flush=True)
print(f"# === JOINT argmin bias +/- SE over {NEV} events ===", flush=True)
prevx = preve = 0.0
for nm, _ in rungs:
    x = np.array(res[nm]['x']); e = np.array(res[nm]['e'])
    print(f"#  {nm:12s} x {x.mean():+.3f} +/-{x.std()/np.sqrt(NEV):.3f} (incr {x.mean()-prevx:+.3f}) | "
          f"energy {e.mean():+6.1f} +/-{e.std()/np.sqrt(NEV):.1f} (incr {e.mean()-preve:+6.1f})", flush=True)
    prevx, preve = x.mean(), e.mean()
print(f"# READ: R0 ~0 => loss correct. R1 = QE/hit-mode. R2-R1 = overlap. R3-R2 = engine. Each incr = that part's bias.", flush=True)
