"""BINNED Poisson first-arrival likelihood (well-conditioned) — integrate the pdf over a TTS-width bin so
the loss uses ONLY the smooth survival R (CDF), never the ill-conditioned point rate -log r.

P(first arrival in [t-D/2, t+D/2]) = exp(-R(t-D/2)) - exp(-R(t+D/2)),  R(t)=sum_j w_ij Phi((t-tau_ij)/sigma)
NLL_i = -log P_i = R_lo - log1mexp(-(R_hi-R_lo))   [stable], joint with RAW Poisson charge.
Checks AD=FD (all params, profile slope) AND per-event bias. K=8, MAXCELL=16, TTS=2.5.
Env: TTS_NS NPHOT NKEYS NEV SIGMA DELTA MODE(adfd|bias).  Usage: CUDA_VISIBLE_DEVICES=g MODE=adfd python loss_poisfa_binned.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '48')); NEV = int(os.environ.get('NEV', '12'))
SIGMA = float(os.environ.get('SIGMA', '2.5')); DELTA = float(os.environ.get('DELTA', '2.5')); MODE = os.environ.get('MODE', 'adfd')
K = 8; PS = np.asarray(H.PARAM_SCALE); PN = H.PARAM_NAMES; theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0, 0, 0.0175, 0, 0.5]); theta0 = theta_true + delta
SQ = float(np.sqrt(2.0))
print(f"# BINNED Poisson FA  MODE={MODE} TTS={os.environ['TTS_NS']} SIGMA={SIGMA} DELTA={DELTA} NKEYS={NKEYS} K={K} MC={os.environ['MAXCELL']}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); tsim = H.build_truth_sim(K=K, n_photons=NPH)
ND = H.num_detectors(pred)

def log1mexp(a):  # log(1 - exp(a)), a < 0; clamp input for BOTH branches so neither is NaN (where double-NaN safe)
    a = jnp.minimum(a, -1e-7)
    return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
def make(oc, ot, hit, wt):
    oc = jax.lax.stop_gradient(oc); ot = jax.lax.stop_gradient(ot); hit = jax.lax.stop_gradient(hit)
    def loss(theta, key):
        log_w, ft, fi, tot = pred(H.theta_to_track(theta), key)
        w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - theta[6])[fi]
        def Rof(tt): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf(((tt - ft)) / (SIGMA * SQ))), fi, num_segments=ND)
        R_lo = Rof(tobs - DELTA / 2); R_hi = Rof(tobs + DELTA / 2)
        dR = jnp.maximum(R_hi - R_lo, 1e-12)
        nll = R_lo - log1mexp(-dR)                                # = -log P(first in bin)
        usable = hit & (dR > 1e-9)
        time = jnp.sum(jnp.where(usable, nll, 0.0))
        mu = jnp.maximum(tot, 1e-8)
        return jnp.sum(mu - oc * jnp.log(mu)) + wt * time
    return loss
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]

if MODE == 'adfd':
    cs, ts = [], []
    for s in range(24):
        c, t = jax.lax.stop_gradient(tsim(H.theta_to_track(jnp.asarray(theta_true)), jax.random.PRNGKey(10000 + s)))
        cs.append(np.asarray(c)); ts.append(np.where(np.asarray(c) > 0, np.asarray(t), np.nan))
    oc = jnp.asarray(np.mean(cs, 0)); hit = jnp.asarray(np.mean(cs, 0) > 1e-6); ot = jnp.asarray(np.nan_to_num(np.nanmean(ts, 0)))
    lossj = jax.jit(make(oc, ot, hit, 1.0)); gradj = jax.jit(jax.grad(make(oc, ot, hit, 1.0)))
    gAD = np.stack([np.asarray(gradj(jnp.asarray(theta0), k)) for k in keys]).mean(0)
    print(f"#  param grp     AD        profile slopes w1/2/4        AD/coarse  smooth?", flush=True)
    for i, nm in enumerate(PN):
        grp = 'S' if nm in ('energy', 't0') else 'G'
        sv = np.linspace(-6 * PS[i], 6 * PS[i], 25); j0 = 12; dg = sv[1] - sv[0]
        prof = np.array([np.mean([float(lossj(jnp.asarray(theta0 + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
        sl = {w: (prof[j0 + w] - prof[j0 - w]) / (2 * w * dg) for w in [1, 2, 4]}
        kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
        tag = 'KINKY' if kinky else f'{gAD[i]/(sl[4]+1e-30):+.2f}'
        print(f"#  {nm:6s} {grp}  {gAD[i]:+11.2f}   {sl[1]:+9.1f} {sl[2]:+9.1f} {sl[4]:+9.1f}   {tag}", flush=True)
else:
    def argmin(lj, i, span=4.0, npts=15):
        sv = np.linspace(-span * PS[i], span * PS[i], npts)
        c = np.array([np.mean([float(lj(jnp.asarray(theta_true + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
        j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
        return (-b / (2 * a) if a > 0 else sv[j])
    for nm, wc, wt in [('charge', 1.0, 0.0), ('joint', 1.0, 1.0)]:
        bx, be = [], []
        for ev in range(NEV):
            oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(5000 + ev))
            lj = jax.jit(make(oc, ot, hit, wt)); bx.append(argmin(lj, 1)); be.append(argmin(lj, 0))
        bx, be = np.array(bx), np.array(be)
        print(f"#  {nm:6s}  x bias {bx.mean():+.3f} std {bx.std():.3f} m | energy bias {be.mean():+6.1f} std {be.std():.1f} MeV", flush=True)
