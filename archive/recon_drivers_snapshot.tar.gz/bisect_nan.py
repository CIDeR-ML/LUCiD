"""Bisect the source->propagate->step->make_hits->loss pipeline (with the step's NaN-sanitizer custom_vjp
BYPASSED) to find which downstream quantity's gradient wrt the track params goes NaN.
Usage: CUDA_VISIBLE_DEVICES=g python bisect_nan.py
"""
import jax, jax.numpy as jnp, numpy as np
import lucid.simulation.simulator as SIM
from lucid.simulation.photon_step import photon_iteration_update_factors as RAW
SIM.photon_iteration_update_factors_safe = RAW                 # bypass sanitizer -> see the real NaN
import recon_ps_setup as PS, recon_harness as H
from lucid.losses import first_arrival_nll
import os
NPH = int(os.environ.get('NPH','80000'))
S = PS.setup(event=0, nphot=NPH, truth_source='siren', pred_temperature=0.1, truth_key=0)
ts = jnp.array(S['theta_star']); pred = S['pred']; oc = S['oc']; hitf=S['hit']; otf=S['ot']; ND=S['ND']
k = jax.random.PRNGKey(0)
def fin(x): return bool(np.isfinite(np.array(x)).all())

def G(name, fn):
    try:
        g = jax.grad(fn)(ts, k)
        print(f"  grad[{name:24}] finite={fin(g)}")
    except Exception as e:
        print(f"  grad[{name:24}] FAILED {type(e).__name__}: {str(e)[:60]}")

print("=== gradient finiteness of intermediate quantities (raw step, no sanitizer) ===")
G("sum total_charge q",   lambda th,kk: jnp.sum(pred(H.theta_to_track(th),kk)[3]))
G("sum log(q+eps)",       lambda th,kk: jnp.sum(jnp.log(pred(H.theta_to_track(th),kk)[3]+1e-8)))
G("charge NLL",           lambda th,kk: (lambda q: jnp.sum(q-oc*jnp.log(q+1e-8)))(pred(H.theta_to_track(th),kk)[3]))
G("sum log_w",            lambda th,kk: jnp.sum(jnp.where(pred(H.theta_to_track(th),kk)[0]>-20, pred(H.theta_to_track(th),kk)[0], 0.0)))
G("sum flat_times*w",     lambda th,kk: (lambda o: jnp.sum(jnp.where(o[0]>-20, o[1]*jnp.exp(jnp.clip(o[0],-20,5)),0.0)))(pred(H.theta_to_track(th),kk)))
def time_nll(th,kk):
    lw,ft,fi,_=pred(H.theta_to_track(th),kk)
    return jnp.sum(jnp.where(hitf, first_arrival_nll(lw,ft,fi,otf-th[6],1.0,ND),0.0))
G("time NLL",             time_nll)
