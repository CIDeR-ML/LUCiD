"""Probe the returned photon_weights of OLD vs density-x-DiCE get_rays at the SOURCE level,
to understand the occupancy scale (sum of weights is what feeds photon_intensities)."""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
from lucid.sources.siren_rays import photonsim_differentiable_get_rays
from lucid.utils import unpack_photonsim_params
import fullsim_dice_test as F   # imports dice_get_rays (and patches; harmless here)
np.set_printoptions(precision=6, suppress=True)

pp = unpack_photonsim_params('muon', 'water')
predictor = SIRENPredictor(pp['siren_model_path'])
grid = create_photonsim_siren_grid(predictor)
mparams = predictor.params
na, nb, nc = pp['num_seeds']
Nphot = 50000
key = jax.random.PRNGKey(0)
O = jnp.zeros(3); D = jnp.array([0., 0., 1.]); E = jnp.array(1050.0)

num_seeds = int(na * (1050.0 ** nb) + nc)
print(f"num_seeds(1050)={num_seeds}  (old samples UNIFORMLY among top {num_seeds} bins)", flush=True)

_, _, w_old = photonsim_differentiable_get_rays(O, D, E, Nphot, grid, mparams, key, na, nb, nc)
_, _, w_new = F.dice_get_rays(O, D, E, Nphot, grid, mparams, key, na, nb, nc)
print(f"OLD weights: sum={float(jnp.sum(w_old)):.2f}  mean={float(jnp.mean(w_old)):.4f}  "
      f"max={float(jnp.max(w_old)):.4f}", flush=True)
print(f"NEW weights: sum={float(jnp.sum(w_new)):.2f}  mean={float(jnp.mean(w_new)):.4f}  "
      f"max={float(jnp.max(w_new)):.4f}", flush=True)
print(f"sum ratio NEW/OLD = {float(jnp.sum(w_new)/jnp.sum(w_old)):.4f}", flush=True)

# the old proposal = uniform over the top num_seeds bins; its expected weight (over bins) is
#   mean_{top} density. density x DiCE samples ~ density: its expected per-photon weight is
#   E_{x~d/Sd}[d_x] = sum d^2 / sum d.  Print both to explain the scale gap.
from fullsim_dice_test import dice_get_rays  # noqa
# reconstruct grid densities for the analytic check
from lucid.sources.siren_rays import normalize_inputs_jit, denormalize_log_predictions
from lucid.siren.core import SIREN
(n_bins, e_min, e_max, a_min, a_max, d_min, d_max, a_bins, d_bins,
 angle_dist_grid, angle_mesh, distance_mesh, log_min, log_max) = grid
adg = jnp.asarray(angle_dist_grid)
ng = normalize_inputs_jit(jnp.stack([jnp.full((adg.shape[0],), 1050.0), adg[:,0], adg[:,1]], 1),
                          e_min, e_max, a_min, a_max, d_min, d_max)
mdl = SIREN(hidden_features=256, hidden_layers=3, out_features=1)
lw, _ = mdl.apply(mparams, ng)
dens = jnp.clip(denormalize_log_predictions(jnp.squeeze(lw), log_max, log_min), 1e-12, None)
ds = jnp.sort(dens)[::-1]
mean_top = float(jnp.mean(ds[:num_seeds]))         # old proposal expected weight
e_dice = float(jnp.sum(dens*dens)/jnp.sum(dens))   # density-x-dice expected weight
print(f"\nanalytic per-photon expected weight:", flush=True)
print(f"  OLD (mean of top {num_seeds} densities)   = {mean_top:.4f}", flush=True)
print(f"  NEW density-x-DiCE (sum d^2 / sum d)       = {e_dice:.4f}", flush=True)
print(f"  ratio NEW/OLD = {e_dice/mean_top:.4f}", flush=True)
