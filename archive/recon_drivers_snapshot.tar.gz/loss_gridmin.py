"""REAL diff-engine test (NOT same-key-to-itself). Predictor = EXP (expected) charge, averaged over NK
INDEPENDENT predictor keys -> mu_bar(theta). Two truths, each averaged over NR INDEPENDENT keys (disjoint key
ranges from the predictor):
  oc_EXP = expected-engine charge  (CONTROL: same engine, diff keys -> grid-min should ->0 with stats = pure key-noise)
  oc_SMP = sample-engine charge (make_hits_data, REAL truth) (-> structural expected-vs-sample bias if any)
Charge-only z & energy via GRID-MIN (fine grid + 3-pt local parabola at the grid min, NOT a wide global parabola).
Run at two stat levels to see convergence: if oc_EXP grid-min ->0 but oc_SMP grid-min FLOORS != 0 => the expected-vs-
sample ENGINE difference is the structural cause. temp=None throughout (overlap matched, cause#1 out).
Env: NPHOT NK NR.  Usage: CUDA_VISIBLE_DEVICES=g NK=24 NR=96 python loss_gridmin.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NK = int(os.environ.get('NK', '24')); NR = int(os.environ.get('NR', '96'))
K = 8; MC = 16; POL, AZ = 0.6, 0.8
th9 = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
SC9 = np.array([50.0, 0.2, 0.2, 0.2, 0.02, 0.02, 0.02, 0.02, 0.2])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# GRID-MIN diff-engine  NPH={NPH} NK(pred)={NK} NR(truth)={NR}  temp=None", flush=True)
PRED = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=True,
    hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
TR_EXP = PRED
TR_SMP = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
ND = H.num_detectors(PRED)
@jax.jit
def mu_exp(t9, key): return jnp.maximum(PRED(sc(t9), key)[3], 1e-8)
# predictor keys 0..NK-1 ; truth keys 5000.. (DISJOINT)
PKEYS = [jax.random.PRNGKey(s) for s in range(NK)]
def mubar(t9):
    return jnp.mean(jnp.stack([mu_exp(jnp.asarray(t9), k) for k in PKEYS]), 0)
# truths (high-stat means, disjoint keys)
ocE = np.zeros(ND); ocS = np.zeros(ND)
for r in range(NR):
    ocE += np.asarray(jax.lax.stop_gradient(TR_EXP(sc(jnp.asarray(th9)), jax.random.PRNGKey(5000 + r)))[3])
    ocS += np.asarray(jax.lax.stop_gradient(TR_SMP(sc(jnp.asarray(th9)), jax.random.PRNGKey(9000 + r)))[0])
ocE = jnp.asarray(ocE / NR); ocS = jnp.asarray(ocS / NR)
print(f"#  total charge: pred(mubar@truth) {float(jnp.sum(mubar(th9))):.0f}  ocEXP {float(jnp.sum(ocE)):.0f}  ocSMP {float(jnp.sum(ocS)):.0f}", flush=True)

def gridmin(oc, i, half, n=61):
    sv = np.linspace(-half, half, n)
    prof = np.array([float(jnp.sum(mubar(th9 + s*np.eye(9)[i]) - oc*jnp.log(mubar(th9 + s*np.eye(9)[i])))) for s in sv])
    j = int(np.argmin(prof))
    if 0 < j < n-1:                                              # 3-pt local parabola at the grid min
        y0,y1,y2 = prof[j-1],prof[j],prof[j+1]; d=(y0-2*y1+y2)
        sref = sv[j] + (0.5*(y0-y2)/d*(sv[1]-sv[0]) if abs(d)>1e-12 else 0.0)
    else: sref = sv[j]
    return sv[j], sref
for nm,i,half in [('energy',0,200.0),('z',3,0.4)]:
    ge_g,ge_l = gridmin(ocE,i,half); gs_g,gs_l = gridmin(ocS,i,half)
    u = 'MeV' if i==0 else 'cm'; f = 1.0 if i==0 else 100.0
    print(f"#  {nm:6s}: truth=EXP(control) gridmin {ge_g*f:+7.2f} local {ge_l*f:+7.2f}{u}  |  truth=SMP(real) gridmin {gs_g*f:+7.2f} local {gs_l*f:+7.2f}{u}", flush=True)
print(f"# READ: EXP-control gridmin ->0 with stats (key-noise). If SMP gridmin FLOORS !=0 => expected-vs-sample ENGINE diff = the cause.", flush=True)
