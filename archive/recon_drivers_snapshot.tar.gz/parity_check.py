"""MC-vs-expected parity: the ported implicit (expected-value) step and the ported sample
step must simulate the SAME physics. Feed the SAME SIREN track through both; the sample
charge averaged over many keys must match the expected charge (PORT_PLAN Phase-4 oracle).
"""
import os, jax, jax.numpy as jnp, numpy as np
from lucid.simulation.simulator import setup_event_simulator
from lucid.detector_params import ParticleParams

GEOM = 'config/SK_geom_config.json'; PHYS = 'config/SK_physics_config.json'
NPHOT = 50_000; K = 7; NK = 64

pred = setup_event_simulator(GEOM, NPHOT, 0.1, K, is_data=False, use_expected_value=True,
    hit_mode='per_photon', max_sensors_per_cell=4, physics_config=PHYS,
    default_detector_params=True, particle='muon')
samp = setup_event_simulator(GEOM, NPHOT, 0.0, K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=4, physics_config=PHYS,
    default_detector_params=True, particle='muon', apply_smearing=False)

track = ParticleParams(energy=jnp.array(1050.0), position=jnp.zeros(3),
                       theta=jnp.array(0.0), phi=jnp.array(0.0), t0=jnp.array(0.0))

_, _, _, q_exp = pred(track, jax.random.PRNGKey(0))
q_exp = np.array(q_exp)
print(f"expected total charge = {q_exp.sum():.1f}  (lit sensors = {int((q_exp>0.01*q_exp.max()).sum())})", flush=True)

qs = []
for i in range(NK):
    qc, _ = samp(track, jax.random.fold_in(jax.random.PRNGKey(1000), i))
    qs.append(np.array(qc))
q_samp = np.mean(qs, 0)

lit = q_exp > 0.02 * q_exp.max()
ratio = q_samp.sum() / q_exp.sum()
per_sensor = np.mean(np.abs(q_samp[lit] - q_exp[lit]) / (q_exp[lit] + 1e-9))
corr = np.corrcoef(q_samp[lit], q_exp[lit])[0, 1]
print(f"sample(mean over {NK}) total = {q_samp.sum():.1f}", flush=True)
print(f"TOTAL charge ratio  sample/expected = {ratio:.4f}   (want ~1.00)", flush=True)
print(f"per-sensor (lit) mean rel-diff      = {per_sensor*100:.2f}%   (MC noise ~1/sqrt(NK*q))", flush=True)
print(f"per-sensor correlation              = {corr:.4f}", flush=True)
print("PARITY: " + ("PASS" if abs(ratio - 1) < 0.03 and corr > 0.98 else "CHECK"), flush=True)
