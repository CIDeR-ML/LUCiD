#!/usr/bin/env python3
"""Compare photon TIMES: SIREN emission-time model (predict_t0) vs GEANT4 photon-table times, vs distance
along track. Good vs bad (wandering) events. Emission level (no propagation)."""
import os,glob,numpy as np, jax, jax.numpy as jnp
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from lucid.utils import unpack_photonsim_params, unpack_t0_params
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
from lucid.sources.siren_rays import photonsim_differentiable_get_rays, predict_t0
from lucid.sources.event_io import read_photon_data_from_photonsim
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NPHOT=150000
pp=unpack_photonsim_params('muon','water'); t0p=unpack_t0_params('muon','water')
predr=SIRENPredictor(pp['siren_model_path']); grid=create_photonsim_siren_grid(predr); mp=predr.params
sa,sb,sc=pp['num_seeds']
getrays=jax.jit(lambda to,td,E,key: photonsim_differentiable_get_rays(to,td,E,NPHOT,grid,mp,key,sa,sb,sc))
def norm(v): return v/np.linalg.norm(v,axis=-1,keepdims=True)
def dtruth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); C=P-P.mean(0)
    _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d
    return P.mean(0)+ (C@d).min()*d, d, float(raw['energy'])
GOOD=[41,24]; BAD=[19,31,73]
fig,ax=plt.subplots(1,3,figsize=(18,5.5))
db=np.linspace(0,10,40)
for grp,evs,col in [('good',GOOD,'C0'),('bad',BAD,'C3')]:
    accG=np.zeros(len(db)-1); accS=np.zeros(len(db)-1); nG=0
    for k,ev in enumerate(evs):
        raw=read_photon_data_from_photonsim(ROOT,ev); vtx,d,E=dtruth(raw)
        O=np.asarray(raw['photon_origins'])/100.0; distG=(O-vtx)@d; tG=np.asarray(raw['photon_times'])
        rv,ro,w=getrays(jnp.asarray(vtx),jnp.asarray(d),jnp.asarray(E),jax.random.PRNGKey(7+ev))
        ro=np.asarray(ro); w=np.asarray(w); distS=(ro-vtx)@d
        tS=np.asarray(predict_t0(jnp.asarray(np.clip(distS,0,None)*1000),E,*t0p))   # clip neg (smear artifact)
        ok=np.isfinite(tS)
        accG+=np.histogram(distG,db)[0]/len(distG); accS+=np.histogram(distS[ok],db,weights=w[ok])[0]/w[ok].sum()
        bins=np.linspace(0,5,20); bc=0.5*(bins[1:]+bins[:-1])
        def prof(dd,tt,wt=None):
            ic=np.digitize(dd,bins); return np.array([np.average(tt[ic==i],weights=None if wt is None else wt[ic==i]) if (ic==i).sum() else np.nan for i in range(1,len(bins))])
        ax[1].plot(bc,prof(distG,tG),col+'-',alpha=0.5,label=f'G4 {grp}' if k==0 else None)
        ax[1].plot(bc,prof(distS[ok],tS[ok],w[ok]),col+'--',alpha=0.5,label=f'SIREN {grp}' if k==0 else None)
        if k==0: print(f'{grp} ev{ev}: G4 dist max {distG.max():.2f}m, frac>4.7m={np.mean(distG>4.7)*100:.1f}% | SIREN frac>4.7m={np.average(distS>4.7,weights=w)*100:.1f}% (>truth range)')
    ax[0].plot(0.5*(db[1:]+db[:-1]),accG/len(evs),col+'-',lw=2,label=f'GEANT4 {grp}')
    ax[0].plot(0.5*(db[1:]+db[:-1]),accS/len(evs),col+'--',lw=2,label=f'SIREN {grp}')
ax[0].axvline(4.7,color='k',ls=':',label='muon range ~4.7m'); ax[0].set_xlabel('emission distance along track (m)'); ax[0].set_ylabel('norm density'); ax[0].set_title('Emission LONGITUDINAL profile (SIREN tail past range!)'); ax[0].legend(fontsize=8); ax[0].grid(alpha=0.3)
ax[1].set_xlabel('distance (m)'); ax[1].set_ylabel('emission time (ns)'); ax[1].set_title('Emission time vs distance'); ax[1].legend(fontsize=8); ax[1].grid(alpha=0.3)
ax[2].axis('off')
fig.suptitle('SIREN vs GEANT4 emission profile & times (good blue / bad red)',fontsize=13)
fig.tight_layout(); fig.savefig('recon_plots/time_compare.png',dpi=115); print('wrote time_compare.png')
