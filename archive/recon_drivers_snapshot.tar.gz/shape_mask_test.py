"""Is the charge-pattern perp runaway caused by the DENSE predicted background on observed-EMPTY sensors?
Scan vtx_perp; compare the Poisson charge-term argmin for: ALL sensors, OBS-HIT-only sensors, and the
"q_hat term only" (sum q_hat over obs-empty sensors). Also the pred vs obs charge profile along perp
(offset vs width). PhotonSim, truth track. Usage: CUDA_VISIBLE_DEVICES=g python shape_mask_test.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.geometry.detector_geometry import DetectorGeometry
np.set_printoptions(precision=4, suppress=True)
NK=8
S=PS.setup(event=0,nphot=80_000,truth_source='photonsim',pred_temperature=0.1)
ts=np.array(S['theta_star']); pred=S['pred']; oc=np.array(S['oc'])
hit=oc>0; empty=~hit
dg=DetectorGeometry.from_config(H.GEOM,temperature=None,max_sensors_per_cell=4); sp=np.array(dg.sensor_points)
pol,az=ts[4],ts[5]; dvec=np.array([np.sin(pol)*np.cos(az),np.sin(pol)*np.sin(az),np.cos(pol)])
perp=np.array([-dvec[1],dvec[0],0.]); perp/=np.linalg.norm(perp)
sperp=(sp-ts[1:4])@perp                           # perp coordinate of each sensor
def qpred(theta):
    return np.mean([np.array(jax.jit(pred)(H.theta_to_track(jnp.asarray(theta)),jax.random.PRNGKey(9000+k))[3]) for k in range(NK)],0)
def shift(o): t=ts.copy(); t[1:4]=ts[1:4]+o*perp; return t
offs=np.linspace(-1.2,1.2,17); Qs=[qpred(shift(o)) for o in offs]
def amin(ys):
    j=int(np.argmin(ys))
    if 0<j<len(ys)-1:
        A,B,C=ys[j-1],ys[j],ys[j+1]; den=A-2*B+C
        return offs[j]+(0.5*(A-C)/den if abs(den)>1e-9 else 0)*(offs[1]-offs[0])
    return offs[j]
LP =lambda q: np.sum(q - oc*np.log(q+1e-8))                       # full Poisson, all sensors
LPh=lambda q: np.sum((q - oc*np.log(q+1e-8))[hit])               # Poisson, obs-hit sensors only
Lbg=lambda q: np.sum(q[empty])                                   # predicted charge wasted on obs-empty
print(f"=== vtx_perp argmin (PhotonSim) ===")
print(f"  Poisson ALL sensors      : {amin([LP(q) for q in Qs]):+.3f} m")
print(f"  Poisson OBS-HIT only      : {amin([LPh(q) for q in Qs]):+.3f} m")
print(f"  q_hat on OBS-EMPTY (bg)    : {amin([Lbg(q) for q in Qs]):+.3f} m")
print(f"  predicted charge on obs-EMPTY sensors @truth = {Qs[8][empty].sum():.0f} of {Qs[8].sum():.0f} "
      f"({Qs[8][empty].sum()/Qs[8].sum()*100:.0f}%)  on {int(empty.sum())} empty sensors")
# pred vs obs charge profile along perp (offset vs width) at truth
q0=Qs[8]; edges=np.linspace(-8,8,17); mid=0.5*(edges[:-1]+edges[1:])
op=np.array([oc[(sperp>=edges[i])&(sperp<edges[i+1])].sum() for i in range(16)])
pp=np.array([q0[(sperp>=edges[i])&(sperp<edges[i+1])].sum() for i in range(16)])
def cw(w): return float((w*mid).sum()/(w.sum()+1e-9));
def sw(w): m=cw(w); return float(np.sqrt((w*(mid-m)**2).sum()/(w.sum()+1e-9)))
print(f"\n=== perp charge profile @truth: obs vs pred (centroid & width) ===")
print(f"  obs : centroid={cw(op):+.2f} m  width={sw(op):.2f} m")
print(f"  pred: centroid={cw(pp):+.2f} m  width={sw(pp):.2f} m")
print("  perp:  "+" ".join(f"{m:+5.1f}" for m in mid))
print("  obs :  "+" ".join(f"{v:5.0f}" for v in op))
print("  pred:  "+" ".join(f"{v:5.0f}" for v in pp))
