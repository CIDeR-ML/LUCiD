"""CORRECTED time term — order statistic CONDITIONED on the OBSERVED count, NORMALIZED survival.

Bug in the binned Poisson FA: it used the PREDICTED mu in the rate -> -log mu double-counts charge ->
energy biased +200MeV at realistic NPH. Fix: factorize L_i = Poisson(n_i;mu) x p(t_i | n_i), where the time
term is the order statistic of n_i (OBSERVED count) draws from the NORMALIZED density (survival S=1-R/mu, a
SHAPE -> energy-independent). Binned for conditioning:
  P(first of n_i in [t-D/2,t+D/2]) = S(t-D/2)^n_i - S(t+D/2)^n_i,  S(t)=1-R(t)/mu = (mu-R(t))/mu
  NLL_time_i = -n_i*log S_lo - log1mexp(n_i*(log S_hi - log S_lo))
Charge = raw Poisson(mu;n). Energy comes ONLY from charge (time term energy-independent); dim-PMT safe (n>=1).
MODE=bias: charge/joint energy+x argmin (NPH scan). MODE=adfd: AD vs profile. K=8 MAXCELL=16 TTS=2.5.
Env: MODE NPHOT NKEYS NEV SIGMA DELTA.  Usage: CUDA_VISIBLE_DEVICES=g MODE=bias NPHOT=500000 python loss_cond.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ.setdefault('MAXCELL', '16')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
MODE = os.environ.get('MODE', 'bias'); NPH = int(os.environ.get('NPHOT', '500000')); NKEYS = int(os.environ.get('NKEYS', '3'))
NEV = int(os.environ.get('NEV', '4')); SIGMA = float(os.environ.get('SIGMA', '2.5')); DELTA = float(os.environ.get('DELTA', '1.0'))
K = 8; MC = 16; SQ = float(np.sqrt(2.0)); PS = np.asarray(H.PARAM_SCALE); PN = H.PARAM_NAMES
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); track = H.theta_to_track(jnp.asarray(theta_true)); delta = np.array([50.0, 0.10, 0, 0, 0.0175, 0, 0.5]); theta0 = theta_true + delta
print(f"# COND time term  MODE={MODE} NPH={NPH} NKEYS={NKEYS} NEV={NEV} SIGMA={SIGMA} DELTA={DELTA} K={K} MC={MC}", flush=True)
pred = H.build_predictor(temperature=0.1, K=K, n_photons=NPH); ND = H.num_detectors(pred)
truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
    hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
def log1mexp(a):
    a = jnp.minimum(a, -1e-7); return jnp.where(a > -0.6931, jnp.log(-jnp.expm1(a)), jnp.log1p(-jnp.exp(a)))
# obs as ARGUMENTS, jit ONCE (no per-event recompile)
@jax.jit
def core(theta, key, oc, ot, hit, wt):
    log_w, ft, fi, tot = pred(H.theta_to_track(theta), key)
    w = jnp.exp(jnp.clip(log_w, -60, 20)); tobs = (ot - theta[6])[fi]; mu = jnp.maximum(tot, 1e-8)
    def Rof(t): return jax.ops.segment_sum(w * 0.5 * (1.0 + erf((t - ft) / (SIGMA * SQ))), fi, num_segments=ND)
    R_lo = Rof(tobs - DELTA / 2); R_hi = Rof(tobs + DELTA / 2)
    S_lo = jnp.clip((mu - R_lo) / mu, 1e-12, 1.0); S_hi = jnp.clip((mu - R_hi) / mu, 1e-12, 1.0)
    n = jnp.maximum(oc, 0.0)
    a = jnp.minimum(n * (jnp.log(S_hi) - jnp.log(S_lo)), -1e-9)
    nll = -n * jnp.log(S_lo) - log1mexp(a)
    time = jnp.sum(jnp.where(hit & ((R_hi - R_lo) > 1e-9) & (oc > 0), nll, 0.0))
    return jnp.sum(mu - oc * jnp.log(mu)) + wt * time
def am(oc, ot, hit, wt, i, span=4.0, npts=15):
    sv = np.linspace(-span * PS[i], span * PS[i], npts); wtj = jnp.asarray(wt)
    c = np.array([np.mean([float(core(jnp.asarray(theta_true + s * np.eye(7)[i]), k, oc, ot, hit, wtj)) for k in keys]) for s in sv])
    j = int(np.argmin(c)); lo = max(0, j - 2); hi = min(npts, j + 3); a, b, _ = np.polyfit(sv[lo:hi], c[lo:hi], 2)
    return (-b / (2 * a) if a > 0 else sv[j])

if MODE == 'bias':
    for tag, wt in [('charge', 0.0), ('joint', 1.0)]:
        ex, ee = [], []
        for ev in range(NEV):
            oc, ot = jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(7 * ev + 1))); hit = oc > 0; ot = jnp.where(hit, ot, 0.0)
            ex.append(am(oc, ot, hit, wt, 1)); ee.append(am(oc, ot, hit, wt, 0))
        ex, ee = np.array(ex), np.array(ee)
        print(f"#  {tag:6s}: x {ex.mean():+.3f}+/-{ex.std()/np.sqrt(NEV):.3f} | energy {ee.mean():+7.1f}+/-{ee.std()/np.sqrt(NEV):.1f} MeV", flush=True)
    print(f"# READ: joint energy ~ charge energy (no time double-count) => fixed. x = timing-constrained vertex.", flush=True)
else:
    if os.environ.get('SINGLE_OBS'):                              # one realization (integer count) — representative
        c, t = jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(123))); c = np.asarray(c); t = np.asarray(t)
        oc = jnp.asarray(c); hit = jnp.asarray(c > 0); ot = jnp.asarray(np.where(c > 0, t, 0.0))
    else:
        cs, ts = [], []
        for s in range(8):
            cc, tt2 = jax.lax.stop_gradient(truth(track, jax.random.PRNGKey(10000 + s))); cs.append(np.asarray(cc)); ts.append(np.where(np.asarray(cc) > 0, np.asarray(tt2), np.nan))
        oc = jnp.asarray(np.mean(cs, 0)); hit = jnp.asarray(np.mean(cs, 0) > 1e-6); ot = jnp.asarray(np.nan_to_num(np.nanmean(ts, 0)))
    wtj = jnp.asarray(1.0)
    gradf = jax.jit(jax.grad(core, argnums=0))
    gAD = np.stack([np.asarray(gradf(jnp.asarray(theta0), k, oc, ot, hit, wtj)) for k in keys]).mean(0)
    for i, nm in enumerate(PN):
        sv = np.linspace(-6 * PS[i], 6 * PS[i], 25); j0 = 12; dg = sv[1] - sv[0]
        prof = np.array([np.mean([float(core(jnp.asarray(theta0 + s * np.eye(7)[i]), k, oc, ot, hit, wtj)) for k in keys]) for s in sv])
        sl = {wv: (prof[j0 + wv] - prof[j0 - wv]) / (2 * wv * dg) for wv in [1, 2, 4]}
        kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
        print(f"#  {nm:6s} AD {gAD[i]:+11.2f} prof {sl[1]:+9.1f}/{sl[2]:+9.1f}/{sl[4]:+9.1f} {'KINKY' if kinky else f'ratio {gAD[i]/(sl[4]+1e-30):+.2f}'}", flush=True)
