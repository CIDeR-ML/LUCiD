"""COMPONENT ISOLATION for cause #2 (longitudinal ~6cm charge SHAPE, persists at temp=None).
2x2 = {STEP: expected/sample} x {CHARGE readout: per_photon(make_hits_likelihood)/realistic(make_hits_data)},
ALL at temp=None (so overlap/cause#1 is matched and OUT). At theta_true, accumulate per-PMT mean charge over N
draws for each combo, then DECOMPOSE the predictor-vs-truth gap:
  EXP_pp (recon predictor's charge model) vs SMP_rl (the truth) = full cause #2.
    STEP effect    = EXP_pp vs SMP_pp   (readout matched = per_photon)
    READOUT effect = SMP_pp vs SMP_rl   (step matched = sample)
Report total, per-occupancy ratio, and the LONGITUDINAL charge profile (project PMT onto track dir) -- the
longitudinal profile difference IS the z/vertex bias driver. NO assumptions: every pair is measured.
Env: NPHOT NDRAW.  Usage: CUDA_VISIBLE_DEVICES=g python loss_components.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); ND_RAW = int(os.environ.get('NDRAW', '48'))
K = 8; MC = 16; POL, AZ = 0.6, 0.8
VTX = np.array([0., 0., 0.])
DIRV = np.array([np.sin(POL)*np.cos(AZ), np.sin(POL)*np.sin(AZ), np.cos(POL)])
trk = ParticleParams(energy=jnp.asarray(1050.0), position=jnp.asarray(VTX), theta=jnp.asarray(POL), phi=jnp.asarray(AZ), t0=jnp.asarray(0.0))
POS = np.load('/tmp/sensor_pos.npy')                                  # (ND,3) sensor positions
print(f"# COMPONENTS (cause #2 isolation, all temp=None)  NPH={NPH} NDRAW={ND_RAW}", flush=True)

def build(use_ev, hm):
    return setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=use_ev,
        hit_mode=hm, max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
        wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
def charge_of(out, hm):
    return out[3] if hm == 'per_photon' else out[0]                  # per_photon->tot ; realistic->charge
def accum(sim, hm, seed0):
    acc = np.zeros(POS.shape[0])
    for i in range(ND_RAW):
        out = jax.lax.stop_gradient(sim(trk, jax.random.PRNGKey(seed0 + i)))
        acc += np.asarray(charge_of(out, hm))
    return acc / ND_RAW

combos = {}
for use_ev, tag in [(True, 'EXP'), (False, 'SMP')]:
    for hm, rt in [('per_photon', 'pp'), ('realistic', 'rl')]:
        sim = build(use_ev, hm); seed0 = (1000 if not use_ev else 0) + (500 if hm == 'realistic' else 0)
        combos[f'{tag}_{rt}'] = accum(sim, hm, seed0)
        print(f"#   built+ran {tag}_{rt}", flush=True)

ND = POS.shape[0]
s = (POS - VTX) @ DIRV                                                # longitudinal coord (m)
def report_pair(a, b, na, nb):
    qa, qb = combos[a], combos[b]
    print(f"#  --- {a} vs {b} :  total {qa.sum():.0f}/{qb.sum():.0f} ratio {qa.sum()/max(qb.sum(),1):.4f} ---", flush=True)
    # occupancy buckets (by qb = the 'truth-side' of the pair)
    for lo, hi in [(0.05,0.2),(0.2,0.5),(0.5,1.0),(1.0,2.0),(2.0,100)]:
        sel = np.where((qb > lo) & (qb <= hi))[0]
        if sel.size: print(f"#     occ {lo:.2f}-{hi:<4.1f} N{sel.size:5d}  {a} {qa[sel].sum():8.1f}  {b} {qb[sel].sum():8.1f}  ratio {qa[sel].sum()/max(qb[sel].sum(),1e-9):.4f}", flush=True)
    # longitudinal profile (charge-weighted centroid + per-bin ratio)
    lit = (qa > 1e-6) | (qb > 1e-6)
    ca = (s[lit]*qa[lit]).sum()/max(qa[lit].sum(),1e-9); cb = (s[lit]*qb[lit]).sum()/max(qb[lit].sum(),1e-9)
    print(f"#     longitudinal charge-centroid  {a} {ca:+.4f}m  {b} {cb:+.4f}m  Δ(a-b) {100*(ca-cb):+.2f}cm", flush=True)
    bins = np.linspace(np.percentile(s,1), np.percentile(s,99), 9)
    idx = np.clip(np.digitize(s, bins), 1, len(bins)-1)
    out = []
    for bi in range(1, len(bins)):
        m = idx == bi
        out.append(f"[{bins[bi-1]:+.1f},{bins[bi]:+.1f}] {qa[m].sum()/max(qb[m].sum(),1e-9):.3f}")
    print(f"#     long-bin ratio(a/b): " + "  ".join(out), flush=True)

print(f"# FULL cause#2 = recon predictor(EXP_pp) vs truth(SMP_rl):", flush=True)
report_pair('EXP_pp', 'SMP_rl', 'EXP_pp', 'SMP_rl')
print(f"# STEP effect (readout matched=per_photon): EXP_pp vs SMP_pp:", flush=True)
report_pair('EXP_pp', 'SMP_pp', 'EXP_pp', 'SMP_pp')
print(f"# READOUT effect (step matched=sample): SMP_pp vs SMP_rl:", flush=True)
report_pair('SMP_pp', 'SMP_rl', 'SMP_pp', 'SMP_rl')
print(f"# cross-check READOUT on expected step: EXP_pp vs EXP_rl:", flush=True)
report_pair('EXP_pp', 'EXP_rl', 'EXP_pp', 'EXP_rl')
print(f"# READ: which pair carries the longitudinal-centroid Δ (the z-bias driver) -> STEP vs READOUT.", flush=True)
