#!/usr/bin/env python3
"""Make distribution + capture-map plots from the mgpu /tmp/mg_<case>_*.log result lines.
Lines look like: '#  ev.. E<resid> |vtx|<cm>cm (lon.. tra..) dir<deg> t0<ns>'. Saves PNGs to recon_plots/."""
import glob,re,os
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'recon_plots'); os.makedirs(OUT,exist_ok=True)
RX=re.compile(r'E\s*([+-][0-9.]+)\s+\|vtx\|\s*([0-9.]+)cm \(lon\s*([0-9.]+) tra\s*([0-9.]+)\).*dir\s*([0-9.]+).*t0\s*([+-][0-9.]+)')
def load(prefix):
    rows=[]
    for f in sorted(glob.glob(f'/tmp/mg_{prefix}_*.log')):
        for l in open(f):
            m=RX.search(l)
            if m: rows.append([float(x) for x in m.groups()])
    return np.array(rows) if rows else np.zeros((0,6))   # cols: E,vtx,lon,tra,dir,t0
rms=lambda x:float(np.sqrt((x**2).mean())) if len(x) else float('nan')

# ---- 1) floor + floorjit residual distributions (2x3) ----
def dist_panel(cases, title, fname):
    labels=[('E','E residual (MeV)',0),('vtx','|vtx| (cm)',1),('lon','longitudinal (cm)',2),
            ('tra','transverse (cm)',3),('dir','direction (deg)',4),('t0','t0 residual (ns)',5)]
    fig,axes=plt.subplots(2,3,figsize=(14,8)); axes=axes.ravel()
    for ax,(key,xl,ci) in zip(axes,labels):
        for cname,col in cases:
            a=load(cname)
            if not len(a): continue
            v=a[:,ci]
            ax.hist(v,bins=15,alpha=0.5,label=f'{cname} (RMS {rms(v):.1f}, p68 {np.percentile(np.abs(v),68):.1f})',color=col,edgecolor='k',lw=0.4)
        ax.set_xlabel(xl); ax.set_ylabel('events'); ax.legend(fontsize=8); ax.grid(alpha=0.3)
        if key in('vtx','lon','tra','dir'): ax.axvline(0,color='k',lw=0.5)
    fig.suptitle(title,fontsize=13); fig.tight_layout()
    fig.savefig(os.path.join(OUT,fname),dpi=110); plt.close(fig); print('wrote',fname)

dist_panel([('floor','C0'),('floorjit','C1')],
           'Floor-start (blue) vs realistic 1σ jitter (orange) — config NOCLIP LR8 RIDGE_I0.3 REFRESH8, 20 ev',
           'floor_distributions.png')

# ---- 2) vertex capture-radius map ----
DI=[('2.5m','b25',2.5),('5m','b50',5),('7.5m','b75',7.5),('10m','b100',10),('15m','b150',15)]
dist=[];cap30=[];cap20=[];vmed=[];lonr=[];trar=[];dirm=[]
for nm,p,dm in DI:
    a=load(p)
    if not len(a): continue
    V=a[:,1]; c=a[V<30]
    dist.append(dm); cap30.append((V<30).mean()*100); cap20.append((V<20).mean()*100)
    vmed.append(np.median(c[:,1]) if len(c) else np.nan); lonr.append(rms(c[:,2])); trar.append(rms(c[:,3])); dirm.append(np.median(c[:,4]) if len(c) else np.nan)
fig,(a1,a2)=plt.subplots(1,2,figsize=(13,5))
a1.plot(dist,cap30,'o-',label='capture <30 cm',lw=2,ms=8); a1.plot(dist,cap20,'s--',label='capture <20 cm',lw=2,ms=7)
a1.set_xlabel('start vertex offset (m)'); a1.set_ylabel('capture fraction (%)'); a1.set_ylim(0,105)
a1.axhline(100,color='g',lw=0.5,ls=':'); a1.set_title('Vertex capture radius'); a1.legend(); a1.grid(alpha=0.3)
a2.plot(dist,vmed,'o-',label='|vtx| median',lw=2,ms=8); a2.plot(dist,lonr,'^-',label='longitudinal RMS',lw=2); a2.plot(dist,trar,'v-',label='transverse RMS',lw=2)
a2.set_xlabel('start vertex offset (m)'); a2.set_ylabel('resolution (cm, captured events)'); a2.set_ylim(0,20)
a2.set_title('Floor of captured events (distance-independent)'); a2.legend(); a2.grid(alpha=0.3)
fig.suptitle('Vertex basin map — RIDGE_I=0.3, vertex-only offset, E/dir/t0 at truth, 10 ev/pt',fontsize=12); fig.tight_layout()
fig.savefig(os.path.join(OUT,'vertex_capture_map.png'),dpi=110); plt.close(fig); print('wrote vertex_capture_map.png')

# ---- 3) RIDGE_I probe at floor ----
RI=[('RIDGE_I=0','ri0','C3'),('RIDGE_I=0.1','ri01','C2'),('RIDGE_I=0.3','ri03','C0')]
fig,axes=plt.subplots(1,3,figsize=(15,4.5));
for ax,(ci,xl) in zip(axes,[(4,'direction (deg)'),(3,'transverse (cm)'),(5,'t0 residual (ns)')]):
    for nm,p,col in RI:
        a=load(p)
        if not len(a): continue
        v=a[:,ci]; vc=np.clip(v,-3,3) if ci==5 else v   # clip t0 runaway for visibility
        ax.hist(vc,bins=15,alpha=0.5,label=f'{nm} (RMS {rms(v):.2f})',color=col,edgecolor='k',lw=0.4)
    ax.set_xlabel(xl+(' [clipped ±3]' if ci==5 else '')); ax.set_ylabel('events'); ax.legend(fontsize=8); ax.grid(alpha=0.3)
fig.suptitle('RIDGE_I floor probe: 0 destabilizes t0 (max|t0|=52ns); 0.1–0.3 stable',fontsize=12); fig.tight_layout()
fig.savefig(os.path.join(OUT,'ridge_probe.png'),dpi=110); plt.close(fig); print('wrote ridge_probe.png')
print('plots in',OUT)
