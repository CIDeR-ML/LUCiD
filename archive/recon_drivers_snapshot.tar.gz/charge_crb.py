"""CHARGE-TERM CRB DIAGNOSTIC. Question the user posed: is the ~50cm longitudinal floor a property of
the CHARGE OBSERVABLE we chose (total + centroid = two scalars) or is the longitudinal information not
there? Answer it with the FISHER information of several charge-term forms, from first principles.

Generative model = extended/marked Poisson per PMT: n_i ~ Poisson(mu_i(theta)); each photon t_ij ~ f_i(t|theta).
  log L_i = [-mu_i + n_i log mu_i]   (CHARGE, Poisson)  +  sum_j log f_i(t_ij)   (TIME, weighted by n_i)
count & times conditionally independent => F = F_charge + F_time (additive).
  F_charge[a,b] = sum_i (1/mu_i) d_a mu_i d_b mu_i           (EXACT Poisson Fisher, no MC)
  F_time[a,b]   = sum_i (mu_i/sigma^2) d_a tau_i d_b tau_i    (per-photon time info x expected count)
tau_i = wavefront t0 + [(P_i-V).d + a_perp*sqrt(n^2-1)]/c   -> EXACTLY null along u=(dV=eps d, dt0=eps/c).

mu_i and d mu_i/d theta come from the differentiable SIREN predictor at truth (jacfwd, avg over keys) =
the model's OWN Fisher (well-specified / self-consistent CRB = the information CEILING; model mismatch
adds BIAS on top, measured separately by the optimizer). Charge-form variants compared:
  TOTAL     s = sum_i Q_i                          (0th moment; 1 scalar)
  CENTROID  s = (sum_i Q_i (P_i.d)) / sum_i Q_i    (1st moment on axis; 1 scalar) = our lCEN
  FULLPOIS  full per-PMT Poisson  sum_i (.)/mu_i   (all PMTs; the ceiling)
(sqrt-MSE/Anscombe has the SAME Fisher as Poisson at truth -- variance-stabilization changes the
estimator's finite-sample bias, NOT the information; so it is not listed separately.)

Reports the LONGITUDINAL vertex CRB (marginalizing the others) for charge-only and charge+time, per form.
Env: NPHOT NKG SIG MUFLOOR EVENT NW. Usage: CUDA_VISIBLE_DEVICES=g python charge_crb.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_ps_setup as PS, recon_harness as H
from lucid.geometry import generate_detector
np.set_printoptions(precision=4, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '80000')); NKG = int(os.environ.get('NKG', '4'))
SIG = float(os.environ.get('SIG', '2.5'))          # per-photon effective time spread (ns) for F_time
MUFLOOR = float(os.environ.get('MUFLOOR', '5e-3')) # floor on mu_i in the 1/mu Poisson weight
EVENT = int(os.environ.get('EVENT', '0')); NW = float(os.environ.get('NW', '1.34'))
C = 0.299792; G = float(np.sqrt(NW**2 - 1.0))

S = PS.setup(event=EVENT, nphot=NPHOT, truth_source='siren', pred_temperature=0.1)
ts = np.array(S['theta_star']); pred = S['pred']; ND = S['ND']
det = generate_detector(H.GEOM); DP = jnp.array(np.array(det.all_points))   # (ND,3) PMT positions
DPn = np.array(DP)
def dvec(pol, az): return jnp.array([jnp.sin(pol)*jnp.cos(az), jnp.sin(pol)*jnp.sin(az), jnp.cos(pol)])
d_true = np.array(dvec(ts[4], ts[5]))                                       # track direction (unit)

# ---- per-PMT mean charge mu_i(theta) and its Jacobian d mu/d theta. The predictor is a custom_vjp
# (DiCE/implicit), so forward-mode jacfwd is BLOCKED; reverse jacrev is ND(>1e4) passes. Instead use
# CENTRAL FINITE DIFFERENCES with COMMON RANDOM NUMBERS (same key for +h/-h): the SIREN photon sampling
# is deterministic given key, so it cancels in the difference -> clean derivative of the soft forward.
STEP = float(os.environ.get('STEP', '0.25')); h = np.array(H.PARAM_SCALE) * STEP   # FD step per param
qof = jax.jit(lambda theta, key: pred(H.theta_to_track(theta), key)[3])     # (ND,) expected per-PMT charge
th = jnp.array(ts)
mus = []; Jqs = []
for k in range(NKG):
    key = jax.random.PRNGKey(1000 + 13*k)
    mus.append(np.array(qof(th, key)))
    Jk = np.zeros((ND, 7))
    for a in range(7):
        e = np.zeros(7); e[a] = h[a]
        qp = np.array(qof(jnp.array(ts + e), key)); qm = np.array(qof(jnp.array(ts - e), key))
        Jk[:, a] = (qp - qm) / (2*h[a])
    Jqs.append(Jk)
mu = np.mean(mus, 0)                       # (ND,) mean charge
Jq = np.mean(Jqs, 0)                       # (ND,7) d mu_i / d theta  (CRN central FD)
print(f"# CHARGE-CRB  NPHOT={NPHOT} NKG={NKG} SIG={SIG}ns MUFLOOR={MUFLOOR}  ND={ND}", flush=True)
print(f"#   truth theta = {ts}", flush=True)
print(f"#   PMTs with mu>{MUFLOOR}: {(mu>MUFLOOR).sum()}   sum(mu)={mu.sum():.0f}   max(mu)={mu.max():.2f}", flush=True)

# ---- wavefront time tau_i(theta) (analytic, differentiable) + Jacobian
def wavefront(theta):
    V = theta[1:4]; d = dvec(theta[4], theta[5]); t0 = theta[6]
    a = DP - V[None, :]; apar = a @ d
    aperp = jnp.sqrt(jnp.maximum((a*a).sum(1) - apar**2, 1e-12))
    return t0 + (apar + aperp*G)/C
Jtau = np.array(jax.jacfwd(wavefront)(th))                                  # (ND,7)

# ---- masks/weights
hit = mu > MUFLOOR
muc = np.clip(mu, MUFLOOR, None)
w_t = mu * hit                                                             # time weight = expected count

# ---- Fisher builders (7x7), physical units [MeV, m,m,m, rad,rad, ns]
def F_charge_full():
    W = (hit / muc)[:, None]                                              # 1/mu Poisson weight
    return Jq.T @ (W * Jq)
def F_charge_scalar(g, var):                                             # rank-1 from a scalar statistic
    return np.outer(g, g) / var
def F_time(sig):
    W = (w_t / sig**2)[:, None]
    return Jtau.T @ (W * Jtau)

# total-charge statistic s=sum Q_i : g=sum_i Jq[i], var=sum mu_i
g_tot = Jq[hit].sum(0); var_tot = mu[hit].sum()
# centroid-on-axis s = (sum Q_i c_i)/(sum Q_i), c_i = P_i . d  (delta-method g and var)
c = DPn @ d_true
A = (mu*hit*c).sum(); B = (mu*hit).sum(); s0 = A/B
dA = (Jq[hit]*c[hit, None]).sum(0); dB = Jq[hit].sum(0)
# direction channel: d(P_i.d)/d(pol,az)
dd = np.array(jax.jacfwd(lambda pa: dvec(pa[0], pa[1]))(jnp.array([ts[4], ts[5]])))  # (3,2)
dc_dpa = DPn[hit] @ dd                                                    # (Nhit,2)
dA_dir = (mu[hit, None]*dc_dpa).sum(0)                                    # (2,)
g_cen = (dA*B - A*dB)/B**2                                                # mu-channel (all 7)
g_cen[4] += dA_dir[0]/B; g_cen[5] += dA_dir[1]/B                          # add direction channel
var_cen = (mu[hit]*(c[hit]-s0)**2).sum()/B**2

# ---- marginalized CRB helper: invert the sub-block over `idx` params, read longitudinal & total vertex.
# Flag rank-deficient (degenerate) blocks instead of printing the pseudo-inverse noise.
def crb(F, idx, tag):
    Fb = F[np.ix_(idx, idx)].copy()
    ev = np.linalg.eigvalsh(Fb); cond = ev[-1]/max(ev[0], 1e-300)
    if ev[0] <= 1e-9*ev[-1]:                     # rank-deficient -> the marginal is unbounded
        return f"  {tag:28s}  DEGENERATE (cond={cond:.1e}, {int((ev>1e-9*ev[-1]).sum())}/{len(idx)} constrained dirs)"
    Cov = np.linalg.inv(Fb)
    pos = {p: j for j, p in enumerate(idx)}
    out = {}
    if all(p in pos for p in (1, 2, 3)):
        Cxyz = Cov[np.ix_([pos[1], pos[2], pos[3]], [pos[1], pos[2], pos[3]])]
        lon = float(np.sqrt(max(d_true @ Cxyz @ d_true, 0)))*100
        tot = float(np.sqrt(max(np.trace(Cxyz), 0)))*100
        out['lon'] = lon; out['vtx'] = tot
    out['E'] = (float(np.sqrt(max(Cov[pos[0], pos[0]], 0)))/ts[0]*100) if 0 in pos else None
    if 4 in pos and 5 in pos:
        out['dir'] = float(np.degrees(np.sqrt(max(Cov[pos[4], pos[4]] + np.sin(ts[4])**2*Cov[pos[5], pos[5]], 0))))
    out['t0'] = (float(np.sqrt(max(Cov[pos[6], pos[6]], 0)))) if 6 in pos else None
    s = f"  {tag:28s}"
    s += f"  lon={out.get('lon', float('nan')):7.1f}cm  vtx={out.get('vtx', float('nan')):7.1f}cm"
    s += f"  dir={out.get('dir', float('nan')):6.2f}deg" if 'dir' in out else "  dir=  -    "
    s += f"  t0={out['t0']:6.2f}ns" if out.get('t0') is not None else "  t0=  -   "
    s += f"  E={out['E']:5.1f}%" if out.get('E') is not None else ""
    return s

FC_full = F_charge_full(); FC_tot = F_charge_scalar(g_tot, var_tot); FC_cen = F_charge_scalar(g_cen, var_cen)
FT = F_time(SIG)

# headline: longitudinal info each charge form puts along the degeneracy direction u=(dV=d, dt0=1/C)
u = np.zeros(7); u[1:4] = d_true; u[6] = 1.0/C
print(f"\n# Longitudinal info along the degeneracy u=(dV=d, dt0=1/c):  u^T F u  (bigger = more)", flush=True)
print(f"#   F_time         u^T F u = {u@FT@u:10.4g}   (should be ~0: the exact null)", flush=True)
print(f"#   charge TOTAL   u^T F u = {u@FC_tot@u:10.4g}", flush=True)
print(f"#   charge CENTROID u^T F u= {u@FC_cen@u:10.4g}", flush=True)
print(f"#   charge FULLPOIS u^T F u= {u@FC_full@u:10.4g}   ratio FULL/CENTROID = {(u@FC_full@u)/(u@FC_cen@u+1e-30):.1f}x", flush=True)

ALL = [0, 1, 2, 3, 4, 5, 6]; NOT0 = [0, 1, 2, 3, 4, 5]                    # param index sets (with / without t0)
print(f"\n# CHARGE ONLY (no time; marginalize E,dir; t0 absent -> charge needs no t0):", flush=True)
print(crb(FC_tot,  NOT0, 'TOTAL    (lE)'), flush=True)
print(crb(FC_cen,  NOT0, 'CENTROID (lCEN)'), flush=True)
print(crb(FC_full, NOT0, 'FULLPOIS (per-PMT)'), flush=True)
print(f"\n# TIME ONLY (degenerate along longitudinal+t0):", flush=True)
print(crb(FT, ALL, 'wavefront first-arrival'), flush=True)
print(f"\n# CHARGE + TIME  (the generalized time-charge likelihood; all 7 params incl t0 free):", flush=True)
print(crb(FC_tot  + FT, ALL, 'TOTAL    + time'), flush=True)
print(crb(FC_cen  + FT, ALL, 'CENTROID + time'), flush=True)
print(crb(FC_full + FT, ALL, 'FULLPOIS + time'), flush=True)
print(f"\n# TARGETS: vtx<15cm dir<2deg t0<1ns E<20%", flush=True)

# ---- sensitivity of the FULLPOIS charge-only longitudinal CRB to the two things that could inflate it:
#  (a) the 1/mu floor (ring-edge low-mu PMTs are the most longitudinal-informative; floor caps their weight)
#  (b) the FD step (Jacobian stability).  Quote an honest RANGE, not one optimistic point.
print(f"\n# SENSITIVITY of FULLPOIS charge-only longitudinal CRB (cm):", flush=True)
def fullpois_lon(muf):
    hh = mu > muf; mc = np.clip(mu, muf, None); W = (hh/mc)[:, None]
    F = Jq.T @ (W*Jq); Fb = F[np.ix_(NOT0, NOT0)]
    ev = np.linalg.eigvalsh(Fb)
    if ev[0] <= 1e-9*ev[-1]: return float('nan')
    Cx = np.linalg.inv(Fb)[1:4, 1:4]; return float(np.sqrt(max(d_true@Cx@d_true, 0)))*100
for muf in [2e-2, 1e-2, 5e-3, 2e-3, 1e-3]:
    print(f"#   MUFLOOR={muf:.0e}  lon={fullpois_lon(muf):7.2f}cm   (PMTs used: {(mu>muf).sum()})", flush=True)
