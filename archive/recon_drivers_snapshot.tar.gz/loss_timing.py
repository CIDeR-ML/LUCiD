"""Is the fit RECOMPILING? Time gradone() across steps and across EVENTS. If only call#0 is slow (compile)
and all later calls (incl a NEW event = new oc/ot) are fast+equal, there is NO recompile (good). If a new
event re-triggers a slow call, it IS recompiling. Also reports XLA compile count via jax cache stats if available.
Env: PRED_K PRED_MC NPHOT.  Usage: CUDA_VISIBLE_DEVICES=g PRED_K=8 PRED_MC=16 python loss_timing.py
"""
import os, time
os.environ.setdefault('TTS_NS','2.5');
PRED_K=int(os.environ.get('PRED_K','8')); PRED_MC=int(os.environ.get('PRED_MC','16'))
os.environ['MAXCELL']=str(PRED_MC)
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
NPH=int(os.environ.get('NPHOT','500000')); SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0)); POL,AZ=0.6,0.8
th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])
def sc(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# TIMING PRED_K={PRED_K} PRED_MC={PRED_MC} NPH={NPH}",flush=True)
pred=H.build_predictor(temperature=0.1,K=PRED_K,n_photons=NPH); ND=H.num_detectors(pred)
truth=setup_event_simulator(H.GEOM,n_photons=NPH,temperature=None,K=PRED_K,is_data=False,use_expected_value=False,hit_mode='realistic',
    max_sensors_per_cell=PRED_MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True)
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def loss_one(th9,oc,ot,key):
    lw,ft,fi,tot=pred(sc(th9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-th9[8])[fi]; mu=jnp.maximum(tot,1e-8); muS=jax.lax.stop_gradient(mu)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(mu-oc*jnp.log(mu))+jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
gradone=jax.jit(jax.value_and_grad(loss_one))
def gen(ev):
    c,t=jax.lax.stop_gradient(truth(sc(jnp.asarray(th9)),jax.random.PRNGKey(5000+ev)))
    return jnp.asarray(np.asarray(c)), jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
def tcall(th,oc,ot,k):
    t0=time.time(); v,g=gradone(jnp.asarray(th),oc,ot,jax.random.PRNGKey(k)); g.block_until_ready(); return time.time()-t0
# event 0
oc,ot=gen(0); th=th9.copy()
t_compile=tcall(th,oc,ot,0)
steps=[tcall(th9+0.01*i*np.eye(9)[3],oc,ot,i%4) for i in range(1,8)]
print(f"#  EVENT0: call#0(compile) {t_compile:6.2f}s   next7 steps {np.mean(steps)*1000:6.1f}ms each  (min {min(steps)*1000:.0f} max {max(steps)*1000:.0f})",flush=True)
# event 1 (NEW oc/ot) -- does it recompile?
oc1,ot1=gen(1)
t_new=tcall(th9+0.05*np.eye(9)[3],oc1,ot1,0)
steps1=[tcall(th9+0.01*i*np.eye(9)[3],oc1,ot1,i%4) for i in range(1,5)]
print(f"#  EVENT1(new oc/ot): first call {t_new*1000:6.1f}ms   next steps {np.mean(steps1)*1000:6.1f}ms  => {'RECOMPILE!' if t_new>5*np.mean(steps1) else 'no recompile (cached)'}",flush=True)
print(f"#  jax compile cache size: {jax.jit(loss_one)._cache_size() if hasattr(jax.jit(loss_one),'_cache_size') else 'n/a'}",flush=True)
print(f"# READ: 1 compile at start; every later call (incl new event) is the SAME fast time => no per-step/per-event recompile.",flush=True)
