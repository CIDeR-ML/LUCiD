"""TIME-LIKELIHOOD DEFECT diagnosis. The count-conditioned first-arrival loss has a z/t0 bias even in SIREN
self-consistency (Fisher: SN time-grad t0=+163, z=-569). Is it an ORDER-STATISTIC (n-dependent) defect, or a
per-photon arrival shift? Tests, at derive_truth:
 (1) per-OCCUPANCY-BIN t0-argmin of the TIME loss: if high-n PMTs want a different t0 than low-n -> order-stat bias.
 (2) EMPIRICAL first-arrival (resample truth NRES times) mean per occupancy bin  vs  MODEL predicted first-arrival
     mean (sample the model order statistic). Systematic (model-truth) offset per bin = the defect, localized by n.
Run for SIREN self-consistency (truth_sn) — isolates the loss form from emission.
Env: EVENT NPHP NKEYS NRES.  Usage: CUDA_VISIBLE_DEVICES=0 EVENT=0 python time_bias.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
np.set_printoptions(precision=3, suppress=True, linewidth=170)
MC=int(os.environ['MAXCELL']); K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0))
EV=int(os.environ.get('EVENT','0')); NKEYS=int(os.environ.get('NKEYS','6')); NPHP=int(os.environ.get('NPHP','1500000')); NRES=int(os.environ.get('NRES','40'))
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2])
POL,AZ=0.05,0.8; th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.])  # SIREN vertical track
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# TIME_BIAS SIREN self-consist  NPHP={NPHP} NKEYS={NKEYS} NRES={NRES} pol={np.degrees(POL):.1f}deg",flush=True)
truth=H.build_truth_sim(K=K,n_photons=NPHP); pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
T0=jnp.asarray(th9); trk=sc2(T0)
# (2) EMPIRICAL first-arrival distribution: resample truth NRES times
OC=np.zeros(ND); FA=np.zeros((NRES,ND)); HIT=np.zeros((NRES,ND))
for r in range(NRES):
    c,t=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(9000+r))); c=np.asarray(c); t=np.asarray(t)
    OC+=c; m=c>0; FA[r]=np.where(m,t,np.nan); HIT[r]=m
ocm=OC/NRES                                   # mean occupancy per PMT
emp_fa=np.nanmean(np.where(HIT>0,FA,np.nan),0) # empirical mean first-arrival per PMT (over resamples it was hit)
# one truth realization as the "observed" for the loss-based test
c0,t0_=jax.lax.stop_gradient(truth(trk,jax.random.PRNGKey(9000))); oc=jnp.asarray(np.asarray(c0)); ot=jnp.asarray(np.where(np.asarray(c0)>0,np.asarray(t0_),0.))
ocn=np.asarray(c0)
# MODEL predicted first-arrival: sample the predictor, build per-PMT order-stat mean E[min of n photons ~F]
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def time_loss_t0(dt0):  # time-only loss as a function of a global t0 shift (around truth)
    key=jax.random.PRNGKey(0); lw,ft,fi,tot=pred(sc2(T0.at[8].set(dt0)),key); ww=jnp.exp(jnp.clip(lw,-60,20)); tobs=(ot-dt0)[fi]; mu=jnp.maximum(tot,1e-8)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((mu-Rlo)/mu,1e-12,1.); Shi=jnp.clip((mu-Rhi)/mu,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.)   # per-PMT time loss
# MODEL predicted first-arrival mean per PMT: build F from predictor, draw n_i photons, take min, average
@jax.jit
def model_pred(key): return pred(sc2(T0),key)
lw,ft,fi,tot=[np.asarray(x) for x in model_pred(jax.random.PRNGKey(0))]
ww=np.exp(np.clip(lw,-60,20))
# group photon (ft,ww) by PMT, sample order-stat mean for hit PMTs
print("# building model first-arrival per PMT (order-stat sample)...",flush=True)
mdl_fa=np.full(ND,np.nan); rng=np.random.default_rng(0)
order=np.argsort(fi); fi_s=fi[order]; ft_s=ft[order]; ww_s=ww[order]
bounds=np.searchsorted(fi_s,np.arange(ND+1))
for i in range(ND):
    a,b=bounds[i],bounds[i+1]; ni=int(round(ocn[i]))
    if b<=a or ni<1: continue
    tt=ft_s[a:b]; wt=ww_s[a:b]; p=wt/wt.sum()
    draws=tt[rng.choice(len(tt),size=(min(ni,200),64),p=p)]+rng.normal(0,SIGMA,size=(min(ni,200),64))  # n photons + TTS, 64 trials
    mdl_fa[i]=draws.min(0).mean()
# OCCUPANCY-BINNED comparison
print("#\n# (2) EMPIRICAL vs MODEL first-arrival, by occupancy bin (SIREN self-consistency):",flush=True)
print("#  n-bin    | #PMT |  <occ> | emp_FA  mdl_FA  (mdl-emp)  <- model-minus-truth offset (ns)",flush=True)
bins=[(1,1.5),(1.5,3),(3,6),(6,12),(12,30),(30,1e9)]
for lo,hi in bins:
    m=(ocm>=lo)&(ocm<hi)&np.isfinite(emp_fa)&np.isfinite(mdl_fa)
    if m.sum()<3: continue
    print(f"#  {lo:5.1f}-{hi:<5.0f}| {m.sum():4d} | {ocm[m].mean():6.2f} | {emp_fa[m].mean():7.3f} {mdl_fa[m].mean():7.3f}  {mdl_fa[m].mean()-emp_fa[m].mean():+7.3f}",flush=True)
mall=np.isfinite(emp_fa)&np.isfinite(mdl_fa)&(ocm>=1)
print(f"#  ALL hit  | {mall.sum():4d} | {ocm[mall].mean():6.2f} | {emp_fa[mall].mean():7.3f} {mdl_fa[mall].mean():7.3f}  {mdl_fa[mall].mean()-emp_fa[mall].mean():+7.3f}",flush=True)
# (1) per-occupancy-bin t0-argmin of the time loss
print("#\n# (1) time-loss t0-argmin by occupancy bin (does the preferred t0 depend on n?):",flush=True)
dts=np.linspace(-2.0,2.0,21); LT=np.array([np.asarray(time_loss_t0(float(d))) for d in dts])  # (21, ND)
print("#  n-bin    | #PMT | t0-argmin(ns)",flush=True)
for lo,hi in bins:
    m=(ocn>=lo)&(ocn<hi)
    if m.sum()<3: continue
    prof=LT[:,m].sum(1); print(f"#  {lo:5.1f}-{hi:<5.0f}| {int(m.sum()):4d} | {dts[np.argmin(prof)]:+.2f}",flush=True)
mall2=ocn>=1; print(f"#  ALL hit  | {int(mall2.sum()):4d} | {dts[np.argmin(LT[:,mall2].sum(1))]:+.2f}",flush=True)
print("# DONE",flush=True)
