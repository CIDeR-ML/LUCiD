"""(b) IRREDUCIBLE LONGITUDINAL sigma — Cramer-Rao bound along the flat direction. The loss Hessian at truth is
INDEFINITE (bias curvature); the CRB uses the FISHER information (PSD). Compute at the truth (SIREN self-consistency,
so it is the clean information bound, no emission bias):
  FIM_charge = Jmu^T diag(1/mu) Jmu        (Jmu = d mu/d theta via FD; Poisson charge Fisher, PSD)
  FIM_time   = data-averaged FD Hessian of the time-only NLL   (expected time curvature, clip tiny negatives)
  FIM = FIM_charge [+ FIM_time].  Cov = FIM^-1 (physical units).  Position block -> project on track dir d:
  sigma_long = sqrt(d . Cov_pos . d),  sigma_trans = the perpendicular, sigma_worst = sqrt(max eig Cov_pos).
Reports charge-only and charge+time bounds (does timing tighten the longitudinal?). Vertical track (pol~3deg) so
the longitudinal = z. Env: NPHP NKEYS NDATA POL.  Usage: CUDA_VISIBLE_DEVICES=0 python crb_long.py
"""
import os
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
np.set_printoptions(precision=4, suppress=True, linewidth=170)
MC=int(os.environ['MAXCELL']); K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0))
NKEYS=int(os.environ.get('NKEYS','8')); NPHP=int(os.environ.get('NPHP','1500000')); NDATA=int(os.environ.get('NDATA','6'))
POL=float(os.environ.get('POL','0.05')); AZ=0.8
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); NM=['E','x','y','z','s_t','c_t','s_p','c_p','t0']
th9=np.array([1050.,0,0,0,np.sin(POL),np.cos(POL),np.sin(AZ),np.cos(AZ),0.]); T0=jnp.asarray(th9)
d=np.array([np.sin(POL)*np.cos(AZ),np.sin(POL)*np.sin(AZ),np.cos(POL)])    # track direction
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
print(f"# CRB_LONG  pol={np.degrees(POL):.1f}deg  NPHP={NPHP} NKEYS={NKEYS} NDATA={NDATA}",flush=True)
truth=H.build_truth_sim(K=K,n_photons=NPHP); pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
@jax.jit
def mu_fn(t9,key): return jnp.maximum(pred(sc2(t9),key)[3],1e-8)
def mu_avg(t9): return np.mean([np.asarray(mu_fn(jnp.asarray(t9),jax.random.PRNGKey(s))) for s in range(NKEYS)],0)
# ---- FIM_charge = Jmu^T diag(1/mu) Jmu (FD jacobian, physical units) ----
mu0=mu_avg(th9); J=np.zeros((ND,9))
for j in range(9):
    h=0.4*SCALE9[j]; J[:,j]=(mu_avg(th9+h*np.eye(9)[j])-mu_avg(th9-h*np.eye(9)[j]))/(2*h)
FIM_c=(J/np.sqrt(mu0)[:,None]).T@(J/np.sqrt(mu0)[:,None])
# ---- FIM_time = data-averaged FD Hessian of time-only NLL ----
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def time_nll(t9,oc,ot,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; muS=jax.lax.stop_gradient(jnp.maximum(tot,1e-8))
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.)
    n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return jnp.sum(jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.))
gtime=jax.jit(jax.grad(time_nll)); KEYS=[jax.random.PRNGKey(s) for s in range(NKEYS)]
FIM_t=np.zeros((9,9))
for r in range(NDATA):
    c,t=jax.lax.stop_gradient(truth(sc2(T0),jax.random.PRNGKey(12000+r))); oc=jnp.asarray(np.asarray(c)); ot=jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
    Hf=np.zeros((9,9))
    for j in range(9):
        h=0.4*SCALE9[j]
        gp=np.mean([np.asarray(gtime(jnp.asarray(th9+h*np.eye(9)[j]),oc,ot,k)) for k in KEYS],0)
        gm=np.mean([np.asarray(gtime(jnp.asarray(th9-h*np.eye(9)[j]),oc,ot,k)) for k in KEYS],0)
        Hf[:,j]=(gp-gm)/(2*h)
    FIM_t+=0.5*(Hf+Hf.T)
FIM_t/=NDATA
def report(FIM,name):
    ev=np.linalg.eigvalsh(0.5*(FIM+FIM.T)); evp=np.clip(ev,1e-6*max(ev.max(),1e-9),None)
    Cov=np.linalg.inv(FIM+1e-6*max(np.diag(FIM).max(),1e-9)*np.eye(9))
    Cp=Cov[1:4,1:4]; sl=float(np.sqrt(max(d@Cp@d,0)))
    # transverse: avg of the two perpendicular eigen-directions of Cp orthogonal to d
    evp_,V=np.linalg.eigh(Cp); worst=float(np.sqrt(max(evp_.max(),0)))
    # perpendicular sigma: project out d
    P=np.eye(3)-np.outer(d,d); Cperp=P@Cp@P; tperp=float(np.sqrt(max(np.trace(Cperp)/2,0)))
    print(f"# {name}: FIM eig(min..max)={ev.min():.3g}..{ev.max():.3g}  | sigma_long(along track)={sl*100:.2f}cm  sigma_trans={tperp*100:.2f}cm  sigma_worst-dir={worst*100:.2f}cm",flush=True)
    print(f"#    pos-cov diag sqrt (x,y,z) = {np.sqrt(np.clip(np.diag(Cp),0,None))*100} cm   (track dir d={d})",flush=True)
print(f"# mu_tot={mu0.sum():.0f}  lit PMT={int((mu0>1e-3).sum())}",flush=True)
print("#\n# CRAMER-RAO bounds at truth (SIREN self-consistency = clean information limit):",flush=True)
report(FIM_c,"CHARGE-only      ")
report(FIM_c+FIM_t,"CHARGE+TIME      ")
report(FIM_t+1e-3*np.eye(9),"TIME-only (approx)")
print("# DONE",flush=True)
