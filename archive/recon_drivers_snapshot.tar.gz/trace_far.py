"""DIAGNOSE far-start stuck behavior: run Fisher-GN for MANY iters from several start distances on ONE event,
record the FULL per-iteration trajectory (all params + |g| + loss + vtx/lon/tra residual), save npz for plotting.
Shows whether far starts are NOT-CONVERGED (still descending) or STUCK in a wrong basin (plateaued far from truth).
Env: EVENT NITERS REFRESH OFFS. Usage: CUDA_VISIBLE_DEVICES=0 EVENT=2 python trace_far.py
"""
import os,time
os.environ.setdefault('TTS_NS','2.5'); os.environ.setdefault('MAXCELL','4'); os.environ.setdefault('AMP_DETACH','1'); os.environ.setdefault('OVERLAP_RENORM','1.009')
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
from lucid.sources.event_io import read_photon_data_from_photonsim
ROOT='data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'; NBUF=400_000
MC=4; K=8; SIGMA=2.5; DELTA=1.0; SQ=float(np.sqrt(2.0)); NPHP=500000
EV=int(os.environ.get('EVENT','2')); NITERS=int(os.environ.get('NITERS','400')); REFRESH=int(os.environ.get('REFRESH','8')); LAM=0.01; STEPCLIP=0.5
OFFS=[float(x) for x in os.environ.get('OFFS','0,12.5,25,50').split(',')]; FIDR=12.; FIDZ=12.
SCALE9=np.array([50.,0.2,0.2,0.2,0.02,0.02,0.02,0.02,0.2]); FDH=0.4*SCALE9
def sc2(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=jnp.sqrt(st*st+ct*ct)+1e-12; npp=jnp.sqrt(sp*sp+cp*cp)+1e-12
    return ParticleParams(energy=t[0],position=t[1:4],theta=jnp.arctan2(st/nt,ct/nt),phi=jnp.arctan2(sp/npp,cp/npp),t0=t[8])
def th9dir(t):
    st,ct,sp,cp=t[4],t[5],t[6],t[7]; nt=np.hypot(st,ct); npp=np.hypot(sp,cp); st,ct,sp,cp=st/nt,ct/nt,sp/npp,cp/npp
    return np.array([st*cp,st*sp,ct])
def _rotax(u,deg):
    a=np.radians(deg); ca,sa=np.cos(a),np.sin(a); u=u/np.linalg.norm(u)
    ux=np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]]); return np.eye(3)*ca+sa*ux+(1-ca)*np.outer(u,u)
def rand_tf(raw,ev):
    rng=np.random.default_rng(100003+ev); beta=np.degrees(np.arccos(rng.uniform(-1,1))); al=rng.uniform(0,2*np.pi)
    axis=np.array([-np.sin(al),np.cos(al),0.]); rr=FIDR*np.sqrt(rng.uniform()); ph=rng.uniform(0,2*np.pi)
    sh=np.array([rr*np.cos(ph),rr*np.sin(ph),rng.uniform(-FIDZ,FIDZ)])*100.0
    raw=dict(raw); O=np.asarray(raw['photon_origins']).astype(float); D=np.asarray(raw['photon_directions']).astype(float); R=_rotax(axis,beta); c=O.mean(0)
    raw['photon_origins']=(O-c)@R.T+c+sh; raw['photon_directions']=D@R.T; return raw
def derive_truth(raw):
    P=np.asarray(raw['photon_origins'])/100.0; tt=np.asarray(raw['photon_times']); C=P-P.mean(0)
    _,_,vt=np.linalg.svd(C,full_matrices=False); d=vt[0]; proj=C@d
    if np.corrcoef(proj,tt)[0,1]<0: d=-d
    vtx=P.mean(0)+proj.min()*d; pol=np.arccos(np.clip(d[2],-1,1)); az=np.arctan2(d[1],d[0])
    return np.array([float(raw['energy']),vtx[0],vtx[1],vtx[2],np.sin(pol),np.cos(pol),np.sin(az),np.cos(az),0.]),d
data_sim=setup_event_simulator(H.GEOM,n_photons=NBUF,temperature=None,K=K,is_data=True,hit_mode='realistic',
    max_sensors_per_cell=MC,physics_config=H.PHYS,default_detector_params=True,particle='muon',wavelength_mode=True,apply_smearing=False)
pred=H.build_predictor(temperature=0.1,K=K,n_photons=NPHP); ND=H.num_detectors(pred)
def pad_event(raw):
    n=int(np.asarray(raw['photon_origins']).shape[0])
    def tile(a): a=np.asarray(a); reps=int(np.ceil(NBUF/n)); return jnp.asarray(np.tile(a,(reps,)+(1,)*(a.ndim-1))[:NBUF])
    pd={'photon_origins':tile(raw['photon_origins']),'photon_directions':tile(raw['photon_directions']),
        'photon_times':tile(raw['photon_times']),'N':jnp.asarray(n),'apply_rotation':False,
        'rotation_axis':jnp.array([1.,0.,0.]),'rotation_angle':jnp.array(0.),'apply_translation':False,'translation_vector':jnp.zeros(3)}
    if 'wavelengths' in raw: pd['wavelengths']=tile(raw['wavelengths'])
    return pd,n
def log1mexp(a): a=jnp.minimum(a,-1e-7); return jnp.where(a>-0.6931,jnp.log(-jnp.expm1(a)),jnp.log1p(-jnp.exp(a)))
@jax.jit
def perpmt(t9,oc,ot,key):
    lw,ft,fi,tot=pred(sc2(t9),key); ww=jax.lax.stop_gradient(jnp.exp(jnp.clip(lw,-60,20))); tobs=(ot-t9[8])[fi]; mu=jnp.maximum(tot,1e-8); muS=jax.lax.stop_gradient(mu)
    Rlo=jax.ops.segment_sum(ww*0.5*(1+erf((tobs-DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND); Rhi=jax.ops.segment_sum(ww*0.5*(1+erf((tobs+DELTA/2-ft)/(SIGMA*SQ))),fi,num_segments=ND)
    Slo=jnp.clip((muS-Rlo)/muS,1e-12,1.); Shi=jnp.clip((muS-Rhi)/muS,1e-12,1.); n=jnp.maximum(oc,0.); a=jnp.minimum(n*(jnp.log(Shi)-jnp.log(Slo)),-1e-9)
    return mu, jnp.where(oc>0,-n*jnp.log(Slo)-log1mexp(a),0.)
@jax.jit
def lossf(t9,oc,ot,key): mu,tn=perpmt(t9,oc,ot,key); return jnp.sum(mu-oc*jnp.log(mu))+jnp.sum(tn)
gradf=jax.jit(jax.grad(lossf)); KEYS=[jax.random.PRNGKey(s) for s in range(4)]
def G(th,oc,ot): return np.mean([np.asarray(gradf(jnp.asarray(th),oc,ot,k)) for k in KEYS],0)
def AL(th,oc,ot): return float(np.mean([float(lossf(jnp.asarray(th),oc,ot,k)) for k in KEYS]))
def fisher(th,oc,ot):
    mu0=np.maximum(np.mean([np.asarray(perpmt(jnp.asarray(th),oc,ot,k)[0]) for k in KEYS],0),1e-8); Jm=np.zeros((ND,9)); Jl=np.zeros((ND,9))
    for j in range(9):
        h=FDH[j]; ej=np.eye(9)[j]
        mp,lp=[np.mean([np.asarray(x) for x in xs],0) for xs in zip(*[perpmt(jnp.asarray(th+h*ej),oc,ot,k) for k in KEYS])]
        mm,lm=[np.mean([np.asarray(x) for x in xs],0) for xs in zip(*[perpmt(jnp.asarray(th-h*ej),oc,ot,k) for k in KEYS])]
        Jm[:,j]=(mp-mm)/(2*h); Jl[:,j]=(lp-lm)/(2*h)
    return (Jm/np.sqrt(mu0)[:,None]).T@(Jm/np.sqrt(mu0)[:,None])+Jl.T@Jl
raw=rand_tf(read_photon_data_from_photonsim(ROOT,EV),EV); th9,d=derive_truth(raw); pd,_=pad_event(raw); T0=jnp.asarray(th9)
c,t=jax.lax.stop_gradient(data_sim(sc2(T0),jax.random.PRNGKey(7000+EV),pd)); oc=jnp.asarray(np.asarray(c)); ot=jnp.asarray(np.where(np.asarray(c)>0,np.asarray(t),0.))
print(f"# TRACE_FAR ev{EV} offs={OFFS} NITERS={NITERS}",flush=True)
trajs={}
for off in OFFS:
    th=th9+off*SCALE9*np.eye(9)[3]; F=None; rec=[]
    for it in range(NITERS):
        g=G(th,oc,ot)
        if F is None or it%REFRESH==0: F=fisher(th,oc,ot)
        lam=LAM*np.diag(F); dth=np.clip(-np.linalg.solve(F+np.diag(lam)+1e-9*np.eye(9),g),-STEPCLIP*SCALE9,STEPCLIP*SCALE9); th=th+dth
        dl=th-th9; dv=np.sqrt((dl[1:4]**2).sum()); lon=abs(np.dot(dl[1:4],d)); tra=np.sqrt(max(dv**2-lon**2,0))
        gn=float(np.linalg.norm(g*SCALE9)); dang=float(np.degrees(np.arccos(np.clip(np.dot(th9dir(th),d),-1,1))))
        if it%4==0 or it==NITERS-1: rec.append([it,gn,AL(th,oc,ot),dv*100,lon*100,tra*100,dl[0],dang,dl[8]])
    trajs[f'off{off}']=np.array(rec); print(f"#  off {off}: final |g|={rec[-1][1]:.1f} vtx={rec[-1][3]:.1f}cm (lon{rec[-1][4]:.0f}/tra{rec[-1][5]:.0f}) loss={rec[-1][2]:.0f}",flush=True)
np.savez(f"/tmp/trace_ev{EV}.npz", **trajs, truthloss=AL(th9,oc,ot)); print("# DONE",flush=True)
