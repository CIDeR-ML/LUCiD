"""IS THE SOFT-OVERLAP PREDICTOR THE REGRESSION? The truth sim uses HARD overlap (temperature=None: each
photon -> one PMT). The predictor I used everywhere is SOFT (temperature=0.1: each photon's charge spread
to neighbors by a Gaussian) -> a blurrier ring than the hard truth = a systematic SOFT-vs-HARD pattern
mismatch. Soft was needed for gradients, but the charge longitudinal is a LINE-SEARCH (no gradient) and the
prior good fits used grid/line search -> could use the matched HARD overlap.

Test: charge longitudinal argmin bias/scatter over N PhotonSim events with the predictor at HARD (temp=None,
matches truth) vs SOFT (temp=0.1, 0.05). If HARD is much better -> that is how it got worse.
Env: NPHOT NKG NKT NEV.  Usage: CUDA_VISIBLE_DEVICES=g python test_overlap.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
from lucid.sources.event_io import read_photon_data_from_photonsim
from lucid.simulation.simulator import setup_event_simulator
from lucid.geometry import generate_detector
np.set_printoptions(precision=3, suppress=True, linewidth=160)

NPHOT = int(os.environ.get('NPHOT', '100000')); NKG = int(os.environ.get('NKG', '3'))
NKT = int(os.environ.get('NKT', '4')); NEV = int(os.environ.get('NEV', '20'))
K = int(os.environ.get('RECON_K', '8')); MC = int(os.environ.get('MAXCELL', '16'))
ROOT = 'data/water/muon/muon_gun_1050_MeV_100_events_fixed_energy.root'
TGT_POL = 0.6; TGT_AZ = 0.8; ts = np.array([1050.0, 0, 0, 0, TGT_POL, TGT_AZ, 0.0])

def _rod(v, ax, an):
    ax = ax/(np.linalg.norm(ax)+1e-12); return v*np.cos(an)+np.cross(ax, v)*np.sin(an)+ax*(ax@v)*(1-np.cos(an))
def photon_data_for(ev):
    raw = read_photon_data_from_photonsim(ROOT, ev); n = int(raw['photon_origins'].shape[0])
    P = np.array(raw['photon_origins'])/100.0; _, _, vt = np.linalg.svd(P-P.mean(0), full_matrices=False); d0 = vt[0]
    if d0[2] < 0: d0 = -d0
    vtx0 = P.mean(0)+((P-P.mean(0))@d0).min()*d0
    dt = np.array([np.sin(TGT_POL)*np.cos(TGT_AZ), np.sin(TGT_POL)*np.sin(TGT_AZ), np.cos(TGT_POL)])
    ax = np.cross(d0, dt); an = 0.0 if np.linalg.norm(ax) < 1e-7 else float(np.arccos(np.clip(d0@dt, -1, 1)))
    if np.linalg.norm(ax) < 1e-7: ax = np.array([1.0, 0, 0])
    pd = {'photon_origins': raw['photon_origins'], 'photon_directions': raw['photon_directions'],
          'photon_times': raw['photon_times'], 'N': n, 'apply_rotation': True,
          'rotation_axis': jnp.array(ax/(np.linalg.norm(ax)+1e-12)), 'rotation_angle': jnp.array(an),
          'apply_translation': True, 'translation_vector': jnp.array(-_rod(vtx0, ax, an))}
    if 'wavelengths' in raw: pd['wavelengths'] = raw['wavelengths']
    return pd

det = generate_detector(H.GEOM); DP = np.array(det.all_points)
def dvec(p, a): return np.array([np.sin(p)*np.cos(a), np.sin(p)*np.sin(a), np.cos(p)])
d_true = dvec(ts[4], ts[5]); dummy = H.theta_to_track(jnp.array(ts))
lam = np.unique(np.concatenate([np.arange(-1.2, 1.201, 0.04), np.arange(-0.1, 0.1001, 0.01)]))

# truth = HARD overlap (temperature=None), as in recon_ps_setup
data_sim = setup_event_simulator(H.GEOM, n_photons=NPHOT, temperature=None, K=K, is_data=True, hit_mode='realistic',
    max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon',
    wavelength_mode=True, apply_smearing=False)
ND = H.num_detectors(data_sim)
# observed charges per event (shared across predictor settings)
QS = []
for ev in range(NEV):
    pd = photon_data_for(ev)
    QS.append(np.mean([np.array(jax.lax.stop_gradient(data_sim(dummy, jax.random.PRNGKey(7*ev+j), pd))[0]) for j in range(NKT)], 0))
print(f"# TEST-OVERLAP NEV={NEV} NPHOT={NPHOT}  truth=HARD overlap (temp=None)  {len(lam)} lon pts", flush=True)

def argmin_cm(curve):
    j = int(np.argmin(curve)); lo = max(0, j-2); hi = min(len(lam), j+3); a, b, _ = np.polyfit(lam[lo:hi], curve[lo:hi], 2)
    return (-b/(2*a) if a > 0 else lam[j])*100

def lon_scatter(temp):
    pred = H.build_predictor(temperature=temp, K=K, n_photons=NPHOT)
    qof = jax.jit(lambda th, key: pred(H.theta_to_track(th), key)[3])
    MU = np.clip(np.stack([np.mean([np.array(qof(jnp.array(ts+np.array([0, d_true[0]*l, d_true[1]*l, d_true[2]*l, 0, 0, 0])), jax.random.PRNGKey(1000+13*k))) for k in range(NKG)], 0) for l in lam]), 1e-8, None)
    am = []
    for ev in range(NEV):
        Q = QS[ev]; am.append(argmin_cm(np.array([np.sum(MU[i]-Q*np.log(MU[i])) for i in range(len(lam))])))
    a = np.array(am); return a, a.mean(), a.std()

print(f"# charge longitudinal argmin over events, predictor overlap HARD vs SOFT:", flush=True)
for tag, temp in [('HARD(None)', None), ('SOFT0.05', 0.05), ('SOFT0.10', 0.10)]:
    a, b, s = lon_scatter(temp)
    print(f"#   predictor {tag:11s}  bias {b:+6.1f}  scatter {s:5.1f}  RMS {np.sqrt(b**2+s**2):5.1f} cm", flush=True)
print(f"# if HARD << SOFT -> the soft-overlap (used for gradients) mismatches the hard truth = how it got worse.", flush=True)
