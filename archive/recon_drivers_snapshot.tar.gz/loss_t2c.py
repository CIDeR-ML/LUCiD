"""TIER 2c — mechanism confirmation: does the low-occupancy late time-bias GROW WITH K?
Mechanism hypothesis: implicit-capture (expected) engine deposits weight at EVERY bounce incl late ones;
a sampled photon is consumed at first detection. => more bounces (higher K) = more late deposits = larger
model-late bias. Sweep K in {6,8,12} (>=6 always); build expected predictor (temp=None) + sample truth at
each K; report dt = <t>model - <t>sample for the LOW-occupancy bucket (where the effect is largest) and the
global median. If dt(low-occ) rises with K => multi-bounce late deposit confirmed.
Env: NPHOT NREAL.  Usage: CUDA_VISIBLE_DEVICES=g python loss_t2c.py
"""
import os
os.environ.setdefault('TTS_NS', '2.5'); os.environ['MAXCELL'] = '16'
import jax, jax.numpy as jnp, numpy as np
from jax.scipy.special import erf
import recon_harness as H
from lucid.detector_params import ParticleParams
from lucid.simulation.simulator import setup_event_simulator
np.set_printoptions(precision=3, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '500000')); NREAL = int(os.environ.get('NREAL', '40'))
MC = 16; SIGMA = 2.5; SQ = float(np.sqrt(2.0))
POL, AZ = 0.6, 0.8
th9_true = np.array([1050.0, 0, 0, 0, np.sin(POL), np.cos(POL), np.sin(AZ), np.cos(AZ), 0.0])
def sc2track(th9):
    st, ct = th9[4], th9[5]; sp, cp = th9[6], th9[7]
    nt = jnp.sqrt(st * st + ct * ct) + 1e-12; npp = jnp.sqrt(sp * sp + cp * cp) + 1e-12
    st, ct, sp, cp = st / nt, ct / nt, sp / npp, cp / npp
    return ParticleParams(energy=th9[0], position=th9[1:4], theta=jnp.arctan2(st, ct), phi=jnp.arctan2(sp, cp), t0=th9[8])
trk = sc2track(jnp.asarray(th9_true))
print(f"# T2c K-sweep mechanism  NPH={NPH} NREAL={NREAL}", flush=True)

def model_first_arrival(log_w, ft, fi, nd):
    w = jnp.exp(jnp.clip(log_w, -60, 20))
    tg = jnp.asarray(np.linspace(float(np.nanpercentile(np.asarray(ft), 0.05)) - 15, float(np.nanpercentile(np.asarray(ft), 99.95)) + 40, 800))
    Rg = jax.lax.map(lambda t: jax.ops.segment_sum(w * 0.5 * (1.0 + erf((t - ft) / (SIGMA * SQ))), fi, num_segments=nd), tg)
    S = jnp.exp(-Rg); f = jnp.clip(-jnp.gradient(S, axis=0), 0.0, None); Z = jnp.sum(f, axis=0)
    return np.asarray(jnp.where(Z > 1e-6, jnp.sum(tg[:, None] * f, axis=0) / jnp.maximum(Z, 1e-6), jnp.nan))

print(f"#   K | total mu(pred/samp) | dt_lowocc(0.05-0.2) | dt_mid(0.5-2) | GLOBAL median  (ns, model-sample)", flush=True)
for K in [6, 8, 12]:
    pred = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=True,
        hit_mode='per_photon', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True,
        particle='muon', wavelength_mode=True, pos_grad_threshold=K, n_grad_iters=K)
    truth = setup_event_simulator(H.GEOM, n_photons=NPH, temperature=None, K=K, is_data=False, use_expected_value=False,
        hit_mode='realistic', max_sensors_per_cell=MC, physics_config=H.PHYS, default_detector_params=True, particle='muon', wavelength_mode=True)
    ND = H.num_detectors(pred)
    lw, ft, fi, tot = [a for a in jax.lax.stop_gradient(pred(trk, jax.random.PRNGKey(0)))]
    mu = np.asarray(tot); tm = model_first_arrival(lw, ft, fi, ND)
    sc = np.zeros((NREAL, ND)); st_ = np.full((NREAL, ND), np.nan)
    for r in range(NREAL):
        c, t = jax.lax.stop_gradient(truth(trk, jax.random.PRNGKey(1000 + r)))
        c = np.asarray(c); sc[r] = c; st_[r] = np.where(c > 0, np.asarray(t), np.nan)
    stm = np.nanmean(st_, 0); dt = tm - stm
    low = np.where((mu > 0.05) & (mu <= 0.2))[0]; mid = np.where((mu > 0.5) & (mu <= 2.0))[0]
    g = np.nanmedian(dt[mu > 1e-6])
    print(f"#  {K:2d} | {mu.sum():.0f}/{sc.mean(0).sum():.0f} | {np.nanmean(dt[low]):+8.3f} ({low.size}) | {np.nanmean(dt[mid]):+7.3f} | {g:+7.3f}", flush=True)
print(f"# READ: dt_lowocc rising with K => implicit-capture multi-bounce LATE deposit confirmed as the source.", flush=True)
