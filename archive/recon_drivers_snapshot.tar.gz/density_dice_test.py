"""Validate the "density x DiCE score" sampler against the DENSITY-WEIGHTED forward.

Reuses the sample_methods.py setup (SIREN density over the (angle,distance) grid).

THE OBSERVABLE TO PRESERVE (the OLD scheme, method A):
    sample bins i  ~ d (detached selection: argsort/categorical, geometry sg)
    weight each photon by w_i = d_i (the density again)
    forward O_A = sum_i d_i g_i / sum_i d_i      (self-normalized)
In expectation over idx ~ d/sum(d):
    numerator   -> (1/Sd) sum_x d_x^2 g_x
    denominator -> (1/Sd) sum_x d_x^2
  => O_A  ->  O_biased(E) = sum_x d^2 g / sum_x d^2     <-- DENSITY-WEIGHTED ground truth
The old AD gradient detaches the selection, so it is BIASED. The correct gradient of
O_biased is  d/dE [ sum d^2 g / sum d^2 ]  (state below). The whole point of density x DiCE
is to PRESERVE O_biased as the forward AND recover its EXACT gradient.

Also test the UN-normalized variant  sum_i d_i g_i  (no /sum_i d_i): its ground truth is
the un-normalized numerator  N_biased(E) = sum_x d^2 g  (times Nphot/Sd; see below).
"""
import os, time, jax, jax.numpy as jnp, numpy as np
from lucid.siren.training.inference import SIRENPredictor
from lucid.siren.core import create_photonsim_siren_grid
from lucid.sources.siren_rays import normalize_inputs_jit, denormalize_log_predictions
from lucid.siren.core import SIREN
from lucid.utils import unpack_photonsim_params
np.set_printoptions(precision=6, suppress=True)

pp = unpack_photonsim_params('muon', 'water')
predictor = SIRENPredictor(pp['siren_model_path'])
td = create_photonsim_siren_grid(predictor)
mparams = predictor.params
(n_bins, e_min, e_max, a_min, a_max, d_min, d_max, a_bins, d_bins,
 angle_dist_grid, angle_mesh, distance_mesh, log_min, log_max) = td
ADG = jnp.asarray(angle_dist_grid)
n_grid = ADG.shape[0]
ang_grid = ADG[:, 0]; dist_grid = ADG[:, 1]
_model = SIREN(hidden_features=256, hidden_layers=3, out_features=1)

@jax.jit
def density_grid(E):
    grid = jnp.stack([jnp.full((n_grid,), E), ang_grid, dist_grid], axis=1)
    ng = normalize_inputs_jit(grid, e_min, e_max, a_min, a_max, d_min, d_max)
    w, _ = _model.apply(mparams, ng)
    dens = denormalize_log_predictions(jnp.squeeze(w), log_max, log_min)
    return jnp.clip(dens, 1e-12, None)

L_ABS_MM = 4000.0
g_grid = jnp.exp(-dist_grid / L_ABS_MM)

E0 = jnp.array(1050.0); NPHOT = 20000
sg = jax.lax.stop_gradient

# ---------------------------------------------------------------------------
# GROUND TRUTHS (all fully differentiable, no sampling)
# ---------------------------------------------------------------------------
def O_unbiased(E):                       # what sample_methods called the "ground truth"
    d = density_grid(E); return jnp.sum(d * g_grid) / jnp.sum(d)

def O_biased(E):                         # the DENSITY-WEIGHTED forward the OLD scheme computes
    d = density_grid(E); return jnp.sum(d * d * g_grid) / jnp.sum(d * d)

# un-normalized old forward sum_i d_i g_i, with idx ~ d/Sd, has expectation
#   E[ sum_i d_i g_i ] = NPHOT * E_{x~d/Sd}[ d_x g_x ] = NPHOT * sum_x d_x^2 g_x / Sd
def N_biased(E):
    d = density_grid(E); return NPHOT * jnp.sum(d * d * g_grid) / jnp.sum(d)

# The OLD scheme's EXACT estimand: sample i ~ Uniform(top-num_seeds density bins), weight=d.
# Self-normalized -> O_topk(E) = sum_{x in topk} d_x g_x / sum_{x in topk} d_x.
# top-k MEMBERSHIP is a non-differentiable boundary; AD of this (with membership detached)
# is what the old scheme can at best capture. We compute its true (membership-frozen) grad.
pp_seeds = unpack_photonsim_params('muon', 'water')['num_seeds']
NUM_SEEDS = int(pp_seeds[0] * (float(E0) ** pp_seeds[1]) + pp_seeds[2])
_dens0 = density_grid(E0)
_topk_idx = jnp.argsort(-_dens0)[:NUM_SEEDS]                  # frozen membership at E0
def O_topk(E):
    d = density_grid(E); dk = d[_topk_idx]; gk = g_grid[_topk_idx]
    return jnp.sum(dk * gk) / jnp.sum(dk)
truth_topk_O = float(O_topk(E0)); truth_topk_G = float(jax.grad(O_topk)(E0))
print(f"OLD top-k estimand:      O={truth_topk_O:.6f}  dO/dE={truth_topk_G:.6e}  "
      f"(num_seeds={NUM_SEEDS}, membership frozen)", flush=True)

truth_unb_O = float(O_unbiased(E0)); truth_unb_G = float(jax.grad(O_unbiased)(E0))
truth_O = float(O_biased(E0));  truth_G = float(jax.grad(O_biased)(E0))
truth_N = float(N_biased(E0));  truth_NG = float(jax.grad(N_biased)(E0))

print(f"n_grid={n_grid}  Nphot={NPHOT}  E0={float(E0)}", flush=True)
print(f"UNBIASED  E_p[g]:        O={truth_unb_O:.6f}  dO/dE={truth_unb_G:.6e}", flush=True)
print(f"BIASED (density-wtd):    O={truth_O:.6f}  dO/dE={truth_G:.6e}   <-- forward to preserve", flush=True)
print(f"BIASED un-normalized N:  N={truth_N:.4f}  dN/dE={truth_NG:.6e}\n", flush=True)

# ---------------------------------------------------------------------------
# METHODS
# ---------------------------------------------------------------------------
@jax.jit
def method_A_old(E, key):                 # the OLD scheme: detached selection, weight=d
    d = density_grid(E); p = sg(d) / jnp.sum(sg(d))
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=p)
    w = d[idx]
    return jnp.sum(w * g_grid[idx]) / jnp.sum(w)

@jax.jit
def method_DD_norm(E, key):               # density x DiCE, SELF-NORMALIZED  (preserve O_biased)
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))     # DiCE box, =1 forward
    w = d[idx] * score                                            # weight = density x dice
    return jnp.sum(w * g_grid[idx]) / jnp.sum(w)

@jax.jit
def method_DD_unnorm(E, key):             # density x DiCE, UN-NORMALIZED sum_i d_i g_i
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))
    w = d[idx] * score
    return jnp.sum(w * g_grid[idx])

@jax.jit
def method_C_pure_dice(E, key):           # reference: pure DiCE (unbiased E_p[g]); weight=1
    d = density_grid(E); p = d / jnp.sum(d)
    idx = jax.random.choice(key, n_grid, (NPHOT,), p=sg(p))
    logp = jnp.log(p[idx]); score = jnp.exp(logp - sg(logp))
    return jnp.mean(g_grid[idx] * score)

# ---------------------------------------------------------------------------
# MEASURE
# ---------------------------------------------------------------------------
NK = 64
keys = jax.random.split(jax.random.PRNGKey(0), NK)

def measure(name, fn, ref_O, ref_G):
    gfn = jax.jit(jax.grad(fn))
    t0 = time.time(); _ = float(fn(E0, keys[0])); _ = float(gfn(E0, keys[0])); tc = time.time() - t0
    t0 = time.time()
    Os = np.array([float(fn(E0, k)) for k in keys])
    Gs = np.array([float(gfn(E0, k)) for k in keys])
    tr = (time.time() - t0) / (2 * NK) * 1000
    relO = Os.mean() / (ref_O + 1e-30)
    relG = Gs.mean() / (ref_G + 1e-30)
    print(f"{name:>20} | O={Os.mean():>11.5f} (vs ref {ref_O:>10.5f}, {relO:.3f}x) | "
          f"dO/dE={Gs.mean():>11.4e} (truth {ref_G:>11.4e}, {relG:.3f}x) | "
          f"gstd={Gs.std():.3e} | comp={tc:5.1f}s run={tr:5.2f}ms", flush=True)
    return Os, Gs

print("--- SELF-NORMALIZED observable (forward should match BIASED density-weighted) ---", flush=True)
measure("A old (detached)", method_A_old, truth_O, truth_G)
measure("DD norm (NEW)",   method_DD_norm, truth_O, truth_G)
print("\n--- UN-NORMALIZED observable sum_i d_i g_i (ground truth N_biased) ---", flush=True)
measure("DD un-norm (NEW)", method_DD_unnorm, truth_N, truth_NG)
print("\n--- reference: pure DiCE (unbiased E_p[g]) ---", flush=True)
measure("C pure DiCE", method_C_pure_dice, truth_unb_O, truth_unb_G)
