"""LOSS DECOMP — localize the AD-vs-true-slope mismatch by K (bounce) and loss term.

For params {y,z,energy,polar,azim}: AD directional derivative vs clean noise-averaged profile slope,
under K in {1,8} (first-bounce vs multi-bounce) and term in {charge-only, full}. SMOOTH params report
AD/profile ratio; KINKY angles report multi-scale profile slopes (consistency = smooth).

If the y/z/energy underestimate appears only at K=8 -> multi-bounce gradient detachments (reflection-normal
sg / survival). If already at K=1 -> first-bounce (free-path sg / overlap STE). If only in 'full' not
'charge' -> the time term. Evaluated at theta0 = theta_true + delta (non-trivial gradient).
Env: NPHOT NKEYS.  Usage: CUDA_VISIBLE_DEVICES=g python loss_decomp.py
"""
import os, jax, jax.numpy as jnp, numpy as np
import recon_harness as H
np.set_printoptions(precision=4, suppress=True, linewidth=160)
NPH = int(os.environ.get('NPHOT', '50000')); NKEYS = int(os.environ.get('NKEYS', '48'))
PN = H.PARAM_NAMES; PS = np.asarray(H.PARAM_SCALE)
theta_true = np.array([1050.0, 0, 0, 0, 0.6, 0.8, 0.0]); delta = np.array([50.0, 0.10, 0.0, 0.0, 0.0175, 0.0, 0.5])
theta0 = theta_true + delta
PARAMS = [('y', 2), ('z', 3), ('energy', 0), ('polar', 4), ('azim', 5)]
keys = [jax.random.PRNGKey(s) for s in range(NKEYS)]
print(f"# LOSS DECOMP  NPH={NPH} NKEYS={NKEYS}  eval@theta0  (AD vs clean profile slope)", flush=True)

def profile_slopes(lossj, i):
    sv = np.linspace(-6 * PS[i], 6 * PS[i], 25); j0 = 12; dg = sv[1] - sv[0]
    prof = np.array([np.mean([float(lossj(jnp.asarray(theta0 + s * np.eye(7)[i]), k)) for k in keys]) for s in sv])
    return {w: (prof[j0 + w] - prof[j0 - w]) / (2 * w * dg) for w in [1, 2, 4]}

for Kval in [1, 8]:
    pred = H.build_predictor(temperature=0.1, K=Kval, n_photons=NPH)
    tsim = H.build_truth_sim(K=Kval, n_photons=NPH); ND = H.num_detectors(pred)
    oc, ot, hit = H.gen_truth(tsim, jnp.asarray(theta_true), jax.random.PRNGKey(777))
    for wt, tag in [(0.0, 'charge'), (1.0, 'full')]:
        loss = H.make_loss(pred, oc, ot, hit, ND, tau_time=1.5, w_charge=1.0, w_time=wt)
        lossj = jax.jit(loss); gradj = jax.jit(jax.grad(loss))
        gAD = np.stack([np.asarray(gradj(jnp.asarray(theta0), k)) for k in keys]).mean(0)
        print(f"\n# === K={Kval}  term={tag} ===", flush=True)
        for nm, i in PARAMS:
            sl = profile_slopes(lossj, i); ad = gAD[i]
            kinky = (np.sign(sl[1]) != np.sign(sl[2])) or (np.sign(sl[2]) != np.sign(sl[4]))
            if kinky:
                print(f"#   {nm:6s} AD {ad:+10.2f} | profile slopes w1/2/4 {sl[1]:+10.1f} {sl[2]:+10.1f} {sl[4]:+10.1f}  KINKY", flush=True)
            else:
                print(f"#   {nm:6s} AD {ad:+10.2f} | profile slope(w2) {sl[2]:+10.1f}  AD/prof {ad/(sl[2]+1e-30):+6.3f}", flush=True)
print(f"\n# READ: y/z/energy ratio ~1 at K1 but <1 at K8 => multi-bounce detach; <1 already at K1 => first-bounce.", flush=True)
print(f"#       angles KINKY persists/clears with K => bounce-driven or first-bounce overlap discreteness.", flush=True)
